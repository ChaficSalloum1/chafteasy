package com.krat.kratEasyApp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
