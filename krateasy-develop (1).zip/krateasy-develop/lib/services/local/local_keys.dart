class LocalKeys {
  LocalKeys._();

  static final LocalKeys _instance = LocalKeys._();

  static LocalKeys get instance => _instance;

  final String accessToken = "token";
  final String language = "language";
  final String fcmToken = "fcmToken";
  final String deviceType = "deviceType";
  final String isLoggedIn = "isLoggedIn";

  final String mobileNumber = "mobileNumber";
  final String countryCode = "countryCode";
  final String currentLocation = "currentLocation";
  final String userName = "userName";
  final String userImage = "userImage";
  final String userId = "userId";
  final String parentPassword = "parentPassword";
  final String rememberMeStudent = "rememberMeStudent";
  final String rememberMeParent = "rememberMeParent";
  final String currentRoute = "currentRoute";
  final String isNotification = "isNotification";
  final String sportList = "sportList";

  final String userRole = "userRole";
}
