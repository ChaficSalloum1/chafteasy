import 'dart:developer';
import 'package:shared_preferences/shared_preferences.dart';

class LocalService {
  static final LocalService _instance = LocalService._internal();

  static LocalService get instance => _instance;

  LocalService._internal();

  SharedPreferences? _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  Future<void> setData(String key, dynamic value) async {
    if (_prefs == null) {
      log("Error saving null $key :: $value");
      return;
    }
    if (value is String) {
      log("storing $key  :: $value");
      await _prefs!.setString(key, value);
    } else if (value is int) {
      await _prefs!.setInt(key, value);
    } else if (value is bool) {
      await _prefs!.setBool(key, value);
    } else if (value is double) {
      await _prefs!.setDouble(key, value);
    } else if (value is List<String>) {
      await _prefs!.setStringList(key, value);
    } else {
      log("undefine saving $key :: $value");
    }
  }

  dynamic getData(String key) {
    if (_prefs == null) return null;
    return _prefs!.get(key);
  }

  Future<void> deleteData(String key) async {
    if (_prefs == null) return;
    await _prefs!.remove(key);
  }

  Future<void> clearAllData() async {
    if (_prefs == null) return;
    await _prefs!.clear();
  }
}
