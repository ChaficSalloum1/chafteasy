class ApiEnds {
  ApiEnds._();

  static ApiEnds instance = ApiEnds._();

  final imageBaseUrl =
      "https://api-ap-south-mum-1.openstack.acecloudhosting.com:8080/invent-colab-obj-bucket/";


  ///-----Auth Apis -----
  final editMyAccount = "app/auth/edit-account";
  final myAccount = "app/auth/profile";
  final sportsList = "common/sport-list";
  final deleteAccount = "app/auth/delete-account";
  final notificationOnOff = "app/notification/turn-on-off";
  final uploadImage = "common/file-upload";
  final notification = "app/notification/list";
  final readNotification = "app/notification/read";
  final unReadNotification = "app/notification/unread";
  final deleteNotification = "app/notification/delete";
  final favouriteCourt = "app/booking/favorite/court";
  // final favouriteCourt = "app/court/favorite-list";
  // final favouritePlayer = "app/booking/favorite/friend";
  // final favouritePlayer = "app/booking/favorite-players";
  final availableChallenge = "app/challenges/available-public-challenges";
  final availableCourtChallenge = "app/court/available-list";
  final facilities = "app/facility/list";
  final filterFacilities = "app/facility/filter-list";
  final myBooking = "app/booking/my-booking";
  final cancelBooking = "app/booking/cancel-upcoming-booking";
  final cancelChallenge = "app/challenges/cancel-challenge";
  final getSlots = "app/court/available-slots";
  // final getChallenges = "app/challenges/available-public-challenges";
  final createChallenge = "app/challenges/create-challenge";
  final getHomeData = "app/home/booking-list";
  final getBookingDetails = "app/booking/detail";
  final getchallengeBookingDetails = "app/booking/detail/challenge";
  final friendpayment = "app/booking/payment-friend";
  final getcourtBookingDetails = "app/booking/detail/booking";
  final getCourtDetails = "app/court/detail";
  final getChallengesDetails = "app/challenges/challenges-detail";
  final joinChallenges = "app/challenges/join-challenge";
  final typeChallenge = "app/challenges/my-challanges";
  final shareFacility = "app/facility/share";
  final addFavouriteCourt = "app/booking/favorite/court";
  final favouritePlayer = "app/booking/favorite/friend";
  final rateBooking = "app/Booking/rate";
  final modifyBookingDetail = "app/booking/modify/";
  final modifyBookingApiEndPoint="app/Booking/update-booking/";
}
