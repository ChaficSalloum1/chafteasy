class ResponseHelper {
  dynamic body;
  bool? status;
  String? message;
  String? token;
  ResponseHelper(this.body, this.message, this.token, this.status);
}


class ResponseHelper2 {
  dynamic body;
dynamic status;
  String? message;
  String? token;
  ResponseHelper2(this.body, this.message, this.token, this.status);
}