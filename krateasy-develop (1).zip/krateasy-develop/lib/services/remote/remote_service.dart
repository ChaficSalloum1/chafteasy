import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import 'package:http/http.dart';
import 'package:kratEasyApp/services/local/local_keys.dart';
import 'package:kratEasyApp/services/local/local_service.dart';
import 'package:kratEasyApp/services/remote/responce_helper.dart';
import 'api_ends.dart';

class RemoteService {
  String baseUrl = "https://backend.krateasy.gr/api/";

  Map<String, String> headers = {"Content-Type": "application/json"};

  RemoteService() {
    baseUrl = dotenv.get("baseUrl");
  }

  Future<bool> checkInternet() async {
    try {
      final response = await http.get(Uri.parse("https://www.google.com"));
      if (response.statusCode == 200) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      return false;
    }
  }

  Future<ResponseHelper> post(
      {required String url,
      required dynamic body,
      bool isSuccessMessage = false,
      bool isErrorMessage = true,
      bool returnData = false}) async {
    final isInternet = await checkInternet();

    if (!isInternet) {
      return ResponseHelper(body, "No internet", "", checkStatus(303));
    } else {
      log("METHOD -: POST, REQUEST URL -: $baseUrl$url,");
      log("JSON REQUEST -: ${body is String ? body : getPrettyJSONString(body)}");
      log("HEADERS -: $headers");

      final token =
          LocalService.instance.getData(LocalKeys.instance.accessToken);
      if (token?.isNotEmpty == true) {
        headers['Authorization'] = 'Bearer $token';
        log("AUTH TOKEN -: $token");
      }
      try {
        final Response response = await http.post(Uri.parse("$baseUrl$url"),
            body: jsonEncode(body), headers: headers);
        return validateResponse(response, isSuccessMessage, isErrorMessage,
            returnData: returnData);
      } catch (err) {
        log("error ====> $err");
        return ResponseHelper(body, "$err", "", checkStatus(302));
      }
    }
  }

  Future<ResponseHelper2> post2(
      {required String url,
      required dynamic body,
      bool isSuccessMessage = false,
      bool isErrorMessage = true,
      bool returnData = false}) async {
    final isInternet = await checkInternet();

    if (!isInternet) {
      return ResponseHelper2(body, "No internet", "", checkStatus(303));
    } else {
      log("METHOD -: POST, REQUEST URL -: $baseUrl$url,");
      log("JSON REQUEST -: ${body is String ? body : getPrettyJSONString(body)}");
      log("HEADERS -: $headers");

      final token =
          LocalService.instance.getData(LocalKeys.instance.accessToken);
      if (token?.isNotEmpty == true) {
        headers['Authorization'] = 'Bearer $token';
        log("AUTH TOKEN -: $token");
      }
      try {
        final Response response = await http.post(Uri.parse("$baseUrl$url"),
            body: jsonEncode(body), headers: headers);
        return validateResponse2(response, isSuccessMessage, isErrorMessage,
            returnData: returnData);
      } catch (err) {
        log("error ====> $err");
        return ResponseHelper2(body, "$err", "", checkStatus(302));
      }
    }
  }

  Future<ResponseHelper> put(
      {required String url,
      dynamic body,
      bool isSuccessMessage = false,
      bool isErrorMessage = true}) async {
    final isInternet = await checkInternet();
    log("METHOD -: PUT, REQUEST URL -: $baseUrl$url,");
    log("JSON REQUEST -: ${getPrettyJSONString(body)}");
    log("HEADERS -: $headers");

    if (!isInternet) {
      return ResponseHelper(body, "No internet", "", checkStatus(303));
    } else {
      final token =
          LocalService.instance.getData(LocalKeys.instance.accessToken);
      if (token?.isNotEmpty == true) {
        headers['Authorization'] = 'Bearer $token';
        log("AUTH TOKEN -: $token");
      }

      try {
        final Response response = await http.put(Uri.parse("$baseUrl$url"),
            body: jsonEncode(body ?? {}), headers: headers);
        return validateResponse(response, isSuccessMessage, isErrorMessage);
      } catch (err) {
        return ResponseHelper(body, "$err", "", checkStatus(302));
      }
    }
  }

  Future<ResponseHelper> get({
    required String url,
    bool isSuccessMessage = false,
    bool isErrorMessage = true,
    bool returnData = false,
    Map<String, dynamic>? queryParams,
  }) async {
    print('GET() start');
    final isInternet = await checkInternet();
    log("METHOD: GET");

    // Build a robust absolute URI (avoids double slashes and supports relative paths)
    final base = Uri.parse(baseUrl);
    final path = url.startsWith('/') ? url.substring(1) : url;

    // Filter and stringify query params (skip nulls; JSON-encode complex values)
    Map<String, String>? qp;
    if (queryParams != null) {
      final filtered = <String, String>{};
      queryParams.forEach((key, value) {
        if (value != null) {
          if (value is List || value is Map) {
            filtered[key] = jsonEncode(value);
          } else {
            filtered[key] = value.toString();
          }
        }
      });
      qp = filtered.isEmpty ? null : filtered;
    }

    final uri = base.resolve(path).replace(queryParameters: qp);

    // Prepare request-scoped headers; do NOT send Content-Type on GET
    final reqHeaders = Map<String, String>.from(headers);
    reqHeaders.remove('Content-Type');

    log("REQUEST URL: $uri");
    log("BASE URL: $baseUrl");
    log("HEADERS (GET): $reqHeaders");

    if (!isInternet) {
      return ResponseHelper(null, "No internet connection", "", checkStatus(303));
    }

    try {
      final token = LocalService.instance.getData(LocalKeys.instance.accessToken);
      print('tokeeee:: $token');
      if (token?.isNotEmpty == true) {
        reqHeaders['Authorization'] = 'Bearer $token';
        log("AUTH TOKEN set");
        print(reqHeaders['Authorization']);
      }

      print("RESPONSE BODY:");
      final Response response = await http.get(uri, headers: reqHeaders);

      log("RESPONSE STATUS: ${response.statusCode}");
      // Uncomment if you need to debug body:
       print("RESPONSE BODY: ${response.body}");

      return validateResponse(
        response,
        isSuccessMessage,
        isErrorMessage,
        returnData: returnData,
      );
    } catch (err, stackTrace) {
      log("ERROR: $err\nSTACKTRACE: $stackTrace");
      return ResponseHelper(null, "Something went wrong", "$err", checkStatus(302));
    }
  }

  Future<ResponseHelper> delete(
      {required String url,
      bool isSuccessMessage = false,
      bool isErrorMessage = true}) async {
    final isInternet = await checkInternet();
    log("METHOD -: Delete, REQUEST URL -: $baseUrl$url,");
    log("HEADERS -: $headers");

    if (!isInternet) {
      return ResponseHelper(null, "No internet", "", checkStatus(303));
    } else {
      try {
        final token =
            LocalService.instance.getData(LocalKeys.instance.accessToken);
        if (token?.isNotEmpty == true) {
          headers['Authorization'] = 'Bearer $token';
          log("AUTH TOKEN -: $token");
        }

        final Response response =
            await http.delete(Uri.parse("$baseUrl$url"), headers: headers);
        return validateResponse(response, isSuccessMessage, isErrorMessage);
      } catch (err) {
        return ResponseHelper(null, "$err", "", checkStatus(302));
      }
    }
  }

  Future<ResponseHelper> validateResponse(
      Response? response, bool isSuccessMessage, bool isErrorMessage,
      {bool returnData = false}) async {
    if (response != null) {
      final jsonBody = jsonResponse(response.body);
      // log("JSON RESPONSE -: ${getPrettyJSONString(jsonBody)}");

      print("response.statusCode is ${response.statusCode}");

      switch (response.statusCode) {
        case 200:
          if (jsonBody.containsKey("access_token")) {
            await LocalService.instance.setData(
                LocalKeys.instance.accessToken, jsonBody["access_token"]);
          }
          if (checkStatus(200)) {
            if (isSuccessMessage) {
              log("Alert! ${checkMessage(jsonBody) ?? ""}");

              /// TODO: display sucess dialogue only if neccessry
            }
            if (returnData == true) {
              print("return 1");
              return ResponseHelper(jsonBody, checkMessage(jsonBody),
                  jsonBody['access_token'], true);
            }
            print("return 2");
            print("data is ${jsonBody['data'] ?? jsonBody['result']}");

            return ResponseHelper(jsonBody['data'] ?? jsonBody['result'],
                checkMessage(jsonBody), jsonBody['access_token'], true);
          }
          break;

        case 201:
          if (returnData == true) {
            return ResponseHelper(jsonBody, checkMessage(jsonBody),
                jsonBody['access_token'], true);
          }
          return ResponseHelper(jsonBody['data'], checkMessage(jsonBody),
              jsonBody['access_token'], true);

        case 400:
          if (isErrorMessage)
            log("Bad Request ${checkMessage(jsonBody) ?? ""}");

          /// TODO: display sucess dialogue only if neccessry
          break;

        case 401:
          if (isErrorMessage)
            log("Unauthorized ${checkMessage(jsonBody) ?? ""}");

          /// TODO: display sucess dialogue only if neccessry
          break;

        case 403:
          if (isErrorMessage)
            log("Unauthorized User ${checkMessage(jsonBody) ?? ""}");

          /// TODO: display sucess dialogue only if neccessry
          break;

        case 404:
          if (isErrorMessage) {
            if (checkMessage(jsonBody) == "User not exist") {
              LocalService.instance.deleteData(LocalKeys.instance.isLoggedIn);
              LocalService.instance.deleteData(LocalKeys.instance.accessToken);
              // Future.delayed(const Duration(milliseconds: 200), () {
              //   Navigator.pushNamedAndRemoveUntil(
              //     NavigationService.navigatorKey.currentContext!,
              //    // Routes.login,
              //     (Route<dynamic> route) => false,
              //   );
              // });
            } else {
              log("Not Found ${checkMessage(jsonBody) ?? ""}");
            }
          }

          break;

        case 406:
          if (isErrorMessage)
            log("Not Acceptable ${checkMessage(jsonBody) ?? ""}");

          /// TODO: display sucess dialogue only if neccessry
          break;

        case 409:
          if (isErrorMessage) log("Conflict ${checkMessage(jsonBody) ?? ""}");

          /// TODO: display sucess dialogue only if neccessry
          break;

        case 205:
          if (isErrorMessage) log("No Content ${checkMessage(jsonBody) ?? ""}");

          /// TODO: display sucess dialogue only if neccessry
          break;

        case 500:
          if (isErrorMessage) {
            if (checkMessage(jsonBody) == "jwt expired") {
              LocalService.instance.deleteData(LocalKeys.instance.isLoggedIn);
              LocalService.instance.deleteData(LocalKeys.instance.accessToken);

              Future.delayed(const Duration(milliseconds: 200), () {
                // Navigator.pushNamedAndRemoveUntil(
                //   NavigationService.navigatorKey.currentContext!,
                //   Routes.login,
                //   (Route<dynamic> route) => false,
                // );
              });
            } else {
              log("Server Error ${checkMessage(jsonBody) ?? ""}");
            }
          }
          break;

        default:
          if (isErrorMessage) log("Error ${checkMessage(jsonBody) ?? ""}");

          /// TODO: display sucess dialogue only if neccessry
          break;
      }

      return ResponseHelper(
          null, checkMessage(jsonBody), "", checkStatus(response.statusCode));
    } else {
      return ResponseHelper(null, "Response is empty", "", false);
    }
  }

  Future<ResponseHelper2> validateResponse2(
      Response? response, bool isSuccessMessage, bool isErrorMessage,
      {bool returnData = false}) async {
    if (response != null) {
      final jsonBody = jsonResponse(response.body);
      // log("JSON RESPONSE -: ${getPrettyJSONString(jsonBody)}");

      print("response.statusCode is ${response.statusCode}");

      switch (response.statusCode) {
        case 200:
          if (jsonBody.containsKey("access_token")) {
            await LocalService.instance.setData(
                LocalKeys.instance.accessToken, jsonBody["access_token"]);
          }
          if (checkStatus(200)) {
            if (isSuccessMessage) {
              log("Alert! ${checkMessage(jsonBody) ?? ""}");

              /// TODO: display sucess dialogue only if neccessry
            }
            if (returnData == true) {
              print("return 1");
              return ResponseHelper2(jsonBody, checkMessage(jsonBody),
                  jsonBody['access_token'], true);
            }
            print("return 2");
            print("data is ${jsonBody['data'] ?? jsonBody['result']}");

            return ResponseHelper2(jsonBody['data'] ?? jsonBody['result'],
                checkMessage(jsonBody), jsonBody['access_token'], true);
          }
          break;

        case 201:
          if (returnData == true) {
            return ResponseHelper2(jsonBody, checkMessage(jsonBody),
                jsonBody['access_token'], true);
          }
          return ResponseHelper2(jsonBody['data'], checkMessage(jsonBody),
              jsonBody['access_token'], true);

        case 400:
          if (isErrorMessage)
            log("Bad Request ${checkMessage(jsonBody) ?? ""}");

          /// TODO: display sucess dialogue only if neccessry
          break;

        case 401:
          if (isErrorMessage)
            log("Unauthorized ${checkMessage(jsonBody) ?? ""}");

          /// TODO: display sucess dialogue only if neccessry
          break;

        case 403:
          if (isErrorMessage)
            log("Unauthorized User ${checkMessage(jsonBody) ?? ""}");

          /// TODO: display sucess dialogue only if neccessry
          break;

        case 404:
          if (isErrorMessage) {
            if (checkMessage(jsonBody) == "User not exist") {
              LocalService.instance.deleteData(LocalKeys.instance.isLoggedIn);
              LocalService.instance.deleteData(LocalKeys.instance.accessToken);
              // Future.delayed(const Duration(milliseconds: 200), () {
              //   Navigator.pushNamedAndRemoveUntil(
              //     NavigationService.navigatorKey.currentContext!,
              //    // Routes.login,
              //     (Route<dynamic> route) => false,
              //   );
              // });
            } else {
              log("Not Found ${checkMessage(jsonBody) ?? ""}");
            }
          }

          break;

        case 406:
          if (isErrorMessage)
            log("Not Acceptable ${checkMessage(jsonBody) ?? ""}");

          /// TODO: display sucess dialogue only if neccessry
          break;

        case 409:
          if (isErrorMessage) log("Conflict ${checkMessage(jsonBody) ?? ""}");

          /// TODO: display sucess dialogue only if neccessry
          break;

        case 205:
          if (isErrorMessage) log("No Content ${checkMessage(jsonBody) ?? ""}");

          /// TODO: display sucess dialogue only if neccessry
          break;

        case 500:
          if (isErrorMessage) {
            if (checkMessage(jsonBody) == "jwt expired") {
              LocalService.instance.deleteData(LocalKeys.instance.isLoggedIn);
              LocalService.instance.deleteData(LocalKeys.instance.accessToken);

              Future.delayed(const Duration(milliseconds: 200), () {
                // Navigator.pushNamedAndRemoveUntil(
                //   NavigationService.navigatorKey.currentContext!,
                //   Routes.login,
                //   (Route<dynamic> route) => false,
                // );
              });
            } else {
              log("Server Error ${checkMessage(jsonBody) ?? ""}");
            }
          }
          break;

        default:
          if (isErrorMessage) log("Error ${checkMessage(jsonBody) ?? ""}");

          /// TODO: display sucess dialogue only if neccessry
          break;
      }

      return ResponseHelper2(
          null, checkMessage(jsonBody), "", checkStatus(response.statusCode));
    } else {
      return ResponseHelper2(null, "Response is empty", "", false);
    }
  }

  Future<ResponseHelper> uploadImage(File? image, String? imageType,
      Map<String, String> additionalArgs) async {
    RemoteService remoteService = RemoteService();
    String baseUrl = dotenv.get("baseUrl");
    log("$baseUrl${ApiEnds.instance.uploadImage}");
    log("${image?.path}");

    // If no image is provided, return error response
    if (image == null) {
      return ResponseHelper(null, "no image uploaded", "", false);
    }

    final isInternet = await remoteService.checkInternet();
    if (isInternet) {
      try {
        final request = http.MultipartRequest(
            "POST", Uri.parse("$baseUrl${ApiEnds.instance.uploadImage}"));
        request.files.add(
            await http.MultipartFile.fromPath(imageType ?? "", image.path));

        if (additionalArgs.isNotEmpty) {
          request.fields.addAll(additionalArgs);
        }

        var response = await request.send();
        print("ae : ${response.statusCode}");

        if (response.statusCode == 200) {
          final jsonResponse = await response.stream.bytesToString();
          log("Response: $jsonResponse");

          var data = jsonDecode(jsonResponse);

          // Null checks for 'data' and 'upload' keys before usage
          var uploadData = data['result'] != null && data['result'][0] != null
              ? data['result'][0]
              : '';
          var message = data['message'] != null ? data['message'] : '';
          var status =
              data['status'] != null ? checkStatus(data['status']) : false;

          return ResponseHelper(uploadData, message, "", status);
        } else {
          // Log error if server responds with status other than 200
          print("Server Error: ${response.statusCode}");
          return ResponseHelper(null, "something went wrong", "", false);
        }
      } on Exception catch (e) {
        // Handle exception and log error
        print("Exception occurred: $e");
        return ResponseHelper(null, "$e", "", false);
      }
    } else {
      // If no internet connection
      return ResponseHelper(null, "No internet", "", false);
    }
  }

  bool checkStatus(dynamic status) {
    if (status == 200 || status == 201 || status == true) {
      return true;
    }
    return false;
    // return (status >= 200 && status < 300) || status == true;
  }

  dynamic jsonResponse(String? body) {
    return body != null ? jsonDecode(body) : null;
  }

  String? checkMessage(dynamic body) {
    if (!checkStatus(body['status'])) {
      if (body["data"] != null && body['data'].isNotEmpty) {
        if (body['data'].containsKey("error")) {
          return body["data"]["error"][0];
        } else {
          return body['message'];
        }
      } else {
        return body['message'];
      }
    } else {
      return body['message'];
    }
  }

  String getPrettyJSONString(jsonObject) {
    var encoder = const JsonEncoder.withIndent("     ");
    return encoder.convert(jsonObject);
  }
}
