import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  /// Requests notification permissions for both FCM and local notifications.
  static Future<bool> requestNotificationPermissions() async {
    try {
      // FCM permission (mostly affects iOS)
      final FirebaseMessaging messaging = FirebaseMessaging.instance;
      final NotificationSettings settings = await messaging.requestPermission(
        alert: true,
        badge: true,
        sound: true,
      );
      print('FCM permission status: ${settings.authorizationStatus}');

      // Local notifications (mostly affects Android 13+)
      bool localPermissionGranted = await Permission.notification.isGranted;
      if (!localPermissionGranted) {
        final status = await Permission.notification.request();
        localPermissionGranted = status.isGranted;
        print('Local notification permission status: $status');
      } else {
        print('Local notification permission already granted');
      }

      return settings.authorizationStatus == AuthorizationStatus.authorized &&
          localPermissionGranted;
    } catch (e) {
      print('Error requesting notification permissions: $e');
      return false;
    }
  }

  /// Initializes local notifications plugin and sets up notification channels.
  static Future<void> initialize() async {
    const AndroidInitializationSettings androidSettings = AndroidInitializationSettings('logo');
    const InitializationSettings initSettings = InitializationSettings(android: androidSettings);

    await _flutterLocalNotificationsPlugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) async {
        if (response.payload != null) {
          print('Notification tapped with payload: ${response.payload}');
          // TODO: Add navigation handling here
        }
      },
    );

    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      'default_channel',
      'Default Channel',
      description: 'Default notification channel for Krat Easy',
      importance: Importance.max,
    );

    await _flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
  }

  /// Displays a push notification when received.
  static Future<void> showNotification(RemoteMessage message) async {
    const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'default_channel',
      'Default Channel',
      channelDescription: 'Default notification channel for Krat Easy',
      importance: Importance.max,
      priority: Priority.high,
      showWhen: true,
    );

    const NotificationDetails platformDetails = NotificationDetails(android: androidDetails);

    final String title = message.notification?.title ?? message.data['title'] ?? 'Krat Easy';
    final String body = message.notification?.body ?? message.data['body'] ?? 'New notification';

    await _flutterLocalNotificationsPlugin.show(
      message.messageId.hashCode,
      title,
      body,
      platformDetails,
      payload: message.data['route'] ?? '',
    );


    print("body $body");
    print("title $title");
    print("platformDetails $platformDetails");
    print("payload ${message.data['route'] }");

  }
}


