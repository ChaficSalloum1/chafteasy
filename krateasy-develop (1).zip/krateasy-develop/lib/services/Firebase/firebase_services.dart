import 'dart:developer';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:kratEasyApp/services/Firebase/notification_services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../GlobalUtils/app_imports.dart';

class FirebaseService {
  static const String fcmTokenKey = 'fcm_token';

  /// Initializes FCM handling and sets up message listeners.
  static Future<void> initialize() async {
    // Register background handler
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
    // Get FCM token
    String? token;
    try{
      token =await FirebaseMessaging.instance.getToken();

    }catch(e){
      token = "";
    }



    // Save token to shared preferences
    if (token != null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(fcmTokenKey, token);
      await prefs.setString("fcmTokenKey", token);
      print('FCM token saved to shared preferences.1');
      log("\x1B[FCM token saved to shared preferences.2: $token\x1B[0m");
      debugPrint("\x1B[FCM token saved to shared preferences.: $token\x1B[0m");
    }

    // Log FCM token for debugging/push targeting
    // final String? token = await FirebaseMessaging.instance.getToken();
    // print('FCM Token: $token');

    // Listen to messages in foreground
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      print('Received foreground message: ${message.messageId}');
      NotificationService.showNotification(message);
    });

    // Handle tap when app is in background
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      print('Notification opened: ${message.messageId}');
      _handleMessageNavigation(message);
    });

    // Handle tap when app is launched from terminated state
    final RemoteMessage? initialMessage =
        await FirebaseMessaging.instance.getInitialMessage();
    if (initialMessage != null) {
      print('Opened from terminated state: ${initialMessage.messageId}');
      _handleMessageNavigation(initialMessage);
    }
  }

  /// Handles messages received in the background.
  static Future<void> _firebaseMessagingBackgroundHandler(
      RemoteMessage message) async {
    print('Handling a background message: ${message.messageId}');
    NotificationService.showNotification(message);
  }

  /// Handles navigation logic based on message content.
  static void _handleMessageNavigation(RemoteMessage message) {
    if (message.data['route'] != null) {
      print('Navigate to: ${message.data['route']}');
      // TODO: Add navigation logic (e.g., using navigatorKey)
    }
  }
}
