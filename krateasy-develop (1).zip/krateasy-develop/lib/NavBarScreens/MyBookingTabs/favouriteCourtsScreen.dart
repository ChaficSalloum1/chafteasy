
import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/utils/extension.dart';
import 'package:kratEasyApp/utils/throttle_debouncy.dart';
import '../../GlobalUtils/app_imports.dart';

class FavouriteCourtsScreen extends StatefulWidget {
  const FavouriteCourtsScreen({super.key});

  @override
  State<FavouriteCourtsScreen> createState() => _FavouriteCourtsScreenState();
}

class _FavouriteCourtsScreenState extends State<FavouriteCourtsScreen> {
  @override
  void initState() {
    debugPrint("dkkdkj");
    WidgetsBinding.instance.addPostFrameCallback((_) async{
     await context.read<MyFavouriteViewModel>().getFavouriteListData(context: context);

    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    print("---->");

    return Scaffold(
      appBar: CommonAppBar(title: l10n.of(context).favoriteCourts),
      backgroundColor: AppColors.white,
      body: SafeArea(
        child: Consumer2<MyFavouriteViewModel, HomeViewModel>(
          builder:
              (BuildContext context, viewModel, homeViewModel, Widget? child) {
            return viewModel.isLoading
                ? Center(
                    child: CircularProgressIndicator(
                        color: AppColors.primaryColor))
                : viewModel.favouriteCourtData.isEmpty
                    ? Center(
                        child: Text(l10n.of(context).favoriteCourtsNotAvailable,
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                                color: AppColors.black)))
                    : ListView.builder(
                        itemCount: viewModel.favouriteCourtData.length,
                        shrinkWrap: true,
                        physics: AlwaysScrollableScrollPhysics(),
                        itemBuilder: (context, index) {
                          var favData = viewModel.favouriteCourtData[index];
                          return InkWell(
                            onTap: () async {
                              TapThrottle.run('courtDetailsTap3', () async {
                                homeViewModel.setRebookTextUpdate(false);
                                final courtDetails =
                                    await homeViewModel.getCourtDetails(context: context,
                                        courtId: favData.courts?.id ?? "");
                                if (courtDetails) {
                                  Navigator.pushNamed(NavigationService.context,
                                      '/viewCourtDetailsCompleteScreen');
                                } else {
                                  showSnackbar(
                                      context: context,
                                      message: l10n.of(context).pleaseTryAgainLater);
                                }
                              });
                            },
                            child: Container(
                              margin: EdgeInsets.only(
                                  left: 16, right: 16, bottom: 10),
                              padding: EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(5),
                                  border:
                                      Border.all(color: AppColors.greyD0D0)),
                              child: Column(
                                children: [
                                  Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      SizedBox(
                                        height: 85,
                                        width: 90,
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(2.5),
                                          child: NetworkImageWidget(
                                            fit: BoxFit.fill,
                                            image: favData?.courts?.image ?? "",
                                          ),
                                        ),
                                      ),
                                      SizedBox(width: 10),
                                      Expanded(
                                        child: Column(
                                          children: [
                                            Row(
                                              children: [
                                                Expanded(
                                                    child: Text(
                                                        favData?.courts?.name
                                                                ?.capitalizeFirstLetter() ??
                                                            "",
                                                        style: TextStyle(
                                                            fontSize: 16,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                            color: AppColors
                                                                .black))),
                                                InkWell(
                                                    onTap: () async {
                                                    await homeViewModel.addCourtToFavouriteApi(
                                                        context: context,
                                                        courtId: favData.courtId ?? "",
                                                      ).then((_){ viewModel.favouriteCourtData.removeAt(index);
                                                     });

                                                    },

                                                    child: SizedBox(
                                                      width: 25,
                                                      height: 25,
                                                      child: Image.asset(
                                                          "assets/icons/heart.png",color: AppColors.primaryColor,
                                                          fit: BoxFit.fill)),
                                                ),
                                              ],
                                            ),
                                            SizedBox(height: 10),
                                            Row(
                                              children: [
                                                SizedBox(
                                                    width: 16,
                                                    height: 16,
                                                    child: Image.asset(
                                                        'assets/icons/rate.png',
                                                        fit: BoxFit.fill)),
                                                SizedBox(width: 4),
                                                Text(
                                                    (favData?.courts?.averageRating)
                                                        .toString(),
                                                    style: TextStyle(
                                                        fontSize: 13,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        color: AppColors
                                                            .black555)),
                                                Container(
                                                    margin:
                                                        EdgeInsets.symmetric(
                                                            horizontal: 3),
                                                    width: 1,
                                                    height: 15,
                                                    color: AppColors.greyD9D9),
                                                Text(
                                                    (favData?.facility?.name ??
                                                            "")
                                                        .toString(),
                                                    style: TextStyle(
                                                        fontSize: 13,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        color: AppColors
                                                            .black555)),
                                              ],
                                            ),
                                            SizedBox(height: 10),
                                            Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                SizedBox(
                                                    width: 16,
                                                    height: 16,
                                                    child: Image.asset(
                                                        AppImages
                                                            .pngLocationGrey,
                                                        fit: BoxFit.fill)),
                                                SizedBox(width: 4),
                                                Expanded(
                                                    child: Text(
                                                        (favData?.facility
                                                                    ?.address ??
                                                                "")
                                                            .toString(),
                                                        maxLines: 1,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        style: TextStyle(
                                                            fontSize: 13,
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            color: AppColors
                                                                .black555))),
                                                if (favData?.courts?.price !=
                                                        0 ||
                                                    favData?.slots?.firstOrNull
                                                            ?.price !=
                                                        0)
                                                  Text(
                                                      "${AppConstants.appCurrency} ${(favData?.courts?.price ?? favData?.slots?.firstOrNull?.price ?? 0).toString()}",
                                                      style: TextStyle(
                                                          fontSize: 16,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color:
                                                              AppColors.black)),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 10),
                                  Container(
                                      width: double.infinity,
                                      height: 1,
                                      color: AppColors.grey3E3),
                                  SizedBox(height: 10),
                                  SingleChildScrollView(
                                    scrollDirection: Axis.horizontal,
                                    child: Row(
                                      children: List.generate(
                                          favData?.slots?.length ?? 0, (ind) {
                                        var slotData = favData?.slots?[ind];
                                        return Padding(
                                          padding:
                                              const EdgeInsets.only(right: 10),
                                          child: InkWell(
                                            onTap: () {
                                              print(
                                                  "favData.slots?.length  is ${favData?.slots?.length}");
                                              viewModel.updateCourtsIndex(
                                                  index, ind);
                                            },
                                            child: Container(
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 14, vertical: 10),
                                              decoration: BoxDecoration(
                                                color: viewModel.courtsIndex[
                                                            index] ==
                                                        ind
                                                    ? AppColors.primaryColor
                                                    : AppColors
                                                        .lightPrimaryColor9EC,
                                                borderRadius:
                                                    BorderRadius.circular(4),
                                              ),
                                              child: Center(
                                                child: Text(
                                                  (slotData?.startTime)
                                                      .toString(),
                                                  style: TextStyle(
                                                      fontSize: 13,
                                                      fontWeight: FontWeight
                                                          .w700,
                                                      color:
                                                          viewModel.courtsIndex[
                                                                      index] ==
                                                                  ind
                                                              ? AppColors.white
                                                              : AppColors
                                                                  .grey585),
                                                ),
                                              ),
                                            ),
                                          ),
                                        );
                                      }),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
          },
        ),
      ),
    );
  }
}
