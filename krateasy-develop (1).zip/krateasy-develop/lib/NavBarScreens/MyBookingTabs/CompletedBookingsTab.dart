import 'package:geolocator/geolocator.dart';
import 'package:kratEasyApp/GlobalUtils/CircularImageStack.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/utils/throttle_debouncy.dart';
import 'package:kratEasyApp/utils/widgets/common_widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../BottomNavScreens/ChallengeTab/CompletedChallengesTab.dart';
import '../../GlobalUtils/app_imports.dart';

class CompletedBookingsTab extends StatefulWidget {
  const CompletedBookingsTab({super.key});

  @override
  State<CompletedBookingsTab> createState() => _CompletedBookingsTabState();
}

class _CompletedBookingsTabState extends State<CompletedBookingsTab> {
  double _currentRating = 1.0;
  bool _isNavigating = false;



  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    return Consumer<MyBookingsViewModel>(builder: (context, viewModel, _) {
      final myBookings = viewModel.myBookingModel.data?.docs?.where(
        (item) => item.status?.toLowerCase() == "completed",
      );
      printLog("completed booking length :${myBookings?.length}");
      return Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 20),
                (myBookings?.isEmpty ?? true)
                    ? noDataWidget(text: l10n.of(context).bookings)
                    : ListView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        padding: EdgeInsets.symmetric(
                            horizontal: screenWidth * 0.04),
                        itemCount: myBookings?.length ?? 0,
                        itemBuilder: (context, index) {
                          // final booking = myBookings?.toList()[index];
                          final booking = myBookings?.toList()[( myBookings.length)!- 1 - index];
                          final bookingDay = booking?.date != null
                              ? "${DateTime.parse(booking?.date.toString() ?? DateTime.now().toString()).day}"
                              : "";
                          final bookingMonthYear = booking?.date != null
                              ? DateFormat('MMM yyyy').format(DateTime.parse(
                                  booking?.date.toString() ??
                                      DateTime.now().toString()))
                              : "";
                          // double distanceInMeters = Geolocator.distanceBetween(
                          //   lat!,
                          //   long!,
                          //   booking.d
                          //   booking.slots?.court?.facility?.latitude ?? 0.0,
                          //   challenge.slots?.court?.facility?.longtitude ?? 0.0,
                          // );

                          return Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: Container(
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  border: Border.all(
                                    color: Color(0xffD0D0D0),
                                  ),
                                  borderRadius: BorderRadius.circular(5)),
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 6, vertical: 4),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            child: NetworkImageWidget(
                                                image:
                                                    booking?.court?.image ?? "",
                                                width: screenWidth * 0.20,
                                                height: 105,
                                                fit: BoxFit.fill)),
                                        SizedBox(width: 8),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                  '#${booking?.bookingId ?? l10n.of(context).na}',
                                                  style: TextStyle(
                                                      fontSize:
                                                          screenWidth * 0.035,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      color:
                                                          Color(0xFF555555))),
                                              SizedBox(height: 2),
                                              Text(
                                                  booking?.court?.name ??
                                                      l10n.of(context).na,
                                                  style: TextStyle(
                                                      fontSize: 16,
                                                      fontWeight:
                                                      FontWeight.w600,
                                                      color: Colors.black)),
                                              Text(
                                                  '${booking?.startTime ?? l10n.of(context).na}-${booking?.endTime ?? l10n.of(context).na}',
                                                  style: TextStyle(
                                                      fontSize:
                                                      screenWidth * 0.035,
                                                      fontWeight:
                                                      FontWeight.w500,
                                                      color:
                                                      Color(0xFF555555))),

                                              SizedBox(
                                                  height: screenHeight * 0.005),
                                              Row(
                                                children: [
                                                  Image.asset(
                                                      "assets/icons/rate.png",
                                                      width: screenWidth * 0.04,
                                                      height:
                                                          screenWidth * 0.04,
                                                      fit: BoxFit.cover),
                                                  SizedBox(
                                                      width:
                                                          screenWidth * 0.012),
                                                  Text(
                                                      booking?.court
                                                              ?.averageRating
                                                              ?.toString() ??
                                                          l10n.of(context).na,
                                                      maxLines: 1,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      style: TextStyle(
                                                          fontSize:
                                                              screenWidth *
                                                                  0.035,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          color: Colors
                                                              .grey[700])),
                                                  SizedBox(
                                                      width:
                                                          screenWidth * 0.012),
                                                  Container(
                                                      width: 1,
                                                      height:
                                                          screenHeight * 0.03,
                                                      color:
                                                          Color(0xFFDD9D9D9)),
                                                  SizedBox(
                                                      width:
                                                          screenWidth * 0.012),
                                                  Expanded(
                                                      child: Text(
                                                          booking?.court
                                                                  ?.name ??
                                                              l10n.of(context).na,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          maxLines: 2,
                                                          style: TextStyle(
                                                              fontSize: 12,
                                                              color: Color(
                                                                  0xFF555555)))),
                                                ],
                                              ),
                                              SizedBox(
                                                  height: screenHeight * 0.005),
                                              Row(
                                                children: [
                                                  Image.asset(
                                                      'assets/icons/location.png',
                                                      width: screenWidth * 0.04,
                                                      height:
                                                          screenWidth * 0.04),
                                                  SizedBox(
                                                      width:
                                                          screenWidth * 0.012),
                                                  // Expanded(child: Text(opening?.court?.address ?? "", style: TextStyle(fontSize: screenWidth * 0.03, color: Color(0xFF555555)))),
                                                  Expanded(
                                                      child: Text(
                                                          booking?.facility
                                                                  ?.address ??
                                                              l10n.of(context).na,
                                                          maxLines: 2,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style: TextStyle(
                                                              fontSize: 12,
                                                              color: Color(
                                                                  0xFF555555)))),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),

                                        /// time And date
                                        Container(
                                          padding: EdgeInsets.symmetric(
                                              vertical: 2, horizontal: 3),
                                          decoration: BoxDecoration(
                                              color: AppColors.greyGreen63F
                                                  .withOpacity(.1),
                                              borderRadius:
                                                  BorderRadius.circular(5)),
                                          child: Column(
                                            children: [
                                              Row(
                                                children: [
                                                  SizedBox(
                                                      height: 21,
                                                      width: 21,
                                                      child: Image.asset(
                                                          "assets/icons/calender.png")),
                                                  SizedBox(width: 3),
                                                  Text(bookingDay,
                                                      style: TextStyle(
                                                          fontSize: 24,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: AppColors
                                                              .primaryColor)),
                                                ],
                                              ),
                                              Text(bookingMonthYear,
                                                  style: TextStyle(
                                                      fontSize: 12,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      color:
                                                          AppColors.black555)),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: screenHeight * 0.01),
                                    Divider(),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text.rich(
                                          TextSpan(
                                            text: l10n.of(context).typeOfBooking,
                                            style: TextStyle(
                                                fontSize: 12,
                                                color: Color(0xFF555555)),
                                            children: [
                                              TextSpan(
                                                  text: booking?.isSplit == true
                                                      ? l10n.of(context).split
                                                      : l10n
                                                          .of(context)
                                                          .wholeCourtBooking,
                                                  style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.w700,
                                                      fontSize: 12))
                                            ],
                                          ),
                                        ),
                                        Row(
                                          children: [
                                            Image.asset(
                                                'assets/icons/amount.png',
                                                width: screenWidth * 0.05,
                                                height: screenWidth * 0.05),
                                            SizedBox(
                                                width: screenWidth * 0.012),
                                            Text(
                                                "${AppConstants.appCurrency} ${booking?.price}",
                                                style: TextStyle(
                                                    fontSize:
                                                        screenWidth * 0.035,
                                                    fontWeight: FontWeight.bold,
                                                    color: Colors.black)),
                                          ],
                                        ),
                                      ],
                                    ),
                                    Divider(),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Expanded(
                                          child: Row(
                                            children: [
                                              ClipOval(
                                                child: NetworkImageWidget(
                                                  image:
                                                      booking?.sport?.image ??
                                                          "",
                                                  width: 26,
                                                  height: 26,
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                              SizedBox(
                                                  width: screenWidth * 0.012),
                                              Text(
                                                  booking?.sport?.name ??
                                                      l10n.of(context).na,
                                                  style: TextStyle(
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.w700,
                                                      color:
                                                          Color(0xFF3B747B))),
                                            ],
                                          ),
                                        ),
                                        Row(
                                          children: [
                                            ElevatedButton.icon(
                                              style: ElevatedButton.styleFrom(
                                                  backgroundColor:
                                                      const Color(0xFF8DC63F),
                                                  shape: RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              8))),
                                              onPressed:context.read<MyBookingsViewModel>().ischange==true? (){}: (){
                                               context.read<MyBookingsViewModel>().setchange(true);
                                                TapThrottle.run(
                                                    'courtDetailsTap2',
                                                    () async {
                                                  Provider.of<HomeViewModel>(
                                                          context,
                                                          listen: false)
                                                      .setRebookTextUpdate(
                                                          true);
                                                  Provider.of<HomeViewModel>(
                                                          context,
                                                          listen: false)
                                                      .getCourtDetails(
                                                          context: context,
                                                          courtId: (booking
                                                                      ?.court
                                                                      ?.sId ??
                                                                  "")
                                                              .toString())
                                                      .then((_) {
                                                    Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                            builder: (context) =>
                                                                ViewCourtDetailsCompleteScreen(
                                                                  ID: booking
                                                                          ?.courtId ??
                                                                      "",isRebook: true,
                                                                )));
                                                    context.read<MyBookingsViewModel>().setchange(false);

                                                  });

                                                });

                                              },
                                              label: Text(
                                                  l10n.of(context).quickRebook,
                                                  style: TextStyle(
                                                      color: Colors.white,
                                                      fontSize:
                                                          screenWidth * 0.03,
                                                      fontWeight:
                                                          FontWeight.bold)),
                                            ),
                                            SizedBox(width: 8),
                                            ElevatedButton.icon(
                                              style: ElevatedButton.styleFrom(
                                                  backgroundColor:
                                                      const Color(0xFF555555),
                                                  shape: RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              8))),
                                              onPressed: () {
                                                showDialog(
                                                  context: context,
                                                  builder:
                                                      (BuildContext context) {
                                                    return Dialog(
                                                      backgroundColor:
                                                          AppColors.white,
                                                      child: ListView(
                                                        shrinkWrap: true,
                                                        physics:
                                                            NeverScrollableScrollPhysics(),
                                                        children: [
                                                          Container(
                                                            width:
                                                                double.infinity,
                                                            padding: EdgeInsets
                                                                .symmetric(
                                                                    horizontal:
                                                                        16,
                                                                    vertical:
                                                                        20),
                                                            decoration: BoxDecoration(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            12)),
                                                            child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .center,
                                                              children: [
                                                                SizedBox(
                                                                    height: 100,
                                                                    width: 100,
                                                                    child: Image.asset(
                                                                        AppImages
                                                                            .pngDialogLke,
                                                                        fit: BoxFit
                                                                            .fill)),
                                                                SizedBox(
                                                                    height: 10),
                                                                RatingBar
                                                                    .builder(
                                                                  itemSize: 35,
                                                                  initialRating:
                                                                      1,
                                                                  minRating: 1,
                                                                  direction: Axis
                                                                      .horizontal,
                                                                  allowHalfRating:
                                                                      true,
                                                                  itemCount: 5,
                                                                  unratedColor:
                                                                      AppColors
                                                                          .lightGold,
                                                                  itemPadding: EdgeInsets
                                                                      .symmetric(
                                                                          horizontal:
                                                                              4.0),
                                                                  itemBuilder: (context,
                                                                          _) =>
                                                                      Icon(
                                                                          Icons
                                                                              .star,
                                                                          color:
                                                                              Colors.amber),
                                                                  onRatingUpdate:
                                                                      (rating) {
                                                                    print(
                                                                        rating);
                                                                    setState(
                                                                        () {
                                                                      _currentRating =
                                                                          rating;
                                                                    });
                                                                  },
                                                                ),
                                                                SizedBox(
                                                                    height: 10),
                                                                Text(
                                                                    l10n
                                                                        .of(
                                                                            context)
                                                                        .rateTheCourt,
                                                                    style: TextStyle(
                                                                        color: AppColors
                                                                            .black,
                                                                        fontSize:
                                                                            20,
                                                                        fontWeight:
                                                                            FontWeight.w600)),
                                                                SizedBox(
                                                                    height: 10),
                                                                AppTextField(
                                                                    controller:
                                                                        viewModel
                                                                            .ratingReviewController,
                                                                    hintText: l10n
                                                                        .of(
                                                                            context)
                                                                        .writeTheComment,
                                                                    fillColor:
                                                                        AppColors
                                                                            .lightWhiteBF1,
                                                                    maxLines: 4,
                                                                    borderColor:
                                                                        AppColors
                                                                            .white),
                                                                SizedBox(
                                                                    height: 20),
                                                                Row(
                                                                  children: [
                                                                    Stack(
                                                                      children: [
                                                                        Container(
                                                                            height:
                                                                                36,
                                                                            width:
                                                                                130,
                                                                            decoration:
                                                                                BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.green033)),
                                                                        GestureDetector(
                                                                          onTap:
                                                                              () {
                                                                            viewModel.rateBooking(
                                                                                bookingId: booking?.sId ?? "",
                                                                                rate: _currentRating,
                                                                                message: viewModel.ratingReviewController.text,
                                                                                context: context);
                                                                            Navigator.pop(context);
                                                                            viewModel.ratingReviewController.clear();
                                                                          },
                                                                          child:
                                                                              Container(
                                                                            height:
                                                                                32,
                                                                            width:
                                                                                130,
                                                                            decoration:
                                                                                BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.primaryColor),
                                                                            child:
                                                                                Center(child: Text(l10n.of(context).submit, style: TextStyle(color: AppColors.black, fontSize: 12, fontWeight: FontWeight.w600))),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                    Expanded(
                                                                      child:
                                                                          AppButton(
                                                                        onPressed:
                                                                            () {
                                                                          Navigator.pop(
                                                                              context);
                                                                        },
                                                                        label: l10n
                                                                            .of(context)
                                                                            .cancel,
                                                                        height:
                                                                            30,
                                                                        bgColor:
                                                                            AppColors.white,
                                                                        textStyle: TextStyle(
                                                                            color: AppColors
                                                                                .black,
                                                                            fontSize:
                                                                                12,
                                                                            fontWeight:
                                                                                FontWeight.w600),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ],
                                                            ),
                                                          )
                                                        ],
                                                      ),
                                                    );
                                                  },
                                                );
                                              },
                                              label: Text(l10n.of(context).review,
                                                  style: TextStyle(
                                                      color: Colors.white,
                                                      fontSize:
                                                          screenWidth * 0.03,
                                                      fontWeight:
                                                          FontWeight.bold)),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                SizedBox(height: 20),

                /// challenges
                Container(
                  height: 40,
                  width: screenWidth,
                  color: AppColors.primaryColor,
                  margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.04),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      SizedBox(
                          height: 12,
                          width: 78,
                          child: Image.asset(
                              "assets/png/png_mltiple_back_arrow.png",
                              fit: BoxFit.fill)),
                      Text(l10n.of(context).challenges,
                          style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w500,
                              color: AppColors.white)),
                      SizedBox(
                          height: 12,
                          width: 78,
                          child: Image.asset(
                              "assets/png/png_multiple_forword_arrrow.png",
                              fit: BoxFit.fill)),
                    ],
                  ),
                ),
                SizedBox(height: 16),

                /// List of challenges
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: screenWidth * .04),
                  child: viewModel
                              .myChallengeDataComplete.data?.docs?.isEmpty ==
                          true
                      ? SizedBox(
                          height: 300,
                          width: double.infinity,
                          child: Center(
                              child: Text(
                                  l10n.of(context).challengesNotAvailableYet,
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      color: AppColors.black555))))
                      : ListView.builder(
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemCount: viewModel
                                  .myChallengeDataComplete.data?.docs?.length ??
                              0,
                          itemBuilder: (context, index) {
                            final challengeData = viewModel
                                .myChallengeDataComplete.data?.docs?[index];
                            // final bookingDay = challengeData?.date != null
                            //     ? DateFormat("dd MMM yyyy").format(
                            //         challengeData!.date!.contains(
                            //                 '-') // If the date is in "dd-MM-yyyy" format
                            //             ? DateFormat("dd-MM-yyyy")
                            //                 .parse(challengeData.date!)
                            //             : DateFormat(
                            //                     "EEE MMM dd yyyy HH:mm:ss 'GMT'Z",
                            //                     'en_US')
                            //                 .parse(challengeData.date!))
                            //     : "";
                            //             "date": "2025-05-19T00:00:00.000Z",

// final bookingDay = challengeData?.date != null
//                                     ? DateFormat("dd MMM yyyy").format(
//                                         DateFormat("dd-MM-yyyy").parse(
//                                             challengeData?.date ??
//                                                 DateTime.now().toString()))
//                                     : "";
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: Container(
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: Border.all(
                                      color: Color(0xffD0D0D0),
                                    ),
                                    borderRadius: BorderRadius.circular(5)),
                                child: Padding(
                                  padding: EdgeInsets.all(screenWidth * 0.03),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      // Content of the card
                                      IntrinsicHeight(
                                        child: Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.stretch,
                                          children: [
                                            SizedBox(
                                              width: 85,
                                              child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(8),
                                                  child: NetworkImageWidget(
                                                      image: (challengeData
                                                                  ?.court
                                                                  ?.image ??
                                                              '')
                                                          .toString(),
                                                      width: screenWidth * 0.20,
                                                      height:
                                                          screenWidth * 0.20,
                                                      fit: BoxFit.cover)),
                                            ),
                                            SizedBox(width: 10),
                                            Expanded(
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                      challengeData
                                                              ?.court?.name ??
                                                          l10n.of(context).na,
                                                      style: TextStyle(
                                                          fontSize:
                                                              screenWidth *
                                                                  0.042,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color:
                                                              AppColors.black)),
                                                  SizedBox(height: 4),
                                                  Text(
                                                      (challengeData?.facility
                                                                  ?.name ??
                                                              l10n.of(context).na)
                                                          .toString(),
                                                      style: TextStyle(
                                                          fontSize:
                                                              screenWidth *
                                                                  0.038,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: AppColors
                                                              .greyGreen47D)),
                                                  SizedBox(height: 6),
                                                  Row(
                                                    children: [
                                                      Image.asset(
                                                          "assets/png/calender.png",
                                                          width: screenWidth *
                                                              0.04,
                                                          height: screenWidth *
                                                              0.04,
                                                          fit: BoxFit.cover),
                                                      SizedBox(width: 8),
                                                      Text(
                                                          formatDateToDayMonthYear(
                                                              challengeData
                                                                      ?.date ??
                                                                  ""),
                                                          style: TextStyle(
                                                              fontSize: 11,
                                                              color: Color(
                                                                  0xFF555555))),
                                                      SizedBox(width: 4),
                                                      Container(
                                                          width: 1,
                                                          height: screenHeight *
                                                              0.03,
                                                          color: Color(
                                                              0xFFDD9D9D9)),
                                                      SizedBox(width: 4),
                                                      Expanded(
                                                          child: Text(
                                                              " ${challengeData?.startTime} - ${challengeData?.endTime}",
                                                              style: TextStyle(
                                                                  fontSize: 11,
                                                                  color: Color(
                                                                      0xFF555555)))),
                                                    ],
                                                  ),
                                                  SizedBox(height: 6),
                                                  Row(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Image.asset(
                                                          'assets/icons/location.png',
                                                          width: screenWidth *
                                                              0.04,
                                                          height: screenWidth *
                                                              0.04),
                                                      SizedBox(
                                                          width: screenWidth *
                                                              0.012),
                                                      Expanded(
                                                          child: Text(
                                                              (challengeData
                                                                          ?.facility
                                                                          ?.address ??
                                                                      l10n
                                                                          .of(
                                                                              context)
                                                                          .na)
                                                                  .toString(),
                                                              maxLines: 3,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              style: TextStyle(
                                                                  fontSize:
                                                                      screenWidth *
                                                                          0.03,
                                                                  color: Color(
                                                                      0xFF555555)))),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              height: 34,
                                              width: 34,
                                              decoration: BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  border: Border.all(
                                                      width: 1,
                                                      color: AppColors
                                                          .primaryColor)),
                                              child: Center(
                                                child: ClipRRect(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            24),
                                                    child: NetworkImageWidget(
                                                        height: 24,
                                                        width: 24,
                                                        fit: BoxFit.cover,
                                                        image: (challengeData
                                                                    ?.sport
                                                                    ?.image ??
                                                                '')
                                                            .toString())),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Divider(),
                                      SizedBox(height: 5),
                                      Stack(
                                        children: [
                                          Container(
                                              height: 6,
                                              width: screenWidth,
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(3),
                                                  color: AppColors.grey1E1)),
                                          Container(
                                              height: 6,
                                              width: ((challengeData?.whoJoined
                                                              ?.length ??
                                                          0) /
                                                      (challengeData
                                                              ?.maxPlayer ??
                                                          1)) *
                                                  screenWidth,
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(3),
                                                  color:
                                                      AppColors.greyGreen47D)),
                                        ],
                                      ),
                                      SizedBox(height: 5),

                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                              "${challengeData?.whoJoinedDetail?.length ?? 0} Player going",
                                              style: TextStyle(
                                                  fontSize: screenWidth * 0.040,
                                                  fontWeight: FontWeight.normal,
                                                  color: AppColors.blackA2A)),

                                          Text(
                                              "Out of ${challengeData?.maxPlayer ?? 0}",
                                              style: TextStyle(
                                                  fontSize: screenWidth * 0.040,
                                                  fontWeight: FontWeight.normal,
                                                  color: AppColors.blackA2A)),

                                          ////
                                        ],
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          CircularImageStackOld(
                                              imageUrls: challengeData
                                                      ?.whoJoinedDetail
                                                      ?.map((item) =>
                                                          item.image.toString())
                                                      .toList() ??
                                                  [],
                                              maxImages: 4),
                                          // ElevatedButton.icon(
                                          //   style: ElevatedButton.styleFrom(
                                          //       backgroundColor:
                                          //           const Color(
                                          //               0xFF8DC63F),
                                          //       shape: RoundedRectangleBorder(
                                          //           borderRadius:
                                          //               BorderRadius
                                          //                   .circular(
                                          //                       8))),
                                          //   onPressed: () {
                                          //     Provider.of<AvailableChallengeGuestViewModel>(
                                          //             context,
                                          //             listen: false)
                                          //         .getChallengesDetails(
                                          //             ispublic: true,
                                          //             myBookingScreen:
                                          //                 true,
                                          //             challengesId:
                                          //                 challengeData
                                          //                         ?.id ??
                                          //                     "",
                                          //             context:
                                          //                 context);
                                          //   },
                                          //   label: Text(
                                          //       "Quick Rebook",
                                          //       style: TextStyle(
                                          //           color:
                                          //               Colors.white,
                                          //           fontSize:
                                          //               screenWidth *
                                          //                   0.03,
                                          //           fontWeight:
                                          //               FontWeight
                                          //                   .bold)),
                                          // ),
                                          SizedBox(height: 4),
                                          ElevatedButton.icon(
                                            style: ElevatedButton.styleFrom(
                                                backgroundColor:
                                                    const Color(0xFF555555),
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            8))),
                                            onPressed: () {
                                              showDialog(
                                                context: context,
                                                builder:
                                                    (BuildContext context) {
                                                  return Dialog(
                                                    backgroundColor:
                                                        AppColors.white,
                                                    child: ListView(
                                                      shrinkWrap: true,
                                                      physics:
                                                          NeverScrollableScrollPhysics(),
                                                      children: [
                                                        Stack(
                                                          children: [
                                                            Container(
                                                              width: double
                                                                  .infinity,
                                                              padding: EdgeInsets
                                                                  .symmetric(
                                                                      horizontal:
                                                                          16,
                                                                      vertical:
                                                                          20),
                                                              decoration: BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              12)),
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .center,
                                                                children: [
                                                                  SizedBox(
                                                                      height:
                                                                          100,
                                                                      width:
                                                                          100,
                                                                      child: Image.asset(
                                                                          AppImages
                                                                              .pngDialogLke,
                                                                          fit: BoxFit
                                                                              .fill)),
                                                                  SizedBox(
                                                                      height:
                                                                          10),
                                                                  RatingBar
                                                                      .builder(
                                                                    itemSize:
                                                                        35,
                                                                    initialRating:
                                                                        2,
                                                                    minRating:
                                                                        1,
                                                                    direction: Axis
                                                                        .horizontal,
                                                                    allowHalfRating:
                                                                        true,
                                                                    itemCount:
                                                                        5,
                                                                    unratedColor:
                                                                        AppColors
                                                                            .lightGold,
                                                                    itemPadding:
                                                                        EdgeInsets.symmetric(
                                                                            horizontal:
                                                                                4.0),
                                                                    itemBuilder: (context, _) => Icon(
                                                                        Icons
                                                                            .star,
                                                                        color: Colors
                                                                            .amber),
                                                                    onRatingUpdate:
                                                                        (rating) {
                                                                      print(
                                                                          rating);
                                                                    },
                                                                  ),
                                                                  SizedBox(
                                                                      height:
                                                                          10),
                                                                  Text(
                                                                      l10n
                                                                          .of(
                                                                              context)
                                                                          .rateTheCourt,
                                                                      style: TextStyle(
                                                                          color: AppColors
                                                                              .black,
                                                                          fontSize:
                                                                              20,
                                                                          fontWeight:
                                                                              FontWeight.w600)),
                                                                  SizedBox(
                                                                      height:
                                                                          10),
                                                                  AppTextField(
                                                                      hintText: l10n
                                                                          .of(
                                                                              context)
                                                                          .writeTheComment,
                                                                      fillColor:
                                                                          AppColors
                                                                              .lightWhiteBF1,
                                                                      maxLines:
                                                                          4,
                                                                      borderColor:
                                                                          AppColors
                                                                              .white),
                                                                  SizedBox(
                                                                      height:
                                                                          20),
                                                                  Stack(
                                                                    children: [
                                                                      Container(
                                                                        height:
                                                                            36,
                                                                        width:
                                                                            150,
                                                                        decoration: BoxDecoration(
                                                                            borderRadius:
                                                                                BorderRadius.circular(10),
                                                                            color: AppColors.green033),
                                                                      ),

                                                                      GestureDetector(
                                                                        onTap:
                                                                            () {
                                                                              viewModel.rateBooking(
                                                                                  bookingId: challengeData?.booking?.id??"",
                                                                                  rate: _currentRating,
                                                                                  message: viewModel.ratingReviewController.text,
                                                                                  context: context);
                                                                              Navigator.pop(context);
                                                                              viewModel.ratingReviewController.clear();
                                                                          // Navigator.pop(
                                                                          //     context);
                                                                        },
                                                                        child:
                                                                            Container(
                                                                          height:
                                                                              32,
                                                                          width:
                                                                              150,
                                                                          decoration: BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(10),
                                                                              color: AppColors.primaryColor),
                                                                          child:
                                                                              Center(
                                                                            child:
                                                                                Text(l10n.of(context).submit, style: TextStyle(color: AppColors.black, fontSize: 12, fontWeight: FontWeight.w600)),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Positioned(
                                                              top: 0,
                                                              right: 0,
                                                              child: Transform
                                                                  .translate(
                                                                offset: Offset(
                                                                    15, -15),
                                                                child:
                                                                    GestureDetector(
                                                                  onTap: () {
                                                                    Navigator.pop(
                                                                        context);
                                                                  },
                                                                  child: SizedBox(
                                                                      height:
                                                                          40,
                                                                      width: 40,
                                                                      child: Image.asset(
                                                                          AppImages
                                                                              .pngDialogCross,
                                                                          fit: BoxFit
                                                                              .fill)),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ],
                                                    ),
                                                  );
                                                },
                                              );
                                            },
                                            label: Text(l10n.of(context).review,
                                                style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize:
                                                        screenWidth * 0.03,
                                                    fontWeight:
                                                        FontWeight.bold)),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                ),
                SizedBox(height: 20),
              ],
            ),
          ),
        ),
      );
    });
  }
}
