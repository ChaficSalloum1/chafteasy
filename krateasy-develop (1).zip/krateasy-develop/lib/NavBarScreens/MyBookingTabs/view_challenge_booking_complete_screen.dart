// import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
// import '../../BottomNavScreens/ChallengeTab/CompletedChallengesTab.dart'
//     show CircularImageStack;

// class ViewChallengeBookingCompleteScreen extends StatefulWidget {
//   const ViewChallengeBookingCompleteScreen({super.key});

//   @override
//   State<ViewChallengeBookingCompleteScreen> createState() =>
//       _ViewChallengeBookingCompleteScreenState();
// }

// class _ViewChallengeBookingCompleteScreenState
//     extends State<ViewChallengeBookingCompleteScreen> {
//   @override
//   Widget build(BuildContext context) {
//     final viewModel = Provider.of<MyBookingsViewModel>(context);
//     double screenWidth = MediaQuery.of(context).size.width;
//     double screenHeight = MediaQuery.of(context).size.height;
//     return Consumer<AvailableChallengeGuestViewModel>(
//       builder: (BuildContext context, challengeViewModel, Widget? child) {
//         final challengeData = challengeViewModel.challengesDetailsModel.data;
//         final bookingDay = challengeData?.date != null
//             ? DateFormat("dd MMM yyyy").format(
//                 challengeData!.date!.contains('-')
//                     ? DateFormat("dd-MM-yyyy").parse(challengeData.date!)
//                     : DateFormat("EEE MMM dd yyyy HH:mm:ss 'GMT'Z", 'en_US')
//                         .parse(challengeData.date!))
//             : "";
//         // final bookingDay = challengeData?.date != null ? DateFormat("dd MMM yyyy").format(DateFormat("dd-MM-yyyy").parse(challengeData?.date ?? DateTime.now().toString())) : "";
//         return Scaffold(
//           backgroundColor: AppColors.white,
//           appBar: CommonAppBar(
//             title: "View Challenge",
//             action: [
//               InkWell(
//                   onTap: () {
//                     viewModel.navigateToFeedsScreen(context);
//                   },
//                   child: SizedBox(
//                       width: 24,
//                       height: 24,
//                       child:
//                           Image.asset(AppImages.pngVideo, fit: BoxFit.fill))),
//               SizedBox(width: 7),
//               InkWell(
//                   onTap: () {
//                     viewModel.navigateToFeedsScreen(context);
//                   },
//                   child: Text("Feeds",
//                       style: TextStyle(
//                           fontSize: 16,
//                           fontWeight: FontWeight.normal,
//                           color: AppColors.black))),
//               SizedBox(width: 10),
//             ],
//           ),
//           floatingActionButtonLocation:
//               FloatingActionButtonLocation.centerFloat,
//           floatingActionButton: Padding(
//             padding: const EdgeInsets.only(bottom: 20),
//             child: Stack(
//               children: [
//                 Container(
//                     height: 52,
//                     width: screenWidth - screenWidth * 0.08,
//                     decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(10),
//                         color: AppColors.green033)),
//                 GestureDetector(
//                   onTap: () {
//                     Navigator.pop(context);
//                   },
//                   child: Container(
//                     height: 47,
//                     width: screenWidth - screenWidth * 0.08,
//                     decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(10),
//                         color: AppColors.primaryColor),
//                     child: Center(
//                         child: Text("Quick Rebook",
//                             style: TextStyle(
//                                 color: AppColors.black,
//                                 fontSize: 18,
//                                 fontWeight: FontWeight.w600))),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           body: SafeArea(
//             child: SingleChildScrollView(
//               child: Column(
//                 children: [
//                   /// top image data
//                   Stack(
//                     children: [
//                       SizedBox(
//                         height: screenHeight * .3,
//                         width: screenWidth,
//                         child: NetworkImageWidget(
//                             image: (challengeData?.slots?.court?.image ?? "")
//                                 .toString(),
//                             fit: BoxFit.fill),
//                       ),
//                       Positioned(
//                         left: 40,
//                         bottom: 11,
//                         child: Row(
//                           children: List.generate(6, (index) {
//                             return Padding(
//                               padding: const EdgeInsets.only(right: 10),
//                               child: ClipRRect(
//                                   borderRadius: BorderRadius.circular(5),
//                                   child: SizedBox(
//                                       height: 47,
//                                       width: 47,
//                                       child: Image.asset(AppImages.pngSmallBg,
//                                           fit: BoxFit.fill))),
//                             );
//                           }),
//                         ),
//                       ),
//                     ],
//                   ),
//                   SizedBox(height: 15),
//                   Padding(
//                     padding: EdgeInsets.all(screenWidth * 0.03),
//                     child: GestureDetector(
//                       onTap: () {
//                         // viewModel.navigateToViewChallengeScreen(context);
//                       },
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           // Content of the card
//                           Row(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               Expanded(
//                                 child: Column(
//                                   crossAxisAlignment: CrossAxisAlignment.start,
//                                   children: [
//                                     Text(
//                                         (challengeData?.slots?.court?.sport
//                                                     ?.name ??
//                                                 "")
//                                             .toString(),
//                                         style: TextStyle(
//                                             fontSize: 20,
//                                             fontWeight: FontWeight.w600,
//                                             color: AppColors.black)),
//                                     Text(
//                                         (challengeData?.slots?.court?.name ??
//                                                 "")
//                                             .toString(),
//                                         style: TextStyle(
//                                             fontSize: 17,
//                                             fontWeight: FontWeight.w600,
//                                             color: AppColors.greyGreen47D)),
//                                     SizedBox(height: screenHeight * 0.005),
//                                     Row(
//                                       children: [
//                                         Image.asset("assets/png/calender.png",
//                                             width: screenWidth * 0.04,
//                                             height: screenWidth * 0.04,
//                                             fit: BoxFit.cover),
//                                         SizedBox(width: screenWidth * 0.002),
//                                         Text(bookingDay,
//                                             style: TextStyle(
//                                                 fontSize: screenWidth * 0.033,
//                                                 fontWeight: FontWeight.normal,
//                                                 color: Color(0xFF555555))),
//                                         SizedBox(width: screenWidth * 0.007),
//                                         Container(
//                                             width: 1,
//                                             height: screenHeight * 0.03,
//                                             color: Color(0xFFDD9D9D9)),
//                                         SizedBox(width: screenWidth * 0.007),
//                                         Text(
//                                             " ${challengeData?.slots?.startTime} - ${challengeData?.slots?.endTime}",
//                                             style: TextStyle(
//                                                 fontSize: screenWidth * 0.033,
//                                                 fontWeight: FontWeight.normal,
//                                                 color: Color(0xFF555555))),
//                                       ],
//                                     ),
//                                     SizedBox(height: screenHeight * 0.005),
//                                     Row(
//                                       children: [
//                                         Image.asset("assets/icons/rate.png",
//                                             width: screenWidth * 0.04,
//                                             height: screenWidth * 0.04,
//                                             fit: BoxFit.cover),
//                                         SizedBox(width: screenWidth * 0.009),
//                                         Text(
//                                             (challengeData?.slots?.court
//                                                         ?.averageRating ??
//                                                     0)
//                                                 .toString(),
//                                             style: TextStyle(
//                                                 fontSize: 16,
//                                                 fontWeight: FontWeight.w700,
//                                                 color: Color(0xFF555555))),
//                                         SizedBox(width: screenWidth * 0.009),
//                                         Container(
//                                             width: 1,
//                                             height: screenHeight * 0.03,
//                                             color: Color(0xFFDD9D9D9)),
//                                         SizedBox(width: screenWidth * 0.009),
//                                         Text(
//                                             "${(challengeData?.slots?.court?.totalBookingCount ?? 0).toString()}+ Bookings",
//                                             style: TextStyle(
//                                                 fontSize: screenWidth * 0.033,
//                                                 fontWeight: FontWeight.normal,
//                                                 color: Color(0xFF555555))),
//                                       ],
//                                     ),
//                                     SizedBox(height: screenHeight * 0.005),
//                                   ],
//                                 ),
//                               ),
//                               Container(
//                                 height: 35,
//                                 width: 35,
//                                 decoration: BoxDecoration(
//                                     shape: BoxShape.circle,
//                                     border: Border.all(
//                                         width: 1,
//                                         color: AppColors.primaryColor)),
//                                 child: Center(
//                                   child: ClipRRect(
//                                       borderRadius: BorderRadius.circular(
//                                           screenWidth * 0.06),
//                                       child: NetworkImageWidget(
//                                           image: (challengeData?.slots?.court
//                                                       ?.sport?.image ??
//                                                   "")
//                                               .toString(),
//                                           fit: BoxFit.fill,
//                                           width: screenWidth * 0.06,
//                                           height: screenWidth * 0.06)),
//                                 ),
//                               ),
//                             ],
//                           ),
//                           SizedBox(height: screenHeight * 0.005),
//                           Row(
//                             children: [
//                               Image.asset('assets/icons/location.png',
//                                   width: screenWidth * 0.045,
//                                   height: screenWidth * 0.045),
//                               SizedBox(width: screenWidth * 0.002),
//                               Expanded(
//                                   child: Text(
//                                       (challengeData?.slots?.court?.facility
//                                                   ?.address ??
//                                               "")
//                                           .toString(),
//                                       style: TextStyle(
//                                           fontSize: screenWidth * 0.033,
//                                           color: Color(0xFF555555)))),
//                               Image.asset('assets/icons/coins.png',
//                                   width: screenWidth * 0.045,
//                                   height: screenWidth * 0.045,
//                                   color: AppColors.black),
//                               SizedBox(width: screenWidth * 0.009),
//                               Text(
//                                   "${AppConstants.appCurrency} ${(challengeData?.slots?.price ?? 0).toString()}/hr",
//                                   style: TextStyle(
//                                       fontSize: 18,
//                                       fontWeight: FontWeight.w600,
//                                       color: AppColors.black)),
//                             ],
//                           ),
//                           SizedBox(height: screenHeight * 0.005),
//                           Row(
//                             children: [
//                               Image.asset(AppImages.pngPrivateIcon,
//                                   width: screenWidth * 0.045,
//                                   height: screenWidth * 0.045),
//                               SizedBox(width: screenWidth * 0.002),
//                               Text("Created By ",
//                                   style: TextStyle(
//                                       fontSize: screenWidth * 0.033,
//                                       color: Color(0xFF555555))),
//                               Spacer(),
//                               SizedBox(width: screenWidth * 0.002),
//                               Text("Joe Jonas",
//                                   style: TextStyle(
//                                       fontSize: 14,
//                                       fontWeight: FontWeight.w400,
//                                       color: AppColors.black)),
//                             ],
//                           ),
//                           Divider(),
//                           SizedBox(height: 5),
//                           Stack(
//                             children: [
//                               Container(
//                                   height: 6,
//                                   width: screenWidth,
//                                   decoration: BoxDecoration(
//                                       borderRadius: BorderRadius.circular(3),
//                                       color: AppColors.grey1E1)),
//                               Container(
//                                   height: 6,
//                                   width:
//                                       ((challengeData?.whoJoined?.length ?? 0) /
//                                               (challengeData?.maxPlayer ?? 1)) *
//                                           screenWidth,
//                                   decoration: BoxDecoration(
//                                       borderRadius: BorderRadius.circular(3),
//                                       color: AppColors.greyGreen47D)),
//                             ],
//                           ),
//                           SizedBox(height: 5),
//                           Row(
//                             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                             children: [
//                               Expanded(
//                                 child: Row(
//                                   mainAxisAlignment:
//                                       MainAxisAlignment.spaceBetween,
//                                   crossAxisAlignment: CrossAxisAlignment.start,
//                                   children: [
//                                     Column(
//                                       crossAxisAlignment:
//                                           CrossAxisAlignment.start,
//                                       children: [
//                                         Text(
//                                             "${challengeData?.whoJoined?.length ?? 0} Player going",
//                                             style: TextStyle(
//                                                 fontSize: screenWidth * 0.040,
//                                                 fontWeight: FontWeight.normal,
//                                                 color: AppColors.blackA2A)),
//                                         Center(
//                                             child: CircularImageStack(
//                                                 imageUrls: challengeData
//                                                         ?.whoJoined
//                                                         ?.map((item) => item
//                                                             .image
//                                                             .toString())
//                                                         .toList() ??
//                                                     [],
//                                                 maxImages: 4)),
//                                       ],
//                                     ),
//                                     Text(
//                                         "Out of ${challengeData?.maxPlayer ?? 1}",
//                                         style: TextStyle(
//                                             fontSize: screenWidth * 0.040,
//                                             fontWeight: FontWeight.normal,
//                                             color: AppColors.blackA2A)),
//                                   ],
//                                 ),
//                               ),
//                             ],
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//                   Divider(),
//                   Padding(
//                     padding:
//                         EdgeInsets.symmetric(horizontal: screenWidth * 0.04),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         RichText(
//                           text: TextSpan(
//                             children: [
//                               TextSpan(
//                                   text: "Description : ",
//                                   style: TextStyle(
//                                       fontSize: 15,
//                                       fontWeight: FontWeight.w600,
//                                       color: AppColors.black555)),
//                               TextSpan(
//                                 text: (challengeData?.slots?.court?.facility
//                                             ?.description ??
//                                         "")
//                                     .toString(),
//                                 style: TextStyle(
//                                     fontSize: 15,
//                                     fontWeight: FontWeight.w400,
//                                     color: AppColors.black555),
//                               ),
//                             ],
//                           ),
//                         ),
//                         SizedBox(height: 7),
//                         Text("Amenities : ",
//                             style: TextStyle(
//                                 fontWeight: FontWeight.w600,
//                                 fontSize: 18,
//                                 color: AppColors.black555)),
//                         SizedBox(height: 7),
//                         SingleChildScrollView(
//                           scrollDirection: Axis.horizontal,
//                           child: Row(
//                             children: List.generate(
//                               challengeData?.slots?.court?.facility?.amenities
//                                       ?.length ??
//                                   0,
//                               (index) {
//                                 final amenitiesData = challengeData
//                                     ?.slots?.court?.facility?.amenities?[index];
//                                 return CommonAmenities(
//                                   text: amenitiesData?.name ?? "",
//                                   image: amenitiesData?.image ?? "",
//                                 );
//                               },
//                             ),
//                           ),
//                         ),
//                         SizedBox(height: 7),
//                         Text("Rules : ",
//                             style: TextStyle(
//                                 fontWeight: FontWeight.w600,
//                                 fontSize: 18,
//                                 color: AppColors.black555)),
//                         SizedBox(height: 7),
//                         CommonRules(
//                             text: (challengeData?.slots?.court?.facility?.bio ??
//                                     "")
//                                 .toString()),
//                         SizedBox(height: 20),
//                         SizedBox(
//                           height: 180,
//                           child: ListView.builder(
//                             itemCount: 5,
//                             scrollDirection: Axis.horizontal,
//                             itemBuilder: (context, index) {
//                               return Padding(
//                                 padding: const EdgeInsets.only(right: 15),
//                                 child: Column(
//                                   children: [
//                                     Stack(
//                                       children: [
//                                         ClipRRect(
//                                             borderRadius:
//                                                 BorderRadius.circular(80),
//                                             child: Image.asset(
//                                                 AppImages.pngUser,
//                                                 width: 70,
//                                                 height: 70)),
//                                         Positioned(
//                                           top: 0,
//                                           right: 0,
//                                           child: Container(
//                                             height: 25,
//                                             width: 25,
//                                             decoration: BoxDecoration(
//                                                 shape: BoxShape.circle,
//                                                 color: AppColors.primaryColor),
//                                             child: Center(
//                                                 child: Image.asset(
//                                                     AppImages.pngRightClick,
//                                                     width: 16,
//                                                     height: 16)),
//                                           ),
//                                         ),
//                                       ],
//                                     ),
//                                     SizedBox(height: 5),
//                                     Text('You',
//                                         style: TextStyle(
//                                             fontSize: 13,
//                                             fontWeight: FontWeight.w500,
//                                             color: AppColors.black555)),
//                                     SizedBox(height: 16),
//                                     Text('£5',
//                                         style: TextStyle(
//                                             fontSize: 20,
//                                             fontWeight: FontWeight.w500,
//                                             color: AppColors.black)),
//                                   ],
//                                 ),
//                               );
//                             },
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                   Stack(
//                     children: [
//                       SizedBox(
//                           height: screenHeight * .3,
//                           width: screenWidth,
//                           child:
//                               Image.asset(AppImages.pngMap, fit: BoxFit.fill)),
//                       Positioned(
//                           left: (screenWidth - 20) / 2,
//                           top: (screenHeight * .06),
//                           child: SizedBox(
//                               width: 46,
//                               height: 53,
//                               child: Image.asset(AppImages.pngLocationGreen,
//                                   fit: BoxFit.fill))),
//                       Positioned(
//                         bottom: 18,
//                         left: screenWidth * 0.04,
//                         right: screenWidth * 0.04,
//                         child: Container(
//                           height: 52,
//                           padding: EdgeInsets.symmetric(horizontal: 10),
//                           width: double.infinity,
//                           decoration: BoxDecoration(
//                               color: Colors.white,
//                               borderRadius: BorderRadius.circular(5)),
//                           child: Row(
//                             children: [
//                               SizedBox(
//                                   width: 17,
//                                   height: 17,
//                                   child: Image.asset(AppImages.pngLocationGrey,
//                                       fit: BoxFit.fill)),
//                               SizedBox(width: 7),
//                               SizedBox(
//                                   width: screenWidth * .7,
//                                   child: Text(
//                                       (challengeData?.slots?.court?.facility
//                                                   ?.address ??
//                                               "")
//                                           .toString(),
//                                       style: TextStyle(
//                                           fontSize: 16,
//                                           fontWeight: FontWeight.normal,
//                                           color: AppColors.black555))),
//                               Spacer(),
//                               SizedBox(
//                                   width: 24,
//                                   height: 24,
//                                   child: Image.asset(
//                                       AppImages.pngLocationCircle,
//                                       fit: BoxFit.fill)),
//                             ],
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                   SizedBox(height: 100),
//                 ],
//               ),
//             ),
//           ),
//         );
//       },
//     );
//   }
// }
