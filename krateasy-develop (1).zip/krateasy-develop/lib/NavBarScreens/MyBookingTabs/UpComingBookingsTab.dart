import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/utils/extension.dart';
import 'package:kratEasyApp/utils/throttle_debouncy.dart';
import 'package:kratEasyApp/utils/widgets/common_widgets.dart';
import 'package:lottie/lottie.dart';

import '../../BottomNavScreens/modifyBookingScreen.dart';
import '../../GlobalUtils/app_imports.dart';
import '../../GlobalUtils/common_share.dart';

class UpComingBookingsTab extends StatelessWidget {
  const UpComingBookingsTab({super.key});

  @override
  Widget build(BuildContext context) {

    print("dndnf");
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    return Consumer2<MyBookingsViewModel, AvailableChallengeGuestViewModel>(
      builder: (context, viewModel, availableChallengeGuestViewModel, _) {
        final myBookings = viewModel.myBookingModel.data?.docs
            ?.where((item) => item.status?.toLowerCase() != "completed");
        printLog("upcoming booking length :${myBookings?.length}");

        return Scaffold(
          backgroundColor: Colors.white,
          body: SafeArea(
            child: SingleChildScrollView(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.04),
                child:
                    ((myBookings ?? []).isEmpty &&
                            (viewModel.myChallengeData.data?.docs == null ||
                                viewModel.myChallengeData.data!.docs!.isEmpty))
                        ? Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12.0, vertical: 20),
                            child: Center(
                              child: Lottie.asset(
                                'assets/lottie/no-data.json',
                                width: 300,
                                height: 300,
                                fit: BoxFit.fill,
                                animate: true,
                                repeat: true,
                              ),
                            ),
                          )
                        : Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(height: 20),
                              // List of openings
                              ((myBookings ?? []).isEmpty)
                                  ? Center(child: SizedBox())
                                  : viewModel.isLoading
                                      ? loaderWidget()
                                      : ListView.builder(
                                          padding: EdgeInsets.only(bottom: 8),
                                          shrinkWrap: true,
                                          physics:
                                              NeverScrollableScrollPhysics(),
                                          itemCount: myBookings?.length ?? 0,
                                          itemBuilder: (context, index) {
                                            final booking =
                                                myBookings?.toList()[index];

                                            final bookingDay = booking?.date !=
                                                    null
                                                ? "${DateTime.parse(booking?.date.toString() ?? DateTime.now().toString()).day}"
                                                : "";

                                            final bookingMonthYear = booking
                                                        ?.date !=
                                                    null
                                                ? DateFormat('MMM yyyy').format(
                                                    DateTime.parse(booking?.date
                                                            .toString() ??
                                                        DateTime.now()
                                                            .toString()))
                                                : "";

                                            return Padding(
                                              padding: const EdgeInsets.only(
                                                  bottom: 8.0),
                                              child: GestureDetector(
                                                onTap: context
                                                        .read<HomeViewModel>()
                                                        .loadding
                                                    ? null
                                                    : () {
                                                        TapThrottle.run(
                                                            'courtDetailsTap4',
                                                            () async {
                                                          Provider.of<HomeViewModel>(
                                                                  context,
                                                                  listen: false)
                                                              .getBookingDetails(
                                                                  context:
                                                                      context,
                                                                  bookingId:
                                                                      booking?.sId ??
                                                                          '',
                                                                  courtId: booking
                                                                          ?.court
                                                                          ?.sId ??
                                                                      "");
                                                        });
                                                      },
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                      color: Colors.white,
                                                      border: Border.all(
                                                        color:
                                                            Color(0xffD0D0D0),
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              5)),
                                                  child: Padding(
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            horizontal: 6,
                                                            vertical: 4),
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        IntrinsicHeight(
                                                          child: Row(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .stretch,
                                                            children: [
                                                              SizedBox(
                                                                width: 90,
                                                                child:
                                                                    ClipRRect(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              5),
                                                                  child: NetworkImageWidget(
                                                                      image: booking
                                                                              ?.court
                                                                              ?.image ??
                                                                          "",
                                                                      width: 85,
                                                                      fit: BoxFit
                                                                          .cover),
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                  width: 10),
                                                              Expanded(
                                                                child: Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Text(
                                                                        '#${booking?.bookingId ?? l10n.of(context).na}',
                                                                        style: TextStyle(
                                                                            fontSize: screenWidth *
                                                                                0.035,
                                                                            fontWeight:
                                                                                FontWeight.normal,
                                                                            color: Color(0xFF555555))),
                                                                    SizedBox(
                                                                        height:
                                                                            2),
                                                                    Text(booking?.court?.name?.capitalizeFirstLetter() ?? l10n.of(context).na,
                                                                        style: TextStyle(
                                                                            fontSize:
                                                                                16,
                                                                            fontWeight:
                                                                                FontWeight.w600,
                                                                            color: Colors.black)),
                                                                    SizedBox(
                                                                        height:
                                                                            2),
                                                                    Row(
                                                                      children: [
                                                                        Image.asset(
                                                                            "assets/icons/rate.png",
                                                                            width: screenWidth *
                                                                                0.04,
                                                                            height: screenWidth *
                                                                                0.04,
                                                                            fit:
                                                                                BoxFit.cover),
                                                                        SizedBox(
                                                                            width:
                                                                                8),
                                                                        Text(
                                                                            booking?.court?.averageRating?.toString() ??
                                                                                "0",
                                                                            style: TextStyle(
                                                                                fontSize: screenWidth * 0.035,
                                                                                fontWeight: FontWeight.bold,
                                                                                color: Colors.grey[700])),
                                                                        SizedBox(
                                                                            width:
                                                                                4),
                                                                        Container(
                                                                            width:
                                                                                1,
                                                                            height: screenHeight *
                                                                                0.03,
                                                                            color:
                                                                                const Color(0xFFDD9D9D9)),
                                                                        SizedBox(
                                                                            width:
                                                                                4),
                                                                        Expanded(
                                                                            child: Text(booking?.facility?.name ?? l10n.of(context).na,
                                                                                maxLines: 1,
                                                                                overflow: TextOverflow.ellipsis,
                                                                                style: TextStyle(fontSize: 12, color: Color(0xFF555555)))),
                                                                      ],
                                                                    ),
                                                                    SizedBox(
                                                                        height:
                                                                            6),
                                                                    Row(
                                                                      children: [
                                                                        Image.asset(
                                                                            'assets/icons/location.png',
                                                                            width: screenWidth *
                                                                                0.04,
                                                                            height:
                                                                                screenWidth * 0.04),
                                                                        SizedBox(
                                                                            width:
                                                                                8),
                                                                        Expanded(
                                                                            child: Text(booking?.facility?.address ?? l10n.of(context).na,
                                                                                maxLines: 3,
                                                                                overflow: TextOverflow.ellipsis,
                                                                                style: TextStyle(fontSize: screenWidth * 0.03, color: Color(0xFF555555)))),
                                                                      ],
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                  width: 6),
                                                              Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Text(
                                                                      booking?.startTime
                                                                              ?.toString() ??
                                                                          l10n
                                                                              .of(
                                                                                  context)
                                                                              .na,
                                                                      style: TextStyle(
                                                                          fontSize:
                                                                              11,
                                                                          fontWeight: FontWeight
                                                                              .w700,
                                                                          color:
                                                                              AppColors.black)),
                                                                  SizedBox(
                                                                      height:
                                                                          2),
                                                                  Container(
                                                                    padding: EdgeInsets.symmetric(
                                                                        vertical:
                                                                            2,
                                                                        horizontal:
                                                                            3),
                                                                    decoration: BoxDecoration(
                                                                        color: AppColors
                                                                            .greyGreen63F
                                                                            .withOpacity(
                                                                                .1),
                                                                        borderRadius:
                                                                            BorderRadius.circular(5)),
                                                                    child:
                                                                        Column(
                                                                      children: [
                                                                        Row(
                                                                          children: [
                                                                            SizedBox(
                                                                                height: 21,
                                                                                width: 21,
                                                                                child: Image.asset("assets/icons/calender.png")),
                                                                            SizedBox(width: 3),
                                                                            Text(bookingDay,
                                                                                style: TextStyle(fontSize: 24, fontWeight: FontWeight.w600, color: AppColors.primaryColor)),
                                                                          ],
                                                                        ),
                                                                        Text(
                                                                            bookingMonthYear,
                                                                            style: TextStyle(
                                                                                fontSize: 12,
                                                                                fontWeight: FontWeight.w600,
                                                                                color: AppColors.black555)),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        SizedBox(height: 4),
                                                        Divider(),
                                                        Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            Text.rich(
                                                              TextSpan(
                                                                text: l10n
                                                                    .of(context)
                                                                    .typeOfBooking,
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        screenWidth *
                                                                            0.032,
                                                                    color: Color(
                                                                        0xFF555555)),
                                                                children: [
                                                                  TextSpan(
                                                                      text: booking?.isSplit ==
                                                                              true
                                                                          ? l10n
                                                                              .of(
                                                                                  context)
                                                                              .split
                                                                          : l10n
                                                                              .of(
                                                                                  context)
                                                                              .wholeCourtBooking,
                                                                      style: TextStyle(
                                                                          fontWeight:
                                                                              FontWeight.bold))
                                                                ],
                                                              ),
                                                            ),
                                                            Row(
                                                              children: [
                                                                Image.asset(
                                                                    'assets/icons/amount.png',
                                                                    width:
                                                                        screenWidth *
                                                                            0.05,
                                                                    height:
                                                                        screenWidth *
                                                                            0.05),
                                                                SizedBox(
                                                                    width: screenWidth *
                                                                        0.012),
                                                                Text(
                                                                    "${AppConstants.appCurrency} ${booking?.price}",
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            screenWidth *
                                                                                0.035,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .bold,
                                                                        color: Colors
                                                                            .black)),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                        Divider(),
                                                        Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            Expanded(
                                                              child: Row(
                                                                children: [
                                                                  ClipOval(
                                                                    child:
                                                                        NetworkImageWidget(
                                                                      image: booking
                                                                              ?.sport
                                                                              ?.image ??
                                                                          "",
                                                                      width: 26,
                                                                      height:
                                                                          26,
                                                                      fit: BoxFit
                                                                          .cover,
                                                                    ),
                                                                  ),
                                                                  SizedBox(
                                                                      width: screenWidth *
                                                                          0.012),
                                                                  Text(
                                                                      booking?.sport
                                                                              ?.name ??
                                                                          l10n
                                                                              .of(
                                                                                  context)
                                                                              .na,
                                                                      style: TextStyle(
                                                                          fontSize:
                                                                              14,
                                                                          fontWeight: FontWeight
                                                                              .w700,
                                                                          color:
                                                                              Color(0xFF3B747B))),
                                                                ],
                                                              ),
                                                            ),
                                                            ValueListenableBuilder<
                                                                bool>(
                                                              valueListenable:
                                                              isSharingNotifier,
                                                              builder: (context,
                                                                  isSharing, child) {
                                                                return Container(
                                                                  width: 25,
                                                                  height: 25,
                                                                  decoration:
                                                                  BoxDecoration(
                                                                    color: Color(
                                                                        0xFF8DC63F),
                                                                    shape:
                                                                    BoxShape.circle,
                                                                  ),
                                                                  child: isSharing
                                                                      ? Padding(
                                                                    padding:
                                                                    const EdgeInsets
                                                                        .all(
                                                                        5),
                                                                    child:
                                                                    CircularProgressIndicator(
                                                                      strokeWidth:
                                                                      2,
                                                                      valueColor: AlwaysStoppedAnimation<
                                                                          Color>(
                                                                          Colors
                                                                              .white),
                                                                    ),
                                                                  )
                                                                      : IconButton(
                                                                    onPressed: () =>
                                                                        shareDataNew(
                                                                            'KratEasy.com/${booking?.bookingId}',
                                                                            isSharingNotifier),
                                                                    icon: Image
                                                                        .asset(
                                                                      'assets/icons/share3.png',
                                                                      width: 15,
                                                                      height: 15,
                                                                    ),
                                                                    padding:
                                                                    EdgeInsets
                                                                        .zero,
                                                                  ),
                                                                );
                                                              },
                                                            ),
                                                            SizedBox(width: 6,),
                                                            ElevatedButton(
                                                              onPressed: () {
                                                                Navigator.push(
                                                                    context,
                                                                    MaterialPageRoute(
                                                                        builder:
                                                                            (context) =>
                                                                            ModifyBookingScreen(
                                                                              bookingId:
                                                                              booking?.sId ?? "",

                                                                            )));
                                                              },
                                                              style: ElevatedButton
                                                                  .styleFrom(
                                                                backgroundColor:
                                                                Color(0xFF3B747D),
                                                                foregroundColor:
                                                                Colors.white,
                                                                minimumSize:
                                                                Size(60, 25),
                                                                shape: RoundedRectangleBorder(
                                                                    borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                        4)),
                                                                padding:
                                                                EdgeInsets.zero,
                                                              ),
                                                              child: Text(
                                                                  l10n
                                                                      .of(context)
                                                                      .modify,
                                                                  style: TextStyle(
                                                                      fontSize: 10,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w700)),
                                                            ),
                                                            SizedBox(width: 6,),
                                                            ElevatedButton(
                                                             style: ElevatedButton
                                                                  .styleFrom(
                                                                backgroundColor:
                                                                    Colors.red.shade300,
                                                                foregroundColor:
                                                                Colors.white,
                                                                minimumSize:
                                                                Size(60, 25),
                                                                shape: RoundedRectangleBorder(
                                                                    borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                        4)),
                                                                padding:
                                                                EdgeInsets.zero,
                                                              ),

                                                              onPressed: () {
                                                                showDialog(
                                                                  context:
                                                                      context,
                                                                  builder:
                                                                      (BuildContext
                                                                          context) {
                                                                    return Dialog(
                                                                      backgroundColor:
                                                                          AppColors
                                                                              .white,
                                                                      child:
                                                                          ListView(
                                                                        shrinkWrap:
                                                                            true,
                                                                        physics:
                                                                            NeverScrollableScrollPhysics(),
                                                                        children: [
                                                                          Container(
                                                                            width:
                                                                                double.infinity,
                                                                            padding:
                                                                                EdgeInsets.symmetric(horizontal: 16, vertical: 20),
                                                                            decoration:
                                                                                BoxDecoration(borderRadius: BorderRadius.circular(12)),
                                                                            child:
                                                                                Column(
                                                                              crossAxisAlignment: CrossAxisAlignment.center,
                                                                              children: [
                                                                                SizedBox(height: 100, width: 100, child: Image.asset(AppImages.pngDialogCancel, fit: BoxFit.fill)),
                                                                                SizedBox(height: 10),
                                                                                Text(l10n.of(context).areYouSure, style: TextStyle(color: AppColors.black, fontSize: 20, fontWeight: FontWeight.w600)),
                                                                                SizedBox(height: 10),
                                                                                Text(
                                                                                  l10n.of(context).areYouSureYouWantToCancelThisBookingIf,
                                                                                  textAlign: TextAlign.center,
                                                                                  style: TextStyle(color: AppColors.grey769, fontSize: 16, fontWeight: FontWeight.normal),
                                                                                ),
                                                                                SizedBox(height: 10),
                                                                                Row(
                                                                                  children: [
                                                                                    Stack(
                                                                                      children: [
                                                                                        Container(height: 36, width: 130, decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.green033)),
                                                                                        GestureDetector(
                                                                                          onTap: viewModel.isCancelBookingLoading
                                                                                              ? () {}
                                                                                              : () async{

                                                                                          final result=   await context.read<MyBookingsViewModel>().cancelPayment  (  courtId: booking?.courtId??"",bookingid:booking?.bookingId?? "");
                                                                                          if(result)  Navigator.pushNamed(
                                                                                              context,
                                                                                              '/dashboard',
                                                                                            ).then((_){
                                                                                              // Navigator.pop(context);
                                                                                            });
                                                                                          else
                                                                                            Navigator.pop(context);
                                                                                                  // viewModel.cancelBooking(
                                                                                                  //   bookingId: booking?.sId ?? "",
                                                                                                  //   context: context,
                                                                                                  // );
                                                                                                  // Navigator.pop(context);
                                                                                                },
                                                                                          child: Container(
                                                                                            height: 32,
                                                                                            width: 130,
                                                                                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.primaryColor),
                                                                                            child: Center(
                                                                                              child: viewModel.isCancelBookingLoading
                                                                                                  ? CircularProgressIndicator(
                                                                                                      color: Colors.white,
                                                                                                    )
                                                                                                  : Text(l10n.of(context).yesConfirm, style: TextStyle(color: AppColors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ],
                                                                                    ),
                                                                                    SizedBox(width: 6),
                                                                                    Expanded(
                                                                                      child: AppButton(
                                                                                        borderColor: AppColors.primaryColor,
                                                                                        height: 35,
                                                                                        label: l10n.of(context).cancel,
                                                                                        bgColor: AppColors.white,
                                                                                        textStyle: TextStyle(color: AppColors.primaryColor, fontSize: 12, fontWeight: FontWeight.w600),
                                                                                        onPressed: () {
                                                                                          Navigator.pop(context);
                                                                                        },
                                                                                      ),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    );
                                                                  },
                                                                );
                                                              },
                                                              child: Text(
                                                                  l10n
                                                                      .of(
                                                                          context)
                                                                      .cancel,
                                                                  style: TextStyle(
                                                                      color: Colors
                                                                          .white,
                                                                      fontSize:
                                                                          10,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold)),
                                                            ),
                                                            SizedBox(width: 6,),
                                                            Container(
                                                              padding: EdgeInsets
                                                                  .symmetric(
                                                                  horizontal:
                                                                  6,
                                                                  vertical:
                                                                  6),
                                                              decoration:
                                                              BoxDecoration(
                                                                borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                    4),
                                                                color: Color(
                                                                    0xFF555555),
                                                              ),
                                                              child: Text(
                                                                   l10n
                                                                      .of(
                                                                      context)
                                                                      .viewBookings,
                                                                  style: TextStyle(
                                                                      color: Colors
                                                                          .white,
                                                                      fontSize:
                                                                      10,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w700)),
                                                            ),
                                                          ],
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            );
                                          },
                                        ),

                              SizedBox(height: 16),

// [Challenges]
                              Container(
                                height: 40,
                                width: screenWidth,
                                color: AppColors.primaryColor,
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                  children: [
                                    SizedBox(
                                        height: 12,
                                        width: 78,
                                        child: Image.asset(
                                            "assets/png/png_mltiple_back_arrow.png",
                                            fit: BoxFit.fill)),
                                    Text(l10n.of(context).challenges,
                                        style: TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.w500,
                                            color: AppColors.white)),
                                    SizedBox(
                                        height: 12,
                                        width: 78,
                                        child: Image.asset(
                                            "assets/png/png_multiple_forword_arrrow.png",
                                            fit: BoxFit.fill)),
                                  ],
                                ),
                              ),
                              SizedBox(height: 16),

// List of challenges
                              (viewModel.myChallengeData.data?.docs == null ||
                                      viewModel
                                          .myChallengeData.data!.docs!.isEmpty)
                                  ? SizedBox(
                                      height: 300,
                                      width: double.infinity,
                                      child: Center(
                                          child: Text(
                                              l10n
                                                  .of(context)
                                                  .challengesNotAvailableYet,
                                              style: TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.w600,
                                                  color: AppColors.black555))))
                                  : ListView.builder(
                                      padding: EdgeInsets.only(bottom: 8),
                                      shrinkWrap: true,
                                      physics: NeverScrollableScrollPhysics(),
                                      itemCount: viewModel.myChallengeData.data
                                              ?.docs?.length ??
                                          0,
                                      itemBuilder: (context, index) {
                                        final challengeData = viewModel
                                            .myChallengeData.data?.docs?[index];

                                        return Padding(
                                          padding: const EdgeInsets.only(
                                              bottom: 8.0),
                                          child: GestureDetector(
                                            onTap:
                                                availableChallengeGuestViewModel
                                                        .isLoad
                                                    ? null
                                                    : () {
                                                        availableChallengeGuestViewModel
                                                            .setLoadingChallengeIndex(
                                                                index);
                                                        availableChallengeGuestViewModel
                                                            .getChallengesDetails(
                                                                ispublic:
                                                                    challengeData
                                                                            ?.isPublic ??
                                                                        false,
                                                                cancelChallenge:
                                                                    true,
                                                                challengesId:
                                                                    challengeData
                                                                            ?.id ??
                                                                        "",
                                                                context:
                                                                    context)
                                                            .then((_) {
                                                          availableChallengeGuestViewModel
                                                              .setLoadingChallengeIndex(
                                                                  null);
                                                        });
                                                      },
                                            child: Container(
                                              decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  border: Border.all(
                                                    color: Color(0xffD0D0D0),
                                                  ),
                                                  borderRadius:
                                                      BorderRadius.circular(5)),
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Padding(
                                                    padding: const EdgeInsets
                                                        .symmetric(
                                                        vertical: 4,
                                                        horizontal: 6),
                                                    child: Column(children: [
                                                      IntrinsicHeight(
                                                        child: Row(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .stretch,
                                                          children: [
                                                            SizedBox(
                                                              width: 90,
                                                              child: ClipRRect(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            5),
                                                                child: NetworkImageWidget(
                                                                    image: (challengeData?.court?.image ??
                                                                            "")
                                                                        .toString(),
                                                                    width: 85,
                                                                    fit: BoxFit
                                                                        .fill),
                                                              ),
                                                            ),
                                                            SizedBox(
                                                                width:
                                                                    screenWidth *
                                                                        0.025),
                                                            Expanded(
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Text(
                                                                      (challengeData?.sport?.name ?? l10n.of(context).na)
                                                                          .toString(),
                                                                      style: TextStyle(
                                                                          fontSize:
                                                                              16,
                                                                          fontWeight: FontWeight
                                                                              .w600,
                                                                          color:
                                                                              AppColors.black)),
                                                                  SizedBox(
                                                                      height:
                                                                          2),
                                                                  Text(
                                                                      (challengeData?.court?.name ?? l10n.of(context).na)
                                                                          .toString(),
                                                                      style: TextStyle(
                                                                          fontSize:
                                                                              14,
                                                                          fontWeight: FontWeight
                                                                              .w500,
                                                                          color:
                                                                              AppColors.greyGreen47D)),
                                                                  SizedBox(
                                                                      height:
                                                                          4),
                                                                  SingleChildScrollView(
                                                                    scrollDirection:
                                                                        Axis.horizontal,
                                                                    child: Row(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .center,
                                                                      children: [
                                                                        Image
                                                                            .asset(
                                                                          "assets/png/calender.png",
                                                                          width:
                                                                              screenWidth * 0.04,
                                                                          height:
                                                                              screenWidth * 0.04,
                                                                          fit: BoxFit
                                                                              .cover,
                                                                        ),
                                                                        SizedBox(
                                                                            width:
                                                                                8),

                                                                        /// Date Text
                                                                        Text(
                                                                          formatDateToDayMonthYear(challengeData?.date ??
                                                                              ""),
                                                                          style: TextStyle(
                                                                              fontSize: 11,
                                                                              color: Color(0xFF555555)),
                                                                        ),

                                                                        SizedBox(
                                                                            width:
                                                                                6),

                                                                        /// Vertical Divider
                                                                        Container(
                                                                          width:
                                                                              1,
                                                                          height:
                                                                              screenHeight * 0.02,
                                                                          color:
                                                                              Color(0xFFDD9D9D9),
                                                                        ),

                                                                        SizedBox(
                                                                            width:
                                                                                6),

                                                                        /// Time Text
                                                                        Text(
                                                                          "${challengeData?.startTime} - ${challengeData?.endTime}",
                                                                          style: TextStyle(
                                                                              fontSize: 11,
                                                                              color: Color(0xFF555555)),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  SizedBox(
                                                                      height:
                                                                          4),
                                                                  Row(
                                                                    children: [
                                                                      Image.asset(
                                                                          'assets/icons/location.png',
                                                                          width: screenWidth *
                                                                              0.04,
                                                                          height:
                                                                              screenWidth * 0.04),
                                                                      SizedBox(
                                                                          width:
                                                                              8),
                                                                      Expanded(
                                                                          child: Text(
                                                                              (challengeData?.facility?.address ?? l10n.of(context).na).toString(),
                                                                              maxLines: 3,
                                                                              overflow: TextOverflow.ellipsis,
                                                                              style: TextStyle(fontSize: screenWidth * 0.03, color: Color(0xFF555555)))),
                                                                    ],
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Column(
                                                              children: [
                                                                Container(
                                                                    height: 34,
                                                                    width: 34,
                                                                    decoration: BoxDecoration(
                                                                        shape: BoxShape
                                                                            .circle,
                                                                        border: Border.all(
                                                                            width:
                                                                                1,
                                                                            color: AppColors
                                                                                .primaryColor)),
                                                                    child:
                                                                        Center(
                                                                      child: ClipRRect(
                                                                          borderRadius: BorderRadius.circular(
                                                                              24),
                                                                          child: NetworkImageWidget(
                                                                              height: 24,
                                                                              width: 24,
                                                                              fit: BoxFit.cover,
                                                                              image: (challengeData?.sport?.image ?? '').toString())),
                                                                    )),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Divider(),
                                                      SizedBox(height: 5),
                                                      Stack(
                                                        children: [
                                                          Container(
                                                              height: 6,
                                                              width:
                                                                  screenWidth,
                                                              decoration: BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              3),
                                                                  color: AppColors
                                                                      .grey1E1)),
                                                          Container(
                                                              height: 6,
                                                              width: ((challengeData
                                                                              ?.whoJoined
                                                                              ?.length ??
                                                                          0) /
                                                                      (challengeData
                                                                              ?.maxPlayer ??
                                                                          1)) *
                                                                  screenWidth,
                                                              decoration: BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              3),
                                                                  color: AppColors
                                                                      .greyGreen47D)),
                                                        ],
                                                      ),
                                                      SizedBox(height: 5),
                                                      Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceBetween,
                                                        children: [
                                                          Text(
                                                              "${challengeData?.whoJoinedDetail?.length ?? 0} Player going",
                                                              style: TextStyle(
                                                                  fontSize:
                                                                      screenWidth *
                                                                          0.040,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .normal,
                                                                  color: AppColors
                                                                      .blackA2A)),

                                                          Text(
                                                              "Out of ${challengeData?.maxPlayer ?? 0}",
                                                              style: TextStyle(
                                                                  fontSize:
                                                                      screenWidth *
                                                                          0.040,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .normal,
                                                                  color: AppColors
                                                                      .blackA2A)),

                                                          ////
                                                        ],
                                                      ),
                                                    ]),
                                                  ),
                                                  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    children: [
                                                      CircularImageStack(
                                                          imageUrls: challengeData
                                                                  ?.whoJoinedDetail
                                                                  ?.map((item) =>
                                                                      item.image
                                                                          .toString())
                                                                  .toList() ??
                                                              [],
                                                          maxImages: 4),

                                                      GestureDetector(
                                                        onTap: viewModel
                                                                .isCancelChallengeLoading
                                                            ? () {}
                                                            : () {
                                                                showDialog(
                                                                  context:
                                                                      context,
                                                                  builder:
                                                                      (BuildContext
                                                                          context) {
                                                                    return Dialog(
                                                                      backgroundColor:
                                                                          AppColors
                                                                              .white,
                                                                      child:
                                                                          ListView(
                                                                        shrinkWrap:
                                                                            true,
                                                                        physics:
                                                                            NeverScrollableScrollPhysics(),
                                                                        children: [
                                                                          Container(
                                                                            width:
                                                                                double.infinity,
                                                                            padding:
                                                                                EdgeInsets.symmetric(horizontal: 16, vertical: 20),
                                                                            decoration:
                                                                                BoxDecoration(borderRadius: BorderRadius.circular(12)),
                                                                            child:
                                                                                Column(
                                                                              crossAxisAlignment: CrossAxisAlignment.center,
                                                                              children: [
                                                                                SizedBox(height: 100, width: 100, child: Image.asset(AppImages.pngDialogCancel, fit: BoxFit.fill)),
                                                                                SizedBox(height: 10),
                                                                                Text(l10n.of(context).areYouSure, style: TextStyle(color: AppColors.black, fontSize: 20, fontWeight: FontWeight.w600)),
                                                                                SizedBox(height: 10),
                                                                                Text(
                                                                                  l10n.of(context).areYouSureYouWantToCancelThisChallengeIf,
                                                                                  textAlign: TextAlign.center,
                                                                                  style: TextStyle(color: AppColors.grey769, fontSize: 16, fontWeight: FontWeight.normal),
                                                                                ),
                                                                                SizedBox(height: 10),
                                                                                Row(
                                                                                  children: [
                                                                                    Stack(
                                                                                      children: [
                                                                                        Container(height: 36, width: 130, decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.green033)),
                                                                                        GestureDetector(
                                                                                          onTap: viewModel.isCancelChallengeLoading
                                                                                              ? () {}
                                                                                              : () async{

                                                                                        final result = await context.read<MyBookingsViewModel>().cancelPayment(courtId: challengeData?.court?.id??"", bookingid: challengeData?.booking?.bookingid??"");
                                                                                        if(result){
                                                                                        context.read<MyBookingsViewModel>().cancelChallenge(challengeID:  challengeData?.id ?? "", context: context).then((onValue) {
                                                                                        Navigator.pushNamed(
                                                                                        context,
                                                                                        '/dashboard',
                                                                                        );
                                                                                        });
                                                                                        }
                                                                                        else
                                                                                        Navigator.pop(context);



                                                                                        },

                                                                                              // () {
                                                                                              //     viewModel.cancelChallenge(challengeID: challengeData?.id ?? "", context: context).then((onValue) {
                                                                                              //       Navigator.pop(context);
                                                                                              //     });
                                                                                              //   },
                                                                                          child: Container(
                                                                                            height: 32,
                                                                                            width: 130,
                                                                                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.primaryColor),
                                                                                            child: Center(
                                                                                              child: viewModel.isCancelChallengeLoading
                                                                                                  ? CircularProgressIndicator(
                                                                                                      color: Colors.white,
                                                                                                    )
                                                                                                  : Text(l10n.of(context).yesConfirm, style: TextStyle(color: AppColors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ],
                                                                                    ),

                                                                                    SizedBox(width: 6),
                                                                                    Expanded(
                                                                                      child: AppButton(
                                                                                        borderColor: AppColors.primaryColor,
                                                                                        height: 35,
                                                                                        label: l10n.of(context).cancel,
                                                                                        bgColor: AppColors.white,
                                                                                        textStyle: TextStyle(color: AppColors.primaryColor, fontSize: 12, fontWeight: FontWeight.w600),
                                                                                        onPressed: () {
                                                                                          Navigator.pop(context);
                                                                                        },
                                                                                      ),
                                                                                    ),

                                                                                    // Expanded(
                                                                                    //   child:
                                                                                    //       AppButton(
                                                                                    //     height: 30,
                                                                                    //     label:S.of(context).cancel,
                                                                                    //     bgColor: AppColors.white,
                                                                                    //     textStyle: TextStyle(color: AppColors.black, fontSize: 12, fontWeight: FontWeight.w600),
                                                                                    //     onPressed: () {
                                                                                    //       Navigator.pop(context);
                                                                                    //     },
                                                                                    //   ),
                                                                                    // ),
                                                                                  ],
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    );
                                                                  },
                                                                );
                                                              },
                                                        child: Container(
                                                          padding: EdgeInsets
                                                              .symmetric(
                                                                  horizontal:
                                                                      10,
                                                                  vertical: 5),
                                                          decoration:
                                                              BoxDecoration(
                                                            color:
                                                                AppColors.black,
                                                            borderRadius: BorderRadius.only(
                                                                topLeft: Radius
                                                                    .circular(
                                                                        3),
                                                                bottomLeft: Radius
                                                                    .circular(
                                                                        5),
                                                                bottomRight:
                                                                    Radius
                                                                        .circular(
                                                                            5)),
                                                          ),
                                                          child: Text(
                                                              viewModel
                                                                          .myChallengeData
                                                                          .data
                                                                          ?.docs?[
                                                                              index]
                                                                          .isPublic ==
                                                                      false
                                                                  ? "${AppConstants.appCurrency} ${viewModel.myChallengeData.data?.docs?[index].booking?.price?.toStringAsFixed(2) ?? 0}| ${l10n.of(context).cancel}"
                                                                  : "${AppConstants.appCurrency} ${(viewModel.myChallengeData.data?.docs?[index].booking?.price ?? 0) * viewModel.myChallengeData.data?.docs?[index].maxPlayer} | ${l10n.of(context).cancel}",
                                                              style: TextStyle(
                                                                  fontSize: 14,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w900,
                                                                  color: Colors
                                                                      .white)),
                                                        ),
                                                      ),
                                                      // SizedBox(width: 6,),
                                                      Container(
                                                        padding: EdgeInsets
                                                            .symmetric(
                                                            horizontal:
                                                            6,
                                                            vertical:
                                                            6),
                                                        decoration:
                                                        BoxDecoration(
                                                          borderRadius:
                                                          BorderRadius
                                                              .circular(
                                                              4),
                                                          color: Color(
                                                              0xFF555555),
                                                        ),
                                                        child: Text(
                                                            l10n
                                                                .of(
                                                                context)
                                                                .viewChallenge,
                                                            style: TextStyle(
                                                                color: Colors
                                                                    .white,
                                                                fontSize:
                                                                10,
                                                                fontWeight:
                                                                FontWeight
                                                                    .w700)),
                                                      ),
                                                      SizedBox(width: 6,)
                                                    ],
                                                  )
                                                ],
                                              ),
                                            ),
                                          ),
                                        );
                                      },
                                    ),
                            ],
                          ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class CircularImageStack extends StatelessWidget {
  final List<String> imageUrls;
  final int maxImages;

  const CircularImageStack(
      {Key? key, required this.imageUrls, this.maxImages = 5})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    double overlap = 15;

    List<Widget> imageWidgets = [];
    int extraCount = imageUrls.length - maxImages;

    for (int i = 0;
        i < (imageUrls.length > maxImages ? maxImages : imageUrls.length);
        i++) {
      imageWidgets.add(Positioned(
        left: i * overlap.toDouble(),
        child: CircleAvatar(
          radius: 16,
          backgroundColor: Colors.white,
          child: CircleAvatar(
            radius: 16,
            backgroundColor: Colors.grey[200],
            child: ClipOval(
              child: CachedNetworkImage(
                imageUrl: imageUrls[i],
                width: 32,
                height: 32,
                fit: BoxFit.cover,
                placeholder: (context, url) =>
                    CircularProgressIndicator(strokeWidth: 1),
                errorWidget: (context, url, error) => Image.asset(
                  'assets/png/user_logo.png', // <-- your fallback asset
                  width: 32,
                  height: 32,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
        ),
      )

          // Positioned(
          //     left: i * overlap.toDouble(),
          //     child: CircleAvatar(
          //         radius: 16,
          //         backgroundColor: Colors.white,
          //         child: CircleAvatar(
          //             radius: 16, backgroundImage: NetworkImage(imageUrls[i])))),
          );
    }

    if (extraCount > 0) {
      imageWidgets.add(
        Positioned(
          left: maxImages * overlap.toDouble(),
          child: CircleAvatar(
              radius: 16,
              backgroundColor: Colors.black,
              child: Text("+$extraCount",
                  style: TextStyle(color: Colors.white, fontSize: 16))),
        ),
      );
    }
    return SizedBox(
        height: 35,
        width: ((maxImages + 1) * overlap + 20).toDouble(),
        child: Stack(children: imageWidgets));
  }
}
