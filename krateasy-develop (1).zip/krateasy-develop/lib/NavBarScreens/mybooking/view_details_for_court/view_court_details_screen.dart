// import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
// import 'package:kratEasyApp/generated/l10n.dart';

// import '../../../BottomNavScreens/ChallengeTab/CompletedChallengesTab.dart';

// class ViewCourtDetailsScreen extends StatefulWidget {
//   String? amount;

//   ViewCourtDetailsScreen({super.key, this.amount});

//   @override
//   State<ViewCourtDetailsScreen> createState() => _ViewCourtDetailsScreenState();
// }

// class _ViewCourtDetailsScreenState extends State<ViewCourtDetailsScreen> {
//   @override
//   Widget build(BuildContext context) {
//     double screenWidth = MediaQuery.of(context).size.width;
//     double screenHeight = MediaQuery.of(context).size.height;
//     return Consumer<HomeViewModel>(
//       builder: (BuildContext context, viewModel, Widget? child) {
//         final courtData = viewModel.courtDetailsModel.data;
//         return Scaffold(
//           backgroundColor: AppColors.white,
//           appBar: CommonAppBar(title:S.of(context).viewCourtDetails),
//           floatingActionButtonLocation:
//               FloatingActionButtonLocation.centerFloat,
//           floatingActionButton: Padding(
//             padding: const EdgeInsets.only(left: 16, bottom: 20, right: 16),
//             child: AppButtonCommon(
//               onPressed: () {
//                 showDialog(
//                   context: context,
//                   builder: (BuildContext context) {
//                     return Dialog(
//                       backgroundColor: AppColors.white,
//                       child: ListView(
//                         shrinkWrap: true,
//                         physics: NeverScrollableScrollPhysics(),
//                         children: [
//                           Container(
//                             width: double.infinity,
//                             padding: EdgeInsets.symmetric(
//                                 horizontal: 16, vertical: 20),
//                             decoration: BoxDecoration(
//                                 borderRadius: BorderRadius.circular(12)),
//                             child: Column(
//                               crossAxisAlignment: CrossAxisAlignment.center,
//                               children: [
//                                 SizedBox(
//                                     height: 100,
//                                     width: 100,
//                                     child: Image.asset(
//                                         AppImages.pngDialogCancel,
//                                         fit: BoxFit.fill)),
//                                 SizedBox(height: 10),
//                                 Text( S.of(context).areYouSure,
//                                     style: TextStyle(
//                                         color: AppColors.black,
//                                         fontSize: 20,
//                                         fontWeight: FontWeight.w600)),
//                                 SizedBox(height: 10),
//                                 Text(
//                                S.of(context).areYouSureYouWantToCancelThisBookingIf,
//                                   textAlign: TextAlign.center,
//                                   style: TextStyle(
//                                       color: AppColors.grey769,
//                                       fontSize: 16,
//                                       fontWeight: FontWeight.normal),
//                                 ),
//                                 SizedBox(height: 10),
//                                 Row(
//                                   children: [
//                                     Stack(
//                                       children: [
//                                         Container(
//                                             height: 36,
//                                             width: 130,
//                                             decoration: BoxDecoration(
//                                                 borderRadius:
//                                                     BorderRadius.circular(10),
//                                                 color: AppColors.green033)),
//                                         GestureDetector(
//                                           onTap: () {
//                                             Navigator.pop(context);
//                                             // context.read<MyBookingsViewModel>().cancelBooking(booking?.sId ?? "") ;
//                                           },
//                                           child: Container(
//                                             height: 32,
//                                             width: 130,
//                                             decoration: BoxDecoration(
//                                                 borderRadius:
//                                                     BorderRadius.circular(10),
//                                                 color: AppColors.primaryColor),
//                                             child: Center(
//                                               child: Text(S.of(context).yesConfirm,
//                                                   style: TextStyle(
//                                                       color: AppColors.white,
//                                                       fontSize: 12,
//                                                       fontWeight:
//                                                           FontWeight.w600)),
//                                             ),
//                                           ),
//                                         ),
//                                       ],
//                                     ),
//                                     SizedBox(width: 6),
//                                     Expanded(
//                                       child: AppButton(
//                                         height: 30,
//                                         label:S.of(context).cancel,
//                                         borderColor: AppColors.primaryColor,
//                                         bgColor: AppColors.white,
//                                         textStyle: TextStyle(
//                                             color: AppColors.primaryColor,
//                                             fontSize: 12,
//                                             fontWeight: FontWeight.w600),
//                                         onPressed: () {
//                                           Navigator.pop(context);
//                                         },
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ],
//                       ),
//                     );
//                   },
//                 );
//                 // Navigator.pop(context);
//               },
//               label: S.of(context).cancelBooking,
//             ),
//           ),
//           body: viewModel.isLoading
//               ? Center(
//                   child:
//                       CircularProgressIndicator(color: AppColors.primaryColor))
//               : SafeArea(
//                   child: SingleChildScrollView(
//                     child: Column(
//                       children: [
//                         /// top image data
//                         Stack(
//                           children: [
//                             SizedBox(
//                                 height: screenHeight * .3,
//                                 width: screenWidth,
//                                 child: NetworkImageWidget(
//                                     image: (courtData?.image ?? "").toString(),
//                                     fit: BoxFit.fill)),
//                             Positioned(
//                               left: 40,
//                               bottom: 11,
//                               child: Row(
//                                 children: List.generate(
//                                     courtData?.gallery?.length ?? 0, (index) {
//                                   var imagesUrl =
//                                       (courtData?.gallery?[index] ?? "")
//                                           .toString();
//                                   return Padding(
//                                       padding: const EdgeInsets.only(right: 10),
//                                       child: ClipRRect(
//                                           borderRadius:
//                                               BorderRadius.circular(5),
//                                           child: SizedBox(
//                                               height: 47,
//                                               width: 47,
//                                               child: NetworkImageWidget(
//                                                   image: imagesUrl,
//                                                   fit: BoxFit.fill))));
//                                 }),
//                               ),
//                             )
//                           ],
//                         ),
//                         SizedBox(height: 15),
//                         Padding(
//                           padding: EdgeInsets.all(screenWidth * 0.03),
//                           child: GestureDetector(
//                             onTap: () {
//                               // viewModel.navigateToViewChallengeScreen(context);
//                             },
//                             child: Column(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 // Content of the card
//                                 Row(
//                                   crossAxisAlignment: CrossAxisAlignment.start,
//                                   children: [
//                                     Expanded(
//                                       child: Column(
//                                         crossAxisAlignment:
//                                             CrossAxisAlignment.start,
//                                         children: [
//                                           Text(
//                                               (courtData?.sportId?.name ?? "")
//                                                   .toString(),
//                                               style: TextStyle(
//                                                   fontSize: 20,
//                                                   fontWeight: FontWeight.w600,
//                                                   color: AppColors.black)),
//                                           Text(
//                                               (courtData?.name ?? "")
//                                                   .toString(),
//                                               style: TextStyle(
//                                                   fontSize: 17,
//                                                   fontWeight: FontWeight.w600,
//                                                   color:
//                                                       AppColors.greyGreen47D)),
//                                           SizedBox(
//                                               height: screenHeight * 0.005),
//                                           Row(
//                                             children: [
//                                               Image.asset(
//                                                   "assets/png/calender.png",
//                                                   width: screenWidth * 0.04,
//                                                   height: screenWidth * 0.04,
//                                                   fit: BoxFit.cover),
//                                               SizedBox(
//                                                   width: screenWidth * 0.002),
//                                               Text(
//                                                   " ${DateFormat('dd MMM, yyyy').format(DateTime.parse((courtData?.bookings?.date ?? "2025-04-29T00:00:00.000Z").toString()).toLocal())}",
//                                                   style: TextStyle(
//                                                       fontSize:
//                                                           screenWidth * 0.033,
//                                                       fontWeight:
//                                                           FontWeight.normal,
//                                                       color:
//                                                           Color(0xFF555555))),
//                                               SizedBox(
//                                                   width: screenWidth * 0.007),
//                                               Container(
//                                                   width: 1,
//                                                   height: screenHeight * 0.03,
//                                                   color: Color(0xFFDD9D9D9)),
//                                               SizedBox(
//                                                   width: screenWidth * 0.007),
//                                               Text(
//                                                   " ${courtData?.bookings?.startTime ?? ""} - ${courtData?.bookings?.endTime ?? ""}",
//                                                   style: TextStyle(
//                                                       fontSize:
//                                                           screenWidth * 0.033,
//                                                       fontWeight:
//                                                           FontWeight.normal,
//                                                       color:
//                                                           Color(0xFF555555))),
//                                             ],
//                                           ),
//                                           SizedBox(
//                                               height: screenHeight * 0.005),
//                                           Row(
//                                             children: [
//                                               Image.asset(
//                                                   "assets/icons/rate.png",
//                                                   width: screenWidth * 0.04,
//                                                   height: screenWidth * 0.04,
//                                                   fit: BoxFit.cover),
//                                               SizedBox(
//                                                   width: screenWidth * 0.009),
//                                               Text(
//                                                   " ${courtData?.averageRating ?? 0}",
//                                                   style: TextStyle(
//                                                       fontSize: 16,
//                                                       fontWeight:
//                                                           FontWeight.w700,
//                                                       color:
//                                                           Color(0xFF555555))),
//                                               SizedBox(
//                                                   width: screenWidth * 0.009),
//                                               Container(
//                                                   width: 1,
//                                                   height: screenHeight * 0.03,
//                                                   color: Color(0xFFDD9D9D9)),
//                                               SizedBox(
//                                                   width: screenWidth * 0.009),
//                                               Text(
//                                                   "${courtData?.totalBookings ?? 1}+ Bookings",
//                                                   style: TextStyle(
//                                                       fontSize:
//                                                           screenWidth * 0.033,
//                                                       fontWeight:
//                                                           FontWeight.normal,
//                                                       color:
//                                                           Color(0xFF555555))),
//                                             ],
//                                           ),
//                                           SizedBox(
//                                               height: screenHeight * 0.005),
//                                         ],
//                                       ),
//                                     ),
//                                     Container(
//                                       height: 60,
//                                       width: 60,
//                                       decoration: BoxDecoration(
//                                           shape: BoxShape.circle,
//                                           border: Border.all(
//                                               width: 1,
//                                               color: AppColors.primaryColor)),
//                                       child: courtData?.sportId?.image != null
//                                           ? Center(
//                                               child: ClipRRect(
//                                                   borderRadius:
//                                                       BorderRadius.circular(35),
//                                                   child: NetworkImageWidget(
//                                                       image: (courtData?.sportId
//                                                                   ?.image ??
//                                                               "")
//                                                           .toString(),
//                                                       width: 35,
//                                                       height: 35,
//                                                       fit: BoxFit.cover)),
//                                             )
//                                           : Center(
//                                               child: ClipRRect(
//                                                   borderRadius:
//                                                       BorderRadius.circular(35),
//                                                   child: Image.asset(
//                                                       "assets/icons/sportsicon.png",
//                                                       fit: BoxFit.fill,
//                                                       width: 35,
//                                                       height: 35))),
//                                     ),
//                                   ],
//                                 ),
//                                 SizedBox(height: screenHeight * 0.005),
//                                 Row(
//                                   crossAxisAlignment: CrossAxisAlignment.start,
//                                   children: [
//                                     Image.asset('assets/icons/location.png',
//                                         width: screenWidth * 0.045,
//                                         height: screenWidth * 0.045),
//                                     SizedBox(width: screenWidth * 0.002),
//                                     Expanded(
//                                         child: Text(
//                                             " ${(courtData?.facilityId?.address ?? "").toString()}",
//                                             style: TextStyle(
//                                                 fontSize: screenWidth * 0.033,
//                                                 color: Color(0xFF555555)))),
//                                     Image.asset('assets/icons/coins.png',
//                                         width: screenWidth * 0.045,
//                                         height: screenWidth * 0.045,
//                                         color: AppColors.black),
//                                     SizedBox(width: screenWidth * 0.009),
//                                     Text(
//                                         "${AppConstants.appCurrency} ${(widget.amount ?? "0").toString()}/hr",
//                                         style: TextStyle(
//                                             fontSize: 18,
//                                             fontWeight: FontWeight.w600,
//                                             color: AppColors.black)),
//                                   ],
//                                 ),
//                                 SizedBox(height: screenHeight * 0.005),
//                                 Row(
//                                   children: [
//                                     Image.asset(AppImages.pngCourtBooking,
//                                         width: screenWidth * 0.045,
//                                         height: screenWidth * 0.045),
//                                     SizedBox(width: screenWidth * 0.002),
//                                     Text(S.of(context).courtBooking,
//                                         style: TextStyle(
//                                             fontSize: screenWidth * 0.033,
//                                             color: Color(0xFF555555))),
//                                     Spacer(),
//                                     SizedBox(width: screenWidth * 0.002),
//                                     Text(
//                                         courtData?.bookings?.isSplit == true
//                                             ?S.of(context).split 
//                                             : S.of(context).fullPaid,
//                                         style: TextStyle(
//                                             fontSize: 14,
//                                             fontWeight: FontWeight.w400,
//                                             color: AppColors.black)),
//                                   ],
//                                 ),
//                                 Divider(),
//                                 SizedBox(height: 5),
//                                 Stack(
//                                   children: [
//                                     Container(
//                                         height: 6,
//                                         width: screenWidth,
//                                         decoration: BoxDecoration(
//                                             borderRadius:
//                                                 BorderRadius.circular(3),
//                                             color: AppColors.grey1E1)),
//                                     Container(
//                                         height: 6,
//                                         width: (9 / 12) * screenWidth,
//                                         decoration: BoxDecoration(
//                                             borderRadius:
//                                                 BorderRadius.circular(3),
//                                             color: AppColors.greyGreen47D)),
//                                   ],
//                                 ),
//                                 SizedBox(height: 5),
//                                 Row(
//                                   mainAxisAlignment:
//                                       MainAxisAlignment.spaceBetween,
//                                   children: [
//                                     Expanded(
//                                       child: Row(
//                                         mainAxisAlignment:
//                                             MainAxisAlignment.spaceBetween,
//                                         crossAxisAlignment:
//                                             CrossAxisAlignment.start,
//                                         children: [
//                                           Column(
//                                             crossAxisAlignment:
//                                                 CrossAxisAlignment.start,
//                                             children: [
//                                               Text( "9 ${S.of(context).playerGoing}",
//                                                   style: TextStyle(
//                                                       fontSize:
//                                                           screenWidth * 0.040,
//                                                       fontWeight:
//                                                           FontWeight.normal,
//                                                       color:
//                                                           AppColors.blackA2A)),
//                                               Center(
//                                                   child: CircularImageStack(
//                                                       imageUrls: [
//                                                     "https://randomuser.me/api/portraits/men/1.jpg",
//                                                     "https://randomuser.me/api/portraits/men/1.jpg"
//                                                   ],
//                                                       maxImages: 4)),
//                                             ],
//                                           ),
//                                           Text("${S.of(context).outOf} 12",
//                                               style: TextStyle(
//                                                   fontSize: screenWidth * 0.040,
//                                                   fontWeight: FontWeight.normal,
//                                                   color: AppColors.blackA2A)),
//                                         ],
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ),
//                         Divider(),
//                         Padding(
//                           padding: EdgeInsets.symmetric(
//                               horizontal: screenWidth * 0.04),
//                           child: Column(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               RichText(
//                                 text: TextSpan(
//                                   children: [
//                                     TextSpan(
//                                         text: S.of(context).description,
//                                         style: TextStyle(
//                                             fontSize: 15,
//                                             fontWeight: FontWeight.w600,
//                                             color: AppColors.black555)),
//                                     TextSpan(
//                                       text:
//                                           "Premier racquets club hosting WTA Rothesay Classic; renowned for tennis & squash excellence.",
//                                       style: TextStyle(
//                                           fontSize: 15,
//                                           fontWeight: FontWeight.w400,
//                                           color: AppColors.black555),
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                               SizedBox(height: 7),
//                               Text(S.of(context).amenities,
//                                   style: TextStyle(
//                                       fontWeight: FontWeight.w600,
//                                       fontSize: 18,
//                                       color: AppColors.black555)),
//                               SizedBox(height: 7),
//                               Row(
//                                 children: [
//                                   CommonAmenities(
//                                       text: 'Fitness Suite',
//                                       image: AppImages.pngGym),
//                                   CommonAmenities(
//                                       text: 'Swimming Pools',
//                                       image: AppImages.pngSwiming),
//                                   // CommonAmenities(text: 'Bar & Bistro', image: AppImages.pngBar),
//                                 ],
//                               ),
//                               SizedBox(height: 7),
//                               Text("Rules : ",
//                                   style: TextStyle(
//                                       fontWeight: FontWeight.w600,
//                                       fontSize: 18,
//                                       color: AppColors.black555)),
//                               SizedBox(height: 7),
//                               CommonRules(
//                                   text:
//                                       'Wear proper sports attire & non-marking shoes.'),
//                               CommonRules(
//                                   text:
//                                       'Courts are available for members and guests.'),
//                               CommonRules(
//                                   text:
//                                       'Be respectful to staff and other players.'),
//                               SizedBox(height: 20)
//                             ],
//                           ),
//                         ),
//                         Stack(
//                           children: [
//                             SizedBox(
//                                 height: screenHeight * .3,
//                                 width: screenWidth,
//                                 child: Image.asset(AppImages.pngMap,
//                                     fit: BoxFit.fill)),
//                             Positioned(
//                                 left: (screenWidth - 20) / 2,
//                                 top: (screenHeight * .06),
//                                 child: SizedBox(
//                                     width: 46,
//                                     height: 53,
//                                     child: Image.asset(
//                                         AppImages.pngLocationGreen,
//                                         fit: BoxFit.fill))),
//                             Positioned(
//                               bottom: 18,
//                               left: screenWidth * 0.04,
//                               right: screenWidth * 0.04,
//                               child: Container(
//                                 height: 52,
//                                 padding: EdgeInsets.symmetric(horizontal: 10),
//                                 width: double.infinity,
//                                 decoration: BoxDecoration(
//                                     color: Colors.white,
//                                     borderRadius: BorderRadius.circular(5)),
//                                 child: Row(
//                                   children: [
//                                     SizedBox(
//                                         width: 17,
//                                         height: 17,
//                                         child: Image.asset(
//                                             AppImages.pngLocationGrey,
//                                             fit: BoxFit.fill)),
//                                     Text(' Edgbaston, Birmingham',
//                                         style: TextStyle(
//                                             fontSize: 16,
//                                             fontWeight: FontWeight.normal,
//                                             color: AppColors.black555)),
//                                     Spacer(),
//                                     SizedBox(
//                                         width: 24,
//                                         height: 24,
//                                         child: Image.asset(
//                                             AppImages.pngLocationCircle,
//                                             fit: BoxFit.fill)),
//                                   ],
//                                 ),
//                               ),
//                             ),
//                           ],
//                         ),
//                         SizedBox(height: 100),
//                       ],
//                     ),
//                   ),
//                 ),
//         );
//       },
//     );
//   }
// }
