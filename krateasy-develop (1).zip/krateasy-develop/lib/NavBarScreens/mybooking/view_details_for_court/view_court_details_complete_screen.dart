// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:kratEasyApp/EntranceScreens/guest_booking.dart';
import 'package:kratEasyApp/GlobalUtils/RuleItem.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/Models/facilities_model.dart';
import 'package:kratEasyApp/ViewModel/BottomNavViewModels/HomeViewModel.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/utils/extension.dart';
import 'package:kratEasyApp/utils/widgets/common_widgets.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../Localization/locale_provider.dart';
import '../../MyBookingTabs/UpComingBookingsTab.dart';

class ViewCourtDetailsCompleteScreen extends StatefulWidget {
  String? ID;
  bool? isChallenge;
  String? starttime;
  String? endtime;
  bool? isRebook;
  ViewCourtDetailsCompleteScreen(
      {super.key,
      this.ID,
      this.isChallenge,
      this.isRebook,
      this.endtime,
      this.starttime});

  @override
  State<ViewCourtDetailsCompleteScreen> createState() =>
      _ViewCourtDetailsCompleteScreenState();
}

class _ViewCourtDetailsCompleteScreenState
    extends State<ViewCourtDetailsCompleteScreen> {
  GoogleMapController? mapController;
  LatLng? _center;

  // final LatLng _center = const LatLng(28.6139, 77.2090);
  final Set<Marker> _markers = {};

  void _onMapCreated(GoogleMapController controller) {
    if (_center == null) return;

    mapController = controller;

    setState(() {
      _markers.add(
        Marker(
          markerId: MarkerId('api_marker'),
          position: _center!,
          infoWindow: InfoWindow(title: 'Court Location'),
        ),
      );
    });
  }

  @override
  void initState() {
    super.initState();
    // Simulate fetching lat/lng from API
    WidgetsBinding.instance.addPostFrameCallback((_) async{
      // _loadSavedData();
      final viewModel1 = context.read<HomeViewModel>();
      viewModel1.setRebookTextUpdate(widget.isRebook ?? false);
      if (widget.ID != null) {
        viewModel1.getCourtDetails(courtId: widget.ID!, context: context);
      }
      final dynamic latRaw =
          viewModel1.courtDetailsModel.data?.facilityId?.latitude;
      final dynamic lngRaw =
          viewModel1.courtDetailsModel.data?.facilityId?.longitude;

      final lat =
          latRaw is String ? double.tryParse(latRaw) : latRaw as double?;
      final lng =
          lngRaw is String ? double.tryParse(lngRaw) : lngRaw as double?;

      if (lat != null && lng != null) {
        _center = LatLng(lat, lng);
        _updateMapLocation(_center!);
      }
    });
  }
  // String? savedValue;
  // Future<void> _loadSavedData() async {
  //   final prefs = await SharedPreferences.getInstance();
  //   setState(() {
  //     savedValue = prefs.getString('language_code'); // 👈 key used while saving
  //   });
  // }

  void _updateMapLocation(LatLng target) {
    if (mapController != null) {
      mapController!.animateCamera(CameraUpdate.newCameraPosition(
        CameraPosition(target: target, zoom: 15),
      ));
    }

    setState(() {
      _markers.clear();
      _markers.add(
        Marker(
          markerId: MarkerId('api_marker'),
          position: target,
          infoWindow: InfoWindow(title: 'Court Location'),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    // final viewModel = Provider.of<MyBookingsViewModel>(context);
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    final likeCourt = Provider.of<HomeViewModel>(context, listen: false);
    return Scaffold(
      backgroundColor: AppColors.white,
      appBar: CommonAppBar(title: l10n.of(context).viewCourtDetails, action: [
        Consumer<HomeViewModel>(
            builder: (BuildContext context, courtModelData, Widget? child) {
          return IconButton(
              onPressed: () {
                likeCourt.addCourtToFavouriteApi(
                    context: context,
                    courtId: likeCourt.courtDetailsModel.data?.id ?? "");
                // Navigator.of(context).pop();
              },
              icon: Icon(
                Icons.favorite,
                color: likeCourt.courtDetailsModel.data?.isFavorite! ?? false
                    ? AppColors.primaryColor
                    : AppColors.grey1E1,
              ));
        })
      ]),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: likeCourt.isCourtDetail
          ? SizedBox()
          : widget.isChallenge == true
              ? SizedBox()
              : Padding(
                  padding:
                      const EdgeInsets.only(left: 16, right: 16, bottom: 20),
                  child: AppButtonCommon(
                    onPressed: () {
                      context.read<BookingProvider>().setownerid(likeCourt.courtDetailsModel.data?.facilityOwnerId??"");
                      // likeCourt.setRebookTextUpdate(false);
                      likeCourt.setRebookTextUpdate(widget.isRebook ?? false);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => GuestBookingScreen(
                            courtId: likeCourt.courtDetailsModel.data?.id ?? "",
                            date: DateFormat('dd-MM-yyyy').format(
                                DateTime.now()), // use the formatted date
                            facilityId: likeCourt
                                    .courtDetailsModel.data?.facilityId?.id ??
                                "",
                            selectedTimeSlots: [],
                          ),
                        ),
                      );
                    },
                    label: likeCourt.rebookTextUpdate
                        ? l10n.of(context).quickRebook
                        : l10n.of(context).bookNow,
                  ),
                ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Consumer<HomeViewModel>(
            builder: (BuildContext context, courtModelData, Widget? child) {
              var courtData = courtModelData.courtDetailsModel.data;

              final finalCourt = Courts(
                id: courtData?.name ?? 'Unknown',
                name:
                context.read<LocaleProvider>().locale.languageCode =="el" ? courtData?.grname??"": courtData?.name ?? 'Unknown Court',
              );
              context
                  .read<BookingProvider>()
                  .storeCourtId(cortId: finalCourt.id.toString());
              context
                  .read<FacilitiesViewModel>()
                  .updateSelectedCourt(finalCourt);
              return courtModelData.isCourtDetail
                  ? DetailScreenShimmer()
                  // SizedBox(
                  //     height: MediaQuery.of(context).size.height * .85,
                  //     child: Center(
                  //         child: CircularProgressIndicator(
                  //             color: AppColors.primaryColor)))
                  : Column(
                      children: [
                        Stack(
                          children: [
                            SizedBox(
                                height: screenHeight * .3,
                                width: screenWidth,
                                child: NetworkImageWidget(
                                    image: (courtData?.image ?? "").toString(),
                                    fit: BoxFit.cover)),
                            Positioned(
                              left: 40,
                              bottom: 11,
                              child: Row(
                                children: List.generate(
                                    courtData?.gallery?.length ?? 0, (index) {
                                  var images =
                                      (courtData?.gallery?[index].images ?? "")
                                          .toString();
                                  return Padding(
                                    padding: const EdgeInsets.only(right: 10),
                                    child: ClipRRect(
                                        borderRadius: BorderRadius.circular(5),
                                        child: SizedBox(
                                            height: 47,
                                            width: 47,
                                            child: NetworkImageWidget(
                                                image: images,
                                                fit: BoxFit.fill))),
                                  );
                                }),
                              ),
                            ),
                          ],
                        ),

                        SizedBox(height: 15),
                        Padding(
                          padding: EdgeInsets.all(screenWidth * 0.03),
                          child: GestureDetector(
                            onTap: () {
                              // viewModel.navigateToViewChallengeScreen(context);
                            },
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Content of the card
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          // Text(
                                          //     "#${(courtData?.bookings?.bookingId ?? '').toString()}",
                                          //     style: TextStyle(
                                          //         fontSize: 18,
                                          //         fontWeight: FontWeight.w600,
                                          //         color: AppColors.black555)),
                                          Text(
                                              context.read<LocaleProvider>().locale.languageCode =="el" ?(courtData?.grname ?? ""):(courtData?.name ?? "")
                                                  .toString()
                                                  .capitalizeFirstLetter(),
                                              style: TextStyle(
                                                  fontSize: 22,
                                                  fontWeight: FontWeight.w600,
                                                  color: AppColors.black)),
                                          SizedBox(
                                              height: screenHeight * 0.005),
                                          Row(
                                            children: [
                                              Image.asset(
                                                  "assets/png/calender.png",
                                                  width: screenWidth * 0.04,
                                                  height: screenWidth * 0.04,
                                                  fit: BoxFit.cover),
                                              SizedBox(
                                                  width: screenWidth * 0.01),
                                              Text(
                                                  DateFormat("dd MMM, yyyy")
                                                      .format(DateTime.parse(
                                                          DateTime.now()
                                                              .toString())),
                                                  style: TextStyle(
                                                      fontSize:
                                                          screenWidth * 0.033,
                                                      fontWeight:
                                                          FontWeight.normal,
                                                      color:
                                                          Color(0xFF555555))),
                                              // Text(
                                              //     DateFormat("dd MMM, yyyy").format(
                                              //         DateTime.parse((courtData
                                              //                     ?.bookings
                                              //                     ?.date ??
                                              //                 "2025-04-04T00:00:00.000Z")
                                              //             .toString())),
                                              //     style: TextStyle(
                                              //         fontSize:
                                              //             screenWidth * 0.033,
                                              //         fontWeight:
                                              //             FontWeight.normal,
                                              //         color:
                                              //             Color(0xFF555555))),

                                              // SizedBox(
                                              //     width: screenWidth * 0.007),
                                              // Container(
                                              //     width: 1,
                                              //     height: screenHeight * 0.03,
                                              //     color: Color(0xFFDD9D9D9)),
                                              // SizedBox(
                                              //     width: screenWidth * 0.007),

                                              // Text(
                                              //     // " ${widget.starttime.toString()} - ${(widget?.endtime ?? "").toString()}",
                                              //     // " ${widget.starttime.toString()} - ${(courtData?.bookings?.endTime ?? "").toString()}",
                                              //     style: TextStyle(
                                              //         fontSize:
                                              //             screenWidth * 0.033,
                                              //         fontWeight:
                                              //             FontWeight.normal,
                                              //         color:
                                              //             Color(0xFF555555))),
                                            ],
                                          ),
                                          SizedBox(
                                              height: screenHeight * 0.005),
                                          Row(
                                            children: [
                                              Image.asset(
                                                  "assets/icons/rate.png",
                                                  width: screenWidth * 0.04,
                                                  height: screenWidth * 0.04,
                                                  fit: BoxFit.cover),
                                              SizedBox(
                                                  width: screenWidth * 0.009),
                                              Text(
                                                  (courtData?.averageRating ??
                                                          "")
                                                      .toString(),
                                                  style: TextStyle(
                                                      fontSize: 16,
                                                      fontWeight:
                                                          FontWeight.w700,
                                                      color:
                                                          Color(0xFF555555))),
                                              SizedBox(
                                                  width: screenWidth * 0.009),
                                              Container(
                                                  width: 1,
                                                  height: screenHeight * 0.03,
                                                  color: Color(0xFFDD9D9D9)),
                                              SizedBox(
                                                  width: screenWidth * 0.009),
                                              Text(
                                                  " ${(courtData?.totalBookings ?? "").toString()}+ ${l10n.of(context).booking}",
                                                  style: TextStyle(
                                                      fontSize:
                                                          screenWidth * 0.033,
                                                      fontWeight:
                                                          FontWeight.normal,
                                                      color:
                                                          Color(0xFF555555))),
                                            ],
                                          ),
                                          SizedBox(
                                              height: screenHeight * 0.005),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      height: 60,
                                      width: 60,
                                      decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          border: Border.all(
                                              width: 1,
                                              color: AppColors.primaryColor)),
                                      child: courtData?.sportId?.image != null
                                          ? Center(
                                              child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(35),
                                                  child: NetworkImageWidget(
                                                      image: (courtData?.sportId
                                                                  ?.image ??
                                                              "")
                                                          .toString(),
                                                      width: 35,
                                                      height: 35,
                                                      fit: BoxFit.cover)),
                                            )
                                          : Center(
                                              child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(35),
                                                  child: Image.asset(
                                                      "assets/icons/sportsicon.png",
                                                      fit: BoxFit.fill,
                                                      width: 35,
                                                      height: 35))),
                                    ),
                                  ],
                                ),
                                SizedBox(height: screenHeight * 0.005),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Image.asset('assets/icons/location.png',
                                        width: screenWidth * 0.045,
                                        height: screenWidth * 0.045),
                                    SizedBox(width: screenWidth * 0.002),
                                    Expanded(
                                        child: Text(
                                            " ${(courtData?.facilityId?.address ?? "").toString()}",
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                                fontSize: screenWidth * 0.033,
                                                color: Color(0xFF555555)))),
                                    Image.asset('assets/icons/coins.png',
                                        width: screenWidth * 0.045,
                                        height: screenWidth * 0.05,
                                        color: AppColors.black),
                                    SizedBox(width: screenWidth * 0.009),
                                    Text(
                                      "${AppConstants.appCurrency} ${(courtData?.price ?? courtData?.slotsData?.firstOrNull?.price ?? 0).toString()}",
                                      style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w600,
                                          color: AppColors.black),
                                      textAlign: TextAlign.center,
                                    ),
                                  ],
                                ),
                                SizedBox(height: screenHeight * 0.005),
                                Row(
                                  children: [
                                    Image.asset(AppImages.pngCourtBooking,
                                        width: screenWidth * 0.045,
                                        height: screenWidth * 0.045),
                                    SizedBox(width: screenWidth * 0.002),
                                    Text(l10n.of(context).courtBooking,
                                        style: TextStyle(
                                            fontSize: screenWidth * 0.033,
                                            color: Color(0xFF555555))),
                                    Spacer(),
                                    SizedBox(width: screenWidth * 0.002),
                                  ],
                                ),
                                // if ((courtData?.bookings?.friends?.isNotEmpty ??
                                //         false) &&
                                //     courtData?.bookings?.friends != null)
                                //   Column(
                                //     children: [
                                //       Divider(),
                                //       SizedBox(height: 5),
                                //       Stack(
                                //         children: [
                                //           Container(
                                //               height: 6,
                                //               width: screenWidth,
                                //               decoration: BoxDecoration(
                                //                   borderRadius:
                                //                       BorderRadius.circular(3),
                                //                   color: AppColors.grey1E1)),
                                //           Container(
                                //               height: 6,
                                //               width: (9 / 12) * screenWidth,
                                //               decoration: BoxDecoration(
                                //                   borderRadius:
                                //                       BorderRadius.circular(3),
                                //                   color:
                                //                       AppColors.greyGreen47D)),
                                //         ],
                                //       ),
                                //       SizedBox(height: 5),
                                //       Row(
                                //         mainAxisAlignment:
                                //             MainAxisAlignment.spaceBetween,
                                //         children: [
                                //           Expanded(
                                //             child: Row(
                                //               mainAxisAlignment:
                                //                   MainAxisAlignment
                                //                       .spaceBetween,
                                //               crossAxisAlignment:
                                //                   CrossAxisAlignment.start,
                                //               children: [
                                //                 Column(
                                //                   crossAxisAlignment:
                                //                       CrossAxisAlignment.start,
                                //                   children: [
                                //                     Text(
                                //                         " ${S.of(context).playerGoing}",
                                //                         style: TextStyle(
                                //                             fontSize:
                                //                                 screenWidth *
                                //                                     0.040,
                                //                             fontWeight:
                                //                                 FontWeight
                                //                                     .normal,
                                //                             color: AppColors
                                //                                 .blackA2A)),
                                //                     Center(
                                //                         child: CircularImageStack(
                                //                             imageUrls:
                                //                                 courtModelData
                                //                                     .imageUrlss,
                                //                             maxImages: courtData
                                //                                     ?.bookings
                                //                                     ?.friends
                                //                                     ?.length ??
                                //                                 0)),
                                //                   ],
                                //                 ),
                                //                 Text("${S.of(context).outOf} ",
                                //                     style: TextStyle(
                                //                         fontSize:
                                //                             screenWidth * 0.040,
                                //                         fontWeight:
                                //                             FontWeight.normal,
                                //                         color: AppColors
                                //                             .blackA2A)),
                                //               ],
                                //             ),
                                //           ),
                                //         ],
                                //       ),
                                //     ],
                                //   ),
                              ],
                            ),
                          ),
                        ),
                        Divider(),
                        Container(
                          width: MediaQuery.of(context).size.width,
                          padding: EdgeInsets.symmetric(horizontal: 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              RichText(
                                text: TextSpan(
                                  children: [
                                    TextSpan(
                                        text:  l10n.of(context).description,
                                        style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.w600,
                                            color: AppColors.black555)),
                                    TextSpan(
                                      text:
                                       context.read<LocaleProvider>().locale.languageCode =="el" ? (courtData?.facilityId?.grdescription ?? ""):  (courtData?.facilityId?.description ??
                                                  "")
                                              .toString(),
                                      style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400,
                                          color: AppColors.black555),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: 7),
                              Text(l10n.of(context).amenities,
                                  style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 18,
                                      color: AppColors.black555)),
                              SizedBox(height: 7),
                              SizedBox(
                                height: 100,
                                child: SingleChildScrollView(
                                  scrollDirection: Axis.horizontal,
                                  child: Row(
                                    children: List.generate(
                                        courtData?.facilityId?.amenities
                                                ?.length ??
                                            0, (index) {
                                      var amenities = courtData
                                          ?.facilityId?.amenities?[index];
                                      return Padding(
                                        padding:
                                            const EdgeInsets.only(right: 10),
                                        child: CommonAmenities(
                                            text:  context.read<LocaleProvider>().locale.languageCode =="el" ?(amenities?.grname ?? "").toString() :(amenities?.name ?? "")
                                                .toString(),
                                            image: (amenities?.image ?? "")
                                                .toString()),
                                      );
                                    }),
                                  ),
                                ),
                              ),
                              SizedBox(height: 7),
                              Text(l10n.of(context).rules,
                                  style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 18,
                                      color: AppColors.black555)),
                              SizedBox(height: 7),
                              RuleList(
                                  text: context.read<LocaleProvider>().locale.languageCode =="el" ?(courtData?.facilityId?.grbio ?? "").toString() :(courtData?.facilityId?.bio ?? "")
                                      .toString()),
                              SizedBox(height: 20),
                              // if ((courtData?.bookings?.friends?.isNotEmpty ??
                              //         false) &&
                              //     courtData?.bookings?.friends != null)
                              //   SizedBox(
                              //     height: 180,
                              //     child: ListView.builder(
                              //       itemCount:
                              //           courtData?.bookings?.friends?.length ??
                              //               0,
                              //       scrollDirection: Axis.horizontal,
                              //       itemBuilder: (context, index) {
                              //         var item =
                              //             courtData?.bookings?.friends?[index];
                              //         return Padding(
                              //           padding:
                              //               const EdgeInsets.only(right: 15),
                              //           child: Column(
                              //             children: [
                              //               Stack(
                              //                 children: [
                              //                   ClipRRect(
                              //                       borderRadius:
                              //                           BorderRadius.circular(
                              //                               80),
                              //                       child: Image.asset(
                              //                           AppImages.pngUser,
                              //                           width: 70,
                              //                           height: 70)),
                              //                   Positioned(
                              //                     top: 0,
                              //                     right: 0,
                              //                     child: Container(
                              //                       height: 25,
                              //                       width: 25,
                              //                       decoration: BoxDecoration(
                              //                           shape: BoxShape.circle,
                              //                           color: AppColors
                              //                               .primaryColor),
                              //                       child: Center(
                              //                           child: Image.asset(
                              //                               AppImages
                              //                                   .pngRightClick,
                              //                               width: 16,
                              //                               height: 16)),
                              //                     ),
                              //                   ),
                              //                 ],
                              //               ),
                              //               SizedBox(height: 5),
                              //               Text(item?.name ?? "",
                              //                   style: TextStyle(
                              //                       fontSize: 13,
                              //                       fontWeight: FontWeight.w500,
                              //                       color: AppColors.black555)),
                              //               SizedBox(height: 16),
                              //               Text('${AppConstants.appCurrency}${item?.splitAmount ?? ""}',
                              //                   style: TextStyle(
                              //                       fontSize: 20,
                              //                       fontWeight: FontWeight.w500,
                              //                       color: AppColors.black)),
                              //             ],
                              //           ),
                              //         );
                              //       },
                              //     ),
                              //   ),
                            ],
                          ),
                        ),
                        Stack(
                          children: [
                            SizedBox(
                              height: screenHeight * .3,
                              width: screenWidth,
                              child: _center == null
                                  ? Center(child: CircularProgressIndicator())
                                  : GoogleMap(
                                      mapType: MapType.normal,
                                      onMapCreated: _onMapCreated,
                                      initialCameraPosition: CameraPosition(
                                          target: _center!, zoom: 14),
                                      markers: _markers,
                                      myLocationEnabled: true,
                                      myLocationButtonEnabled: true,
                                      zoomGesturesEnabled: true,
                                      scrollGesturesEnabled: true,
                                      tiltGesturesEnabled: true,
                                      rotateGesturesEnabled: true,
                                    ),
                            ),
                            Positioned(
                              bottom: 18,
                              left: screenWidth * 0.04,
                              right: screenWidth * 0.04,
                              child: GestureDetector(
                                onTap: () {
                                  final lat = _center?.latitude;
                                  final lng = _center?.longitude;

                                  if (lat != null && lng != null) {
                                    openMap(lat, lng);
                                  }
                                },
                                child: Container(
                                  height: 52,
                                  padding: EdgeInsets.symmetric(horizontal: 10),
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(5)),
                                  child: Row(
                                    children: [
                                      SizedBox(
                                          width: 17,
                                          height: 17,
                                          child: Image.asset(
                                              AppImages.pngLocationGrey,
                                              fit: BoxFit.fill)),
                                      SizedBox(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              .7,
                                          child: Text(
                                              (courtData?.facilityId?.address ??
                                                      "")
                                                  .toString(),
                                              style: TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.normal,
                                                  color: AppColors.black555))),
                                      Spacer(),
                                      SizedBox(
                                          width: 24,
                                          height: 24,
                                          child: Image.asset(
                                              AppImages.pngLocationCircle,
                                              fit: BoxFit.fill)),
                                    ],
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                        SizedBox(height: 100),
                      ],
                    );
            },
          ),
        ),
      ),
    );
  }

  Future<void> openMap(double latitude, double longitude) async {
    final url = Uri.parse(
        'https://www.google.com/maps/search/?api=1&query=$latitude,$longitude');

    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    } else {
      throw 'Could not open the map.';
    }
  }
}
