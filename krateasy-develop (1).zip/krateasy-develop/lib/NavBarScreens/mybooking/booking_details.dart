import 'dart:async';

import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:kratEasyApp/GlobalUtils/RuleItem.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/utils/extension.dart';
import 'package:kratEasyApp/utils/widgets/common_widgets.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../EntranceScreens/friend_payment_scren.dart';
import '../../EntranceScreens/guest_join_challenge.dart';
import '../../GlobalUtils/app_imports.dart';

// ignore: must_be_immutable
class BookingDetails extends StatefulWidget {
  String? ID;

  BookingDetails({super.key, this.ID});

  @override
  State<BookingDetails> createState() => _BookingDetailsState();
}

class _BookingDetailsState extends State<BookingDetails> {
  GoogleMapController? mapController;
  LatLng? _center;

  // final LatLng _center = const LatLng(28.6139, 77.2090);
  final Set<Marker> _markers = {};

  void _onMapCreated(GoogleMapController controller) {
    mapController = controller;

    if (_center != null) {
      _updateMapLocation(_center!);
    }
  }

  String getTimeDifference(String apiDateString) {
    // Parse the API date string as UTC
    DateTime apiDate = DateTime.parse(apiDateString).toUtc();

    // Get the current UTC time
    DateTime now = DateTime.now().toUtc();

    // Calculate the difference
    Duration diff = apiDate.difference(now);

    if (diff.isNegative) {
      setState(() {
        _timeLeft = "Time had been Already Passed";
      });
      return "Time had been Already Passed";
    }

    int hours = diff.inHours;
    int minutes = diff.inMinutes % 60;
    int seconds = diff.inSeconds % 60;

    String timeLeft = "${hours.toString().padLeft(2, '0')}h "
        "${minutes.toString().padLeft(2, '0')}m "
        "${seconds.toString().padLeft(2, '0')}s";

    setState(() {
      _timeLeft = timeLeft;
    });

    return timeLeft;
  }

  String _timeLeft = '';

  Timer? _timer;

  void _updateTimeLeft() {
    final joinViewModel = Provider.of<HomeViewModel>(context, listen: false);

    getTimeDifference(
        joinViewModel.bookingDetailsModel.data?.bookingstarttime ?? "");
  }

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final viewModel = context.read<HomeViewModel>();
      _updateTimeLeft();
      _timer =
          Timer.periodic(const Duration(seconds: 60), (_) => _updateTimeLeft());
      if (viewModel.bookingDetailsModel.data?.type == "Challenge") {
        await viewModel.getChalllengeBookingDetails(
            context: context,
            challenggid: viewModel.bookingDetailsModel.data?.challengeId);
      }
      if (viewModel.bookingDetailsModel.data?.type == "Court") {
        await viewModel.getCourtBookingdetails(
            context: context,
            challenggid: viewModel.bookingDetailsModel.data?.id ?? "");
      }
      if (widget.ID != null) {
        await viewModel.getCourtDetails(
            courtId: widget.ID!, context: context); // await here
      }

      final latRaw = viewModel.courtDetailsModel.data?.facilityId?.latitude;
      final lngRaw = viewModel.courtDetailsModel.data?.facilityId?.longitude;

      final lat = latRaw is String
          ? double.tryParse(latRaw.toString())
          : latRaw as double?;
      final lng = lngRaw is String
          ? double.tryParse(lngRaw.toString())
          : lngRaw as double?;

      if (lat != null && lng != null) {
        setState(() {
          _center = LatLng(lat, lng);
        });
      }
    });
  }

  void _updateMapLocation(LatLng target) {
    if (mapController != null) {
      mapController!.animateCamera(CameraUpdate.newCameraPosition(
        CameraPosition(target: target, zoom: 15),
      ));
    }

    setState(() {
      _markers.clear();
      _markers.add(
        Marker(
          markerId: MarkerId('api_marker'),
          position: target,
          infoWindow: InfoWindow(title: 'Court Location'),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    print("---->aa");
    print(widget.ID);

    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: AppColors.white,
      appBar: CommonAppBar(title: l10n.of(context).bookingDetails),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: Padding(
        padding: const EdgeInsets.only(left: 16, bottom: 20, right: 16),
        child: Consumer<HomeViewModel>(
          builder: (BuildContext context, homeViewModel, Widget? child) {
            String bookingId = homeViewModel.bookingDetailsModel.data?.id ?? "";
            return AppButtonCommon(
              // isLoading: homeViewModel.isLoading,
              onPressed: () {
                debugPrint("BookingId >>>>>>>> $bookingId");

                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return Dialog(
                      backgroundColor: AppColors.white,
                      child: ListView(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        children: [
                          Container(
                            width: double.infinity,
                            padding: EdgeInsets.symmetric(
                                horizontal: 16, vertical: 20),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12)),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                SizedBox(
                                    height: 100,
                                    width: 100,
                                    child: Image.asset(
                                        AppImages.pngDialogCancel,
                                        fit: BoxFit.fill)),
                                SizedBox(height: 10),
                                Text("Are you sure ?",
                                    style: TextStyle(
                                        color: AppColors.black,
                                        fontSize: 20,
                                        fontWeight: FontWeight.w600)),
                                SizedBox(height: 10),
                                Text(
                                  "Are you sure you want to cancel this booking? If yes, please press the confirm button. We will deduct the platform fee, and the remaining amount will be transferred to your wallet. Thank you.",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: AppColors.grey769,
                                      fontSize: 16,
                                      fontWeight: FontWeight.normal),
                                ),
                                SizedBox(height: 10),
                                Row(
                                  children: [
                                    Stack(
                                      children: [
                                        Container(
                                            height: 36,
                                            width: 130,
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                                color: AppColors.green033)),
                                        GestureDetector(
                                          onTap: () async {
                                            // await context.read<MyBookingsViewModel>().cancelBooking  ( bookingId:  bookingId,context: context);
                                            //  Navigator.pushNamed(
                                            //    context,
                                            //    '/dashboard',
                                            //  );
                                            //  print("fj");
                                            await context
                                                .read<MyBookingsViewModel>()
                                                .cancelPayment(
                                                    courtId: widget.ID ?? "",
                                                    bookingid: homeViewModel
                                                            .bookingDetailsModel
                                                            .data
                                                            ?.bookingId ??
                                                        "");
                                            Navigator.pushNamed(
                                              context,
                                              '/dashboard',
                                            );
                                          },
                                          child: Container(
                                            height: 32,
                                            width: 130,
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                                color: AppColors.primaryColor),
                                            child: Center(
                                              child: Text("Yes, Confirm",
                                                  style: TextStyle(
                                                      color: AppColors.black,
                                                      fontSize: 12,
                                                      fontWeight:
                                                          FontWeight.w600)),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Expanded(
                                      child: AppButton(
                                        height: 30,
                                        label: "Cancel",
                                        bgColor: AppColors.white,
                                        textStyle: TextStyle(
                                            color: AppColors.black,
                                            fontSize: 12,
                                            fontWeight: FontWeight.w600),
                                        onPressed: () {
                                          Navigator.pop(context);
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                );
                // Navigator.pop(context);
              },
              label: l10n.of(context).cancelBookings,
            );
          },
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Consumer<HomeViewModel>(
            builder: (BuildContext context, viewModel, Widget? child) {
              var bookingData = viewModel.bookingDetailsModel.data;
              print("typpe ==>${viewModel.bookingDetailsModel.data?.type}");
              return viewModel.loadding
                  ? Center(
                      child: CircularProgressIndicator(),
                    )
                  : Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        /// top image data
                        Stack(
                          children: [
                            SizedBox(
                                height: screenHeight * .3,
                                width: screenWidth,
                                child: NetworkImageWidget(
                                    image: (bookingData?.courtId?.image ?? "")
                                        .toString())),
                            Positioned(
                              left: 40,
                              bottom: 11,
                              child: Row(
                                children: List.generate(
                                    bookingData?.courtId?.gallery?.length ?? 0,
                                    (index) {
                                  return GestureDetector(
                                    onTap: () {
                                      final List<String?> galleryList =
                                          (bookingData?.courtId?.gallery ?? [])
                                              .cast<String?>();
                                      showDialog(
                                        context: context,
                                        builder: (_) => ImageCarouselDialog(
                                          imageUrls: galleryList,
                                          initialIndex: index,
                                        ),
                                      );
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.only(right: 10),
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(5),
                                        child: SizedBox(
                                          height: 47,
                                          width: 47,
                                          child: Image.network(
                                            bookingData
                                                ?.courtId?.gallery?[index],
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ),
                                    ),
                                  );
                                }),
                              ),
                            )
                          ],
                        ),
                        SizedBox(height: 15),
                        Padding(
                          padding: EdgeInsets.all(screenWidth * 0.03),
                          child: GestureDetector(
                            onTap: () {
                              // viewModel.navigateToViewChallengeScreen(context);
                            },
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Content of the card
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                              (bookingData?.courtId?.name
                                                          ?.capitalizeFirstLetter() ??
                                                      "")
                                                  .toString(),
                                              style: TextStyle(
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.w600,
                                                  color: AppColors.black)),
                                          Text(
                                              (bookingData?.courtId?.facilityId
                                                          ?.name
                                                          ?.capitalizeFirstLetter() ??
                                                      "")
                                                  .toString(),
                                              style: TextStyle(
                                                  fontSize: 17,
                                                  fontWeight: FontWeight.w600,
                                                  color:
                                                      AppColors.greyGreen47D)),
                                          SizedBox(
                                              height: screenHeight * 0.005),
                                          Row(
                                            children: [
                                              Image.asset(
                                                  "assets/png/calender.png",
                                                  width: screenWidth * 0.04,
                                                  height: screenWidth * 0.04,
                                                  fit: BoxFit.cover),
                                              SizedBox(
                                                  width: screenWidth * 0.002),
                                              Text(
                                                  "  ${DateFormat('dd MMM, yyyy').format(DateTime.parse((bookingData?.date ?? DateTime.now()).toString()))}",
                                                  style: TextStyle(
                                                      fontSize:
                                                          screenWidth * 0.033,
                                                      fontWeight:
                                                          FontWeight.normal,
                                                      color:
                                                          Color(0xFF555555))),
                                              SizedBox(
                                                  width: screenWidth * 0.007),
                                              Container(
                                                  width: 1,
                                                  height: screenHeight * 0.03,
                                                  color: Color(0xFFDD9D9D9)),
                                              SizedBox(
                                                  width: screenWidth * 0.007),
                                              Text(
                                                  " ${(bookingData?.startTime ?? '').toString()} - ${(bookingData?.endTime ?? '').toString()}",
                                                  style: TextStyle(
                                                      fontSize:
                                                          screenWidth * 0.033,
                                                      fontWeight:
                                                          FontWeight.normal,
                                                      color:
                                                          Color(0xFF555555))),
                                            ],
                                          ),
                                          SizedBox(
                                              height: screenHeight * 0.005),
                                          Row(
                                            children: [
                                              Image.asset(
                                                  "assets/icons/rate.png",
                                                  width: screenWidth * 0.04,
                                                  height: screenWidth * 0.04,
                                                  fit: BoxFit.cover),
                                              SizedBox(
                                                  width: screenWidth * 0.009),
                                              Text(
                                                  " ${(bookingData?.courtId?.averageRating ?? l10n.of(context).na).toString()} ",
                                                  style: TextStyle(
                                                      fontSize: 16,
                                                      fontWeight:
                                                          FontWeight.w700,
                                                      color:
                                                          Color(0xFF555555))),
                                              SizedBox(
                                                  width: screenWidth * 0.009),
                                              Container(
                                                  width: 1,
                                                  height: screenHeight * 0.03,
                                                  color: Color(0xFFDD9D9D9)),
                                              SizedBox(
                                                  width: screenWidth * 0.009),
                                              Text(
                                                  "${bookingData?.courtBookingCount}+ Bookings",
                                                  style: TextStyle(
                                                      fontSize:
                                                          screenWidth * 0.033,
                                                      fontWeight:
                                                          FontWeight.normal,
                                                      color:
                                                          Color(0xFF555555))),
                                            ],
                                          ),
                                          SizedBox(
                                              height: screenHeight * 0.005),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      padding: EdgeInsets.all(10),
                                      decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          border: Border.all(
                                              width: 1,
                                              color: AppColors.primaryColor)),
                                      child: RotatedBox(
                                          quarterTurns: 45,
                                          child: Image.asset(
                                              "assets/icons/tennis.png",
                                              width: screenWidth * 0.06,
                                              height: screenWidth * 0.06)),
                                    ),
                                  ],
                                ),
                                SizedBox(height: screenHeight * 0.005),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Image.asset('assets/icons/location.png',
                                        width: screenWidth * 0.045,
                                        height: screenWidth * 0.045),
                                    SizedBox(width: screenWidth * 0.002),
                                    Expanded(
                                        child: Text(
                                            (bookingData?.courtId?.facilityId
                                                        ?.address ??
                                                    l10n.of(context).na)
                                                .toString(),
                                            style: TextStyle(
                                                fontSize: screenWidth * 0.033,
                                                color: Color(0xFF555555)))),
                                    Image.asset('assets/icons/coins.png',
                                        width: screenWidth * 0.045,
                                        height: screenWidth * 0.045,
                                        color: AppColors.black),
                                    SizedBox(width: screenWidth * 0.009),
                                    Text(
                                        "${AppConstants.appCurrency} ${(bookingData?.price ?? 0).toString()}",
                                        style: TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.w600,
                                            color: AppColors.black)),
                                  ],
                                ),
                                SizedBox(height: screenHeight * 0.005),
                                Row(
                                  children: [
                                    Image.asset(AppImages.pngCourtBooking,
                                        width: screenWidth * 0.045,
                                        height: screenWidth * 0.045),
                                    SizedBox(width: screenWidth * 0.002),
                                    Text(l10n.of(context).courtBooking,
                                        style: TextStyle(
                                            fontSize: screenWidth * 0.033,
                                            color: Color(0xFF555555))),
                                    Spacer(),
                                    SizedBox(width: screenWidth * 0.002),
                                    Text(
                                        bookingData?.isSplit == true
                                            ? l10n.of(context).split
                                            : l10n.of(context).fullPaid,
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w400,
                                            color: AppColors.black)),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Image.asset(AppImages.pngCourtBooking,
                                        width: screenWidth * 0.045,
                                        height: screenWidth * 0.045),
                                    SizedBox(width: screenWidth * 0.002),
                                    Text(l10n.of(context).bookingId,
                                        style: TextStyle(
                                            fontSize: screenWidth * 0.033,
                                            color: Color(0xFF555555))),
                                    Spacer(),
                                    SizedBox(width: screenWidth * 0.002),
                                    Text(bookingData?.bookingId ?? "",
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w400,
                                            color: AppColors.black)),
                                  ],
                                ),

                                // Row(
                                //   children: [
                                //     Icon(Icons.gamepad_rounded,
                                //         size: screenWidth * 0.045,
                                //         ),
                                //     SizedBox(width: screenWidth * 0.002),
                                //  //    Text( "Game name",
                                //  //        style: TextStyle(
                                //  //            fontSize: screenWidth * 0.033,
                                //  //            color: Color(0xFF555555))),
                                //  //    Spacer(),
                                //  //    SizedBox(width: screenWidth * 0.002),
                                //  //    Text(
                                //  // viewModel.courtDetailsModel.data?.gamename??"",
                                //  //        style: TextStyle(
                                //  //            fontSize: 14,
                                //  //            fontWeight: FontWeight.w400,
                                //  //            color: AppColors.black)),
                                //   ],
                                // ),
                              ],
                            ),
                          ),
                        ),
                        Divider(),
                        Padding(
                          padding: EdgeInsets.symmetric(
                              horizontal: screenWidth * 0.04),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              RichText(
                                text: TextSpan(
                                  children: [
                                    TextSpan(
                                        text: l10n.of(context).description,
                                        style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.w600,
                                            color: AppColors.black555)),
                                    TextSpan(
                                      text: (bookingData
                                                  ?.facilityId?.description ??
                                              "")
                                          .toString(),
                                      style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400,
                                          color: AppColors.black555),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: 7),
                              if (bookingData?.facilityId?.amenities?.length !=
                                  0)
                                Text(l10n.of(context).amenities,
                                    style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 18,
                                        color: AppColors.black555)),
                              SizedBox(height: 7),
                              if (bookingData?.facilityId?.amenities != null)
                                SizedBox(
                                  height: bookingData
                                              ?.facilityId?.amenities?.length !=
                                          0
                                      ? 100
                                      : 0,
                                  child: SingleChildScrollView(
                                    scrollDirection: Axis.horizontal,
                                    child: Row(
                                      children: List.generate(
                                          bookingData?.facilityId?.amenities
                                                  ?.length ??
                                              0, (index) {
                                        var amenities = bookingData
                                            ?.facilityId?.amenities?[index];
                                        return Padding(
                                          padding:
                                              const EdgeInsets.only(right: 10),
                                          child: CommonAmenities(
                                              text: ("").toString(),
                                              image: (amenities?.image ?? "")
                                                  .toString()),
                                        );
                                      }),
                                    ),
                                  ),
                                ),
                              SizedBox(height: 7),
                              bookingData?.facilityId?.bio != null
                                  ? Text(l10n.of(context).rules,
                                      style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                          fontSize: 18,
                                          color: AppColors.black555))
                                  : SizedBox(),
                              SizedBox(height: 7),
                              RuleList(
                                  text: (bookingData?.facilityId?.bio ?? "")
                                      .toString()),
                              SizedBox(height: 20),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  QrcodeView(
                                    id: bookingData?.bookingId ?? "",
                                  ),
                                  Center(
                                    child: Text(
                                      _timeLeft,
                                      style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.black,
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 20),
                                  if (viewModel
                                          .bookingDetailsModel.data?.type ==
                                      "Court")
                                    Stack(
                                      children: [
                                        Container(
                                          width: 220,
                                          height: 220,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            gradient: LinearGradient(
                                              colors:
                                                  AppColors.dark348Green62ELg,
                                              begin: Alignment.topCenter,
                                              end: Alignment.bottomCenter,
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          left: 12,
                                          top: 12,
                                          child: Container(
                                            width: 196,
                                            height: 196,
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              color: AppColors.white,
                                            ),
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Text(
                                                  l10n.of(context).paid,
                                                  style: TextStyle(
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.w500,
                                                    color: AppColors.black555,
                                                  ),
                                                ),
                                                SizedBox(height: 8),
                                                Text(
                                                  viewModel.bookkingcourtnew
                                                          .data?.paidAmount
                                                          .toString() ??
                                                      "0",

                                                  style: TextStyle(
                                                    fontSize: 25,
                                                    fontWeight: FontWeight.w700,
                                                    color: AppColors.green67B,
                                                  ),
                                                ),
                                                Divider(
                                                  thickness: 2,
                                                  color: AppColors.black555
                                                      .withOpacity(.1),
                                                ),
                                                Text(
                                                  viewModel.bookkingcourtnew
                                                          .data?.leftAmount
                                                          .toString() ??
                                                      "0",
                                                  // (homeview.challlengebookingDetailsModel.data?.leftAmount?.toStringAsFixed(2))??"",

                                                  style: TextStyle(
                                                    fontSize: 25,
                                                    fontWeight: FontWeight.w700,
                                                    color: AppColors.black,
                                                  ),
                                                ),
                                                SizedBox(height: 8),
                                                Text(
                                                  l10n.of(context).left,
                                                  style: TextStyle(
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.w500,
                                                    color: AppColors.black555,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                ],
                              )
                            ],
                          ),
                        ),
                        SizedBox(height: 24),

                        if (viewModel.bookingDetailsModel.data?.type ==
                                "Challenge" &&
                            viewModel.bookingDetailsModel.data?.isSplit ==
                                true) ...{
                          if (viewModel.challlengebookingDetailsModel.data
                                  ?.challenge?.friends?.isNotEmpty ??
                              false)
                            SizedBox.shrink(
                              child: ListView.builder(
                                itemCount: viewModel
                                    .challlengebookingDetailsModel
                                    .data
                                    ?.challenge
                                    ?.friends
                                    ?.length,
                                scrollDirection: Axis.horizontal,
                                itemBuilder: (context, index) {
                                  var item = viewModel
                                      .challlengebookingDetailsModel
                                      .data
                                      ?.challenge
                                      ?.friends?[index];
                                  return item?.name == "You"
                                      ? SizedBox()
                                      : Padding(
                                          padding:
                                              const EdgeInsets.only(right: 13),
                                          child: SizedBox(
                                            width: 75,
                                            child: Column(
                                              children: [
                                                SizedBox(height: 5),
                                                Image.asset(
                                                    "assets/png/user_logo.png",
                                                    width: 65,
                                                    height: 65),
                                                Text(item?.name ?? "",
                                                    maxLines: 2,
                                                    style: TextStyle(
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        fontSize: 13,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        color: AppColors
                                                            .black555)),
                                                Spacer(),
                                                Text(
                                                    '${AppConstants.appCurrency}${item?.splitAmount ?? 0}',
                                                    style: TextStyle(
                                                        fontSize: 18,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        color:
                                                            AppColors.black)),
                                                SizedBox(height: 5),
                                                AppButton(
                                                  height: 30,
                                                  width: 70,
                                                  radius: 5,
                                                  label: item?.isPaid == true
                                                      ? 'Paid'
                                                      : "Pay",
                                                  textStyle: TextStyle(
                                                      fontSize: 15,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      color: AppColors.black),
                                                  onPressed: () {
                                                    if (item?.isPaid == false) {
                                                      Navigator.push(
                                                          context,
                                                          MaterialPageRoute(
                                                              builder: (context) =>
                                                                  FriendPayment(
                                                                    frienddid:
                                                                        item?.id ??
                                                                            "",
                                                                    playerid:
                                                                        item?.playerid ??
                                                                            "",
                                                                    challlengeid: viewModel
                                                                            .bookingDetailsModel
                                                                            .data
                                                                            ?.challengeId ??
                                                                        "",
                                                                    amount:
                                                                        item?.splitAmount ??
                                                                            0,
                                                                    bookingid:
                                                                        bookingData?.bookingId ??
                                                                            "",
                                                                  )));

                                                      // context.read<HomeViewModel>().paymentfriendsApi(friendid: item?.id??"", context: context,id: viewModel.bookingDetailsModel.data?.challengeId);
                                                    }
                                                  },
                                                  bgColor: item?.isPaid == false
                                                      ? AppColors.primaryColor
                                                      : AppColors.grey3E3,
                                                ),
                                              ],
                                            ),
                                          ),
                                        );
                                },
                              ),
                            ),
                        } else if (viewModel.bookingDetailsModel.data?.type ==
                                "Court" &&
                            viewModel.bookingDetailsModel.data?.isSplit ==
                                true) ...{
                          if (bookingData?.friends?.isNotEmpty ?? false)
                            SizedBox(
                              height: 190,
                              child: ListView.builder(
                                itemCount: bookingData?.friends?.length ?? 0,
                                scrollDirection: Axis.horizontal,
                                itemBuilder: (context, index) {
                                  var item = bookingData?.friends?[index];
                                  // var item = viewModel.bookkingcourt.data?.friends?[index];
                                  return Padding(
                                    padding: const EdgeInsets.only(right: 13),
                                    child: SizedBox(
                                      width: 75,
                                      child: Column(
                                        children: [
                                          SizedBox(height: 5),
                                          Image.asset(
                                              "assets/png/user_logo.png",
                                              width: 65,
                                              height: 65),
                                          Text(item?.name ?? "",
                                              maxLines: 2,
                                              style: TextStyle(
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  fontSize: 13,
                                                  fontWeight: FontWeight.w500,
                                                  color: AppColors.black555)),
                                          Spacer(),
                                          Text(
                                              '${AppConstants.appCurrency}${item?.splitAmount ?? 0}',
                                              style: TextStyle(
                                                  fontSize: 18,
                                                  fontWeight: FontWeight.w500,
                                                  color: AppColors.black)),
                                          SizedBox(height: 5),
                                          AppButton(
                                            height: 30,
                                            width: 70,
                                            radius: 5,
                                            label: item?.isPaid == true
                                                ? 'Paid'
                                                : "Pay",
                                            textStyle: TextStyle(
                                                fontSize: 15,
                                                fontWeight: FontWeight.w600,
                                                color: AppColors.black),
                                            onPressed: () {
                                              if (item?.isPaid == false) {
                                                print("pay1");

                                                Navigator.push(
                                                    context,
                                                    MaterialPageRoute(
                                                        builder: (context) =>
                                                            FriendPayment(
                                                              frienddid:
                                                                  item?.id ??
                                                                      "",
                                                              playerid:
                                                                  item?.playerid ??
                                                                      "",
                                                              challlengeid: viewModel
                                                                      .bookingDetailsModel
                                                                      .data
                                                                      ?.id ??
                                                                  "",
                                                              amount:
                                                                  item?.splitAmount ??
                                                                      0,
                                                              booktype:
                                                                  'booking',
                                                              bookingid: bookingData
                                                                      ?.bookingId ??
                                                                  "",
                                                            )));
                                              }
                                            },
                                            bgColor: item?.isPaid == false
                                                ? AppColors.primaryColor
                                                : AppColors.grey3E3,
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),
                            )
                        },

                        Stack(
                          children: [
                            SizedBox(
                              height: screenHeight * .3,
                              width: screenWidth * 2,
                              child: _center == null
                                  ? Center(child: CircularProgressIndicator())
                                  : GoogleMap(
                                      mapType: MapType.normal,
                                      onMapCreated: _onMapCreated,
                                      initialCameraPosition: CameraPosition(
                                          target: _center!, zoom: 14),
                                      markers: _markers,
                                      myLocationEnabled: true,
                                      myLocationButtonEnabled: true,
                                      zoomGesturesEnabled: true,
                                      scrollGesturesEnabled: true,
                                      tiltGesturesEnabled: true,
                                      rotateGesturesEnabled: true,
                                    ),

                              // child: _center == null
                              //     ? Center(child: CircularProgressIndicator())
                              //     : GoogleMap(
                              //         mapType: MapType.normal,
                              //         onMapCreated: _onMapCreated,
                              //         initialCameraPosition:
                              //             CameraPosition(target: _center!, zoom: 14),
                              //         markers: _markers,
                              //         myLocationEnabled: true,
                              //         myLocationButtonEnabled: true,
                              //         zoomGesturesEnabled: true,
                              //         scrollGesturesEnabled: true,
                              //         tiltGesturesEnabled: true,
                              //         rotateGesturesEnabled: true,
                              //       ),
                            ),
                            Positioned(
                              bottom: 18,
                              left: screenWidth * 0.04,
                              right: screenWidth * 0.04,
                              child: GestureDetector(
                                onTap: () {
                                  print("dmfm");
                                  final lat = _center?.latitude;
                                  final lng = _center?.longitude;

                                  if (lat != null && lng != null) {
                                    openMap(lat, lng);
                                  }
                                },
                                child: Container(
                                  height: 52,
                                  padding: EdgeInsets.symmetric(horizontal: 10),
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(5)),
                                  child: Row(
                                    children: [
                                      SizedBox(
                                          width: 17,
                                          height: 17,
                                          child: Image.asset(
                                              AppImages.pngLocationGrey,
                                              fit: BoxFit.fill)),
                                      SizedBox(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              .7,
                                          child: Text(
                                              (bookingData?.facilityId
                                                          ?.address ??
                                                      "")
                                                  .toString(),
                                              style: TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.normal,
                                                  color: AppColors.black555))),
                                      Spacer(),
                                      SizedBox(
                                          width: 24,
                                          height: 24,
                                          child: Image.asset(
                                              AppImages.pngLocationCircle,
                                              fit: BoxFit.fill)),
                                    ],
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),

                        SizedBox(height: 100),
                      ],
                    );
            },
          ),
        ),
      ),
    );
  }

  Future<void> openMap(double latitude, double longitude) async {
    final url = Uri.parse(
        'https://www.google.com/maps/search/?api=1&query=$latitude,$longitude');

    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    } else {
      throw 'Could not open the map.';
    }
  }
}
