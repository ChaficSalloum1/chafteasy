import 'package:kratEasyApp/generated/l10n.dart';

import '../GlobalUtils/app_imports.dart';

class MyAccountScreen extends StatefulWidget {
  const MyAccountScreen({super.key});

  @override
  State<MyAccountScreen> createState() => _MyAccountScreenState();
}

class _MyAccountScreenState extends State<MyAccountScreen> {
  late MyAccountViewModel viewModel;

  @override
  void initState() {
    viewModel = context.read<MyAccountViewModel>();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      viewModel.getProfileDataApi();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    final isLargeScreen = screenWidth > 600;

    return Consumer<MyAccountViewModel>(
      builder: (context, viewModel, child) {
        return WillPopScope(
          onWillPop: () async {
            // If not on HomeScreen, navigate to HomeScreen first
            Navigator.popUntil(context, ModalRoute.withName('/dashboard'));
            return false;
          },
          child: Scaffold(
            backgroundColor: Colors.white,
            appBar: CommonAppBar(
                title: l10n.of(context).myAccount,
                backIconColor: Colors.white,
                backgroundColor: Colors.white),
            body: viewModel.isLoading
                ? Center(
                    child: CircularProgressIndicator(
                        color: AppColors.primaryColor))
                : SingleChildScrollView(
                    padding: EdgeInsets.all(isLargeScreen ? 24.0 : 16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        // Profile Image
                        viewModel.profileModel.image != null
                            ? ClipRRect(
                                borderRadius: BorderRadius.circular(100),
                                child: NetworkImageWidget(
                                  height: 100,
                                  width: 100,
                                  image:
                                      viewModel.profileModel.image.toString(),
                                ),
                              )
                            : SizedBox(
                                height: 100,
                                width: 100,
                                child: CircleAvatar(
                                    radius: 81,
                                    backgroundImage:
                                        AssetImage(viewModel.logoPath))),

                        const SizedBox(height: 10),

                        Text(viewModel.name,
                            style: TextStyle(
                                fontSize: 20,
                                color: Colors.black,
                                fontWeight: FontWeight.w600)),

                        Text(viewModel.email,
                            style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w400,
                                color: Color(0xFF767676))),

                        const SizedBox(height: 20),

                        Container(
                          decoration: BoxDecoration(
                            color: Color(0xFFE8FFC8), // Background color
                            borderRadius:
                                BorderRadius.circular(12), // Rounded corners
                          ),
                          padding: const EdgeInsets.all(
                              12), // Padding inside the box
                          child: Column(
                            children: [
                              // User Details
                              _buildInfoRow(
                                l10n.of(context).fullName,
                                viewModel.name,
                                // context.watch<DashboardViewModel>().userName,
                                isLargeScreen,
                              ),
                              _buildInfoRow(l10n.of(context).emailAddress,
                                  viewModel.email, isLargeScreen),
                              _buildInfoRow(
                                  l10n.of(context).mobileNumber,
                                  "+${viewModel.countryCode} ${viewModel.mobileno}",
                                  isLargeScreen),
                              _buildInfoRow(l10n.of(context).skillSet,
                                  viewModel.skillSet, isLargeScreen),
                            ],
                          ),
                        ),
                        const SizedBox(height: 10),
                        if ((viewModel.profileModel.sports ?? []).isNotEmpty)
                          Text(l10n.of(context).interestedSports,
                              textAlign: TextAlign.right,
                              style: TextStyle(
                                  fontSize: 20, fontWeight: FontWeight.w600)),
                        const SizedBox(height: 10),
                        SizedBox(
                          height: screenHeight * 0.15,
                          child: Consumer<MyAccountViewModel>(
                            builder: (context, viewModel, child) {
                              return ListView.builder(
                                scrollDirection: Axis.horizontal,
                                itemCount:
                                    viewModel.profileModel.sports?.length ?? 0,
                                padding: EdgeInsets.symmetric(
                                    horizontal: isLargeScreen ? 20 : 10),
                                itemBuilder: (context, index) {
                                  final sport =
                                      viewModel.profileModel.sports?[index];
                                  return Padding(
                                      padding: const EdgeInsets.only(right: 10),
                                      child: _buildFeatureBox(
                                          sport?.image ?? "",
                                          sport?.name ?? "",
                                          sport?.skillLevel ?? "",
                                          isLargeScreen));
                                },
                              );
                            },
                          ),
                        ),
                        SizedBox(height: 60),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 8),
                          child: Stack(
                            children: [
                              Container(
                                height: 52,
                                width: double
                                    .infinity, // Full width for responsiveness
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    color: Color(0xFF72A033)),
                              ),
                              GestureDetector(
                                onTap: () {
                                  viewModel.editProfile(context);
                                },
                                child: Container(
                                  height: 47,
                                  width: double
                                      .infinity, // Full width for responsiveness
                                  decoration: BoxDecoration(
                                      color: Color(0xFF8DC63F),
                                      borderRadius: BorderRadius.circular(10)),
                                  child: Center(
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        SizedBox(width: 5),
                                        Text(l10n.of(context).editProfile,
                                            style: TextStyle(
                                                color: Colors.black,
                                                fontSize: 16,
                                                fontWeight: FontWeight.w600))
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
          ),
        );
      },
    );
  }

  Widget _buildInfoRow(String label, String value, bool isLargeScreen) {
    return Container(
      decoration: BoxDecoration(
        //color: Color(0xFFE8FFC8), // Background color
        borderRadius: BorderRadius.circular(12), // Rounded corners
      ),
      padding: const EdgeInsets.symmetric(
          vertical: 8, horizontal: 10), // Padding for spacing
      child: Row(
        children: [
          Expanded(
              child: Text(label,
                  style: TextStyle(
                      fontSize: 15,
                      color: Color(0xFF767676),
                      fontWeight: FontWeight.w400))),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: TextStyle(
                  color: Color(0xFF121212),
                  fontSize: 15,
                  fontWeight: FontWeight.w500),
              overflow:
                  TextOverflow.ellipsis, // Show ellipsis if text overflows
              maxLines: 1, // Ensure single-line text
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureBox(
      String imagePath, String label, String skillLevel, bool isLargeScreen) {
    return Container(
      width: isLargeScreen ? 120 : 100,
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
          color: Color(0xFFE3E3E3), // Border color
          width: 1, // Border width
        ),
        borderRadius: BorderRadius.circular(8), // Optional: rounded corners
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          NetworkImageWidget(height: 33, width: 33, image: imagePath),
          // Image.network(imagePath, width: isLargeScreen ? 50 : 35, height: isLargeScreen ? 50 : 40),
          const SizedBox(height: 5),
          Text(label,
              style: TextStyle(
                  fontSize: isLargeScreen ? 14 : 12,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF555555)),
              textAlign: TextAlign.center),
          Text(skillLevel,
              style: TextStyle(
                  fontSize: isLargeScreen ? 14 : 12,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF3B747D)),
              textAlign: TextAlign.center),
        ],
      ),
    );
  }
}
