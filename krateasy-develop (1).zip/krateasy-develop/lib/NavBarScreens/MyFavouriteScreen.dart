import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/utils/extension.dart';

class MyFavouriteScreen extends StatefulWidget {
  const MyFavouriteScreen({super.key});

  @override
  State<MyFavouriteScreen> createState() => _MyFavouriteScreenState();
}

class _MyFavouriteScreenState extends State<MyFavouriteScreen> {
  late MyFavouriteViewModel viewModel1;
  @override
  void initState() {
    viewModel1 = context.read<MyFavouriteViewModel>();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      viewModel1.getFavouritePlayerData(context: context);
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CommonAppBar(
          title: l10n.of(context).myFavouritePlayers,
          backIconColor: Colors.white,
          backgroundColor: Colors.white),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Consumer2<MyFavouriteViewModel, HomeViewModel>(
          builder: (context, viewModel, homeView, child) {
            final players = viewModel.favouritePlayerData;
            return viewModel.isLoading
                ? SizedBox(
                    height: MediaQuery.of(context).size.height * .7,
                    child: loaderWidget())
                : Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (players.isEmpty)
                        SizedBox(
                          height: MediaQuery.of(context).size.height * .7,
                          child: Center(
                              child: Text(l10n.of(context).noFavouritePlayersFound,
                                  style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 16,
                                      color: AppColors.black555))),
                        ),
                      ListView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: players.length,
                        itemBuilder: (context, index) {
                          var player = players[index];
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical:12,horizontal: 16),
                            child: Row(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Container(
                                    height: 40,
                                    width: 40,
                                    decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: AppColors.primaryColor),
                                    child: Center(
                                        child: Text(
                                            player.friend?.name
                                                    ?.substring(0, 1).capitalizeFirstLetter() ??
                                                "".toString(),
                                            style: TextStyle(
                                                fontSize: 15,
                                                fontWeight: FontWeight.w700,
                                                color: AppColors.black))),
                                  ),
                                ),
                                const SizedBox(width: 16),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text((player.friend?.name ?? l10n.of(context).na).capitalizeFirstLetter().toString(),
                                        style: const TextStyle(
                                            fontSize: 15,color: AppColors.black,
                                            fontWeight: FontWeight.w700)),
                                    Text(
                                        "+${player.friend?.countryCode ?? ""}  ${player.friend?.mobileNumber ?? "---"}",
                                        style: const TextStyle(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w700,
                                            color: AppColors.black555)),
                                  ],
                                ),
                                const Spacer(),
                                InkWell(
                          onTap: () async {
                          await homeView.removePlayerFromFavouriteApi(
                          context: context,
                          playerId: player.playerid ?? "",
                          players: players, // pass the actual list being used in UI
                          );
                          },

                          // onTap: () async {
                                  //   homeView.removePlayerFromFavouriteApi(context: context,
                                  //       playerId: player.id ?? "");
                                  //   await viewModel.getFavouritePlayerData(context: context);
                                  // },
                                  child: ClipRRect(
                                      borderRadius: BorderRadius.circular(8),
                                      child: Image.asset(
                                          'assets/icons/heart.png',
                                          width: 25,
                                          height: 25,color: AppColors.primaryColor,
                                          fit: BoxFit.fill)),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ],
                  );
          },
        ),
      ),
    );
  }
}
