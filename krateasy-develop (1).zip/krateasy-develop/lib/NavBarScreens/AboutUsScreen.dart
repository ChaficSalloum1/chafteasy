import 'package:flutter/material.dart';
import 'package:kratEasyApp/GlobalUtils/app_colors.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:provider/provider.dart';
import '../GlobalUtils/common_app_bar.dart';
import '../ViewModel/NavBarViewModels/TermsAndConditionsViewModel.dart';

class AboutUsScreen extends StatelessWidget {
  const AboutUsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) =>
          TermsAndConditionsViewModel()..fetchAboutUs(context: context),
      child: WillPopScope(
        onWillPop: () async {
          Navigator.popUntil(context, ModalRoute.withName('/dashboard'));
          return false;
        },
        child: Scaffold(
          backgroundColor: Colors.white,
          appBar: CommonAppBar(
              title: l10n.of(context).aboutUs,
              backIconColor: Colors.white,
              backgroundColor: Colors.white),
          body: Padding(
            padding: const EdgeInsets.all(16),
            child: Consumer<TermsAndConditionsViewModel>(
              builder: (context, viewModel, child) {
                if (viewModel.isLoading) {
                  return Center(
                      child: CircularProgressIndicator(
                          color: AppColors.primaryColor));
                } else if (viewModel.errorMessage.isNotEmpty) {
                  return Center(child: Text(viewModel.errorMessage));
                } else if (viewModel.aboutUsUrl.isEmpty) {
                  return Center(child: Text(l10n.of(context).noDataAvailable));
                } else {
                  return SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(l10n.of(context).aboutUs,
                            style: TextStyle(
                                color: Color(0xFF555555),
                                fontSize: 18,
                                fontWeight: FontWeight.w700)),
                        const SizedBox(height: 16),
                        Text(viewModel.termsAndConditions!.enDescription,
                            style: const TextStyle(
                                color: Color(0xFF555555),
                                fontSize: 15,
                                fontWeight: FontWeight.w400),
                            textAlign: TextAlign.justify),
                      ],
                    ),
                  );
                }
              },
            ),
          ),
        ),
      ),
    );
  }
}
