import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:provider/provider.dart';

import '../../GlobalUtils/app_colors.dart';
import '../GlobalUtils/TransactionTile.dart';
import '../GlobalUtils/app_constants.dart';
import '../GlobalUtils/common_app_bar.dart';
import '../ViewModel/NavBarViewModels/WalletViewModel.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  _WalletScreenState createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  late WalletViewModel viewModel;
  bool _isFirstLoad = true;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_isFirstLoad) {
      viewModel = Provider.of<WalletViewModel>(context, listen: false);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        viewModel.fetchTransactions();
        viewModel.fetchWalletDetail();
      });
      _isFirstLoad = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    // final screenHeight = MediaQuery.of(context).size.height;

    return WillPopScope(
      onWillPop: () async {
        Navigator.pushReplacementNamed(context, '/dashboard');
        return false;
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: CommonAppBar(
          bg: AppColors.black,
          titleWidget:  Text(
            l10n.of(context).transactions,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: AppColors.white,
            ),
          ),
          backgroundColor: Colors.black,
          isBack: true,
          isLeading: true,
          backIconColor: Colors.white,
          action: [SizedBox(width: (screenWidth - 80) / 2)],
        ),
        body: Consumer<WalletViewModel>(
          builder: (context, vm, _) {
            if (vm.isLoading) {
              return const Center(
                  child:
                      CircularProgressIndicator(color: AppColors.primaryColor));
            }

            if (vm.errorMessage.isNotEmpty) {
              return Center(
                child: Text(
                  vm.errorMessage,
                  style: const TextStyle(color: Colors.red),
                ),
              );
            }

            return SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: double.infinity,
                    decoration: const BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(30),
                        bottomRight: Radius.circular(30),
                      ),
                    ),
                    padding: const EdgeInsets.only(bottom: 28),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                         Text(
                          l10n.of(context).totalAmount,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          "${AppConstants.appCurrency}${(vm.walletDetailModel?.wallet?.amount ?? 0) < 0 ? 0.0.toStringAsFixed(0) : vm.walletDetailModel?.wallet?.amount?.toStringAsFixed(0) ?? '0'}",
                          style: const TextStyle(
                            fontSize: 35,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                        // const SizedBox(height: 20),
                        // Row(
                        //   mainAxisAlignment: MainAxisAlignment.center,
                        //   children: [
                        //     _buildActionButton(
                        //       context,
                        //       label: "Add Amount",
                        //       iconPath: "assets/icons/plus.png",
                        //       color: const Color(0xFF8DC63F),
                        //       onPressed: () {
                        //         vm.addAmount(
                        //           context,
                        //           (vm.walletDetailModel?.wallet?.amount ?? 0) <
                        //                   0
                        //               ? 0.0.toStringAsFixed(0)
                        //               : vm.walletDetailModel?.wallet?.amount
                        //                       ?.toStringAsFixed(0) ??
                        //                   '0',
                        //         );
                        //       },
                        //     ),
                        //     const SizedBox(width: 10),
                        //     _buildActionButton(
                        //       context,
                        //       label: "Withdraw",
                        //       iconPath: "assets/icons/arrowDown.png",
                        //       color: AppColors.primaryColor,
                        //       onPressed: () => vm.addAmount(
                        //         context,
                        //         (vm.walletDetailModel?.wallet?.amount ?? 0) < 0
                        //             ? 0.0.toStringAsFixed(0)
                        //             : vm.walletDetailModel?.wallet?.amount
                        //                     ?.toStringAsFixed(0) ??
                        //                 '0',
                        //       ),
                        //     ),
                        //   ],
                        // ),

                      ],
                    ),
                  ),
                  Padding(
                    padding:
                        EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
                    child: Column(
                      children: [
                        const SizedBox(height: 20),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                             Text(
                              l10n.of(context).transactions,
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w600,
                                color: Colors.black,
                              ),
                            ),
                            SizedBox(
                              width: 72,
                              height: 28,
                              child: ElevatedButton(
                                onPressed: () => vm.navigateToAllTxns(context),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xFF3B747D),
                                  padding: EdgeInsets.zero,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                ),
                                child:  Text(
                                  l10n.of(context).viewAll,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Divider(height: 1, color: Color(0xFFE3E3E3)),
                        const SizedBox(height: 20),
                        vm.transactions.isEmpty
                            ?  Center(
                                child: Padding(
                                  padding: EdgeInsets.only(top: 40),
                                  child: Text(
                                    l10n.of(context).noTransactionsFound,
                                    style: TextStyle(
                                        fontSize: 16, color: Colors.grey),
                                  ),
                                ),
                              )
                            : ListView.builder(
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                itemCount: vm.transactions.length,
                                itemBuilder: (context, index) {
                                  final transaction = vm.transactions[index];
                                  final currentMonthYear =
                                      DateFormat('MMMM yyyy')
                                          .format(transaction.createdAt);
                                  final previousMonthYear = index > 0
                                      ? DateFormat('MMMM yyyy').format(
                                          vm.transactions[index - 1].createdAt)
                                      : null;

                                  final bool showHeader =
                                      currentMonthYear != previousMonthYear;

                                  return Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      if (showHeader)
                                        Text(
                                          currentMonthYear,
                                          style: const TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w400,
                                            color: Color(0xFF110B2A),
                                          ),
                                        ),
                                      TransactionTile(transaction: transaction),
                                    ],
                                  );
                                },
                              ),
                        SizedBox(height: 10),
                      ],
                    ),
                  )
                ],
              ),
            );
          },
        ),
      ),
    );
  }


}
