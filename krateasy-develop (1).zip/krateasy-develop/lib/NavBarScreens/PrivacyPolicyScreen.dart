import 'package:flutter/material.dart';
import 'package:kratEasyApp/GlobalUtils/app_colors.dart';
import 'package:provider/provider.dart';
import '../GlobalUtils/common_app_bar.dart';
import '../ViewModel/NavBarViewModels/PrivacyPolicyViewModel.dart'; // Your ViewModel

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => PrivacyPolicyViewModel()..fetchPrivacyPolicy(context: context),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: CommonAppBar(title: "Privacy Policy", backIconColor: Colors.white, backgroundColor: Colors.white),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Consumer<PrivacyPolicyViewModel>(
            builder: (context, viewModel, child) {
              if (viewModel.isLoading) {
                return Center(child: CircularProgressIndicator(color: AppColors.primaryColor));
              } else if (viewModel.errorMessage.isNotEmpty) {
                return Center(child: Text(viewModel.errorMessage));
              } else if (viewModel.privacyPolicy == null) {
                return const Center(child: Text("No data available"));
              } else {
                return SingleChildScrollView(
                  child: Text( viewModel.privacyPolicy!.enDescription),
                );
              }
            },
          ),
        ),
      ),
    );
  }
}
