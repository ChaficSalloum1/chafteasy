import 'package:country_code_picker/country_code_picker.dart';
import 'package:flutter/services.dart';
import 'package:kratEasyApp/Localization/locale_provider.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import '../GlobalUtils/app_imports.dart';

class EditScreen extends StatefulWidget {
  const EditScreen({
    super.key,
  });

  @override
  createState() => _EditScreenState();
}

class _EditScreenState extends State<EditScreen> {
  String? countryCode;

  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();

  // TextEditingController countryCodeController = TextEditingController();
  TextEditingController phoneNumberController = TextEditingController();
  String? selectedSportId;
  String? selectedSkillSet;

  @override
  void initState() {
    final viewModel = Provider.of<MyAccountViewModel>(context, listen: false);
    if (viewModel.selectedSportsAndSkills.isEmpty) {
      viewModel.addSportAndSkill('', '');
    }
    MyAccountViewModel viewModelMyAccount = context.read<MyAccountViewModel>();
    EditScreenViewModel editScreenViewModel =
        context.read<EditScreenViewModel>();
    viewModelMyAccount.updateImageUplaodPath("");
    nameController.text =
        (viewModelMyAccount.profileModel.name ?? "").toString();
    emailController.text =
        (viewModelMyAccount.profileModel.email ?? "").toString();
    // countryCodeController.text =
    //     (viewModelMyAccount.profileModel?.countryCode ?? "").toString();
    phoneNumberController.text =
        (viewModelMyAccount.profileModel.mobileNumber ?? "").toString();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // This runs after the first frame is rendered
      final args = ModalRoute.of(context)?.settings.arguments as Map?;
      if (args != null) {
        setState(() {
          countryCode = args['countryCode']?.toString() ?? "44";
        });
      }
      editScreenViewModel.getSportsDataApi();
    });
    super.initState();
  }

  @override
  void dispose() {
    nameController.dispose();
    emailController.dispose();
    // countryCodeController.dispose();
    phoneNumberController.dispose();
    super.dispose();
  }

  String imagePath = '';

  @override
  Widget build(BuildContext context) {
    return Consumer2<EditScreenViewModel, MyAccountViewModel>(
      builder: (context, viewModel, myAccountProvider, child) {
        return WillPopScope(
          onWillPop: () async {
            // If not on HomeScreen, navigate to HomeScreen first

            Navigator.popUntil(context, ModalRoute.withName('/dashboard'));
            return false;
          },
          child: Scaffold(
            backgroundColor: Colors.white,
            appBar: CommonAppBar(
                title: l10n.of(context).editProfile,
                backIconColor: Colors.white,
                backgroundColor: Colors.white),
            body: SafeArea(
              child: myAccountProvider.isLoading || viewModel.isLoadingSports
                  ? Center(
                      child: CircularProgressIndicator(
                        color: AppColors.primaryColor,
                      ),
                    )
                  : SingleChildScrollView(
                      child: Center(
                        child: Column(
                          children: [
                            SizedBox(height: 10),
                            Stack(
                              children: [
                                myAccountProvider.imageStorePath != null &&
                                        myAccountProvider.imageStorePath != ""
                                    ? ClipRRect(
                                        borderRadius: BorderRadius.circular(50),
                                        child: Image.network(
                                          height: 100,
                                          width: 100,
                                          fit: BoxFit.cover,
                                          myAccountProvider.imageStorePath ??
                                              'assets/icons/user.png',
                                          errorBuilder:
                                              (context, error, stackTrace) {
                                            return CircleAvatar(
                                              radius: 50,
                                              backgroundImage: AssetImage(
                                                'assets/icons/user.png',
                                              ),
                                            );
                                          },
                                        ),
                                      )
                                    : myAccountProvider.imageStorePath ==
                                                null ||
                                            myAccountProvider
                                                    .profileModel.image !=
                                                null ||
                                            myAccountProvider.image != null
                                        ? ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(100),
                                            child: myAccountProvider
                                                        .profileModel.image !=
                                                    null
                                                ? NetworkImageWidget(
                                                    height: 100,
                                                    width: 100,
                                                    image: myAccountProvider
                                                        .profileModel.image
                                                        .toString(),
                                                  )
                                                : Image.file(
                                                    myAccountProvider.image!,
                                                    height: 100,
                                                    width: 100,
                                                    fit: BoxFit.fill),
                                          )
                                        : CircleAvatar(
                                            radius: 50,
                                            backgroundImage: AssetImage(
                                                'assets/icons/user.png'),
                                          ),
                                Positioned(
                                  bottom: 0,
                                  right: 0,
                                  child: GestureDetector(
                                    // onTap: viewModel.pickImage,
                                    onTap: () {
                                      showModalBottomSheet(
                                        context: context,
                                        builder: (context) {
                                          return SafeArea(
                                            bottom: true,
                                            child: ListView(
                                              shrinkWrap: true,
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 16, vertical: 30),
                                              children: [
                                                Row(
                                                  children: [
                                                    Expanded(
                                                      flex: 1,
                                                      child: InkWell(
                                                        onTap: () {
                                                          myAccountProvider
                                                              .pickImageCamera();
                                                          if (myAccountProvider
                                                                  .imageStorePath !=
                                                              null) {
                                                            imagePath =
                                                                myAccountProvider
                                                                    .imageStorePath!;

                                                            setState(() {});
                                                          }
                                                        },
                                                        child: Container(
                                                          height: 52,
                                                          decoration: BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          12),
                                                              color: AppColors
                                                                  .primaryColor),
                                                          child: Center(
                                                              child: Text(
                                                                  l10n
                                                                      .of(
                                                                          context)
                                                                      .camera,
                                                                  style: TextStyle(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500,
                                                                      fontSize:
                                                                          16,
                                                                      color: AppColors
                                                                          .white))),
                                                        ),
                                                      ),
                                                    ),
                                                    SizedBox(width: 10),
                                                    Expanded(
                                                      flex: 1,
                                                      child: InkWell(
                                                        onTap: () async {
                                                          await myAccountProvider
                                                              .pickImageGallery();
                                                          if (myAccountProvider
                                                                  .imageStorePath !=
                                                              null) {
                                                            imagePath =
                                                                myAccountProvider
                                                                    .imageStorePath!;

                                                            setState(() {});
                                                          }
                                                        },
                                                        child: Container(
                                                          height: 52,
                                                          decoration: BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          12),
                                                              color: AppColors
                                                                  .primaryColor),
                                                          child: Center(
                                                              child: Text(
                                                                  l10n
                                                                      .of(
                                                                          context)
                                                                      .gallery,
                                                                  style: TextStyle(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500,
                                                                      fontSize:
                                                                          16,
                                                                      color: AppColors
                                                                          .white))),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          );
                                        },
                                      );
                                    },
                                    child: Container(
                                        height: 35,
                                        width: 35,
                                        decoration: BoxDecoration(
                                            color: Color(0xFF8DC63F),
                                            shape: BoxShape.circle),
                                        child: Image.asset(
                                            'assets/icons/upload.png')),
                                  ),
                                ),
                              ],
                            ),
                            Padding(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 10),
                              child: Column(
                                children: [
                                  AppTextField(
                                    textstyle: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.normal,
                                        color: AppColors.black555),
                                    fillColor: AppColors.lightPrimaryColorFFE5,
                                    hintText: l10n.of(context).enterYourName,
                                    controller: nameController,
                                    borderColor:
                                        AppColors.lightPrimaryColorFFE5,
                                  ),
                                  SizedBox(height: 10),
                                  AppTextField(
                                    keyboardType: TextInputType.emailAddress,
                                    textstyle: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.normal,
                                        color: AppColors.black555),
                                    suffix: SizedBox(
                                        height: 24,
                                        width: 24,
                                        child: Image.asset(
                                            "assets/icons/email.png",
                                            fit: BoxFit.fill)),
                                    fillColor: AppColors.lightPrimaryColorFFE5,
                                    hintText: l10n.of(context).enterYourEmail,
                                    controller: emailController,
                                    borderColor:
                                        AppColors.lightPrimaryColorFFE5,
                                  ),
                                  SizedBox(height: 10),
                                  AppTextField(
                                    isReadOnly: true,
                                    textstyle: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.normal,
                                      color: AppColors.black555,
                                    ),
                                    borderColor:
                                        AppColors.lightPrimaryColorFFE5,
                                    controller: phoneNumberController,
                                    fillColor: AppColors.lightPrimaryColorFFE5,
                                    prefixWidget: AbsorbPointer(
                                      absorbing: true, // Makes it non-clickable
                                      child: CountryCodePicker(
                                        padding: EdgeInsets.zero,
                                        margin: EdgeInsets.only(right: 5),
                                        initialSelection: "+${countryCode}",
                                        // e.g., "237"
                                        showCountryOnly: true,
                                        showOnlyCountryWhenClosed: false,
                                        alignLeft: false,
                                        backgroundColor: AppColors.white,
                                        dialogBackgroundColor: AppColors.white,
                                        flagWidth: 25,
                                        flagDecoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                        ),
                                        searchPadding: EdgeInsets.zero,
                                        onChanged: (_) {}, // No-op if needed
                                      ),
                                    ),
                                    validator: (value) {
                                      if (value == null || value.isEmpty) {
                                        return l10n
                                            .of(context)
                                            .enter810DigitPhoneNumber;
                                      }
                                      if (!RegExp(r'^\d{8,12}$')
                                          .hasMatch(value)) {
                                        return l10n
                                            .of(context)
                                            .phoneNumberMustBe810Digits;
                                      }
                                      return null;
                                    },
                                    inputFormatters: [
                                      FilteringTextInputFormatter.digitsOnly,
                                      LengthLimitingTextInputFormatter(12),
                                    ],
                                    height: 42,
                                    hintText: l10n
                                        .of(context)
                                        .enter810DigitPhoneNumber,
                                    keyboardType: TextInputType.number,
                                  )
                                ],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.symmetric(horizontal: 16),
                              child: DropdownButtonFormField<String>(
                                icon: Image.asset("assets/icons/lowarrow.png",
                                    height: 14, width: 12),
                                value: viewModel.selectedSkill,
                                items: [
                                  "Beginner",
                                  "Intermediate",
                                  "Professional"
                                ]
                                    .map((String skill) =>
                                        DropdownMenuItem<String>(
                                            value: skill, child: Text(skill)))
                                    .toList(),
                                onChanged: (String? newValue) {
                                  if (newValue != null) {
                                    viewModel.setSkill(newValue);
                                  }
                                },
                                decoration: InputDecoration(
                                  filled: true,
                                  fillColor: Color(0xFFF5FFE5),
                                  // Background color
                                  contentPadding:
                                      EdgeInsets.symmetric(horizontal: 10),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide(
                                      color: Colors
                                          .transparent, // Transparent border
                                    ),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide(
                                      color: Colors.transparent,
                                    ),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide(
                                      color: Colors.transparent,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(height: 10),
                            Consumer2<MyAccountViewModel, EditScreenViewModel>(
                              builder: (context, viewModel, viewModel1, child) {
                                final selectedList =
                                    viewModel.selectedSportsAndSkills;

                                return Column(
                                  children: [
                                    if (selectedList.isEmpty)
                                      Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 16),
                                        child: ElevatedButton.icon(
                                          onPressed: () {
                                            viewModel.addSportAndSkill('', '');
                                          },
                                          icon: Image.asset(
                                              'assets/icons/add.png',
                                              width: 20,
                                              height: 20),
                                          label: Text(l10n.of(context).addMore),
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor:
                                                const Color(0xFF4CAF50),
                                            foregroundColor: Colors.white,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                          ),
                                        ),
                                      )
                                    else
                                      ListView.builder(
                                        shrinkWrap: true,
                                        physics: NeverScrollableScrollPhysics(),
                                        itemCount: selectedList.length,
                                        itemBuilder: (context, index) {
                                          final selectedSport =
                                              selectedList[index];
                                          return Column(
                                            children: [
                                              /// Header Row with Title and Add/Delete buttons
                                              Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 16),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Text(
                                                      '${l10n.of(context).selectSport} ${(index + 1).toString().padLeft(2, '0')}',
                                                      style: const TextStyle(
                                                          fontSize: 16,
                                                          fontWeight:
                                                              FontWeight.bold),
                                                    ),
                                                    index == 0
                                                        ? ElevatedButton.icon(
                                                            onPressed: () {
                                                              viewModel
                                                                  .addSportAndSkill(
                                                                      '', '');
                                                            },
                                                            icon: Image.asset(
                                                                'assets/icons/add.png',
                                                                width: 20,
                                                                height: 20),
                                                            label: Text(l10n
                                                                .of(context)
                                                                .addMore),
                                                            style:
                                                                ElevatedButton
                                                                    .styleFrom(
                                                              backgroundColor:
                                                                  const Color(
                                                                      0xFF4CAF50),
                                                              foregroundColor:
                                                                  Colors.white,
                                                              shape: RoundedRectangleBorder(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              10)),
                                                            ),
                                                          )
                                                        : IconButton(
                                                            onPressed: () {
                                                              viewModel
                                                                  .removeSportAndSkill(
                                                                      index);
                                                            },
                                                            icon: Image.asset(
                                                                'assets/icons/delete.png',
                                                                width: 20,
                                                                height: 20),
                                                          ),
                                                  ],
                                                ),
                                              ),
                                              const SizedBox(height: 16),

                                              /// Sports Dropdown
                                              Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 16),
                                                child: DropdownButtonFormField<
                                                    String>(
                                                  icon: Image.asset(
                                                      "assets/icons/lowarrow.png",
                                                      height: 14,
                                                      width: 12),
                                                  decoration: InputDecoration(
                                                    filled: true,
                                                    hintText: l10n
                                                        .of(context)
                                                        .selectSport,
                                                    fillColor:
                                                        const Color(0xFFF5FFE5),
                                                    contentPadding:
                                                        const EdgeInsets
                                                            .symmetric(
                                                            horizontal: 10),
                                                    border: OutlineInputBorder(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(10),
                                                        borderSide:
                                                            BorderSide.none),
                                                    enabledBorder:
                                                        OutlineInputBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        10),
                                                            borderSide:
                                                                BorderSide
                                                                    .none),
                                                    focusedBorder:
                                                        OutlineInputBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        10),
                                                            borderSide:
                                                                BorderSide
                                                                    .none),
                                                  ),
                                                  value: viewModel1
                                                          .sportsListModel
                                                          .any((sport) =>
                                                              sport.id
                                                                  .toString() ==
                                                              selectedSport[
                                                                  'sportId'])
                                                      ? selectedSport['sportId']
                                                      : null,
                                                  items: viewModel1
                                                      .sportsListModel
                                                      .map((sport) {
                                                    return DropdownMenuItem<
                                                        String>(
                                                      value:
                                                          sport.id.toString(),
                                                      child: Text(context
                                                                  .read<
                                                                      LocaleProvider>()
                                                                  .locale
                                                                  .languageCode ==
                                                              "el"
                                                          ? sport.grname ?? ""
                                                          : sport.name ??
                                                              "Unknown Sport"),
                                                    );
                                                  }).toList(),
                                                  onChanged: (value) {
                                                    viewModel
                                                        .updateSportAndSkill(
                                                      index,
                                                      value!,
                                                      selectedSport['skill']!,
                                                    );
                                                  },
                                                ),
                                              ),

                                              const SizedBox(height: 16),

                                              /// Skill Dropdown
                                              Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 16),
                                                child: DropdownButtonFormField<
                                                    String>(
                                                  icon: Image.asset(
                                                      "assets/icons/lowarrow.png",
                                                      height: 14,
                                                      width: 12),
                                                  decoration: InputDecoration(
                                                    filled: true,
                                                    hintText: l10n
                                                        .of(context)
                                                        .skillSet,
                                                    fillColor:
                                                        const Color(0xFFF5FFE5),
                                                    contentPadding:
                                                        const EdgeInsets
                                                            .symmetric(
                                                            horizontal: 10),
                                                    border: OutlineInputBorder(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(10),
                                                        borderSide:
                                                            BorderSide.none),
                                                    enabledBorder:
                                                        OutlineInputBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        10),
                                                            borderSide:
                                                                BorderSide
                                                                    .none),
                                                    focusedBorder:
                                                        OutlineInputBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        10),
                                                            borderSide:
                                                                BorderSide
                                                                    .none),
                                                  ),
                                                  value: [
                                                    "Beginner",
                                                    "Intermediate",
                                                    "Advanced"
                                                  ].contains(selectedSport[
                                                          'skill'])
                                                      ? selectedSport['skill']
                                                      : null,
                                                  // items: context.read<LocaleProvider>().locale.languageCode=="el"?["Αρχάριος", "Μεσαίος", "Προχωρημένος"]:
                                                  items: [
                                                    "Beginner",
                                                    "Intermediate",
                                                    "Advanced"
                                                  ]
                                                      .map((skill) =>
                                                          DropdownMenuItem<
                                                              String>(
                                                            value: skill,
                                                            child: Text(skill),
                                                          ))
                                                      .toList(),
                                                  onChanged: (value) {
                                                    if (value != null) {
                                                      viewModel
                                                          .updateSportAndSkill(
                                                        index,
                                                        selectedSport[
                                                                'sportId'] ??
                                                            '',
                                                        value,
                                                      );
                                                    }
                                                  },
                                                ),
                                              ),
                                            ],
                                          );
                                        },
                                      ),
                                  ],
                                );
                              },
                            ),
                            SizedBox(height: 60),
                            Consumer<EditScreenViewModel>(
                                builder: (context, viewModel1, child) {
                              return Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal:
                                        20), // Proper padding from left & right
                                child: AppButtonCommon(
                                    label: l10n.of(context).saveProfile,
                                    isLoading: myAccountProvider.isLoading,
                                    onPressed: () {
                                      final email = emailController.text.trim();
                                      if (!_isValidEmail(email) &&
                                          email.isNotEmpty) {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          SnackBar(
                                            content: Text(
                                              "Please enter valid email",
                                            ),
                                          ),
                                        );
                                        return;
                                      }

                                      myAccountProvider.editMyAccount(
                                        context: context,
                                        name: nameController.text.trim(),
                                        skillSet: viewModel.selectedSkill,
                                        email: email,
                                        countryCode: countryCode!,
                                        phoneNumber:
                                            phoneNumberController.text.trim(),
                                   //     imagePath: imagePath,
                                      );
                                    }),
                              );
                            }),
                            SizedBox(
                              height: 20,
                            )
                          ],
                        ),
                      ),
                    ),
            ),
          ),
        );
      },
    );
  }

  bool _isValidEmail(String email) {
    final emailRegex = RegExp(
      r"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$",
    );
    return emailRegex.hasMatch(email);
  }
}
