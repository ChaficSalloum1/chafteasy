// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import '../../GlobalUtils/common_app_bar.dart';
// import '../../ViewModel/NavBarViewModels/AddAmountViewModel/AddAmountViewModel.dart';
// import 'AmountAddedSuccessScreen.dart';

// class AddAmountScreen extends StatefulWidget {
//   const AddAmountScreen({super.key});

//   @override
//   State<AddAmountScreen> createState() => _AddAmountScreenState();
// }

// class _AddAmountScreenState extends State<AddAmountScreen> {
//   String? amount;
//   @override
//   void didChangeDependencies() {
//     super.didChangeDependencies();
//     final args = ModalRoute.of(context)?.settings.arguments as Map?;
//     if (args != null) {
//       amount = args['amount'] ?? "";
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     double screenWidth = MediaQuery.of(context).size.width;
//     double screenHeight = MediaQuery.of(context).size.height;

//     return WillPopScope(
//       onWillPop: () async {
//         // If not on HomeScreen, navigate to HomeScreen first
//         Navigator.popUntil(context, ModalRoute.withName('/dashboard'));
//         return false;
//       },
//       child: Scaffold(
//         backgroundColor: Colors.white,
//         appBar: CommonAppBar(
//           title: "Add Money",
//           backIconColor: Colors.white,
//           backgroundColor: Colors.white,
//         ),
//         body: Padding(
//           padding: EdgeInsets.all(screenWidth * 0.05),
//           child: Consumer<AddAmountViewModel>(
//             builder: (context, viewModel, child) {
//               return Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Container(
//                     padding: EdgeInsets.all(screenWidth * 0.04),
//                     decoration: BoxDecoration(
//                       color: Colors.white,
//                       borderRadius: BorderRadius.circular(12.0),
//                       border: Border.all(
//                         color: Colors.grey.shade400,
//                         width: 1.0,
//                       ),
//                     ),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Row(
//                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                           crossAxisAlignment: CrossAxisAlignment.center,
//                           children: [
//                             Column(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 const Text(
//                                   "Current Balance",
//                                   style: TextStyle(
//                                     fontSize: 15,
//                                     fontWeight: FontWeight.w500,
//                                     color: Colors.black,
//                                   ),
//                                 ),
//                               ],
//                             ),
//                             Container(
//                               padding: const EdgeInsets.symmetric(
//                                 horizontal: 12,
//                                 vertical: 5,
//                               ),
//                               decoration: BoxDecoration(
//                                 color: Colors.black,
//                                 borderRadius: BorderRadius.circular(100),
//                               ),
//                               child: Text(
//                                 "${AppConstants.appCurrency}$amount",
//                                 style: const TextStyle(
//                                   fontSize: 18,
//                                   color: Colors.white,
//                                   fontWeight: FontWeight.w700,
//                                 ),
//                               ),
//                             )
//                           ],
//                         ),
//                         SizedBox(height: screenHeight * 0.04),
//                         Container(
//                           decoration: BoxDecoration(
//                             color: Color(0xFFEFEFEF),
//                             borderRadius: BorderRadius.circular(10.0),
//                           ),
//                           padding: EdgeInsets.symmetric(horizontal: 12.0),
//                           child: TextField(
//                             keyboardType: TextInputType.number,
//                             controller: viewModel.amountController,
//                             decoration: InputDecoration(
//                               hintText: "Add Amount",
//                               border: InputBorder.none,
//                             ),
//                             style: TextStyle(
//                               fontSize: 16,
//                               fontWeight: FontWeight.w400,
//                               color: Colors.black,
//                             ),
//                           ),
//                         ),
//                         SizedBox(height: screenHeight * 0.03),
//                         Row(
//                           mainAxisAlignment: MainAxisAlignment.start,
//                           children: [250, 150, 100].map((amount) {
//                             return Padding(
//                               padding: EdgeInsets.only(
//                                 right: screenWidth * 0.02,
//                               ),
//                               child: GestureDetector(
//                                 onTap: () {
//                                   viewModel.setSelectedAmount(amount);
//                                 },
//                                 child: Container(
//                                   padding: EdgeInsets.symmetric(
//                                     vertical: screenHeight * 0.010,
//                                     horizontal: screenWidth * 0.04,
//                                   ),
//                                   decoration: BoxDecoration(
//                                     color: viewModel.selectedAmount == amount
//                                         ? Color(0xFF8DC63F)
//                                         : Color(0xFFEFEFEF),
//                                     borderRadius: BorderRadius.circular(50),
//                                   ),
//                                   child: Text(
//                                     "£$amount",
//                                     style: TextStyle(
//                                       fontSize: 16,
//                                       fontWeight: FontWeight.w400,
//                                       color: Colors.black,
//                                     ),
//                                   ),
//                                 ),
//                               ),
//                             );
//                           }).toList(),
//                         ),
//                       ],
//                     ),
//                   ),
//                   const Spacer(),
//                   // Add Amount Button
//                   Padding(
//                     padding: const EdgeInsets.symmetric(
//                       horizontal: 16.0,
//                     ), // Adjust as needed
//                     child: Stack(
//                       children: [
//                         Container(
//                           height: 52,
//                           width:
//                               double.infinity, // Full width for responsiveness
//                           decoration: BoxDecoration(
//                             borderRadius: BorderRadius.circular(10),
//                             color: const Color(0xFF72A033),
//                           ),
//                         ),
//                         GestureDetector(
//                           onTap: () async {
//                             if (!viewModel.isLoading) {
//                               bool isSuccess = await viewModel.addMoney(
//                                 context,
//                               );
//                               if (isSuccess) {
//                                 viewModel.amountController.clear();
//                                 viewModel.selectedAmount = null;

//                                 Navigator.pushReplacement(
//                                   context,
//                                   MaterialPageRoute(
//                                     builder: (context) =>
//                                         AmountAddedSuccessScreen(),
//                                   ),
//                                 );
//                               }
//                             }
//                           },
//                           child: Container(
//                             height: 47,
//                             width: double.infinity,
//                             decoration: BoxDecoration(
//                               color: const Color(0xFF8DC63F),
//                               borderRadius: BorderRadius.circular(10),
//                             ),
//                             child: Center(
//                               child: viewModel.isLoading
//                                   ? const SizedBox(
//                                       width: 24,
//                                       height: 24,
//                                       child: CircularProgressIndicator(
//                                         color: Colors.white,
//                                         strokeWidth: 2,
//                                       ),
//                                     )
//                                   : const Text(
//                                       "Add Amount",
//                                       style: TextStyle(
//                                         color: Colors.black,
//                                         fontSize: 16,
//                                         fontWeight: FontWeight.w600,
//                                       ),
//                                     ),
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ],
//               );
//             },
//           ),
//         ),
//       ),
//     );
//   }
// }
