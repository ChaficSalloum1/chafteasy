import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:kratEasyApp/GlobalUtils/common_app_bar.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:provider/provider.dart';

import '../../GlobalUtils/TransactionTile.dart';
import '../../ViewModel/NavBarViewModels/WalletViewModel.dart';

class AllTransactionsScreen extends StatefulWidget {
  const AllTransactionsScreen({super.key});

  @override
  State<AllTransactionsScreen> createState() => _AllTransactionsScreenState();
}

class _AllTransactionsScreenState extends State<AllTransactionsScreen> {
  late WalletViewModel viewModel;

  @override
  void initState() {
    super.initState();
    viewModel = Provider.of<WalletViewModel>(context, listen: false);

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await viewModel.fetchTransactions();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<WalletViewModel>(
      builder: (context, viewModel, _) => Scaffold(
        backgroundColor: Colors.white,
        appBar: CommonAppBar(
          title: l10n.of(context).transaction,
        ),
        body: viewModel.istxnLoading
            ? Center(
                child: CircularProgressIndicator(),
              )
            : viewModel.transactions.isEmpty
                ? Center(
                    child: Text(
                      "No Transactions Yet",
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
                    ),
                  )
                : ListView.builder(
                    itemCount: viewModel.transactions.length,
                    itemBuilder: (context, index) {
                      final transaction = viewModel.transactions[index];
                      final currentMonthYear = DateFormat(
                        'MMMM yyyy',
                      ).format(transaction.createdAt);
                      final previousMonthYear = index > 0
                          ? DateFormat(
                              'MMMM yyyy',
                            ).format(
                              viewModel.transactions[index - 1].createdAt)
                          : null;

                      // Show month and year if it's the first transaction or the month changes
                      final bool showHeader =
                          currentMonthYear != previousMonthYear;

                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (showHeader)
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 16,
                                  vertical: 8,
                                ),
                                child: Text(
                                  currentMonthYear,
                                  style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w400,
                                    color: Color(0xFF110B2A),
                                  ),
                                ),
                              ),
                            TransactionTile(transaction: transaction),
                            SizedBox(height: 10)
                          ],
                        ),
                      );
                    },
                  ),
      ),
    );
  }
}
