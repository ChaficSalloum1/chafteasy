// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import '../../ViewModel/NavBarViewModels/AddAmountViewModel/AmountAddedSuccessViewModel.dart';
// import '../../ViewModel/NavBarViewModels/WalletViewModel.dart';

// class AmountAddedSuccessScreen extends StatelessWidget {
//   const AmountAddedSuccessScreen({super.key});

//   @override
//   Widget build(BuildContext context) {
//     double commonWidth =
//         MediaQuery.of(context).size.width * 0.9; // Increased width
//     double commonHeight = 55; // Standardized height
//     return ChangeNotifierProvider(
//       create: (context) => AmountAddedSuccessViewModel(),
//       child: Consumer<AmountAddedSuccessViewModel>(
//         builder: (context, viewModel, child) {
//           return Scaffold(
//             body: Stack(
//               children: [
//                 Column(
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   children: [
//                     Spacer(flex: 5),
//                     Center(
//                       child: Column(
//                         children: [
//                           Image.asset(
//                             viewModel.logoPath,
//                             width: 228,
//                             height: 219,
//                           ),
//                           SizedBox(height: 5),
//                           Text(
//                             viewModel.headText,
//                             style: TextStyle(
//                               fontSize: 32,
//                               fontWeight: FontWeight.w600,
//                             ),
//                           ),
//                           Text(
//                             viewModel.midText,
//                             style: TextStyle(
//                               fontSize: 14,
//                               color: Colors.grey[700],
//                             ),
//                           ),
//                           SizedBox(height: 30),
//                           Padding(
//                             padding: EdgeInsets.symmetric(
//                               horizontal: 20,
//                             ), // Proper padding from left & right
//                             child: Stack(
//                               children: [
//                                 Container(
//                                   height: 52,
//                                   width: double
//                                       .infinity, // Full width for responsiveness
//                                   decoration: BoxDecoration(
//                                     borderRadius: BorderRadius.circular(10),
//                                     color: Color(0xFF72A033),
//                                   ),
//                                 ),
//                                 GestureDetector(
//                                   onTap: () {
//                                     Navigator.pop(context);
//                                     Future.delayed(
//                                       const Duration(milliseconds: 200),
//                                       () {
//                                         // This will trigger the refresh on the WalletScreen
//                                         final viewModel =
//                                             Provider.of<WalletViewModel>(
//                                           context,
//                                           listen: false,
//                                         );
//                                         viewModel.fetchTransactions();
//                                         viewModel.fetchWalletDetail();
//                                       },
//                                     );
//                                   },
//                                   child: Container(
//                                     height: 47,
//                                     width: double
//                                         .infinity, // Full width for responsiveness
//                                     decoration: BoxDecoration(
//                                       color: Color(0xFF8DC63F),
//                                       borderRadius: BorderRadius.circular(10),
//                                     ),
//                                     child: Center(
//                                       child: Row(
//                                         mainAxisAlignment:
//                                             MainAxisAlignment.center,
//                                         children: [
//                                           SizedBox(width: 5),
//                                           Text(
//                                             "Back to Wallet",
//                                             style: TextStyle(
//                                               color: Colors.black,
//                                               fontSize: 16,
//                                               fontWeight: FontWeight.w600,
//                                             ),
//                                           ),
//                                         ],
//                                       ),
//                                     ),
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                     Spacer(flex: 5),
//                   ],
//                 ),
//               ],
//             ),
//           );
//         },
//       ),
//     );
//   }
// }
