
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/main.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import '../../GlobalUtils/app_constants.dart';
import '../../GlobalUtils/common_app_bar.dart';
import '../../Models/TransactionDetailsModel.dart';

class TransactionDetailsScreen extends StatelessWidget {
  final TransactionDetailsModel transaction;

  const TransactionDetailsScreen({Key? key, required this.transaction})
      : super(key: key);

  Future<void> _generateAndOpenPDF(BuildContext context) async {
    try {
      // Labels
      final transactionDetailsLabel = l10n.of(context).transactionDetails;
      final transactionIdLabel = l10n.of(context).transactionId;
      final successfulLabel = l10n.of(context).successful;

      // Load fonts safely
      final fontRegularData = await rootBundle.load("assets/fonts/Outfit-Regular.ttf");
      final fontBoldData = await rootBundle.load("assets/fonts/Outfit-Bold.ttf");
      final fontRegular = pw.Font.ttf(fontRegularData);
      final fontBold = pw.Font.ttf(fontBoldData);

      // Create PDF
      final pdf = pw.Document();
      pdf.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          build: (_) => pw.Container(
            padding: const pw.EdgeInsets.all(20),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(transactionDetailsLabel,
                    style: pw.TextStyle(font: fontBold, fontSize: 24)),
                pw.SizedBox(height: 20),
                pw.Container(
                  padding: const pw.EdgeInsets.all(12),
                  decoration: pw.BoxDecoration(
                    color: PdfColors.grey200,
                    borderRadius: pw.BorderRadius.circular(8),
                  ),
                  child: pw.Row(
                    mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                    children: [
                      pw.Text(
                        "${AppConstants.appCurrency}${transaction.amount.toStringAsFixed(2)}",
                        style: pw.TextStyle(font: fontBold, fontSize: 22, color: PdfColors.green800),
                      ),
                      pw.Text(transaction.type,
                          style: pw.TextStyle(font: fontRegular, fontSize: 14)),
                    ],
                  ),
                ),
                pw.SizedBox(height: 20),
                pw.Text(
                  "$successfulLabel ${DateFormat('hh:mm a \'on\' MMM dd, yyyy').format(transaction.createdAt)}",
                  style: pw.TextStyle(font: fontRegular, fontSize: 14),
                ),
                pw.SizedBox(height: 10),
                pw.Text(transactionIdLabel,
                    style: pw.TextStyle(font: fontBold, fontSize: 16)),
                pw.Text("#${transaction.transactionId}",
                    style: pw.TextStyle(font: fontRegular, fontSize: 16)),
              ],
            ),
          ),
        ),
      );

      // Save file
      final dir = await getTemporaryDirectory();
      final file = File("${dir.path}/transaction_${transaction.transactionId}.pdf");
      await file.writeAsBytes(await pdf.save());

      // Open or Share
      if (Platform.isAndroid) {
        await OpenFilex.open(file.path);
      } else if (Platform.isIOS) {
        await Share.shareXFiles([XFile(file.path)], text: transactionDetailsLabel);
      }
    } catch (e) {
      debugPrint("PDF generation error: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error generating PDF: $e")),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    Color statusColor;
    String statusLabel;
    Color boxBgColor;
    Color textColor;

    switch (transaction.type) {
      case 'Add':
        statusColor = Colors.black;
        statusLabel = l10n.of(context).addedAmount;
        boxBgColor = Colors.black;
        textColor = Colors.white;
        break;
      case 'Credit':
      case 'Debit':
        statusColor = const Color(0xFFFF0200);
        statusLabel = l10n.of(context).paidAmount;
        boxBgColor = const Color(0xFF3B747D);
        textColor = Colors.white;
        break;
      case 'Refund':
        statusColor = const Color(0xFF8DC63F);
        statusLabel = l10n.of(context).refunded;
        boxBgColor = const Color(0xFF5EA101);
        textColor = Colors.white;
        break;
      default:
        statusColor = Colors.grey;
        statusLabel = l10n.of(context).cancel;
        boxBgColor = Colors.grey;
        textColor = Colors.white;
    }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CommonAppBar(
        title: l10n.of(context).transactionDetails,
        backIconColor: Colors.white,
        backgroundColor: Colors.white,

        action: [
          IconButton(
            icon: Icon(Icons.download, color: Colors.black),
            onPressed: () => _generateAndOpenPDF(context),
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  l10n.of(context).transactionInfo,
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                  decoration: BoxDecoration(
                    color: boxBgColor,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    statusLabel,
                    style: TextStyle(
                      color: textColor,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 30),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    blurRadius: 6,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '${AppConstants.appCurrency}${transaction.amount.toStringAsFixed(2)}',
                        style: TextStyle(
                          color: statusColor,
                          fontSize: 30,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Image.asset(
                        'assets/icons/txnamount.png',
                        height: 40,
                        width: 40,
                      ),
                    ],
                  ),
                  Text(
                    '${l10n.of(context).successful} ${DateFormat('hh:mm a \'on\' MMM dd, yyyy').format(transaction.createdAt)}',
                    style: const TextStyle(
                      color: Color(0xFF555555),
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    l10n.of(context).transactionId,
                    style: const TextStyle(
                      color: Color(0XFFA19D9D),
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  Text(
                    '#${transaction.transactionId}',
                    style: const TextStyle(
                      color: Colors.black,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
