class NotificationModel {
  String? id;
  bool? isRead;
  bool? isDelete;
  String? fromId;
  String? toId;
  String? notificationType;
  String? title;
  String? description;
  Data? data;
  String? createdAt;
  String? updatedAt;
  int? v;

  NotificationModel({this.id, this.isRead, this.isDelete, this.fromId, this.toId, this.notificationType, this.title, this.description, this.data, this.createdAt, this.updatedAt, this.v});

  NotificationModel.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    isRead = json["is_read"];
    isDelete = json["is_delete"];
    fromId = json["from_id"];
    toId = json["to_id"];
    notificationType = json["notification_type"];
    title = json["title"];
    description = json["description"];
    data = json["data"] == null ? null : Data.fromJson(json["data"]);
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["is_read"] = isRead;
    _data["is_delete"] = isDelete;
    _data["from_id"] = fromId;
    _data["to_id"] = toId;
    _data["notification_type"] = notificationType;
    _data["title"] = title;
    _data["description"] = description;
    if (data != null) {
      _data["data"] = data?.toJson();
    }
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    return _data;
  }
}

class Data {
  String? type;

  Data({this.type});

  Data.fromJson(Map<String, dynamic> json) {
    type = json["type"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["type"] = type;
    return _data;
  }
}
