

// To parse this JSON data, do
//
//     final bookingCourtDetailsModel = bookingCourtDetailsModelFromJson(jsonString);

import 'dart:convert';

BookingCourtDetailsModel bookingCourtDetailsModelFromJson(String str) => BookingCourtDetailsModel.fromJson(json.decode(str));

String bookingCourtDetailsModelToJson(BookingCourtDetailsModel data) => json.encode(data.toJson());

class BookingCourtDetailsModel {
  bool? status;
  String? message;
  Data? data;
  int? exeTime;

  BookingCourtDetailsModel({
    this.status,
    this.message,
    this.data,
    this.exeTime,
  });

  factory BookingCourtDetailsModel.fromJson(Map<String, dynamic> json) => BookingCourtDetailsModel(
    status: json["status"],
    message: json["message"],
    data: json["data"] == null ? null : Data.fromJson(json["data"]),
    exeTime: json["exeTime"],
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "data": data?.toJson(),
    "exeTime": exeTime,
  };
}

class Data {
  String? id;
  String? bookingId;
  String? userId;
  CourtId? courtId;
  dynamic challengeId;
  DataFacilityId? facilityId;
  String? facilityOwnerId;
  SlotId? slotId;
  DateTime? bookingStartTime;
  String? slotTime;
  String? startTime;
  String? endTime;
  double? startTime24;
  double? endTime24;
  dynamic duration;
  int? adminCommission;
  int? facilityOwnerAmount;
  int? price;
  String? type;
  dynamic discountId;
  int? discountAmount;
  bool? isRecorded;
  bool? isOfflineBooking;
  bool? isReview;
  bool? isModified;
  String? status;
  bool? isSplit;
  String? paymentStatus;
  DateTime? date;
  List<Friend>? friends;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;
  int? courtBookingCount;

  Data({
    this.id,
    this.bookingId,
    this.userId,
    this.courtId,
    this.challengeId,
    this.facilityId,
    this.facilityOwnerId,
    this.slotId,
    this.bookingStartTime,
    this.slotTime,
    this.startTime,
    this.endTime,
    this.startTime24,
    this.endTime24,
    this.duration,
    this.adminCommission,
    this.facilityOwnerAmount,
    this.price,
    this.type,
    this.discountId,
    this.discountAmount,
    this.isRecorded,
    this.isOfflineBooking,
    this.isReview,
    this.isModified,
    this.status,
    this.isSplit,
    this.paymentStatus,
    this.date,
    this.friends,
    this.createdAt,
    this.updatedAt,
    this.v,
    this.courtBookingCount,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    id: json["_id"],
    bookingId: json["booking_id"],
    userId: json["user_id"],
    courtId: json["court_id"] == null ? null : CourtId.fromJson(json["court_id"]),
    challengeId: json["challenge_id"],
    facilityId: json["facility_id"] == null ? null : DataFacilityId.fromJson(json["facility_id"]),
    facilityOwnerId: json["facility_owner_id"],
    slotId: json["slot_id"] == null ? null : SlotId.fromJson(json["slot_id"]),
    bookingStartTime: json["bookingStartTime"] == null ? null : DateTime.parse(json["bookingStartTime"]),
    slotTime: json["slotTime"],
    startTime: json["startTime"],
    endTime: json["endTime"],
    startTime24: json["startTime24"]?.toDouble(),
    endTime24: json["endTime24"]?.toDouble(),
    duration: json["duration"],
    adminCommission: json["admin_commission"],
    facilityOwnerAmount: json["facility_owner_amount"],
    price: json["price"],
    type: json["type"],
    discountId: json["discountId"],
    discountAmount: json["discountAmount"],
    isRecorded: json["is_recorded"],
    isOfflineBooking: json["isOfflineBooking"],
    isReview: json["is_review"],
    isModified: json["is_modified"],
    status: json["status"],
    isSplit: json["is_split"],
    paymentStatus: json["payment_status"],
    date: json["date"] == null ? null : DateTime.parse(json["date"]),
    friends: json["friends"] == null ? [] : List<Friend>.from(json["friends"]!.map((x) => Friend.fromJson(x))),
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    v: json["__v"],
    courtBookingCount: json["court_booking_count"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "booking_id": bookingId,
    "user_id": userId,
    "court_id": courtId?.toJson(),
    "challenge_id": challengeId,
    "facility_id": facilityId?.toJson(),
    "facility_owner_id": facilityOwnerId,
    "slot_id": slotId?.toJson(),
    "bookingStartTime": bookingStartTime?.toIso8601String(),
    "slotTime": slotTime,
    "startTime": startTime,
    "endTime": endTime,
    "startTime24": startTime24,
    "endTime24": endTime24,
    "duration": duration,
    "admin_commission": adminCommission,
    "facility_owner_amount": facilityOwnerAmount,
    "price": price,
    "type": type,
    "discountId": discountId,
    "discountAmount": discountAmount,
    "is_recorded": isRecorded,
    "isOfflineBooking": isOfflineBooking,
    "is_review": isReview,
    "is_modified": isModified,
    "status": status,
    "is_split": isSplit,
    "payment_status": paymentStatus,
    "date": date?.toIso8601String(),
    "friends": friends == null ? [] : List<dynamic>.from(friends!.map((x) => x.toJson())),
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "__v": v,
    "court_booking_count": courtBookingCount,
  };
}

class CourtId {
  String? id;
  String? image;
  int? startTime;
  int? endTime;
  int? price;
  int? minHours;
  List<dynamic>? gallery;
  int? averageRating;
  int? totalRating;
  SportId? sportId;
  CourtIdFacilityId? facilityId;
  String? facilityOwnerId;
  String? userId;
  bool? isActive;
  bool? isDelete;
  bool? isFavorite;
  String? name;
  String? grName;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;
  int? totalBookings;

  CourtId({
    this.id,
    this.image,
    this.startTime,
    this.endTime,
    this.price,
    this.minHours,
    this.gallery,
    this.averageRating,
    this.totalRating,
    this.sportId,
    this.facilityId,
    this.facilityOwnerId,
    this.userId,
    this.isActive,
    this.isDelete,
    this.isFavorite,
    this.name,
    this.grName,
    this.createdAt,
    this.updatedAt,
    this.v,
    this.totalBookings,
  });

  factory CourtId.fromJson(Map<String, dynamic> json) => CourtId(
    id: json["_id"],
    image: json["image"],
    startTime: json["startTime"],
    endTime: json["endTime"],
    price: json["price"],
    minHours: json["minHours"],
    gallery: json["gallery"] == null ? [] : List<dynamic>.from(json["gallery"]!.map((x) => x)),
    averageRating: json["averageRating"],
    totalRating: json["totalRating"],
    sportId: json["sport_id"] == null ? null : SportId.fromJson(json["sport_id"]),
    facilityId: json["facility_id"] == null ? null : CourtIdFacilityId.fromJson(json["facility_id"]),
    facilityOwnerId: json["facility_owner_id"],
    userId: json["user_id"],
    isActive: json["is_active"],
    isDelete: json["is_delete"],
    isFavorite: json["is_favorite"],
    name: json["name"],
    grName: json["gr_name"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    v: json["__v"],
    totalBookings: json["total_bookings"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "image": image,
    "startTime": startTime,
    "endTime": endTime,
    "price": price,
    "minHours": minHours,
    "gallery": gallery == null ? [] : List<dynamic>.from(gallery!.map((x) => x)),
    "averageRating": averageRating,
    "totalRating": totalRating,
    "sport_id": sportId?.toJson(),
    "facility_id": facilityId?.toJson(),
    "facility_owner_id": facilityOwnerId,
    "user_id": userId,
    "is_active": isActive,
    "is_delete": isDelete,
    "is_favorite": isFavorite,
    "name": name,
    "gr_name": grName,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "__v": v,
    "total_bookings": totalBookings,
  };
}

class CourtIdFacilityId {
  String? id;
  String? name;
  String? image;
  String? address;

  CourtIdFacilityId({
    this.id,
    this.name,
    this.image,
    this.address,
  });

  factory CourtIdFacilityId.fromJson(Map<String, dynamic> json) => CourtIdFacilityId(
    id: json["_id"],
    name: json["name"],
    image: json["image"],
    address: json["address"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "name": name,
    "image": image,
    "address": address,
  };
}

class SportId {
  String? id;
  String? name;
  String? image;
  List<String>? skillLevel;
  String? matchType;
  bool? isActive;
  bool? isDelete;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;

  SportId({
    this.id,
    this.name,
    this.image,
    this.skillLevel,
    this.matchType,
    this.isActive,
    this.isDelete,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  factory SportId.fromJson(Map<String, dynamic> json) => SportId(
    id: json["_id"],
    name: json["name"],
    image: json["image"],
    skillLevel: json["skill_level"] == null ? [] : List<String>.from(json["skill_level"]!.map((x) => x)),
    matchType: json["match_type"],
    isActive: json["is_active"],
    isDelete: json["is_delete"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    v: json["__v"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "name": name,
    "image": image,
    "skill_level": skillLevel == null ? [] : List<dynamic>.from(skillLevel!.map((x) => x)),
    "match_type": matchType,
    "is_active": isActive,
    "is_delete": isDelete,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "__v": v,
  };
}

class DataFacilityId {
  String? id;
  String? name;
  String? image;
  String? description;
  String? bio;
  List<dynamic>? gallery;
  String? subscriptionStatus;
  double? latitude;
  double? longitude;
  String? address;
  List<String>? amenities;
  String? facilityOwner;
  bool? isActive;
  bool? isDelete;
  Location? location;
  List<dynamic>? team;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;

  DataFacilityId({
    this.id,
    this.name,
    this.image,
    this.description,
    this.bio,
    this.gallery,
    this.subscriptionStatus,
    this.latitude,
    this.longitude,
    this.address,
    this.amenities,
    this.facilityOwner,
    this.isActive,
    this.isDelete,
    this.location,
    this.team,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  factory DataFacilityId.fromJson(Map<String, dynamic> json) => DataFacilityId(
    id: json["_id"],
    name: json["name"],
    image: json["image"],
    description: json["description"],
    bio: json["bio"],
    gallery: json["gallery"] == null ? [] : List<dynamic>.from(json["gallery"]!.map((x) => x)),
    subscriptionStatus: json["subscription_status"],
    latitude: json["latitude"]?.toDouble(),
    longitude: json["longitude"]?.toDouble(),
    address: json["address"],
    amenities: json["amenities"] == null ? [] : List<String>.from(json["amenities"]!.map((x) => x)),
    facilityOwner: json["facility_owner"],
    isActive: json["is_active"],
    isDelete: json["is_delete"],
    location: json["location"] == null ? null : Location.fromJson(json["location"]),
    team: json["team"] == null ? [] : List<dynamic>.from(json["team"]!.map((x) => x)),
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    v: json["__v"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "name": name,
    "image": image,
    "description": description,
    "bio": bio,
    "gallery": gallery == null ? [] : List<dynamic>.from(gallery!.map((x) => x)),
    "subscription_status": subscriptionStatus,
    "latitude": latitude,
    "longitude": longitude,
    "address": address,
    "amenities": amenities == null ? [] : List<dynamic>.from(amenities!.map((x) => x)),
    "facility_owner": facilityOwner,
    "is_active": isActive,
    "is_delete": isDelete,
    "location": location?.toJson(),
    "team": team == null ? [] : List<dynamic>.from(team!.map((x) => x)),
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "__v": v,
  };
}

class Location {
  String? type;
  List<double>? coordinates;

  Location({
    this.type,
    this.coordinates,
  });

  factory Location.fromJson(Map<String, dynamic> json) => Location(
    type: json["type"],
    coordinates: json["coordinates"] == null ? [] : List<double>.from(json["coordinates"]!.map((x) => x?.toDouble())),
  );

  Map<String, dynamic> toJson() => {
    "type": type,
    "coordinates": coordinates == null ? [] : List<dynamic>.from(coordinates!.map((x) => x)),
  };
}

class Friend {
  String? name;
  String? mobileNumber;
  String? countryCode;
  int? splitAmount;
  bool? isPaid;
  bool? isFriendFavorite;
  bool? isReviewed;
  String? id;

  Friend({
    this.name,
    this.mobileNumber,
    this.countryCode,
    this.splitAmount,
    this.isPaid,
    this.isFriendFavorite,
    this.isReviewed,
    this.id,
  });

  factory Friend.fromJson(Map<String, dynamic> json) => Friend(
    name: json["name"],
    mobileNumber: json["mobile_number"],
    countryCode: json["country_code"],
    splitAmount: json["split_amount"],
    isPaid: json["is_paid"],
    isFriendFavorite: json["is_friend_favorite"],
    isReviewed: json["isReviewed"],
    id: json["_id"],
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "mobile_number": mobileNumber,
    "country_code": countryCode,
    "split_amount": splitAmount,
    "is_paid": isPaid,
    "is_friend_favorite": isFriendFavorite,
    "isReviewed": isReviewed,
    "_id": id,
  };
}

class SlotId {
  String? id;
  String? startTime;
  String? endTime;
  double? startTime24;
  double? endTime24;
  String? day;
  int? price;
  String? courtId;
  bool? isActive;
  bool? isDelete;
  int? v;
  DateTime? createdAt;
  DateTime? updatedAt;

  SlotId({
    this.id,
    this.startTime,
    this.endTime,
    this.startTime24,
    this.endTime24,
    this.day,
    this.price,
    this.courtId,
    this.isActive,
    this.isDelete,
    this.v,
    this.createdAt,
    this.updatedAt,
  });

  factory SlotId.fromJson(Map<String, dynamic> json) => SlotId(
    id: json["_id"],
    startTime: json["startTime"],
    endTime: json["endTime"],
    startTime24: json["startTime24"]?.toDouble(),
    endTime24: json["endTime24"]?.toDouble(),
    day: json["day"],
    price: json["price"],
    courtId: json["court_id"],
    isActive: json["is_active"],
    isDelete: json["is_delete"],
    v: json["__v"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "startTime": startTime,
    "endTime": endTime,
    "startTime24": startTime24,
    "endTime24": endTime24,
    "day": day,
    "price": price,
    "court_id": courtId,
    "is_active": isActive,
    "is_delete": isDelete,
    "__v": v,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
  };
}
