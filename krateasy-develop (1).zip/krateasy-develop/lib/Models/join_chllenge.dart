

// To parse this JSON data, do
//
//     final joinChallengeModel = joinChallengeModelFromJson(jsonString);

import 'dart:convert';

JoinChallengeModel joinChallengeModelFromJson(String str) => JoinChallengeModel.fromJson(json.decode(str));

String joinChallengeModelToJson(JoinChallengeModel data) => json.encode(data.toJson());

class JoinChallengeModel {
  bool? status;
  String? message;
  Data? data;
  int? exeTime;

  JoinChallengeModel({
    this.status,
    this.message,
    this.data,
    this.exeTime,
  });

  factory JoinChallengeModel.fromJson(Map<String, dynamic> json) => JoinChallengeModel(
    status: json["status"],
    message: json["message"],
    data: json["data"] == null ? null : Data.fromJson(json["data"]),
    exeTime: json["exeTime"],
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "data": data?.toJson(),
    "exeTime": exeTime,
  };
}

class Data {
  String? id;
  bool? isPublic;
  bool? isRecorded;
  DateTime? bookingStartTime;
  dynamic slotTime;
  String? startTime;
  String? endTime;
  int? startTime24;
  int? endTime24;
  bool? isDisabled;
  String? sportId;
  String? skillLevel;
  String? status;
  String? facilityId;
  int? maxPlayer;
  List<String>? whoJoined;
  String? courtId;
  String? userId;
  List<String>? slotId;
  dynamic privateCode;
  bool? isReview;
  bool? isActive;
  bool? isDelete;
  bool? isSplit;
  String? cancellationPolicy;
  String? transactionId;
  DateTime? date;
  List<dynamic>? friends;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;
  String? bookingId;

  Data({
    this.id,
    this.isPublic,
    this.isRecorded,
    this.bookingStartTime,
    this.slotTime,
    this.startTime,
    this.endTime,
    this.startTime24,
    this.endTime24,
    this.isDisabled,
    this.sportId,
    this.skillLevel,
    this.status,
    this.facilityId,
    this.maxPlayer,
    this.whoJoined,
    this.courtId,
    this.userId,
    this.slotId,
    this.privateCode,
    this.isReview,
    this.isActive,
    this.isDelete,
    this.isSplit,
    this.cancellationPolicy,
    this.transactionId,
    this.date,
    this.friends,
    this.createdAt,
    this.updatedAt,
    this.v,
    this.bookingId,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    id: json["_id"],
    isPublic: json["is_public"],
    isRecorded: json["is_recorded"],
    bookingStartTime: json["bookingStartTime"] == null ? null : DateTime.parse(json["bookingStartTime"]),
    slotTime: json["slotTime"],
    startTime: json["startTime"],
    endTime: json["endTime"],
    startTime24: json["startTime24"],
    endTime24: json["endTime24"],
    isDisabled: json["is_disabled"],
    sportId: json["sport_id"],
    skillLevel: json["skill_level"],
    status: json["status"],
    facilityId: json["facility_id"],
    maxPlayer: json["max_player"],
    whoJoined: json["who_joined"] == null ? [] : List<String>.from(json["who_joined"]!.map((x) => x)),
    courtId: json["court_id"],
    userId: json["user_id"],
    slotId: json["slot_id"] == null ? [] : List<String>.from(json["slot_id"]!.map((x) => x)),
    privateCode: json["private_code"],
    isReview: json["is_review"],
    isActive: json["is_active"],
    isDelete: json["is_delete"],
    isSplit: json["isSplit"],
    cancellationPolicy: json["cancellation_policy"],
    transactionId: json["transactionId"],
    date: json["date"] == null ? null : DateTime.parse(json["date"]),
    friends: json["friends"] == null ? [] : List<dynamic>.from(json["friends"]!.map((x) => x)),
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    v: json["__v"],
    bookingId: json["booking_id"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "is_public": isPublic,
    "is_recorded": isRecorded,
    "bookingStartTime": bookingStartTime?.toIso8601String(),
    "slotTime": slotTime,
    "startTime": startTime,
    "endTime": endTime,
    "startTime24": startTime24,
    "endTime24": endTime24,
    "is_disabled": isDisabled,
    "sport_id": sportId,
    "skill_level": skillLevel,
    "status": status,
    "facility_id": facilityId,
    "max_player": maxPlayer,
    "who_joined": whoJoined == null ? [] : List<dynamic>.from(whoJoined!.map((x) => x)),
    "court_id": courtId,
    "user_id": userId,
    "slot_id": slotId == null ? [] : List<dynamic>.from(slotId!.map((x) => x)),
    "private_code": privateCode,
    "is_review": isReview,
    "is_active": isActive,
    "is_delete": isDelete,
    "isSplit": isSplit,
    "cancellation_policy": cancellationPolicy,
    "transactionId": transactionId,
    "date": date?.toIso8601String(),
    "friends": friends == null ? [] : List<dynamic>.from(friends!.map((x) => x)),
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "__v": v,
    "booking_id": bookingId,
  };
}
