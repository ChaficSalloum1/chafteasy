class BookingDetailsModel {
  bool? status;
  String? message;
  Data? data;
  int? exeTime;

  BookingDetailsModel({this.status, this.message, this.data, this.exeTime});

  BookingDetailsModel.fromJson(Map<String, dynamic> json) {
    status = json["status"];
    message = json["message"];
    data = json["data"] == null ? null : Data.fromJson(json["data"]);
    exeTime = json["exeTime"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["status"] = status;
    _data["message"] = message;
    if (data != null) {
      _data["data"] = data?.toJson();
    }
    _data["exeTime"] = exeTime;
    return _data;
  }
}

class Data {
  String? id;
  String? bookingId;
  String? userId;
  CourtId? courtId;
  dynamic challengeId;
  FacilityId1? facilityId;
  String? facilityOwnerId;
  SlotId? slotId;
  String? slotTime;
  String? startTime;
  String? endTime;
  dynamic duration;
  dynamic adminCommission;
  dynamic facilityOwnerAmount;
  dynamic price;
  String? type;
  dynamic discountId;
  dynamic discountAmount;
  bool? isRecorded;
  bool? isReview;
  String? status;
  bool? isSplit;
  String? paymentStatus;
  String? date;
  String? bookingstarttime;
  List<Friend>? friends;
  String? createdAt;
  String? updatedAt;
  dynamic v;
  dynamic courtBookingCount;

  Data(
      {this.id,
      this.bookingId,
      this.userId,
      this.courtId,
      this.challengeId,
      this.facilityId,
      this.facilityOwnerId,
      this.slotId,
      this.slotTime,
      this.startTime,
      this.endTime,
      this.duration,
      this.adminCommission,
      this.facilityOwnerAmount,
      this.price,
      this.type,
      this.discountId,
      this.discountAmount,
      this.isRecorded,
      this.isReview,
      this.status,
      this.isSplit,
      this.paymentStatus,
      this.date,
      this.bookingstarttime,
      this.friends,
      this.createdAt,
      this.updatedAt,
      this.v,
      this.courtBookingCount});

  Data.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    bookingId = json["booking_id"];
    userId = json["user_id"];
    courtId =
        json["court_id"] == null ? null : CourtId.fromJson(json["court_id"]);
    challengeId = json["challenge_id"];
    facilityId = json["facility_id"] == null
        ? null
        : FacilityId1.fromJson(json["facility_id"]);
    facilityOwnerId = json["facility_owner_id"];
    slotId = json["slot_id"] == null ? null : SlotId.fromJson(json["slot_id"]);
    slotTime = json["slotTime"];
    startTime = json["startTime"];
    endTime = json["endTime"];
    duration = json["duration"];
    adminCommission = json["admin_commission"];
    facilityOwnerAmount = json["facility_owner_amount"];
    price = json["price"];
    type = json["type"];
    discountId = json["discountId"];
    discountAmount = json["discountAmount"];
    isRecorded = json["is_recorded"];
    isReview = json["is_review"];
    status = json["status"];
    isSplit = json["is_split"];
    paymentStatus = json["payment_status"];
    date = json["date"];
    bookingstarttime = json["bookingStartTime"];

    friends = (json['friends'] as List<dynamic>?)
        ?.map((e) => Friend.fromJson(e as Map<String, dynamic>))
        .toList();
    // friends = json["friends"] ?? [];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
    courtBookingCount = json["court_booking_count"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["booking_id"] = bookingId;
    _data["user_id"] = userId;
    if (courtId != null) {
      _data["court_id"] = courtId?.toJson();
    }
    _data["challenge_id"] = challengeId;
    if (facilityId != null) {
      _data["facility_id"] = facilityId?.toJson();
    }
    _data["facility_owner_id"] = facilityOwnerId;
    if (slotId != null) {
      _data["slot_id"] = slotId?.toJson();
    }
    _data["slotTime"] = slotTime;
    _data["startTime"] = startTime;
    _data["endTime"] = endTime;
    _data["duration"] = duration;
    _data["admin_commission"] = adminCommission;
    _data["facility_owner_amount"] = facilityOwnerAmount;
    _data["price"] = price;
    _data["type"] = type;
    _data["discountId"] = discountId;
    _data["discountAmount"] = discountAmount;
    _data["is_recorded"] = isRecorded;
    _data["is_review"] = isReview;
    _data["status"] = status;
    _data["is_split"] = isSplit;
    _data["payment_status"] = paymentStatus;
    _data["date"] = date;
    _data["bookingStartTime"] = bookingstarttime;
    if (friends != null) {
      _data["friends"] = friends;
    }
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    _data["court_booking_count"] = courtBookingCount;
    return _data;
  }
}

class SlotId {
  String? id;
  String? startTime;
  String? endTime;
  String? day;
  dynamic price;
  String? courtId;
  bool? isActive;
  bool? isDelete;
  dynamic v;
  String? createdAt;
  String? updatedAt;

  SlotId(
      {this.id,
      this.startTime,
      this.endTime,
      this.day,
      this.price,
      this.courtId,
      this.isActive,
      this.isDelete,
      this.v,
      this.createdAt,
      this.updatedAt});

  SlotId.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    startTime = json["startTime"];
    endTime = json["endTime"];
    day = json["day"];
    price = json["price"];
    courtId = json["court_id"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    v = json["__v"];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["startTime"] = startTime;
    _data["endTime"] = endTime;
    _data["day"] = day;
    _data["price"] = price;
    _data["court_id"] = courtId;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["__v"] = v;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    return _data;
  }
}

class FacilityId1 {
  String? id;
  String? name;
  dynamic image;
  String? description;
  String? bio;
  List<dynamic>? gallery;
  String? subscriptionStatus;
  double? latitude;
  double? longitude;
  String? address;
  List<Amenities>? amenities;
  String? facilityOwner;
  bool? isActive;
  bool? isDelete;
  List<dynamic>? team;
  Location? location;
  String? createdAt;
  String? updatedAt;
  dynamic v;

  FacilityId1(
      {this.id,
      this.name,
      this.image,
      this.description,
      this.bio,
      this.gallery,
      this.subscriptionStatus,
      this.latitude,
      this.longitude,
      this.address,
      this.amenities,
      this.facilityOwner,
      this.isActive,
      this.isDelete,
      this.team,
      this.location,
      this.createdAt,
      this.updatedAt,
      this.v});

  FacilityId1.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    name = json["name"];
    image = json["image"];
    description = json["description"];
    bio = json["bio"];
    gallery = json["gallery"] ?? [];
    subscriptionStatus = json["subscription_status"];
    latitude = json["latitude"];
    longitude = json["longitude"];
    address = json["address"];
    if (json["amenities"] != null && json["amenities"] is List) {
      amenities = (json["amenities"] as List)
          .where((e) => e is Map<String, dynamic>)
          .map((e) => Amenities.fromJson(e as Map<String, dynamic>))
          .toList();
    } else {
      amenities = null;
    }

    facilityOwner = json["facility_owner"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    team = json["team"] ?? [];
    location =
        json["location"] == null ? null : Location.fromJson(json["location"]);
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["name"] = name;
    _data["image"] = image;
    _data["description"] = description;
    _data["bio"] = bio;
    if (gallery != null) {
      _data["gallery"] = gallery;
    }
    _data["subscription_status"] = subscriptionStatus;
    _data["latitude"] = latitude;
    _data["longitude"] = longitude;
    _data["address"] = address;
    if (amenities != null) {
      _data["amenities"] = amenities?.map((e) => e.toJson()).toList();
    }
    _data["facility_owner"] = facilityOwner;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    if (team != null) {
      _data["team"] = team;
    }
    if (location != null) {
      _data["location"] = location?.toJson();
    }
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    return _data;
  }
}

class Amenities {
  String? id;
  bool? isActive;
  bool? isDelete;
  String? name;
  String? image;
  String? createdAt;
  String? updatedAt;
  dynamic v;

  Amenities(
      {this.id,
      this.isActive,
      this.isDelete,
      this.name,
      this.image,
      this.createdAt,
      this.updatedAt,
      this.v});

  Amenities.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    name = json["name"];
    image = json["image"];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["name"] = name;
    _data["image"] = image;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    return _data;
  }
}

class Location {
  String? type;
  List<double>? coordinates;

  Location({this.type, this.coordinates});

  Location.fromJson(Map<String, dynamic> json) {
    type = json["type"];
    coordinates = json["coordinates"] == null
        ? null
        : List<double>.from(json["coordinates"]);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["type"] = type;
    if (coordinates != null) {
      _data["coordinates"] = coordinates;
    }
    return _data;
  }
}

class CourtId {
  String? id;
  String? image;
  dynamic price;
  List<dynamic>? gallery;
  dynamic averageRating;
  SportId? sportId;
  FacilityId? facilityId;
  String? facilityOwnerId;
  String? userId;
  bool? isActive;
  bool? isDelete;
  bool? isFavorite;
  String? name;
  String? createdAt;
  String? updatedAt;
  dynamic v;
  dynamic totalRating;
  dynamic totalBookings;

  CourtId(
      {this.id,
      this.image,
      this.price,
      this.gallery,
      this.averageRating,
      this.sportId,
      this.facilityId,
      this.facilityOwnerId,
      this.userId,
      this.isActive,
      this.isDelete,
      this.isFavorite,
      this.name,
      this.createdAt,
      this.updatedAt,
      this.v,
      this.totalRating,
      this.totalBookings});

  CourtId.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    image = json["image"];
    price = json["price"];
    gallery = json["gallery"] ?? [];
    averageRating = json["averageRating"];
    sportId =
        json["sport_id"] == null ? null : SportId.fromJson(json["sport_id"]);
    facilityId = json["facility_id"] == null
        ? null
        : FacilityId.fromJson(json["facility_id"]);
    facilityOwnerId = json["facility_owner_id"];
    userId = json["user_id"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    isFavorite = json["is_favorite"];
    name = json["name"];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
    totalRating = json["totalRating"];
    totalBookings = json["total_bookings"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["image"] = image;
    _data["price"] = price;
    if (gallery != null) {
      _data["gallery"] = gallery;
    }
    _data["averageRating"] = averageRating;
    if (sportId != null) {
      _data["sport_id"] = sportId?.toJson();
    }
    if (facilityId != null) {
      _data["facility_id"] = facilityId?.toJson();
    }
    _data["facility_owner_id"] = facilityOwnerId;
    _data["user_id"] = userId;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["is_favorite"] = isFavorite;
    _data["name"] = name;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    _data["totalRating"] = totalRating;
    _data["total_bookings"] = totalBookings;
    return _data;
  }
}

class FacilityId {
  String? id;
  String? name;
  dynamic image;
  String? address;

  FacilityId({this.id, this.name, this.image, this.address});

  FacilityId.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    name = json["name"];
    image = json["image"];
    address = json["address"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["name"] = name;
    _data["image"] = image;
    _data["address"] = address;
    return _data;
  }
}

class SportId {
  String? id;
  String? name;
  String? image;
  List<String>? skillLevel;
  String? matchType;
  bool? isActive;
  bool? isDelete;
  String? createdAt;
  String? updatedAt;
  dynamic v;

  SportId(
      {this.id,
      this.name,
      this.image,
      this.skillLevel,
      this.matchType,
      this.isActive,
      this.isDelete,
      this.createdAt,
      this.updatedAt,
      this.v});

  SportId.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    name = json["name"];
    image = json["image"];
    skillLevel = json["skill_level"] == null
        ? null
        : List<String>.from(json["skill_level"]);
    matchType = json["match_type"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["name"] = name;
    _data["image"] = image;
    if (skillLevel != null) {
      _data["skill_level"] = skillLevel;
    }
    _data["match_type"] = matchType;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    return _data;
  }
}

//friend arrey
class Friend {
  final String? id;
  final String? playerid;
  final String? image;
  final String? name;
  final String? mobileNumber;
  final String? countryCode;
  final dynamic? splitAmount;
  final bool? isPaid;
  final bool? isFriendFavorite;
  final bool? isReviewed;

  Friend(
      {this.id,this.playerid,
      this.name,
      this.mobileNumber,
      this.countryCode,
      this.splitAmount,
      this.isPaid,
      this.isFriendFavorite,
      this.isReviewed,
      this.image});

  factory Friend.fromJson(Map<String, dynamic> json) {
    return Friend(
        id: json['_id'],
        playerid: json['player_id'],
        name: json['name'],
        mobileNumber: json['mobile_number'],
        countryCode: json['country_code'],
        splitAmount: json['split_amount'],
        isPaid: json['is_paid'],
        isFriendFavorite: json['is_friend_favorite'],
        isReviewed: json['isReviewed'],
        image: json["image"]);
  }

  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'player_id': playerid,
      'name': name,
      'mobile_number': mobileNumber,
      'country_code': countryCode,
      'split_amount': splitAmount,
      'is_paid': isPaid,
      'is_friend_favorite': isFriendFavorite,
      'isReviewed': isReviewed,
      "image":image
    };
  }
}
