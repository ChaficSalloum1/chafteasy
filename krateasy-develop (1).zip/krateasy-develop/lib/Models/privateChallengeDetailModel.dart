class PrivateChallengeDetailModel {
  final bool? status;
  final String? message;
  final ChallengeData? data;
  final int? exeTime;

  PrivateChallengeDetailModel({this.status, this.message, this.data, this.exeTime});

  factory PrivateChallengeDetailModel.fromJson(Map<String, dynamic> json) {
    return PrivateChallengeDetailModel(
      status: json['status'],
      message: json['message'],
      data: json['data'] != null ? ChallengeData.fromJson(json['data']) : null,
      exeTime: json['exeTime'],
    );
  }
}

class ChallengeData {
  final String? id;
  final String? date;
  final dynamic skillLevel;
  final int? maxPlayer;
  final List<JoinedUser>? whoJoined;
  final CreatedBy? createdBy;
  final SlotData? slots;

  ChallengeData({
    this.id,
    this.date,
    this.skillLevel,
    this.maxPlayer,
    this.whoJoined,
    this.createdBy,
    this.slots,
  });

  factory ChallengeData.fromJson(Map<String, dynamic> json) {
    return ChallengeData(
      id: json['_id'],
      date: json['date'],
      skillLevel: json['skill_level'],
      maxPlayer: json['max_player'],
      whoJoined: (json['who_joined'] as List?)
          ?.map((e) => JoinedUser.fromJson(e))
          .toList(),
      createdBy: json['created_by'] != null
          ? CreatedBy.fromJson(json['created_by'])
          : null,
      slots: json['slots'] != null ? SlotData.fromJson(json['slots']) : null,
    );
  }
}

class JoinedUser {
  final String? id;
  final String? image;
  final String? name;

  JoinedUser({this.id, this.image, this.name});

  factory JoinedUser.fromJson(Map<String, dynamic> json) {
    return JoinedUser(
      id: json['_id'],
      image: json['image'],
      name: json['name'],
    );
  }
}

class CreatedBy {
  final String? id;

  CreatedBy({this.id});

  factory CreatedBy.fromJson(Map<String, dynamic> json) {
    return CreatedBy(id: json['_id']);
  }
}

class SlotData {
  final String? startTime;
  final String? endTime;
  final String? day;
  final Court? court;
  final dynamic price;

  SlotData({this.startTime, this.endTime, this.day, this.court, this.price});

  factory SlotData.fromJson(Map<String, dynamic> json) {
    return SlotData(
      startTime: json['startTime'],
      endTime: json['endTime'],
      day: json['day'],
      court: json['court'] != null ? Court.fromJson(json['court']) : null,
      price: json['price'],
    );
  }
}

class Court {
  final String? id;
  final String? image;
  final int? averageRating;
  final String? name;
  final Sport? sport;
  final Facility? facility;
  final int? totalBookingCount;

  Court({
    this.id,
    this.image,
    this.averageRating,
    this.name,
    this.sport,
    this.facility,
    this.totalBookingCount,
  });

  factory Court.fromJson(Map<String, dynamic> json) {
    return Court(
      id: json['_id'],
      image: json['image'],
      averageRating: json['averageRating'],
      name: json['name'],
      sport: json['sport'] != null ? Sport.fromJson(json['sport']) : null,
      facility:
          json['facility'] != null ? Facility.fromJson(json['facility']) : null,
      totalBookingCount: json['totalBookingCount'],
    );
  }
}

class Sport {
  final String? name;
  final String? image;

  Sport({this.name, this.image});

  factory Sport.fromJson(Map<String, dynamic> json) {
    return Sport(
      name: json['name'],
      image: json['image'],
    );
  }
}

class Facility {
  final String? name;
  final String? image;
  final String? description;
  final String? bio;
  final List<dynamic>? gallery;
  final String? address;
  final List<Amenity>? amenities;

  Facility({
    this.name,
    this.image,
    this.description,
    this.bio,
    this.gallery,
    this.address,
    this.amenities,
  });

  factory Facility.fromJson(Map<String, dynamic> json) {
    return Facility(
      name: json['name'],
      image: json['image'],
      description: json['description'],
      bio: json['bio'],
      gallery: json['gallery'],
      address: json['address'],
      amenities: (json['amenities'] as List?)
          ?.map((e) => Amenity.fromJson(e))
          .toList(),
    );
  }
}

class Amenity {
  final String? id;
  final bool? isActive;
  final bool? isDelete;
  final String? name;
  final String? image;
  final String? createdAt;
  final String? updatedAt;
  final int? v;

  Amenity({
    this.id,
    this.isActive,
    this.isDelete,
    this.name,
    this.image,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  factory Amenity.fromJson(Map<String, dynamic> json) {
    return Amenity(
      id: json['_id'],
      isActive: json['is_active'],
      isDelete: json['is_delete'],
      name: json['name'],
      image: json['image'],
      createdAt: json['created_at'],
      updatedAt: json['updated_at'],
      v: json['__v'],
    );
  }
}
