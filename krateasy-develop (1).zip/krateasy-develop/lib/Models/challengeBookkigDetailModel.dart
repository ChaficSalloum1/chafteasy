


// To parse this JSON data, do
//
//     final bookingChallengesDetailsModel = bookingChallengesDetailsModelFromJson(jsonString);

import 'dart:convert';

BookingChallengesDetailsModel bookingChallengesDetailsModelFromJson(String str) => BookingChallengesDetailsModel.fromJson(json.decode(str));

String bookingChallengesDetailsModelToJson(BookingChallengesDetailsModel data) => json.encode(data.toJson());

class BookingChallengesDetailsModel {
  bool? status;
  String? message;
  BookingChallengesDetailsModelData? data;
  int? exeTime;

  BookingChallengesDetailsModel({
    this.status,
    this.message,
    this.data,
    this.exeTime,
  });

  factory BookingChallengesDetailsModel.fromJson(Map<String, dynamic> json) => BookingChallengesDetailsModel(
    status: json["status"],
    message: json["message"],
    data: json["data"] == null ? null : BookingChallengesDetailsModelData.fromJson(json["data"]),
    exeTime: json["exeTime"],
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "data": data?.toJson(),
    "exeTime": exeTime,
  };
}

class BookingChallengesDetailsModelData {
  List<User>? user;
  double? paidAmount;
  double? leftAmount;
  double? commission;
  DataData? data;
  Challenge? challenge;

  BookingChallengesDetailsModelData({
    this.user,
    this.paidAmount,
    this.leftAmount,
    this.commission,
    this.data,
    this.challenge,
  });

  factory BookingChallengesDetailsModelData.fromJson(Map<String, dynamic> json) => BookingChallengesDetailsModelData(
    user: json["user"] == null ? [] : List<User>.from(json["user"]!.map((x) => User.fromJson(x))),
    paidAmount: json["paidAmount"]?.toDouble(),
    leftAmount: json["leftAmount"]?.toDouble(),
    commission: json["commission"]?.toDouble(),
    data: json["data"] == null ? null : DataData.fromJson(json["data"]),
    challenge: json["challenge"] == null ? null : Challenge.fromJson(json["challenge"]),
  );

  Map<String, dynamic> toJson() => {
    "user": user == null ? [] : List<dynamic>.from(user!.map((x) => x.toJson())),
    "paidAmount": paidAmount,
    "leftAmount": leftAmount,
    "data": data?.toJson(),
    "challenge": challenge?.toJson(),
  };
}

class Challenge {
  String? id;
  bool? isPublic;
  bool? isRecorded;
  DateTime? bookingStartTime;
  dynamic slotTime;
  String? startTime;
  String? endTime;
  dynamic? startTime24;
  dynamic? endTime24;
  bool? isDisabled;
  String? sportId;
  String? skillLevel;
  String? status;
  String? facilityId;
  int? maxPlayer;
  List<WhoJoined>? whoJoined;
  String? courtId;
  String? userId;
  List<String>? slotId;
  String? privateCode;
  bool? isReview;
  bool? isActive;
  bool? isDelete;
  DateTime? date;
  List<User>? friends;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;

  Challenge({
    this.id,
    this.isPublic,
    this.isRecorded,
    this.bookingStartTime,
    this.slotTime,
    this.startTime,
    this.endTime,
    this.startTime24,
    this.endTime24,
    this.isDisabled,
    this.sportId,
    this.skillLevel,
    this.status,
    this.facilityId,
    this.maxPlayer,
    this.whoJoined,
    this.courtId,
    this.userId,
    this.slotId,
    this.privateCode,
    this.isReview,
    this.isActive,
    this.isDelete,
    this.date,
    this.friends,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  factory Challenge.fromJson(Map<String, dynamic> json) => Challenge(
    id: json["_id"],
    isPublic: json["is_public"],
    isRecorded: json["is_recorded"],
    bookingStartTime: json["bookingStartTime"] == null ? null : DateTime.parse(json["bookingStartTime"]),
    slotTime: json["slotTime"],
    startTime: json["startTime"],
    endTime: json["endTime"],
    startTime24: json["startTime24"],
    endTime24: json["endTime24"],
    isDisabled: json["is_disabled"],
    sportId: json["sport_id"],
    skillLevel: json["skill_level"],
    status: json["status"],
    facilityId: json["facility_id"],
    maxPlayer: json["max_player"],
    // friends = (json['friends'] as List<dynamic>?)
    //     ?.map((e) => Friend.fromJson(e as Map<String, dynamic>))
    //     .toList();
    // whoJoined: json["who_joined"] == null ? [] : List<WhoJoined>.from(json["who_joined"]!.map((x) => x)),
    courtId: json["court_id"],
    userId: json["user_id"],
    slotId: json["slot_id"] == null ? [] : List<String>.from(json["slot_id"]!.map((x) => x)),
    privateCode: json["private_code"],
    isReview: json["is_review"],
    isActive: json["is_active"],
    isDelete: json["is_delete"],
    date: json["date"] == null ? null : DateTime.parse(json["date"]),
    friends: json["friends"] == null ? [] : List<User>.from(json["friends"]!.map((x) => User.fromJson(x))),
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    v: json["__v"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "is_public": isPublic,
    "is_recorded": isRecorded,
    "bookingStartTime": bookingStartTime?.toIso8601String(),
    "slotTime": slotTime,
    "startTime": startTime,
    "endTime": endTime,
    "startTime24": startTime24,
    "endTime24": endTime24,
    "is_disabled": isDisabled,
    "sport_id": sportId,
    "skill_level": skillLevel,
    "status": status,
    "facility_id": facilityId,
    "max_player": maxPlayer,
    "who_joined": whoJoined == null ? [] : List<dynamic>.from(whoJoined!.map((x) => x)),
    "court_id": courtId,
    "user_id": userId,
    "slot_id": slotId == null ? [] : List<dynamic>.from(slotId!.map((x) => x)),
    "private_code": privateCode,
    "is_review": isReview,
    "is_active": isActive,
    "is_delete": isDelete,
    "date": date?.toIso8601String(),
    "friends": friends == null ? [] : List<dynamic>.from(friends!.map((x) => x.toJson())),
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "__v": v,
  };
}


class User {
  String? name;
  String? mobileNumber;
  String? countryCode;
  double? splitAmount;
  bool? isPaid;
  bool? isReviewed;
  bool? isFriendFavorite;
  String? id;
  String? playerid;
  String? image;

  User({
    this.name,
    this.mobileNumber,
    this.countryCode,
    this.splitAmount,
    this.isPaid,
    this.isReviewed,
    this.isFriendFavorite,
    this.id,
    this.playerid,
    this.image,
  });

  factory User.fromJson(Map<String, dynamic> json) => User(
    name: json["name"],
    mobileNumber: json["mobile_number"],
    countryCode: json["country_code"],
    splitAmount: json["split_amount"]?.toDouble(),
    isPaid: json["is_paid"],
    isReviewed: json["isReviewed"],
    isFriendFavorite: json["is_friend_favorite"],
    id: json["_id"],
    playerid: json["player_id"],
    image: json["image"],
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "mobile_number": mobileNumber,
    "country_code": countryCode,
    "split_amount": splitAmount,
    "is_paid": isPaid,
    "isReviewed": isReviewed,
    "is_friend_favorite": isFriendFavorite,
    "_id": id,
    "player_id": id,
    "image": image,
  };
}

class DataData {
  String? id;
  String? bookingId;
  String? userId;
  String? courtId;
  String? challengeId;
  String? facilityId;
  String? facilityOwnerId;
  List<String>? slotId;
  DateTime? bookingStartTime;
  String? slotTime;
  String? startTime;
  String? endTime;
  dynamic? startTime24;
  dynamic? endTime24;
  dynamic duration;
  dynamic? adminCommission;
  dynamic? facilityOwnerAmount;
  dynamic? price;
  String? type;
  dynamic discountId;
  dynamic? discountAmount;
  dynamic qrCode;
  bool? isRecorded;
  bool? isOfflineBooking;
  bool? isReview;
  bool? isModified;
  String? status;
  bool? isSplit;
  String? paymentStatus;
  DateTime? date;
  List<dynamic>? friends;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;

  DataData({
    this.id,
    this.bookingId,
    this.userId,
    this.courtId,
    this.challengeId,
    this.facilityId,
    this.facilityOwnerId,
    this.slotId,
    this.bookingStartTime,
    this.slotTime,
    this.startTime,
    this.endTime,
    this.startTime24,
    this.endTime24,
    this.duration,
    this.adminCommission,
    this.facilityOwnerAmount,
    this.price,
    this.type,
    this.discountId,
    this.discountAmount,
    this.qrCode,
    this.isRecorded,
    this.isOfflineBooking,
    this.isReview,
    this.isModified,
    this.status,
    this.isSplit,
    this.paymentStatus,
    this.date,
    this.friends,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  factory DataData.fromJson(Map<String, dynamic> json) => DataData(
    id: json["_id"],
    bookingId: json["booking_id"],
    userId: json["user_id"],
    courtId: json["court_id"],
    challengeId: json["challenge_id"],
    facilityId: json["facility_id"],
    facilityOwnerId: json["facility_owner_id"],
    slotId: json["slot_id"] == null ? [] : List<String>.from(json["slot_id"]!.map((x) => x)),
    bookingStartTime: json["bookingStartTime"] == null ? null : DateTime.parse(json["bookingStartTime"]),
    slotTime: json["slotTime"],
    startTime: json["startTime"],
    endTime: json["endTime"],
    startTime24: json["startTime24"],
    endTime24: json["endTime24"],
    duration: json["duration"],
    adminCommission: json["admin_commission"],
    facilityOwnerAmount: json["facility_owner_amount"],
    price: json["price"],
    type: json["type"],
    discountId: json["discountId"],
    discountAmount: json["discountAmount"],
    qrCode: json["qr_code"],
    isRecorded: json["is_recorded"],
    isOfflineBooking: json["isOfflineBooking"],
    isReview: json["is_review"],
    isModified: json["is_modified"],
    status: json["status"],
    isSplit: json["is_split"],
    paymentStatus: json["payment_status"],
    date: json["date"] == null ? null : DateTime.parse(json["date"]),
    friends: json["friends"] == null ? [] : List<dynamic>.from(json["friends"]!.map((x) => x)),
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    v: json["__v"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "booking_id": bookingId,
    "user_id": userId,
    "court_id": courtId,
    "challenge_id": challengeId,
    "facility_id": facilityId,
    "facility_owner_id": facilityOwnerId,
    "slot_id": slotId == null ? [] : List<dynamic>.from(slotId!.map((x) => x)),
    "bookingStartTime": bookingStartTime?.toIso8601String(),
    "slotTime": slotTime,
    "startTime": startTime,
    "endTime": endTime,
    "startTime24": startTime24,
    "endTime24": endTime24,
    "duration": duration,
    "admin_commission": adminCommission,
    "facility_owner_amount": facilityOwnerAmount,
    "price": price,
    "type": type,
    "discountId": discountId,
    "discountAmount": discountAmount,
    "qr_code": qrCode,
    "is_recorded": isRecorded,
    "isOfflineBooking": isOfflineBooking,
    "is_review": isReview,
    "is_modified": isModified,
    "status": status,
    "is_split": isSplit,
    "payment_status": paymentStatus,
    "date": date?.toIso8601String(),
    "friends": friends == null ? [] : List<dynamic>.from(friends!.map((x) => x)),
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "__v": v,
  };
}


class WhoJoined {
  String? sId;
  String? image;
  String? mobileNumber;
  String? countryCode;
  String? name;
  String? email;

  WhoJoined(
      {this.sId,
        this.image,
        this.mobileNumber,
        this.countryCode,
        this.name,
        this.email});

  WhoJoined.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    image = json['image'];
    mobileNumber = json['mobile_number'];
    countryCode = json['country_code'];
    name = json['name'];
    email = json['email'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['image'] = this.image;
    data['mobile_number'] = this.mobileNumber;
    data['country_code'] = this.countryCode;
    data['name'] = this.name;
    data['email'] = this.email;
    return data;
  }
}
