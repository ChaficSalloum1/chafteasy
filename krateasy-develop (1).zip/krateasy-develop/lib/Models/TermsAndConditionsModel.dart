// import 'package:html/parser.dart' as htmlParser;

// class TermsAndConditionsModel {
//   final String enDescription;

//   TermsAndConditionsModel({required this.enDescription});

//   factory TermsAndConditionsModel.fromJson(Map<String, dynamic> json) {
//     // Convert HTML to plain text
//     String plainText = parseHtmlToPlainText(json['en_description'] ?? '');
//     return TermsAndConditionsModel(enDescription: plainText);
//   }

//   // Function to parse HTML content into plain text
//   static String parseHtmlToPlainText(String htmlString) {
//     if (htmlString.isEmpty) return "No terms & conditions available.";

//     final document = htmlParser.parse(htmlString);
//     String parsedText = document.body?.text ?? '';

//     return parsedText.trim(); // Trim spaces for cleaner output
//   }
// }

import 'package:html/parser.dart' as htmlParser;
import 'package:html/dom.dart';

class TermsAndConditionsModel {
  final String enDescription;

  TermsAndConditionsModel({required this.enDescription});

  factory TermsAndConditionsModel.fromJson(Map<String, dynamic> json) {
    // Convert HTML to formatted plain text
    String plainText = parseHtmlToPlainText(json['en_description'] ?? '');
    return TermsAndConditionsModel(enDescription: plainText);
  }

  // Enhanced function to parse and format HTML
  static String parseHtmlToPlainText(String htmlString) {
    if (htmlString.isEmpty) return "No terms & conditions available.";

    final document = htmlParser.parse(htmlString);
    final buffer = StringBuffer();

    void parseNode(Node node) {
      if (node is Text) {
        buffer.write(node.text);
      } else if (node is Element) {
        switch (node.localName) {
          case 'p':
            buffer.write('\n${node.text.trim()}\n');
            break;
          case 'strong':
          case 'b':
            buffer.write('**${node.text.trim()}**');
            break;
          case 'ul':
            node.children.forEach(parseNode);
            break;
          case 'li':
            buffer.write('\n• ${node.text.trim()}');
            break;
          case 'h1':
          case 'h2':
          case 'h3':
          case 'h4':
            buffer.write('\n\n${node.text.trim().toUpperCase()}\n');
            break;
          default:
            node.nodes.forEach(parseNode);
        }
      }
    }

    document.body?.nodes.forEach(parseNode);
    return buffer.toString().trim();
  }
}
