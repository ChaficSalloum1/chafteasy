

class SearchFilterDataModel {
  bool? success;
  String? message;
  List<Data>? data;
  bool? exactSlotAvailable;

  SearchFilterDataModel(
      {this.success, this.message, this.data, this.exactSlotAvailable});

  SearchFilterDataModel.fromJson(Map<String, dynamic> json) {
    success = json["success"];
    message = json["message"];
    exactSlotAvailable = json['exactSlotAvailable'] ?? false;
    data = json["data"] == null
        ? null
        : (json["data"] as List).map((e) => Data.fromJson(e)).toList();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["success"] = success;
    _data["message"] = message;
    _data["exactSlotAvailable"]=exactSlotAvailable;
    if (data != null) {
      _data["data"] = data?.map((e) => e.toJson()).toList();
    }
    return _data;
  }
}

class Data {
  String? id;
  String? image;
  dynamic price;
  List<dynamic>? gallery;
  dynamic averageRating;
  List<Slots>? slots;
  String? sportId;
  String? facilityId;
  String? facilityOwnerId;
  dynamic userId;
  bool? isActive;
  bool? isDelete;
  bool? isFavorite;
  String? name;
  String? grname;
  String? sportname;
  String? grsportname;
  String? createdAt;
  String? updatedAt;
  int? v;
  Facility? facility;
  String? date;

  Data(
      {this.id,
      this.image,
      this.price,
      this.gallery,
      this.averageRating,
      this.slots,
      this.sportId,
      this.facilityId,
      this.facilityOwnerId,
      this.userId,
      this.isActive,
      this.isDelete,
      this.isFavorite,
      this.name,
        this.grname,
        this.sportname,
        this.grsportname,
      this.createdAt,
      this.updatedAt,
      this.v,
      this.facility,
      this.date});

  Data.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    image = json["image"];
    price = json["price"];
    gallery = json["gallery"] ?? [];
    averageRating = json["averageRating"];
    slots = json["slots"] == null
        ? null
        : (json["slots"] as List).map((e) => Slots.fromJson(e)).toList();
    sportId = json["sport_id"];
    facilityId = json["facility_id"];
    facilityOwnerId = json["facility_owner_id"];
    userId = json["user_id"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    isFavorite = json["is_favorite"];
    name = json["name"];
    grname = json ['gr_name']??"";
    sportname =json['sportName'];
    grsportname =json['gr_sportName']??"";
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
    facility =
        json["facility"] == null ? null : Facility.fromJson(json["facility"]);
    date = json["date"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["image"] = image;
    _data["price"] = price;
    if (gallery != null) {
      _data["gallery"] = gallery;
    }
    _data["averageRating"] = averageRating;
    if (slots != null) {
      _data["slots"] = slots?.map((e) => e.toJson()).toList();
    }
    _data["sport_id"] = sportId;
    _data["facility_id"] = facilityId;
    _data["facility_owner_id"] = facilityOwnerId;
    _data["user_id"] = userId;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["is_favorite"] = isFavorite;
    _data["name"] = name;
    _data["gr_name"] = grname;
    _data["sportName"] = sportname;
    _data["gr_sportName"] = grsportname;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    if (facility != null) {
      _data["facility"] = facility?.toJson();
    }
    _data["date"] = date;
    return _data;
  }
}

class Facility {
  String? id;
  String? name;
  String? grname;
  String? address;
  double? distance;

  Facility({this.id, this.name, this.address, this.distance});

  Facility.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    name = json["name"];
    grname = json["gr_name"];
    address = json["address"];
    distance = json["distance"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["name"] = name;
    _data["gr_name"] = grname;
    _data["address"] = address;
    _data["distance"] = distance;
    return _data;
  }
}

class Slots {
  String? id;
  String? startTime;
  String? endTime;
  String? day;
  int? price;
  String? courtId;
  bool? isActive;
  bool? isDelete;
  int? v;
  String? createdAt;
  String? updatedAt;

  Slots(
      {this.id,
      this.startTime,
      this.endTime,
      this.day,
      this.price,
      this.courtId,
      this.isActive,
      this.isDelete,
      this.v,
      this.createdAt,
      this.updatedAt});

  Slots.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    startTime = json["startTime"];
    endTime = json["endTime"];
    day = json["day"];
    price = json["price"];
    courtId = json["court_id"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    v = json["__v"];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["startTime"] = startTime;
    _data["endTime"] = endTime;
    _data["day"] = day;
    _data["price"] = price;
    _data["court_id"] = courtId;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["__v"] = v;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    return _data;
  }
}
