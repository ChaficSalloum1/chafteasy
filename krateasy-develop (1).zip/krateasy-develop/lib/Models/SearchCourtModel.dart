// // Model
// class SearchCourtModel {
//   final String date;
//   final List<String> time;
//   final String sportId;
//   final List<String> amenityId;

//   SearchCourtModel({
//     required this.date,
//     required this.time,
//     required this.sportId,
//     required this.amenityId,
//   });

//   Map<String, dynamic> toJson() {
//     return {
//       "date": date,
//       "time": time,
//       "sport_id": sportId,
//       "amenity_id": amenityId,
//     };
//   }
// }



class SearchCourtModel {
  final String date;
  final List<String> time;
  final String sportId;
  final List<String>? amenityId;

  SearchCourtModel({
    required this.date,
    required this.time,
    required this.sportId,
    this.amenityId,
  });

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {
      "date": date,
      "time": time,
      "sport_id": sportId,
    };

    if (amenityId != null && amenityId!.isNotEmpty) {
      data["amenity_id"] = amenityId;
    }

    return data;
  }
}
