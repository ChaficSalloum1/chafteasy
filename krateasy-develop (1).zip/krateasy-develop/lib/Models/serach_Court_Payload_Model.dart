import 'dart:developer';

class BookingRequest {
  final String? sportId;
  final String? date;
  final List? time;
  final List? amenityId;
  final String? lat;
  final String? long;
  final String timeZone;

  BookingRequest({
    this.sportId,
    this.date,
    this.time,
    this.lat,
    this.long,
    this.amenityId,required this.timeZone
  });

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {
      "date": date,
      "time": time,
      "sport_id": sportId,
      "latitude": lat,
      "longitude": long,
      "timeZone": timeZone,
    };

    // Add amenity_id only if it's not null or empty
    if (amenityId != null && amenityId!.isNotEmpty) {
      data["amenity_id"] = amenityId;
    }

    log("data ...>$data");
    return data;
  }
}
