// Model
class TransactionDetailsModel {
  final String id;
  final String transactionId;
  final double amount;
  final String transactionType;
  final double availableBalance;
  final String type;
  final DateTime createdAt;

  TransactionDetailsModel({
    required this.id,
    required this.transactionId,
    required this.amount,
    required this.transactionType,
    required this.availableBalance,
    required this.type,
    required this.createdAt,
  });

  factory TransactionDetailsModel.fromJson(Map<String, dynamic> json) {
    return TransactionDetailsModel(
      id: json['_id'],
      transactionId: json['transaction_id'],
      amount: (json['amount'] ?? 0).toDouble(),
      transactionType: json['payment_status'],
      availableBalance: (json['available_balance'] ?? 0).toDouble(),
      type: json['type'],
      createdAt: DateTime.parse(json['created_at']),
    );
  }
}
