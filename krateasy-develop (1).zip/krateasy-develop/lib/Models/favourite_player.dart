class FavouritePlayerModel {
  bool? isActive;
  bool? isDelete;
  String? id;
  String? userId;
  String? type;
  Friend? friend;
  String? createdAt;
  String? playerid;
  String? updatedAt;
  int? v;

  FavouritePlayerModel(
      {this.isActive,
      this.isDelete,
      this.id,
      this.userId,
      this.type,
      this.friend,
      this.createdAt,this.playerid,
      this.updatedAt,
      this.v});

  FavouritePlayerModel.fromJson(Map<String, dynamic> json) {
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    id = json["_id"];
    userId = json["user_id"];
    type = json["type"];
    friend = json["friend"] == null ? null : Friend.fromJson(json["friend"]);
    createdAt = json["created_at"];
    playerid = json["player_id"];
    updatedAt = json["updated_at"];
    v = json["__v"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["_id"] = id;
    _data["user_id"] = userId;
    _data["type"] = type;
    if (friend != null) {
      _data["friend"] = friend?.toJson();
    }
    _data["created_at"] = createdAt;
    _data["player_id"] = playerid;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    return _data;
  }
}

class Friend {
  String? name;
  String? mobileNumber;
  dynamic splitAmount;
  String? countryCode;

  Friend({this.name, this.mobileNumber, this.splitAmount, this.countryCode});

  Friend.fromJson(Map<String, dynamic> json) {
    name = json["name"];
    mobileNumber = json["mobile_number"];
    splitAmount = json["split_amount"];
    countryCode = json["country_code"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["name"] = name;
    _data["mobile_number"] = mobileNumber;
    _data["split_amount"] = splitAmount;
    _data["country_code"] = countryCode;
    return _data;
  }
}
