class FacilitiesModel {
  String? id;
  String? name;
  String? image;
  List<dynamic>? gallery;
  Location? location;
  double? latitude;
  double? longitude;
  String? description;
  dynamic? distance;
  String? bio;
  String? address;
  List<Amenities>? amenities;
  List<Courts>? courts;
  dynamic totalBookingCount;
  dynamic availableCourtCount;
  dynamic rating;
  double? distanceInKm; // Add this

  FacilitiesModel(
      {this.id,
      this.name,
      this.image,
      this.gallery,
      this.location,
      this.latitude,
      this.longitude,
      this.description,this.distance,
      this.bio,
      this.address,
      this.amenities,
      this.courts,
      this.totalBookingCount,
      this.availableCourtCount,
      this.distanceInKm,
      this.rating});

  FacilitiesModel.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    name = json["name"];
    image = json["image"];
    gallery = json["gallery"] ?? [];
    location =
        json["location"] == null ? null : Location.fromJson(json["location"]);
    latitude =
        (json["latitude"] != null) ? (json["latitude"] as num).toDouble() : 0.0;
    longitude = (json["longitude"] != null)
        ? (json["longitude"] as num).toDouble()
        : 0.0;

    description = json["description"];
    distance = json["distance"];

    bio = json["bio"];
    address = json["address"];
    amenities = json["amenities"] == null
        ? null
        : (json["amenities"] as List)
            .map((e) => Amenities.fromJson(e))
            .toList();
    courts = json["courts"] == null
        ? null
        : (json["courts"] as List).map((e) => Courts.fromJson(e)).toList();
    totalBookingCount = json["total_booking_count"];
    availableCourtCount = json["available_court_count"];
    rating = json["rating"];
    distanceInKm = 0.0; // will be overwritten after parsing
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["name"] = name;
    _data["image"] = image;
    if (gallery != null) {
      _data["gallery"] = gallery;
    }
    if (location != null) {
      _data["location"] = location?.toJson();
    }
    _data["latitude"] = latitude;
    _data["longitude"] = longitude;
    _data["description"] = description;
    _data["distance"] = distance;
    _data["bio"] = bio;
    _data["address"] = address;
    if (amenities != null) {
      _data["amenities"] = amenities?.map((e) => e.toJson()).toList();
    }
    if (courts != null) {
      _data["courts"] = courts?.map((e) => e.toJson()).toList();
    }
    _data["total_booking_count"] = totalBookingCount;
    _data["available_court_count"] = availableCourtCount;
    _data["rating"] = rating;
    return _data;
  }
}

class Courts {
  String? id;
  dynamic image;
  dynamic price;
  List<dynamic>? gallery;
  dynamic averageRating;
  dynamic totalrating;
  Slots? slots;
  String? sportId;
  String? facilityId;
  String? facilityOwnerId;
  dynamic userId;
  bool? isActive;
  bool? isDelete;
  bool? isFavorite;
  String? name;
  String? grname;
  String? createdAt;
  String? updatedAt;
  dynamic v;

  Courts(
      {this.id,
      this.image,
      this.price,
      this.gallery,
      this.averageRating,
      this.totalrating,
      this.slots,
      this.sportId,
      this.facilityId,
      this.facilityOwnerId,
      this.userId,
      this.isActive,
      this.isDelete,
      this.isFavorite,
      this.name,
      this.grname,
      this.createdAt,
      this.updatedAt,
      this.v});

  Courts.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    image = json["image"];
    price = json["price"];
    gallery = json["gallery"] ?? [];
    averageRating = json["averageRating"];
    totalrating = json["totalRating"];
    slots = json["slots"] == null ? null : Slots.fromJson(json["slots"]);
    sportId = json["sport_id"];
    facilityId = json["facility_id"];
    facilityOwnerId = json["facility_owner_id"];
    userId = json["user_id"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    isFavorite = json["is_favorite"];
    name = json["name"];
    grname = json["gr_name"];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["image"] = image;
    _data["price"] = price;
    if (gallery != null) {
      _data["gallery"] = gallery;
    }
    _data["averageRating"] = averageRating;
    _data["totalRating"] = totalrating;
    if (slots != null) {
      _data["slots"] = slots?.toJson();
    }
    _data["sport_id"] = sportId;
    _data["facility_id"] = facilityId;
    _data["facility_owner_id"] = facilityOwnerId;
    _data["user_id"] = userId;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["is_favorite"] = isFavorite;
    _data["name"] = name;
    _data["gr_name"] = grname;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    return _data;
  }
}

class Slots {
  List<Tuesday>? tuesday;
  List<Thursday>? thursday;

  Slots({this.tuesday, this.thursday});

  Slots.fromJson(Map<String, dynamic> json) {
    tuesday = json["Tuesday"] == null
        ? null
        : (json["Tuesday"] as List).map((e) => Tuesday.fromJson(e)).toList();
    thursday = json["Thursday"] == null
        ? null
        : (json["Thursday"] as List).map((e) => Thursday.fromJson(e)).toList();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    if (tuesday != null) {
      _data["Tuesday"] = tuesday?.map((e) => e.toJson()).toList();
    }
    if (thursday != null) {
      _data["Thursday"] = thursday?.map((e) => e.toJson()).toList();
    }
    return _data;
  }
}

class Thursday {
  String? startTime;
  String? endTime;

  Thursday({this.startTime, this.endTime});

  Thursday.fromJson(Map<String, dynamic> json) {
    startTime = json["start_time"];
    endTime = json["end_time"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["start_time"] = startTime;
    _data["end_time"] = endTime;
    return _data;
  }
}

class Tuesday {
  String? startTime;
  String? endTime;
  dynamic price;

  Tuesday({this.startTime, this.endTime, this.price});

  Tuesday.fromJson(Map<String, dynamic> json) {
    startTime = json["start_time"];
    endTime = json["end_time"];
    price = json["price"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["start_time"] = startTime;
    _data["end_time"] = endTime;
    _data["price"] = price;
    return _data;
  }
}

class Amenities {
  String? id;
  bool? isActive;
  bool? isDelete;
  String? name;
  String? grname;
  String? image;
  String? createdAt;
  String? updatedAt;
  dynamic v;

  Amenities(
      {this.id,
      this.isActive,
      this.isDelete,
      this.name,this.grname,
      this.image,
      this.createdAt,
      this.updatedAt,
      this.v});

  Amenities.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    name = json["name"];
    grname = json["gr_name"];
    image = json["image"];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["name"] = name;
    _data["gr_name"] = grname;
    _data["image"] = image;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    return _data;
  }
}

class Location {
  String? type;
  List<double>? coordinates;

  Location({this.type, this.coordinates});

  Location.fromJson(Map<String, dynamic> json) {
    type = json["type"];
    coordinates = json["coordinates"] == null
        ? null
        : (json["coordinates"] as List)
            .map((e) => (e as num).toDouble())
            .toList();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["type"] = type;
    if (coordinates != null) {
      _data["coordinates"] = coordinates;
    }
    return _data;
  }
}


