class SlotsResponseModel {
  bool? status;
  String? message;
  Data? data;

  SlotsResponseModel({this.status, this.message, this.data});

  SlotsResponseModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  List<AvailableSlots>? availableSlots;

  Data({this.availableSlots});

  Data.fromJson(Map<String, dynamic> json) {
    if (json['availableSlots'] != null) {
      availableSlots = <AvailableSlots>[];
      json['availableSlots'].forEach((v) {
        availableSlots!.add(new AvailableSlots.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.availableSlots != null) {
      data['availableSlots'] =
          this.availableSlots!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

// class AvailableSlots {
//   String? sId;
//   String? startTime;
//   String? endTime;
//   String? day;
//   dynamic price;
//   String? courtId;
//   bool? isActive;
//   bool? isDelete;
//   dynamic iV;
//   dynamic? createdAt;
//   dynamic? updatedAt;
//
//   AvailableSlots(
//       {this.sId,
//         this.startTime,
//         this.endTime,
//         this.day,
//         this.price,
//         this.courtId,
//         this.isActive,
//         this.isDelete,
//         this.iV,
//         this.createdAt,
//         this.updatedAt});
//
//   AvailableSlots.fromJson(Map<String, dynamic> json) {
//     sId = json['_id'];
//     startTime = json['startTime'];
//     endTime = json['endTime'];
//     day = json['day'];
//     price = json['price'];
//     courtId = json['court_id'];
//     isActive = json['is_active'];
//     isDelete = json['is_delete'];
//     iV = json['__v'];
//     createdAt = json['created_at'];
//     updatedAt = json['updated_at'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['_id'] = this.sId;
//     data['startTime'] = this.startTime;
//     data['endTime'] = this.endTime;
//     data['day'] = this.day;
//     data['price'] = this.price;
//     data['court_id'] = this.courtId;
//     data['is_active'] = this.isActive;
//     data['is_delete'] = this.isDelete;
//     data['__v'] = this.iV;
//     data['created_at'] = this.createdAt;
//     data['updated_at'] = this.updatedAt;
//     return data;
//   }
// }
class AvailableSlots {
  String? sId;
  String? startTime;
  String? endTime;
  String? day;
  dynamic price;
  String? courtId;
  bool? isActive;
  bool? isDelete;
  dynamic iV;
  dynamic? createdAt;
  dynamic? updatedAt;
  double? startTime24; // Add this field
  double? endTime24;   // Add this field

  AvailableSlots({
    this.sId,
    this.startTime,
    this.endTime,
    this.day,
    this.price,
    this.courtId,
    this.isActive,
    this.isDelete,
    this.iV,
    this.createdAt,
    this.updatedAt,
    this.startTime24,
    this.endTime24,
  });

  AvailableSlots.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    startTime = json['startTime'];
    endTime = json['endTime'];
    day = json['day'];
    price = json['price'];
    courtId = json['court_id'];
    isActive = json['is_active'];
    isDelete = json['is_delete'];
    iV = json['__v'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    startTime24 = json['startTime24']?.toDouble(); // Parse as double
    endTime24 = json['endTime24']?.toDouble();     // Parse as double
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['_id'] = sId;
    data['startTime'] = startTime;
    data['endTime'] = endTime;
    data['day'] = day;
    data['price'] = price;
    data['court_id'] = courtId;
    data['is_active'] = isActive;
    data['is_delete'] = isDelete;
    data['__v'] = iV;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    data['startTime24'] = startTime24;
    data['endTime24'] = endTime24;
    return data;
  }
}