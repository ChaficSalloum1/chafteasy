
class SportsListModel {
  String? name;
  String? grname;
  String? image;
  List<String>? skillLevel;
  String? matchType;
  bool? isActive;
  bool? isDelete;
  String? id;
  String? createdAt;
  String? updatedAt;
  int? v;

  SportsListModel({this.name, this.image,this.grname ,this.skillLevel, this.matchType, this.isActive, this.isDelete, this.id, this.createdAt, this.updatedAt, this.v});

  SportsListModel.fromJson(Map<String, dynamic> json) {
    name = json["name"];
    grname = json["gr_name"];
    image = json["image"];
    skillLevel = json["skill_level"] == null ? null : List<String>.from(json["skill_level"]);
    matchType = json["match_type"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    id = json["_id"];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["name"] = name;
    _data["gr_name"] = grname;
    _data["image"] = image;
    if(skillLevel != null) {
      _data["skill_level"] = skillLevel;
    }
    _data["match_type"] = matchType;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["_id"] = id;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    return _data;
  }
}