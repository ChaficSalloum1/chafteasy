

class CreateChallengeFacilityModel {
  bool? status;
  String? message;
  List<CreateFacilityData>? data;
  int? exeTime;

  CreateChallengeFacilityModel({
    this.status,
    this.message,
    this.data,
    this.exeTime,
  });

  factory CreateChallengeFacilityModel.fromJson(Map<String, dynamic> json) {
    return CreateChallengeFacilityModel(
      status: json['status'] as bool?,
      message: json['message'] as String?,
      exeTime: json['exeTime'] as int?,
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => CreateFacilityData.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }

  Map<String, dynamic> toJson() => {
    'status': status,
    'message': message,
    'data': data?.map((e) => e.toJson()).toList(),
    'exeTime': exeTime,
  };
}

class CreateFacilityData {
  String? id;
  String? name;
  String? image;
  String? description;
  String? bio;
  String? address;
  List<Court>? courts;
  List<Amenity>? amenities;
  int? totalBookingCount;
  dynamic? distance;
  int? availableCourtCount;

  CreateFacilityData({
    this.id,
    this.name,
    this.image,
    this.description,
    this.bio,
    this.address,
    this.courts,
    this.amenities,
    this.totalBookingCount,
    this.distance,
    this.availableCourtCount,
  });

  factory CreateFacilityData.fromJson(Map<String, dynamic> json) {
    return CreateFacilityData(
      id: json['_id']?.toString(),
      name: json['name']?.toString(),
      image: json['image']?.toString(),
      description: json['description']?.toString(),
      bio: json['bio']?.toString(),
      address: json['address']?.toString(),
      courts: (json['courts'] as List?)?.map((e) => Court.fromJson(e)).toList(),
      amenities: (json['amenities'] as List?)?.map((e) => Amenity.fromJson(e)).toList(),
      totalBookingCount: json['total_booking_count'] is int ? json['total_booking_count'] : int.tryParse(json['total_booking_count']?.toString() ?? ''),
      distance: json['distance'],
      availableCourtCount: json['available_court_count'] is int ? json['available_court_count'] : int.tryParse(json['available_court_count']?.toString() ?? ''),
    );
  }

  Map<String, dynamic> toJson() => {
    '_id': id,
    'name': name,
    'image': image,
    'description': description,
    'bio': bio,
    'address': address,
    'courts': courts?.map((e) => e.toJson()).toList(),
    'amenities': amenities?.map((e) => e.toJson()).toList(),
    'total_booking_count': totalBookingCount,
    'distance':distance,
    'available_court_count': availableCourtCount,
  };
}

class Court {
  String? id;
  String? image;
  dynamic price;
  List<dynamic>? gallery;
  int? averageRating;
  String? sportId;
  String? facilityId;
  String? facilityOwnerId;
  dynamic userId;
  bool? isActive;
  bool? isDelete;
  bool? isFavorite;
  String? name;
  String? createdAt;
  String? updatedAt;
  int? v;
  Sport? sport;

  Court({
    this.id,
    this.image,
    this.price,
    this.gallery,
    this.averageRating,
    this.sportId,
    this.facilityId,
    this.facilityOwnerId,
    this.userId,
    this.isActive,
    this.isDelete,
    this.isFavorite,
    this.name,
    this.createdAt,
    this.updatedAt,
    this.v,
    this.sport,
  });

  factory Court.fromJson(Map<String, dynamic> json) {
    return Court(
      id: json['_id']?.toString(),
      image: json['image']?.toString(),
      price: json['price'],
      gallery: (json['gallery'] as List?)?.map((e) => e).toList(),
      averageRating: json['averageRating'] is int ? json['averageRating'] : int.tryParse(json['averageRating']?.toString() ?? ''),
      sportId: json['sport_id']?.toString(),
      facilityId: json['facility_id']?.toString(),
      facilityOwnerId: json['facility_owner_id']?.toString(),
      userId: json['user_id'],
      isActive: json['is_active'] as bool?,
      isDelete: json['is_delete'] as bool?,
      isFavorite: json['is_favorite'] as bool?,
      name: json['name']?.toString(),
      createdAt: json['created_at']?.toString(),
      updatedAt: json['updated_at']?.toString(),
      v: json['__v'] is int ? json['__v'] : int.tryParse(json['__v']?.toString() ?? ''),
      sport: json['sport'] is Map ? Sport.fromJson(json['sport']) : null,
    );
  }

  Map<String, dynamic> toJson() => {
    '_id': id,
    'image': image,
    'price': price,
    'gallery': gallery,
    'averageRating': averageRating,
    'sport_id': sportId,
    'facility_id': facilityId,
    'facility_owner_id': facilityOwnerId,
    'user_id': userId,
    'is_active': isActive,
    'is_delete': isDelete,
    'is_favorite': isFavorite,
    'name': name,
    'created_at': createdAt,
    'updated_at': updatedAt,
    '__v': v,
    'sport': sport?.toJson(),
  };
}

class Sport {
  String? id;
  String? name;
  String? image;
  List<String>? skillLevel;
  String? matchType;
  bool? isActive;
  bool? isDelete;
  String? createdAt;
  String? updatedAt;
  int? v;

  Sport({
    this.id,
    this.name,
    this.image,
    this.skillLevel,
    this.matchType,
    this.isActive,
    this.isDelete,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  factory Sport.fromJson(Map<String, dynamic> json) {
    return Sport(
      id: json['_id']?.toString(),
      name: json['name']?.toString(),
      image: json['image']?.toString(),
      skillLevel: (json['skill_level'] as List?)?.map((e) => e.toString()).toList(),
      matchType: json['match_type']?.toString(),
      isActive: json['is_active'] as bool?,
      isDelete: json['is_delete'] as bool?,
      createdAt: json['created_at']?.toString(),
      updatedAt: json['updated_at']?.toString(),
      v: json['__v'] is int ? json['__v'] : int.tryParse(json['__v']?.toString() ?? ''),
    );
  }

  Map<String, dynamic> toJson() => {
    '_id': id,
    'name': name,
    'image': image,
    'skill_level': skillLevel,
    'match_type': matchType,
    'is_active': isActive,
    'is_delete': isDelete,
    'created_at': createdAt,
    'updated_at': updatedAt,
    '__v': v,
  };
}

class Amenity {
  String? id;
  bool? isActive;
  bool? isDelete;
  String? name;
  String? image;
  String? createdAt;
  String? updatedAt;
  int? v;

  Amenity({
    this.id,
    this.isActive,
    this.isDelete,
    this.name,
    this.image,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  factory Amenity.fromJson(Map<String, dynamic> json) {
    return Amenity(
      id: json['_id']?.toString(),
      isActive: json['is_active'] as bool?,
      isDelete: json['is_delete'] as bool?,
      name: json['name']?.toString(),
      image: json['image']?.toString(),
      createdAt: json['created_at']?.toString(),
      updatedAt: json['updated_at']?.toString(),
      v: json['__v'] is int ? json['__v'] : int.tryParse(json['__v']?.toString() ?? ''),
    );
  }

  Map<String, dynamic> toJson() => {
    '_id': id,
    'is_active': isActive,
    'is_delete': isDelete,
    'name': name,
    'image': image,
    'created_at': createdAt,
    'updated_at': updatedAt,
    '__v': v,
  };
}
