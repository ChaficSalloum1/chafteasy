import 'package:html/parser.dart' as htmlParser;

class PrivacyPolicyModel {
  final String enDescription;

  PrivacyPolicyModel({required this.enDescription});

  factory PrivacyPolicyModel.fromJson(Map<String, dynamic> json) {
    // Convert HTML to plain text
    String plainText = parseHtmlToPlainText(json['en_description'] ?? '');
    return PrivacyPolicyModel(enDescription: plainText);
  }

  // Function to parse HTML content into plain text
  static String parseHtmlToPlainText(String htmlString) {
    if (htmlString.isEmpty) return "No privacy policy available.";

    final document = htmlParser.parse(htmlString);
    String parsedText = document.body?.text ?? '';

    return parsedText.trim(); // Trim spaces for cleaner output
  }
}
