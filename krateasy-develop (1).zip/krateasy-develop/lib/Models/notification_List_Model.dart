class NotificationListModel {
  NotificationListModel({
    required this.status,
    required this.message,
    required this.docs,
    required this.totalDocs,
    required this.limit,
    required this.page,
    required this.totalPages,
    required this.pagingCounter,
    required this.hasPrevPage,
    required this.hasNextPage,
    required this.prevPage,
    required this.nextPage,
    required this.exeTime,
  });

  final bool status;
  final String message;
  final List<NotificationListModelDoc> docs;
  final int totalDocs;
  final int limit;
  final int page;
  final int totalPages;
  final int pagingCounter;
  final bool hasPrevPage;
  final bool hasNextPage;
  final dynamic prevPage;
  final dynamic nextPage;
  final int exeTime;

  factory NotificationListModel.fromJson(Map<String, dynamic> json) {
    return NotificationListModel(
      status: json["status"] ?? false,
      message: json["message"] ?? "",
      docs: json["docs"] == null
          ? []
          : List<NotificationListModelDoc>.from(
              json["docs"]!.map((x) => NotificationListModelDoc.fromJson(x))),
      totalDocs: json["totalDocs"] ?? 0,
      limit: json["limit"] ?? 0,
      page: json["page"] ?? 0,
      totalPages: json["totalPages"] ?? 0,
      pagingCounter: json["pagingCounter"] ?? 0,
      hasPrevPage: json["hasPrevPage"] ?? false,
      hasNextPage: json["hasNextPage"] ?? false,
      prevPage: json["prevPage"],
      nextPage: json["nextPage"],
      exeTime: json["exeTime"] ?? 0,
    );
  }

  Map<String, dynamic> toJson() => {
        "status": status,
        "message": message,
        "docs": docs.map((x) => x?.toJson()).toList(),
        "totalDocs": totalDocs,
        "limit": limit,
        "page": page,
        "totalPages": totalPages,
        "pagingCounter": pagingCounter,
        "hasPrevPage": hasPrevPage,
        "hasNextPage": hasNextPage,
        "prevPage": prevPage,
        "nextPage": nextPage,
        "exeTime": exeTime,
      };

  @override
  String toString() {
    return "$status, $message, $docs, $totalDocs, $limit, $page, $totalPages, $pagingCounter, $hasPrevPage, $hasNextPage, $prevPage, $nextPage, $exeTime, ";
  }
}

class NotificationListModelDoc {
  NotificationListModelDoc({
    required this.id,
    required this.sent,
    required this.toId,
    required this.fromId,
    required this.title,
    required this.description,
    required this.data,
    required this.v,
    required this.createdAt,
    required this.updatedAt,
    this.isRead,
  });

  final String id;
  final bool sent;
   bool? isRead;
  final String toId;
  final String fromId;
  final String title;
  final String description;
  final Data? data;
  final int v;
  final String? createdAt;
  final DateTime? updatedAt;

  factory NotificationListModelDoc.fromJson(Map<String, dynamic> json) {
    return NotificationListModelDoc(
      id: json["_id"] ?? "",
      sent: json["sent"] ?? false,
      isRead: json["is_read"] ?? false,
      toId: json["to_id"] ?? "",
      fromId: json["from_id"] ?? "",
      title: json["title"] ?? "",
      description: json["description"] ?? "",
      data: json["data"] == null ? null : Data.fromJson(json["data"]),
      v: json["__v"] ?? 0,
      createdAt: json["created_at"] ?? "",
      updatedAt: DateTime.tryParse(json["updated_at"] ?? ""),
    );
  }

  Map<String, dynamic> toJson() => {
        "_id": id,
        "sent": sent,
        "to_id": toId,
        "from_id": fromId,
        "title": title,
        "description": description,
        "data": data?.toJson(),
        "__v": v,
        "created_at": createdAt,
        "updated_at": updatedAt?.toIso8601String(),
        "is_read": isRead,
      };

  @override
  String toString() {
    return "$id, $sent, $toId, $fromId, $title, $description, $data, $v, $createdAt, $updatedAt,$isRead ";
  }
}

class Data {
  Data({
    required this.type,
    required this.challengeId,
    required this.bookingId,
    required this.courtId
  });

  final String type;
  final String? challengeId;

  final String? bookingId;
  final String? courtId;


  ///

  factory Data.fromJson(Map<String, dynamic> json) {
    return Data(

        courtId: json["court_id"] ?? "",
        type: json["type"] ?? "",
        challengeId: json["challenge_id"]?.toString() ?? "",
        bookingId:json['booking_id'].toString()
    );
  }

  Map<String, dynamic> toJson() => {
        "type": type,
        "challenge_id": challengeId,
      };

  @override
  String toString() {
    return "$type, $challengeId, ";
  }
}
