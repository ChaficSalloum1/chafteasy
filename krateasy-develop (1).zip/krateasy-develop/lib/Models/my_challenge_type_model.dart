class MyChallengeTypeModel {
  bool? status;
  String? message;
  Data? data;
  dynamic exeTime;

  MyChallengeTypeModel({this.status, this.message, this.data, this.exeTime});

  MyChallengeTypeModel.fromJson(Map<String, dynamic> json) {
    status = json["status"];
    message = json["message"];
    data = json["data"] == null ? null : Data.fromJson(json["data"]);
    exeTime = json["exeTime"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["status"] = status;
    _data["message"] = message;
    if (data != null) {
      _data["data"] = data?.toJson();
    }
    _data["exeTime"] = exeTime;
    return _data;
  }
}

class Data {
  List<Docs>? docs;
  dynamic totalDocs;
  dynamic limit;
  dynamic page;
  dynamic totalPages;
  dynamic pagingCounter;
  bool? hasPrevPage;
  bool? hasNextPage;
  dynamic prevPage;
  dynamic nextPage;

  Data(
      {this.docs,
      this.totalDocs,
      this.limit,
      this.page,
      this.totalPages,
      this.pagingCounter,
      this.hasPrevPage,
      this.hasNextPage,
      this.prevPage,
      this.nextPage});

  Data.fromJson(Map<String, dynamic> json) {
    docs = json["docs"] == null
        ? null
        : (json["docs"] as List).map((e) => Docs.fromJson(e)).toList();
    totalDocs = json["totalDocs"];
    limit = json["limit"];
    page = json["page"];
    totalPages = json["totalPages"];
    pagingCounter = json["pagingCounter"];
    hasPrevPage = json["hasPrevPage"];
    hasNextPage = json["hasNextPage"];
    prevPage = json["prevPage"];
    nextPage = json["nextPage"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    if (docs != null) {
      _data["docs"] = docs?.map((e) => e.toJson()).toList();
    }
    _data["totalDocs"] = totalDocs;
    _data["limit"] = limit;
    _data["page"] = page;
    _data["totalPages"] = totalPages;
    _data["pagingCounter"] = pagingCounter;
    _data["hasPrevPage"] = hasPrevPage;
    _data["hasNextPage"] = hasNextPage;
    _data["prevPage"] = prevPage;
    _data["nextPage"] = nextPage;
    return _data;
  }
}

class Docs {
  String? id;
  bool? isPublic;
  bool? isRecorded;
  String? date;
  String? startTime;
  String? endTime;
  bool? isDisabled;
  String? sportId;
  dynamic skillLevel;
  String? status;
  String? facilityId;
  dynamic maxPlayer;
  List<String>? whoJoined;
  String? courtId;
  String? userId;
  List<String>? slotId;
  bool? isActive;
  bool? isDelete;
  List<dynamic>? friends;
  String? createdAt;
  String? updatedAt;
  int? v;
  UserDetail? userDetail;
  List<WhoJoinedDetail>? whoJoinedDetail;
  Court? court;
  Facility? facility;
  Sport? sport;
  List<SlotsDetail>? slotsDetail;
  Booking? booking;

  Docs({
    this.id,
    this.isPublic,
    this.isRecorded,
    this.date,
    this.startTime,
    this.endTime,
    this.isDisabled,
    this.sportId,
    this.skillLevel,
    this.status,
    this.facilityId,
    this.maxPlayer,
    this.whoJoined,
    this.courtId,
    this.userId,
    this.slotId,
    this.isActive,
    this.isDelete,
    this.friends,
    this.createdAt,
    this.updatedAt,
    this.v,
    this.userDetail,
    this.whoJoinedDetail,
    this.court,
    this.facility,
    this.sport,
    this.slotsDetail,
    this.booking,
  });

  Docs.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    isPublic = json["is_public"];
    isRecorded = json["is_recorded"];
    date = json["date"];
    startTime = json["startTime"];
    endTime = json["endTime"];
    isDisabled = json["is_disabled"];
    sportId = json["sport_id"];
    skillLevel = json["skill_level"];
    status = json["status"];
    facilityId = json["facility_id"];
    maxPlayer = json["max_player"];
    whoJoined = json["who_joined"] == null
        ? null
        : List<String>.from(json["who_joined"]);
    courtId = json["court_id"];
    userId = json["user_id"];
    slotId =
        json["slot_id"] == null ? null : List<String>.from(json["slot_id"]);
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    friends = json["friends"] ?? [];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
    userDetail = json["user_detail"] == null
        ? null
        : UserDetail.fromJson(json["user_detail"]);
    whoJoinedDetail = json["who_joined_detail"] == null
        ? null
        : (json["who_joined_detail"] as List)
            .map((e) => WhoJoinedDetail.fromJson(e))
            .toList();
    court = json["court"] == null ? null : Court.fromJson(json["court"]);
    facility =
        json["facility"] == null ? null : Facility.fromJson(json["facility"]);
    sport = json["sport"] == null ? null : Sport.fromJson(json["sport"]);
    slotsDetail = json["slots_detail"] == null
        ? null
        : (json["slots_detail"] as List)
            .map((e) => SlotsDetail.fromJson(e))
            .toList();
    booking =
        json["booking"] == null ? null : Booking.fromJson(json["booking"]);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["is_public"] = isPublic;
    _data["is_recorded"] = isRecorded;
    _data["date"] = date;
    _data["startTime"] = startTime;
    _data["endTime"] = endTime;
    _data["is_disabled"] = isDisabled;
    _data["sport_id"] = sportId;
    _data["skill_level"] = skillLevel;
    _data["status"] = status;
    _data["facility_id"] = facilityId;
    _data["max_player"] = maxPlayer;
    if (whoJoined != null) {
      _data["who_joined"] = whoJoined;
    }
    _data["court_id"] = courtId;
    _data["user_id"] = userId;
    if (slotId != null) {
      _data["slot_id"] = slotId;
    }
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    if (friends != null) {
      _data["friends"] = friends;
    }
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    if (userDetail != null) {
      _data["user_detail"] = userDetail?.toJson();
    }
    if (whoJoinedDetail != null) {
      _data["who_joined_detail"] =
          whoJoinedDetail?.map((e) => e.toJson()).toList();
    }
    if (court != null) {
      _data["court"] = court?.toJson();
    }
    if (facility != null) {
      _data["facility"] = facility?.toJson();
    }
    if (sport != null) {
      _data["sport"] = sport?.toJson();
    }
    if (slotsDetail != null) {
      _data["slots_detail"] = slotsDetail?.map((e) => e.toJson()).toList();
    }
    return _data;
  }
}

class SlotsDetail {
  String? id;
  String? startTime;
  String? endTime;
  String? day;
  dynamic price;
  String? courtId;
  bool? isActive;
  bool? isDelete;
  int? v;
  String? createdAt;
  String? updatedAt;

  SlotsDetail(
      {this.id,
      this.startTime,
      this.endTime,
      this.day,
      this.price,
      this.courtId,
      this.isActive,
      this.isDelete,
      this.v,
      this.createdAt,
      this.updatedAt});

  SlotsDetail.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    startTime = json["startTime"];
    endTime = json["endTime"];
    day = json["day"];
    price = json["price"];
    courtId = json["court_id"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    v = json["__v"];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["startTime"] = startTime;
    _data["endTime"] = endTime;
    _data["day"] = day;
    _data["price"] = price;
    _data["court_id"] = courtId;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["__v"] = v;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    return _data;
  }
}

class Sport {
  String? id;
  String? name;
  String? image;
  List<String>? skillLevel;
  String? matchType;
  bool? isActive;
  bool? isDelete;
  String? createdAt;
  String? updatedAt;
  int? v;

  Sport(
      {this.id,
      this.name,
      this.image,
      this.skillLevel,
      this.matchType,
      this.isActive,
      this.isDelete,
      this.createdAt,
      this.updatedAt,
      this.v});

  Sport.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    name = json["name"];
    image = json["image"];
    skillLevel = json["skill_level"] == null
        ? null
        : List<String>.from(json["skill_level"]);
    matchType = json["match_type"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["name"] = name;
    _data["image"] = image;
    if (skillLevel != null) {
      _data["skill_level"] = skillLevel;
    }
    _data["match_type"] = matchType;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    return _data;
  }
}

class Facility {
  String? id;
  String? name;
  String? image;
  String? description;
  String? bio;
  List<dynamic>? gallery;
  String? subscriptionStatus;
  dynamic latitude;
  dynamic longitude;
  String? address;
  List<String>? amenities;
  String? facilityOwner;
  bool? isActive;
  bool? isDelete;
  List<Team>? team;
  Location? location;
  String? createdAt;
  String? updatedAt;
  int? v;

  Facility(
      {this.id,
      this.name,
      this.image,
      this.description,
      this.bio,
      this.gallery,
      this.subscriptionStatus,
      this.latitude,
      this.longitude,
      this.address,
      this.amenities,
      this.facilityOwner,
      this.isActive,
      this.isDelete,
      this.team,
      this.location,
      this.createdAt,
      this.updatedAt,
      this.v});

  Facility.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    name = json["name"];
    image = json["image"];
    description = json["description"];
    bio = json["bio"];
    gallery = json["gallery"] ?? [];
    subscriptionStatus = json["subscription_status"];
    latitude = json["latitude"];
    longitude = json["longitude"];
    address = json["address"];
    amenities =
        json["amenities"] == null ? null : List<String>.from(json["amenities"]);
    facilityOwner = json["facility_owner"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    team = json["team"] == null
        ? null
        : (json["team"] as List).map((e) => Team.fromJson(e)).toList();
    location =
        json["location"] == null ? null : Location.fromJson(json["location"]);
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["name"] = name;
    _data["image"] = image;
    _data["description"] = description;
    _data["bio"] = bio;
    if (gallery != null) {
      _data["gallery"] = gallery;
    }
    _data["subscription_status"] = subscriptionStatus;
    _data["latitude"] = latitude;
    _data["longitude"] = longitude;
    _data["address"] = address;
    if (amenities != null) {
      _data["amenities"] = amenities;
    }
    _data["facility_owner"] = facilityOwner;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    if (team != null) {
      _data["team"] = team?.map((e) => e.toJson()).toList();
    }
    if (location != null) {
      _data["location"] = location?.toJson();
    }
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    return _data;
  }
}

class Location {
  String? type;
  List<dynamic>? coordinates;

  Location({this.type, this.coordinates});

  Location.fromJson(Map<String, dynamic> json) {
    type = json["type"];
    coordinates = json["coordinates"] == null
        ? null
        : List<dynamic>.from(json["coordinates"]);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["type"] = type;
    if (coordinates != null) {
      _data["coordinates"] = coordinates;
    }
    return _data;
  }
}

class Team {
  String? name;
  String? mobileNumber;
  String? countryCode;
  String? email;
  String? id;

  Team({this.name, this.mobileNumber, this.countryCode, this.email, this.id});

  Team.fromJson(Map<String, dynamic> json) {
    name = json["name"];
    mobileNumber = json["mobile_number"];
    countryCode = json["country_code"];
    email = json["email"];
    id = json["_id"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["name"] = name;
    _data["mobile_number"] = mobileNumber;
    _data["country_code"] = countryCode;
    _data["email"] = email;
    _data["_id"] = id;
    return _data;
  }
}

class Court {
  String? id;
  String? image;
  dynamic price;
  List<dynamic>? gallery;
  dynamic averageRating;
  Slots? slots;
  String? sportId;
  String? facilityId;
  String? facilityOwnerId;
  dynamic userId;
  bool? isActive;
  bool? isDelete;
  bool? isFavorite;
  String? name;
  String? createdAt;
  String? updatedAt;
  int? v;

  Court(
      {this.id,
      this.image,
      this.price,
      this.gallery,
      this.averageRating,
      this.slots,
      this.sportId,
      this.facilityId,
      this.facilityOwnerId,
      this.userId,
      this.isActive,
      this.isDelete,
      this.isFavorite,
      this.name,
      this.createdAt,
      this.updatedAt,
      this.v});

  Court.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    image = json["image"];
    price = json["price"];
    gallery = json["gallery"] ?? [];
    averageRating = json["averageRating"];
    slots = json["slots"] == null ? null : Slots.fromJson(json["slots"]);
    sportId = json["sport_id"];
    facilityId = json["facility_id"];
    facilityOwnerId = json["facility_owner_id"];
    userId = json["user_id"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    isFavorite = json["is_favorite"];
    name = json["name"];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["image"] = image;
    _data["price"] = price;
    if (gallery != null) {
      _data["gallery"] = gallery;
    }
    _data["averageRating"] = averageRating;
    if (slots != null) {
      _data["slots"] = slots?.toJson();
    }
    _data["sport_id"] = sportId;
    _data["facility_id"] = facilityId;
    _data["facility_owner_id"] = facilityOwnerId;
    _data["user_id"] = userId;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["is_favorite"] = isFavorite;
    _data["name"] = name;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    return _data;
  }
}

class Slots {
  List<Monday>? monday;

  Slots({this.monday});

  Slots.fromJson(Map<String, dynamic> json) {
    monday = json["Monday"] == null
        ? null
        : (json["Monday"] as List).map((e) => Monday.fromJson(e)).toList();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    if (monday != null) {
      _data["Monday"] = monday?.map((e) => e.toJson()).toList();
    }
    return _data;
  }
}

class Monday {
  String? startTime;
  String? endTime;
  String? price;

  Monday({this.startTime, this.endTime, this.price});

  Monday.fromJson(Map<String, dynamic> json) {
    startTime = json["start_time"];
    endTime = json["end_time"];
    price = json["price"].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["start_time"] = startTime;
    _data["end_time"] = endTime;
    _data["price"] = price;
    return _data;
  }
}

class WhoJoinedDetail {
  String? id;
  String? userType;
  String? password;
  dynamic uniqueId;
  dynamic dob;
  String? gender;
  dynamic address;
  dynamic cityId;
  bool? isActive;
  bool? isDelete;
  dynamic otp;
  bool? isApprove;
  String? loginType;
  String? deviceType;
  String? image;
  dynamic country;
  dynamic voipToken;
  dynamic latitude;
  dynamic longitude;
  dynamic deviceToken;
  dynamic socialId;
  bool? isVerify;
  bool? isNotificationOn;
  String? mobileNumber;
  String? countryCode;
  List<Sports>? sports;
  String? createdAt;
  String? updatedAt;
  int? v;
  String? email;
  String? name;

  WhoJoinedDetail(
      {this.id,
      this.userType,
      this.password,
      this.uniqueId,
      this.dob,
      this.gender,
      this.address,
      this.cityId,
      this.isActive,
      this.isDelete,
      this.otp,
      this.isApprove,
      this.loginType,
      this.deviceType,
      this.image,
      this.country,
      this.voipToken,
      this.latitude,
      this.longitude,
      this.deviceToken,
      this.socialId,
      this.isVerify,
      this.isNotificationOn,
      this.mobileNumber,
      this.countryCode,
      this.sports,
      this.createdAt,
      this.updatedAt,
      this.v,
      this.email,
      this.name});

  WhoJoinedDetail.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    userType = json["user_type"];
    password = json["password"];
    uniqueId = json["uniqueId"];
    dob = json["dob"];
    gender = json["gender"];
    address = json["address"];
    cityId = json["city_id"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    otp = json["otp"];
    isApprove = json["isApprove"];
    loginType = json["loginType"];
    deviceType = json["deviceType"];
    image = json["image"];
    country = json["country"];
    voipToken = json["voipToken"];
    latitude = json["latitude"];
    longitude = json["longitude"];
    deviceToken = json["deviceToken"];
    socialId = json["socialId"];
    isVerify = json["isVerify"];
    isNotificationOn = json["is_notification_on"];
    mobileNumber = json["mobile_number"];
    countryCode = json["country_code"];
    sports = json["sports"] == null
        ? null
        : (json["sports"] as List).map((e) => Sports.fromJson(e)).toList();
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
    email = json["email"];
    name = json["name"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["user_type"] = userType;
    _data["password"] = password;
    _data["uniqueId"] = uniqueId;
    _data["dob"] = dob;
    _data["gender"] = gender;
    _data["address"] = address;
    _data["city_id"] = cityId;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["otp"] = otp;
    _data["isApprove"] = isApprove;
    _data["loginType"] = loginType;
    _data["deviceType"] = deviceType;
    _data["image"] = image;
    _data["country"] = country;
    _data["voipToken"] = voipToken;
    _data["latitude"] = latitude;
    _data["longitude"] = longitude;
    _data["deviceToken"] = deviceToken;
    _data["socialId"] = socialId;
    _data["isVerify"] = isVerify;
    _data["is_notification_on"] = isNotificationOn;
    _data["mobile_number"] = mobileNumber;
    _data["country_code"] = countryCode;
    if (sports != null) {
      _data["sports"] = sports?.map((e) => e.toJson()).toList();
    }
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    _data["email"] = email;
    _data["name"] = name;
    return _data;
  }
}

class Sports {
  String? sportId;
  String? id;
  String? skillLevel;

  Sports({this.sportId, this.id, this.skillLevel});

  Sports.fromJson(Map<String, dynamic> json) {
    sportId = json["sport_id"];
    id = json["_id"];
    skillLevel = json["skill_level"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["sport_id"] = sportId;
    _data["_id"] = id;
    _data["skill_level"] = skillLevel;
    return _data;
  }
}

class UserDetail {
  String? id;
  String? userType;
  String? password;
  dynamic uniqueId;
  dynamic dob;
  String? gender;
  dynamic address;
  dynamic cityId;
  bool? isActive;
  bool? isDelete;
  dynamic otp;
  bool? isApprove;
  String? loginType;
  String? deviceType;
  dynamic image;
  dynamic country;
  dynamic voipToken;
  dynamic latitude;
  dynamic longitude;
  dynamic deviceToken;
  dynamic socialId;
  bool? isVerify;
  bool? isNotificationOn;
  String? mobileNumber;
  String? countryCode;
  List<dynamic>? sports;
  String? createdAt;
  String? updatedAt;
  int? v;

  UserDetail(
      {this.id,
      this.userType,
      this.password,
      this.uniqueId,
      this.dob,
      this.gender,
      this.address,
      this.cityId,
      this.isActive,
      this.isDelete,
      this.otp,
      this.isApprove,
      this.loginType,
      this.deviceType,
      this.image,
      this.country,
      this.voipToken,
      this.latitude,
      this.longitude,
      this.deviceToken,
      this.socialId,
      this.isVerify,
      this.isNotificationOn,
      this.mobileNumber,
      this.countryCode,
      this.sports,
      this.createdAt,
      this.updatedAt,
      this.v});

  UserDetail.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    userType = json["user_type"];
    password = json["password"];
    uniqueId = json["uniqueId"];
    dob = json["dob"];
    gender = json["gender"];
    address = json["address"];
    cityId = json["city_id"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    otp = json["otp"];
    isApprove = json["isApprove"];
    loginType = json["loginType"];
    deviceType = json["deviceType"];
    image = json["image"];
    country = json["country"];
    voipToken = json["voipToken"];
    latitude = json["latitude"];
    longitude = json["longitude"];
    deviceToken = json["deviceToken"];
    socialId = json["socialId"];
    isVerify = json["isVerify"];
    isNotificationOn = json["is_notification_on"];
    mobileNumber = json["mobile_number"];
    countryCode = json["country_code"];
    sports = json["sports"] ?? [];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["user_type"] = userType;
    _data["password"] = password;
    _data["uniqueId"] = uniqueId;
    _data["dob"] = dob;
    _data["gender"] = gender;
    _data["address"] = address;
    _data["city_id"] = cityId;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["otp"] = otp;
    _data["isApprove"] = isApprove;
    _data["loginType"] = loginType;
    _data["deviceType"] = deviceType;
    _data["image"] = image;
    _data["country"] = country;
    _data["voipToken"] = voipToken;
    _data["latitude"] = latitude;
    _data["longitude"] = longitude;
    _data["deviceToken"] = deviceToken;
    _data["socialId"] = socialId;
    _data["isVerify"] = isVerify;
    _data["is_notification_on"] = isNotificationOn;
    _data["mobile_number"] = mobileNumber;
    _data["country_code"] = countryCode;
    if (sports != null) {
      _data["sports"] = sports;
    }
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    return _data;
  }
}

class Booking {
  double? price;
  String? id;
  String? bookingid;


  Booking({this.price,this.id, this.bookingid});
Booking.fromJson(Map<String, dynamic> json) {
  price = json["price"] != null ? (json["price"] as num).toDouble() : 0.0;
  id = json["_id"];
  bookingid = json["booking_id"];
}

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _booking = <String, dynamic>{};
    _booking["price"] = price;
    _booking["_id"] = id;
    _booking ["booking_id"] = bookingid;
    return _booking;
  }
}
