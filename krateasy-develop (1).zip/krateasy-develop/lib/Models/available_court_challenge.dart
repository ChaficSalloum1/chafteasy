
class AvailableNearbyCourtsModel {
  String? id;
  String? image;
  dynamic price;
  List<dynamic>? gallery;
  dynamic averageRating;
  String? sportId;
  String? facilityId;
  dynamic facilityOwnerId;
  dynamic userId;
  bool? isActive;
  bool? isDelete;
  bool? isFavorite;
  String? name;
  String? createdAt;
  String? updatedAt;
  dynamic v;
  Facility? facility;
  List<SlotsData>? slotsData;
  dynamic requestedDate;

  AvailableNearbyCourtsModel({this.id, this.image, this.price, this.gallery, this.averageRating, this.sportId, this.facilityId, this.facilityOwnerId, this.userId, this.isActive, this.isDelete, this.isFavorite, this.name, this.createdAt, this.updatedAt, this.v, this.facility, this.slotsData, this.requestedDate});

  AvailableNearbyCourtsModel.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    image = json["image"];
    price = json["price"];
    gallery = json["gallery"] ?? [];
    averageRating = json["averageRating"];
    sportId = json["sport_id"];
    facilityId = json["facility_id"];
    facilityOwnerId = json["facility_owner_id"];
    userId = json["user_id"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    isFavorite = json["is_favorite"];
    name = json["name"];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
    facility = json["facility"] == null ? null : Facility.fromJson(json["facility"]);
    slotsData = json["slotsData"] == null ? null : (json["slotsData"] as List).map((e) => SlotsData.fromJson(e)).toList();
    requestedDate = json["requestedDate"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["image"] = image;
    _data["price"] = price;
    if(gallery != null) {
      _data["gallery"] = gallery;
    }
    _data["averageRating"] = averageRating;
    _data["sport_id"] = sportId;
    _data["facility_id"] = facilityId;
    _data["facility_owner_id"] = facilityOwnerId;
    _data["user_id"] = userId;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["is_favorite"] = isFavorite;
    _data["name"] = name;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    if(facility != null) {
      _data["facility"] = facility?.toJson();
    }
    if(slotsData != null) {
      _data["slotsData"] = slotsData?.map((e) => e.toJson()).toList();
    }
    _data["requestedDate"] = requestedDate;
    return _data;
  }
}

class SlotsData {
  String? id;
  String? startTime;
  String? endTime;
  String? day;
  dynamic price;
  String? courtId;
  bool? isActive;
  bool? isDelete;
  dynamic v;
  String? createdAt;
  String? updatedAt;

  SlotsData({this.id, this.startTime, this.endTime, this.day, this.price, this.courtId, this.isActive, this.isDelete, this.v, this.createdAt, this.updatedAt});

  SlotsData.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    startTime = json["startTime"];
    endTime = json["endTime"];
    day = json["day"];
    price = json["price"];
    courtId = json["court_id"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    v = json["__v"];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["startTime"] = startTime;
    _data["endTime"] = endTime;
    _data["day"] = day;
    _data["price"] = price;
    _data["court_id"] = courtId;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["__v"] = v;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    return _data;
  }
}

class Facility {
  String? id;
  String? name;
  String? image;
  String? description;
  String? bio;
  List<dynamic>? gallery;
  String? subscriptionStatus;
  dynamic latitude;
  dynamic longitude;
  String? address;
  List<String>? amenities;
  String? facilityOwner;
  bool? isActive;
  bool? isDelete;
  Location? location;
  List<dynamic>? team;
  String? createdAt;
  String? updatedAt;
  dynamic v;

  Facility({this.id, this.name, this.image, this.description, this.bio, this.gallery, this.subscriptionStatus, this.latitude, this.longitude, this.address, this.amenities, this.facilityOwner, this.isActive, this.isDelete, this.location, this.team, this.createdAt, this.updatedAt, this.v});

  Facility.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    name = json["name"];
    image = json["image"];
    description = json["description"];
    bio = json["bio"];
    gallery = json["gallery"] == null
        ? []
        : List<String>.from(json["gallery"].where((e) => e is String));
    subscriptionStatus = json["subscription_status"];
    latitude = json["latitude"];
    longitude = json["longitude"];
    address = json["address"];
    amenities = json["amenities"] == null
        ? null
        : json["amenities"].map((e) => e.toString()).toList().cast<String>();
    facilityOwner = json["facility_owner"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    location = json["location"] == null ? null : Location.fromJson(json["location"]);
    team = json["team"] == null
        ? []
        : List<String>.from(json["team"].where((e) => e is String));
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
  }


  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["name"] = name;
    _data["image"] = image;
    _data["description"] = description;
    _data["bio"] = bio;
    if(gallery != null) {
      _data["gallery"] = gallery;
    }
    _data["subscription_status"] = subscriptionStatus;
    _data["latitude"] = latitude;
    _data["longitude"] = longitude;
    _data["address"] = address;
    if(amenities != null) {
      _data["amenities"] = amenities;
    }
    _data["facility_owner"] = facilityOwner;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    if(location != null) {
      _data["location"] = location?.toJson();
    }
    if(team != null) {
      _data["team"] = team;
    }
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    return _data;
  }
}

class Location {
  String? type;
  List<double>? coordinates;

  Location({this.type, this.coordinates});

  Location.fromJson(Map<String, dynamic> json) {
    type = json["type"];
    coordinates = json["coordinates"] == null
        ? null
        : List<double>.from(json["coordinates"].map((e) => (e as num).toDouble()));
  }


  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["type"] = type;
    if(coordinates != null) {
      _data["coordinates"] = coordinates;
    }
    return _data;
  }
}