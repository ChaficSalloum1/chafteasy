
class CourtDetailsModel {
  bool? status;
  String? message;
  Data? data;
  dynamic exeTime;

  CourtDetailsModel({this.status, this.message, this.data, this.exeTime});

  CourtDetailsModel.fromJson(Map<String, dynamic> json) {
    status = json["status"];
    message = json["message"];
    data = json["data"] == null ? null : Data.fromJson(json["data"]);
    exeTime = json["exeTime"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["status"] = status;
    _data["message"] = message;
    if(data != null) {
      _data["data"] = data?.toJson();
    }
    _data["exeTime"] = exeTime;
    return _data;
  }
}

class Data {
  String? id;
  String? image;
  dynamic price;
  List<dynamic>? gallery;
  dynamic averageRating;
  SportId? sportId;
  FacilityId? facilityId;
  String? facilityOwnerId;
  String? userId;
  bool? isActive;
  bool? isDelete;
  bool? isFavorite;
  String? name;
  String? grname;
  String? createdAt;
  String? updatedAt;
  dynamic v;
  dynamic totalBookings;
  Bookings? bookings;
  List<SlotsData>? slotsData;

  Data({this.id, this.image, this.price, this.gallery, this.averageRating, this.sportId, this.facilityId, this.facilityOwnerId, this.userId, this.isActive, this.isDelete, this.isFavorite, this.name, this.createdAt, this.updatedAt, this.v, this.totalBookings, this.bookings, this.slotsData, this.grname});

  Data.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    image = json["image"];
    price = json["price"];
    gallery = json["gallery"] ?? [];
    averageRating = json["averageRating"];
    sportId = json["sport_id"] == null ? null : SportId.fromJson(json["sport_id"]);
    facilityId = json["facility_id"] == null ? null : FacilityId.fromJson(json["facility_id"]);
    facilityOwnerId = json["facility_owner_id"];
    userId = json["user_id"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    isFavorite = json["is_favorite"];
    name = json["name"];
    grname = json["gr_name"];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
    totalBookings = json["totalBookings"];
    bookings = json["bookings"] == null ? null : Bookings.fromJson(json["bookings"]);
    slotsData = json["slotsData"] == null ? null : (json["slotsData"] as List).map((e) => SlotsData.fromJson(e)).toList();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["image"] = image;
    _data["price"] = price;
    if(gallery != null) {
      _data["gallery"] = gallery;
    }
    _data["averageRating"] = averageRating;
    if(sportId != null) {
      _data["sport_id"] = sportId?.toJson();
    }
    if(facilityId != null) {
      _data["facility_id"] = facilityId?.toJson();
    }
    _data["facility_owner_id"] = facilityOwnerId;
    _data["user_id"] = userId;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["is_favorite"] = isFavorite;
    _data["name"] = name;
    _data["gr_name"] = grname;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    _data["totalBookings"] = totalBookings;
    if(bookings != null) {
      _data["bookings"] = bookings?.toJson();
    }
    if(slotsData != null) {
      _data["slotsData"] = slotsData?.map((e) => e.toJson()).toList();
    }
    return _data;
  }
}

class SlotsData {
  String? id;
  String? startTime;
  String? endTime;
  String? day;
  dynamic price;
  String? courtId;
  bool? isActive;
  bool? isDelete;
  dynamic v;
  String? createdAt;
  String? updatedAt;

  SlotsData({this.id, this.startTime, this.endTime, this.day, this.price, this.courtId, this.isActive, this.isDelete, this.v, this.createdAt, this.updatedAt});

  SlotsData.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    startTime = json["startTime"];
    endTime = json["endTime"];
    day = json["day"];
    price = json["price"];
    courtId = json["court_id"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    v = json["__v"];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["startTime"] = startTime;
    _data["endTime"] = endTime;
    _data["day"] = day;
    _data["price"] = price;
    _data["court_id"] = courtId;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["__v"] = v;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    return _data;
  }
}

class Bookings {
  String? id;
  String? bookingId;
  String? userId;
  String? courtId;
  String? facilityId;
  String? facilityOwnerId;
  dynamic slotId;
  String? slotTime;
  String? startTime;
  String? endTime;
  dynamic duration;
  dynamic adminCommission;
  dynamic facilityOwnerAmount;
  dynamic price;
  bool? isRecorded;
  String? status;
  bool? isSplit;
  String? paymentStatus;
  String? date;
  // List<dynamic>? friends;
  List<Friends>? friends;
  String? createdAt;
  String? updatedAt;
  dynamic v;

  Bookings({this.id, this.bookingId, this.userId, this.courtId, this.facilityId, this.facilityOwnerId, this.slotId, this.slotTime, this.startTime, this.endTime, this.duration, this.adminCommission, this.facilityOwnerAmount, this.price, this.isRecorded, this.status, this.isSplit, this.paymentStatus, this.date, this.friends, this.createdAt, this.updatedAt, this.v});

  Bookings.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    bookingId = json["booking_id"];
    userId = json["user_id"];
    courtId = json["court_id"];
    facilityId = json["facility_id"];
    facilityOwnerId = json["facility_owner_id"];
    slotId = json["slot_id"];
    slotTime = json["slotTime"];
    startTime = json["startTime"];
    endTime = json["endTime"];
    duration = json["duration"];
    adminCommission = json["admin_commission"];
    facilityOwnerAmount = json["facility_owner_amount"];
    price = json["price"];
    isRecorded = json["is_recorded"];
    status = json["status"];
    isSplit = json["is_split"];
    paymentStatus = json["payment_status"];
    date = json["date"];
    if (json['friends'] != null) {
      friends = <Friends>[];
      json['friends'].forEach((v) {
        friends!.add(new Friends.fromJson(v));
      });
    }
    // friends = json["friends"] ?? [];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["booking_id"] = bookingId;
    _data["user_id"] = userId;
    _data["court_id"] = courtId;
    _data["facility_id"] = facilityId;
    _data["facility_owner_id"] = facilityOwnerId;
    _data["slot_id"] = slotId;
    _data["slotTime"] = slotTime;
    _data["startTime"] = startTime;
    _data["endTime"] = endTime;
    _data["duration"] = duration;
    _data["admin_commission"] = adminCommission;
    _data["facility_owner_amount"] = facilityOwnerAmount;
    _data["price"] = price;
    _data["is_recorded"] = isRecorded;
    _data["status"] = status;
    _data["is_split"] = isSplit;
    _data["payment_status"] = paymentStatus;
    _data["date"] = date;
    if (this.friends != null) {
      _data['friends'] = this.friends!.map((v) => v.toJson()).toList();
    }
    // if(friends != null) {
    //   _data["friends"] = friends;
    // }
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    return _data;
  }
}

class FacilityId {
  String? id;
  String? name;
  String? image;
  String? description;
  String? grdescription;
  String? bio;
  String? grbio;
  List<dynamic>? gallery;
  String? subscriptionStatus;
  dynamic latitude;
  dynamic longitude;
  String? address;
  List<Amenities>? amenities;
  String? facilityOwner;
  bool? isActive;
  bool? isDelete;
  Location? location;
  List<dynamic>? team;
  String? createdAt;
  String? updatedAt;
  dynamic v;

  FacilityId({this.id, this.name, this.image,this.grdescription ,this.description, this.bio,this.grbio, this.gallery, this.subscriptionStatus, this.latitude, this.longitude, this.address, this.amenities, this.facilityOwner, this.isActive, this.isDelete, this.location, this.team, this.createdAt, this.updatedAt, this.v});

  FacilityId.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    name = json["name"];
    image = json["image"];
    description = json["description"];
    grdescription = json["gr_description"]??"";
    bio = json["bio"];
    grbio = json["gr_bio"]??"";
    gallery = json["gallery"] ?? [];
    subscriptionStatus = json["subscription_status"];
    latitude = json["latitude"];
    longitude = json["longitude"];
    address = json["address"];
    amenities = json["amenities"] == null ? null : (json["amenities"] as List).map((e) => Amenities.fromJson(e)).toList();
    facilityOwner = json["facility_owner"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    location = json["location"] == null ? null : Location.fromJson(json["location"]);
    team = json["team"] ?? [];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["name"] = name;
    _data["image"] = image;
    _data["description"] = description;
    _data["gr_description"] = grdescription;
    _data["bio"] = bio;
    _data["gr_bio"] = grbio;
    if(gallery != null) {
      _data["gallery"] = gallery;
    }
    _data["subscription_status"] = subscriptionStatus;
    _data["latitude"] = latitude;
    _data["longitude"] = longitude;
    _data["address"] = address;
    if(amenities != null) {
      _data["amenities"] = amenities?.map((e) => e.toJson()).toList();
    }
    _data["facility_owner"] = facilityOwner;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    if(location != null) {
      _data["location"] = location?.toJson();
    }
    if(team != null) {
      _data["team"] = team;
    }
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    return _data;
  }
}

class Location {
  String? type;
  List<double>? coordinates;

  Location({this.type, this.coordinates});

  Location.fromJson(Map<String, dynamic> json) {
    type = json["type"];
    coordinates = json["coordinates"] == null ? null : List<double>.from(json["coordinates"]);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["type"] = type;
    if(coordinates != null) {
      _data["coordinates"] = coordinates;
    }
    return _data;
  }
}

class Amenities {
  String? id;
  bool? isActive;
  bool? isDelete;
  String? name;
  String? grname;
  String? image;
  String? createdAt;
  String? updatedAt;
  dynamic v;

  Amenities({this.id, this.isActive, this.isDelete,this.grname ,this.name, this.image, this.createdAt, this.updatedAt, this.v});

  Amenities.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    name = json["name"];
    grname = json ["gr_name"]??"";
    image = json["image"];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["name"] = name;
    _data["gr_name"] = grname;

    _data["image"] = image;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    return _data;
  }
}

class SportId {
  String? id;
  String? name;
  String? image;
  List<String>? skillLevel;
  String? matchType;
  bool? isActive;
  bool? isDelete;
  String? createdAt;
  String? updatedAt;
  dynamic v;

  SportId({this.id, this.name, this.image, this.skillLevel, this.matchType, this.isActive, this.isDelete, this.createdAt, this.updatedAt, this.v});

  SportId.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    name = json["name"];
    image = json["image"];
    skillLevel = json["skill_level"] == null ? null : List<String>.from(json["skill_level"]);
    matchType = json["match_type"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["name"] = name;
    _data["image"] = image;
    if(skillLevel != null) {
      _data["skill_level"] = skillLevel;
    }
    _data["match_type"] = matchType;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    return _data;
  }
}



class Friends {
  String? name;
  String? mobileNumber;
  String? countryCode;
  dynamic? splitAmount;
  bool? isPaid;
  bool? isFriendFavorite;
  bool? isReviewed;
  String? sId;

  Friends(
      {this.name,
        this.mobileNumber,
        this.countryCode,
        this.splitAmount,
        this.isPaid,
        this.isFriendFavorite,
        this.isReviewed,
        this.sId});

  Friends.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    mobileNumber = json['mobile_number'];
    countryCode = json['country_code'];
    splitAmount = json['split_amount'];
    isPaid = json['is_paid'];
    isFriendFavorite = json['is_friend_favorite'];
    isReviewed = json['isReviewed'];
    sId = json['_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['mobile_number'] = this.mobileNumber;
    data['country_code'] = this.countryCode;
    data['split_amount'] = this.splitAmount;
    data['is_paid'] = this.isPaid;
    data['is_friend_favorite'] = this.isFriendFavorite;
    data['isReviewed'] = this.isReviewed;
    data['_id'] = this.sId;
    return data;
  }
}