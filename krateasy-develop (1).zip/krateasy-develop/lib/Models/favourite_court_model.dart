
class FavouriteCourtModel {
  bool? status;
  String? message;
  List<ResultModel>? result;
  int? exeTime;

  FavouriteCourtModel({this.status, this.message, this.result, this.exeTime});

  FavouriteCourtModel.fromJson(Map<String, dynamic> json) {
    status = json["status"];
    message = json["message"];
    result = json["result"] == null ? null : (json["result"] as List).map((e) => ResultModel.fromJson(e)).toList();
    exeTime = json["exeTime"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["status"] = status;
    _data["message"] = message;
    if(result != null) {
      _data["result"] = result?.map((e) => e.toJson()).toList();
    }
    _data["exeTime"] = exeTime;
    return _data;
  }
}

class ResultModel {
  String? id;
  bool? isActive;
  bool? isDelete;
  String? userId;
  String? type;
  String? courtId;
  String? createdAt;
  String? updatedAt;
  int? v;
  Courts? courts;
  Facility? facility;
  Sport? sport;
  List<Slots1>? slots;

  ResultModel({this.id, this.isActive, this.isDelete, this.userId, this.type, this.courtId, this.createdAt, this.updatedAt, this.v, this.courts, this.facility, this.sport, this.slots});

  ResultModel.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    userId = json["user_id"];
    type = json["type"];
    courtId = json["court_id"];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
    courts = json["courts"] == null ? null : Courts.fromJson(json["courts"]);
    facility = json["facility"] == null ? null : Facility.fromJson(json["facility"]);
    sport = json["sport"] == null ? null : Sport.fromJson(json["sport"]);
    slots = json["slots"] == null ? null : (json["slots"] as List).map((e) => Slots1.fromJson(e)).toList();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["user_id"] = userId;
    _data["type"] = type;
    _data["court_id"] = courtId;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    if(courts != null) {
      _data["courts"] = courts?.toJson();
    }
    if(facility != null) {
      _data["facility"] = facility?.toJson();
    }
    if(sport != null) {
      _data["sport"] = sport?.toJson();
    }
    if(slots != null) {
      _data["slots"] = slots?.map((e) => e.toJson()).toList();
    }
    return _data;
  }
}

class Slots1 {
  String? id;
  String? startTime;
  String? endTime;
  var startTime24;
  var endTime24;
  String? day;
  var price;
  String? courtId;
  bool? isActive;
  bool? isDelete;
  var v;
  String? createdAt;
  String? updatedAt;

  Slots1({this.id, this.startTime, this.endTime, this.startTime24, this.endTime24, this.day, this.price, this.courtId, this.isActive, this.isDelete, this.v, this.createdAt, this.updatedAt});

  Slots1.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    startTime = json["startTime"];
    endTime = json["endTime"];
    startTime24 = json["startTime24"];
    endTime24 = json["endTime24"];
    day = json["day"];
    price = json["price"];
    courtId = json["court_id"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    v = json["__v"];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["startTime"] = startTime;
    _data["endTime"] = endTime;
    _data["startTime24"] = startTime24;
    _data["endTime24"] = endTime24;
    _data["day"] = day;
    _data["price"] = price;
    _data["court_id"] = courtId;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["__v"] = v;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    return _data;
  }
}

class Sport {
  String? id;
  String? name;
  String? image;
  List<String>? skillLevel;
  String? matchType;
  bool? isActive;
  bool? isDelete;
  String? createdAt;
  String? updatedAt;
  var v;

  Sport({this.id, this.name, this.image, this.skillLevel, this.matchType, this.isActive, this.isDelete, this.createdAt, this.updatedAt, this.v});

  Sport.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    name = json["name"];
    image = json["image"];
    skillLevel = json["skill_level"] == null ? null : List<String>.from(json["skill_level"]);
    matchType = json["match_type"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["name"] = name;
    _data["image"] = image;
    if(skillLevel != null) {
      _data["skill_level"] = skillLevel;
    }
    _data["match_type"] = matchType;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    return _data;
  }
}

class Facility {
  String? id;
  String? name;
  dynamic image;
  String? description;
  dynamic bio;
  List<String>? gallery;
  String? subscriptionStatus;
  var latitude;
  var longitude;
  String? address;
  List<String>? amenities;
  String? facilityOwner;
  bool? isActive;
  bool? isDelete;
  List<dynamic>? team;
  Location? location;
  String? createdAt;
  String? updatedAt;
  var v;

  Facility({this.id, this.name, this.image, this.description, this.bio, this.gallery, this.subscriptionStatus, this.latitude, this.longitude, this.address, this.amenities, this.facilityOwner, this.isActive, this.isDelete, this.team, this.location, this.createdAt, this.updatedAt, this.v});

  Facility.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    name = json["name"];
    image = json["image"];
    description = json["description"];
    bio = json["bio"];
    gallery = json["gallery"] == null ? null : List<String>.from(json["gallery"]);
    subscriptionStatus = json["subscription_status"];
    latitude = json["latitude"];
    longitude = json["longitude"];
    address = json["address"];
    amenities = json["amenities"] == null ? null : List<String>.from(json["amenities"]);
    facilityOwner = json["facility_owner"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    team = json["team"] ?? [];
    location = json["location"] == null ? null : Location.fromJson(json["location"]);
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["name"] = name;
    _data["image"] = image;
    _data["description"] = description;
    _data["bio"] = bio;
    if(gallery != null) {
      _data["gallery"] = gallery;
    }
    _data["subscription_status"] = subscriptionStatus;
    _data["latitude"] = latitude;
    _data["longitude"] = longitude;
    _data["address"] = address;
    if(amenities != null) {
      _data["amenities"] = amenities;
    }
    _data["facility_owner"] = facilityOwner;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    if(team != null) {
      _data["team"] = team;
    }
    if(location != null) {
      _data["location"] = location?.toJson();
    }
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    return _data;
  }
}

class Location {
  String? type;
  List<dynamic>? coordinates;

  Location({this.type, this.coordinates});

  Location.fromJson(Map<String, dynamic> json) {
    type = json["type"];
    coordinates = json["coordinates"] == null ? null : List<dynamic>.from(json["coordinates"]);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["type"] = type;
    if(coordinates != null) {
      _data["coordinates"] = coordinates;
    }
    return _data;
  }
}

class Courts {
  String? id;
  dynamic image;
  var startTime;
  var endTime;
  var price;
  var minHours;
  List<dynamic>? gallery;
  var averageRating;
  var totalRating;
  Slots? slots;
  String? sportId;
  String? facilityId;
  String? facilityOwnerId;
  String? userId;
  bool? isActive;
  bool? isDelete;
  bool? isFavorite;
  String? name;
  String? grName;
  String? createdAt;
  String? updatedAt;
  var v;

  Courts({this.id, this.image, this.startTime, this.endTime, this.price, this.minHours, this.gallery, this.averageRating, this.totalRating, this.slots, this.sportId, this.facilityId, this.facilityOwnerId, this.userId, this.isActive, this.isDelete, this.isFavorite, this.name, this.grName, this.createdAt, this.updatedAt, this.v});

  Courts.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    image = json["image"];
    startTime = json["startTime"];
    endTime = json["endTime"];
    price = json["price"];
    minHours = json["minHours"];
    gallery = json["gallery"] ?? [];
    averageRating = json["averageRating"];
    totalRating = json["totalRating"];
    slots = json["slots"] == null ? null : Slots.fromJson(json["slots"]);
    sportId = json["sport_id"];
    facilityId = json["facility_id"];
    facilityOwnerId = json["facility_owner_id"];
    userId = json["user_id"];
    isActive = json["is_active"];
    isDelete = json["is_delete"];
    isFavorite = json["is_favorite"];
    name = json["name"];
    grName = json["gr_name"];
    createdAt = json["created_at"];
    updatedAt = json["updated_at"];
    v = json["__v"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["image"] = image;
    _data["startTime"] = startTime;
    _data["endTime"] = endTime;
    _data["price"] = price;
    _data["minHours"] = minHours;
    if(gallery != null) {
      _data["gallery"] = gallery;
    }
    _data["averageRating"] = averageRating;
    _data["totalRating"] = totalRating;
    if(slots != null) {
      _data["slots"] = slots?.toJson();
    }
    _data["sport_id"] = sportId;
    _data["facility_id"] = facilityId;
    _data["facility_owner_id"] = facilityOwnerId;
    _data["user_id"] = userId;
    _data["is_active"] = isActive;
    _data["is_delete"] = isDelete;
    _data["is_favorite"] = isFavorite;
    _data["name"] = name;
    _data["gr_name"] = grName;
    _data["created_at"] = createdAt;
    _data["updated_at"] = updatedAt;
    _data["__v"] = v;
    return _data;
  }
}

class Slots {
  List<Monday>? monday;
  List<Tuesday>? tuesday;
  List<Wednesday>? wednesday;
  List<Thursday>? thursday;
  List<Friday>? friday;
  List<Saturday>? saturday;
  List<Sunday>? sunday;

  Slots({this.monday, this.tuesday, this.wednesday, this.thursday, this.friday, this.saturday, this.sunday});

  Slots.fromJson(Map<String, dynamic> json) {
    monday = json["Monday"] == null ? null : (json["Monday"] as List).map((e) => Monday.fromJson(e)).toList();
    tuesday = json["Tuesday"] == null ? null : (json["Tuesday"] as List).map((e) => Tuesday.fromJson(e)).toList();
    wednesday = json["Wednesday"] == null ? null : (json["Wednesday"] as List).map((e) => Wednesday.fromJson(e)).toList();
    thursday = json["Thursday"] == null ? null : (json["Thursday"] as List).map((e) => Thursday.fromJson(e)).toList();
    friday = json["Friday"] == null ? null : (json["Friday"] as List).map((e) => Friday.fromJson(e)).toList();
    saturday = json["Saturday"] == null ? null : (json["Saturday"] as List).map((e) => Saturday.fromJson(e)).toList();
    sunday = json["Sunday"] == null ? null : (json["Sunday"] as List).map((e) => Sunday.fromJson(e)).toList();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    if(monday != null) {
      _data["Monday"] = monday?.map((e) => e.toJson()).toList();
    }
    if(tuesday != null) {
      _data["Tuesday"] = tuesday?.map((e) => e.toJson()).toList();
    }
    if(wednesday != null) {
      _data["Wednesday"] = wednesday?.map((e) => e.toJson()).toList();
    }
    if(thursday != null) {
      _data["Thursday"] = thursday?.map((e) => e.toJson()).toList();
    }
    if(friday != null) {
      _data["Friday"] = friday?.map((e) => e.toJson()).toList();
    }
    if(saturday != null) {
      _data["Saturday"] = saturday?.map((e) => e.toJson()).toList();
    }
    if(sunday != null) {
      _data["Sunday"] = sunday?.map((e) => e.toJson()).toList();
    }
    return _data;
  }
}

class Sunday {
  String? startTime;
  String? endTime;
  var startTime24;
  var endTime24;
  String? price;

  Sunday({this.startTime, this.endTime, this.startTime24, this.endTime24, this.price});

  Sunday.fromJson(Map<String, dynamic> json) {
    startTime = json["start_time"];
    endTime = json["end_time"];
    startTime24 = json["startTime24"];
    endTime24 = json["endTime24"];
    price = json["price"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["start_time"] = startTime;
    _data["end_time"] = endTime;
    _data["startTime24"] = startTime24;
    _data["endTime24"] = endTime24;
    _data["price"] = price;
    return _data;
  }
}

class Saturday {
  String? startTime;
  String? endTime;
  var startTime24;
  var endTime24;
  String? price;

  Saturday({this.startTime, this.endTime, this.startTime24, this.endTime24, this.price});

  Saturday.fromJson(Map<String, dynamic> json) {
    startTime = json["start_time"];
    endTime = json["end_time"];
    startTime24 = json["startTime24"];
    endTime24 = json["endTime24"];
    price = json["price"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["start_time"] = startTime;
    _data["end_time"] = endTime;
    _data["startTime24"] = startTime24;
    _data["endTime24"] = endTime24;
    _data["price"] = price;
    return _data;
  }
}

class Friday {
  String? startTime;
  String? endTime;
  var startTime24;
  var endTime24;
  String? price;

  Friday({this.startTime, this.endTime, this.startTime24, this.endTime24, this.price});

  Friday.fromJson(Map<String, dynamic> json) {
    startTime = json["start_time"];
    endTime = json["end_time"];
    startTime24 = json["startTime24"];
    endTime24 = json["endTime24"];
    price = json["price"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["start_time"] = startTime;
    _data["end_time"] = endTime;
    _data["startTime24"] = startTime24;
    _data["endTime24"] = endTime24;
    _data["price"] = price;
    return _data;
  }
}

class Thursday {
  String? startTime;
  String? endTime;
  var startTime24;
  var endTime24;
  String? price;

  Thursday({this.startTime, this.endTime, this.startTime24, this.endTime24, this.price});

  Thursday.fromJson(Map<String, dynamic> json) {
    startTime = json["start_time"];
    endTime = json["end_time"];
    startTime24 = json["startTime24"];
    endTime24 = json["endTime24"];
    price = json["price"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["start_time"] = startTime;
    _data["end_time"] = endTime;
    _data["startTime24"] = startTime24;
    _data["endTime24"] = endTime24;
    _data["price"] = price;
    return _data;
  }
}

class Wednesday {
  String? startTime;
  String? endTime;
  var startTime24;
  var endTime24;
  String? price;

  Wednesday({this.startTime, this.endTime, this.startTime24, this.endTime24, this.price});

  Wednesday.fromJson(Map<String, dynamic> json) {
    startTime = json["start_time"];
    endTime = json["end_time"];
    startTime24 = json["startTime24"];
    endTime24 = json["endTime24"];
    price = json["price"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["start_time"] = startTime;
    _data["end_time"] = endTime;
    _data["startTime24"] = startTime24;
    _data["endTime24"] = endTime24;
    _data["price"] = price;
    return _data;
  }
}

class Tuesday {
  String? startTime;
  String? endTime;
  var startTime24;
  var endTime24;
  String? price;

  Tuesday({this.startTime, this.endTime, this.startTime24, this.endTime24, this.price});

  Tuesday.fromJson(Map<String, dynamic> json) {
    startTime = json["start_time"];
    endTime = json["end_time"];
    startTime24 = json["startTime24"];
    endTime24 = json["endTime24"];
    price = json["price"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["start_time"] = startTime;
    _data["end_time"] = endTime;
    _data["startTime24"] = startTime24;
    _data["endTime24"] = endTime24;
    _data["price"] = price;
    return _data;
  }
}

class Monday {
  String? startTime;
  String? endTime;
  var startTime24;
  var endTime24;
  String? price;

  Monday({this.startTime, this.endTime, this.startTime24, this.endTime24, this.price});

  Monday.fromJson(Map<String, dynamic> json) {
    startTime = json["start_time"];
    endTime = json["end_time"];
    startTime24 = json["startTime24"];
    endTime24 = json["endTime24"];
    price = json["price"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["start_time"] = startTime;
    _data["end_time"] = endTime;
    _data["startTime24"] = startTime24;
    _data["endTime24"] = endTime24;
    _data["price"] = price;
    return _data;
  }
}