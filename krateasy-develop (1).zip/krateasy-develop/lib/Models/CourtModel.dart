class CourtModel {
  final String name;
  final String image;
  final List<Slot> slots;
  final Facility facility;

  CourtModel({
    required this.name,
    required this.image,
    required this.slots,
    required this.facility,
  });

  factory CourtModel.fromJson(Map<String, dynamic> json) {
    return CourtModel(
      name: json['name'],
      image: json['image'],
      slots: (json['slots'] as List).map((slot) => Slot.fromJson(slot)).toList(),
      facility: Facility.fromJson(json['facility']),
    );
  }
}

class Slot {
  final String startTime;
  final String endTime;
  final String price;

  Slot({required this.startTime, required this.endTime, required this.price});

  factory Slot.fromJson(Map<String, dynamic> json) {
    return Slot(
      startTime: json['start_time'],
      endTime: json['end_time'],
      price: json['price'].toString(),
    );
  }
}

class Facility {
  final String name;
  final String address;

  Facility({required this.name, required this.address});

  factory Facility.fromJson(Map<String, dynamic> json) {
    return Facility(
      name: json['name'],
      address: json['address'],
    );
  }
}