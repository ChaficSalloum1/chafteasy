
// To parse this JSON data, do
//
//     final bookingDetailsModelNew = bookingDetailsModelNewFromJson(jsonString);

import 'dart:convert';

BookingDetailsModelNew bookingDetailsModelNewFromJson(String str) => BookingDetailsModelNew.fromJson(json.decode(str));

String bookingDetailsModelNewToJson(BookingDetailsModelNew data) => json.encode(data.toJson());

class BookingDetailsModelNew {
  bool? status;
  String? message;
  BookingDetailsModelNewData? data;
  int? exeTime;

  BookingDetailsModelNew({
    this.status,
    this.message,
    this.data,
    this.exeTime,
  });

  factory BookingDetailsModelNew.fromJson(Map<String, dynamic> json) => BookingDetailsModelNew(
    status: json["status"],
    message: json["message"],
    data: json["data"] == null ? null : BookingDetailsModelNewData.fromJson(json["data"]),
    exeTime: json["exeTime"],
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "data": data?.toJson(),
    "exeTime": exeTime,
  };
}

class BookingDetailsModelNewData {
  List<User>? user;
  dynamic? paidAmount;
  dynamic? leftAmount;
  DataData? data;

  BookingDetailsModelNewData({
    this.user,
    this.paidAmount,
    this.leftAmount,
    this.data,
  });

  factory BookingDetailsModelNewData.fromJson(Map<String, dynamic> json) => BookingDetailsModelNewData(
    user: json["user"] == null ? [] : List<User>.from(json["user"]!.map((x) => User.fromJson(x))),
    paidAmount: json["paidAmount"]?.toDouble(),
    leftAmount: json["leftAmount"]?.toDouble(),
    data: json["data"] == null ? null : DataData.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "user": user == null ? [] : List<dynamic>.from(user!.map((x) => x.toJson())),
    "paidAmount": paidAmount,
    "leftAmount": leftAmount,
    "data": data?.toJson(),
  };
}

class DataData {
  String? id;
  String? bookingId;
  String? userId;
  String? courtId;
  dynamic challengeId;
  String? facilityId;
  String? facilityOwnerId;
  List<String>? slotId;
  DateTime? bookingStartTime;
  String? slotTime;
  String? startTime;
  String? endTime;
  int? startTime24;
  int? endTime24;
  dynamic duration;
  int? adminCommission;
  int? facilityOwnerAmount;
  int? price;
  String? type;
  dynamic discountId;
  int? discountAmount;
  bool? isRecorded;
  bool? isOfflineBooking;
  bool? isReview;
  bool? isModified;
  String? status;
  bool? isSplit;
  String? paymentStatus;
  DateTime? date;
  List<User>? friends;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;

  DataData({
    this.id,
    this.bookingId,
    this.userId,
    this.courtId,
    this.challengeId,
    this.facilityId,
    this.facilityOwnerId,
    this.slotId,
    this.bookingStartTime,
    this.slotTime,
    this.startTime,
    this.endTime,
    this.startTime24,
    this.endTime24,
    this.duration,
    this.adminCommission,
    this.facilityOwnerAmount,
    this.price,
    this.type,
    this.discountId,
    this.discountAmount,
    this.isRecorded,
    this.isOfflineBooking,
    this.isReview,
    this.isModified,
    this.status,
    this.isSplit,
    this.paymentStatus,
    this.date,
    this.friends,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  factory DataData.fromJson(Map<String, dynamic> json) => DataData(
    id: json["_id"],
    bookingId: json["booking_id"],
    userId: json["user_id"],
    courtId: json["court_id"],
    challengeId: json["challenge_id"],
    facilityId: json["facility_id"],
    facilityOwnerId: json["facility_owner_id"],
    slotId: json["slot_id"] == null ? [] : List<String>.from(json["slot_id"]!.map((x) => x)),
    bookingStartTime: json["bookingStartTime"] == null ? null : DateTime.parse(json["bookingStartTime"]),
    slotTime: json["slotTime"],
    startTime: json["startTime"],
    endTime: json["endTime"],
    startTime24: json["startTime24"],
    endTime24: json["endTime24"],
    duration: json["duration"],
    adminCommission: json["admin_commission"],
    facilityOwnerAmount: json["facility_owner_amount"],
    price: json["price"],
    type: json["type"],
    discountId: json["discountId"],
    discountAmount: json["discountAmount"],
    isRecorded: json["is_recorded"],
    isOfflineBooking: json["isOfflineBooking"],
    isReview: json["is_review"],
    isModified: json["is_modified"],
    status: json["status"],
    isSplit: json["is_split"],
    paymentStatus: json["payment_status"],
    date: json["date"] == null ? null : DateTime.parse(json["date"]),
    friends: json["friends"] == null ? [] : List<User>.from(json["friends"]!.map((x) => User.fromJson(x))),
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    v: json["__v"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "booking_id": bookingId,
    "user_id": userId,
    "court_id": courtId,
    "challenge_id": challengeId,
    "facility_id": facilityId,
    "facility_owner_id": facilityOwnerId,
    "slot_id": slotId == null ? [] : List<dynamic>.from(slotId!.map((x) => x)),
    "bookingStartTime": bookingStartTime?.toIso8601String(),
    "slotTime": slotTime,
    "startTime": startTime,
    "endTime": endTime,
    "startTime24": startTime24,
    "endTime24": endTime24,
    "duration": duration,
    "admin_commission": adminCommission,
    "facility_owner_amount": facilityOwnerAmount,
    "price": price,
    "type": type,
    "discountId": discountId,
    "discountAmount": discountAmount,
    "is_recorded": isRecorded,
    "isOfflineBooking": isOfflineBooking,
    "is_review": isReview,
    "is_modified": isModified,
    "status": status,
    "is_split": isSplit,
    "payment_status": paymentStatus,
    "date": date?.toIso8601String(),
    "friends": friends == null ? [] : List<dynamic>.from(friends!.map((x) => x.toJson())),
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
    "__v": v,
  };
}

class User {
  String? name;
  String? mobileNumber;
  String? countryCode;
  double? splitAmount;
  bool? isPaid;
  bool? isFriendFavorite;
  bool? isReviewed;
  String? id;
  String? image;

  User({
    this.name,
    this.mobileNumber,
    this.countryCode,
    this.splitAmount,
    this.isPaid,
    this.isFriendFavorite,
    this.isReviewed,
    this.id,
    this.image,
  });

  factory User.fromJson(Map<String, dynamic> json) => User(
    name: json["name"],
    mobileNumber: json["mobile_number"],
    countryCode: json["country_code"],
    splitAmount: json["split_amount"]?.toDouble(),
    isPaid: json["is_paid"],
    isFriendFavorite: json["is_friend_favorite"],
    isReviewed: json["isReviewed"],
    id: json["_id"],
    image: json["image"],
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "mobile_number": mobileNumber,
    "country_code": countryCode,
    "split_amount": splitAmount,
    "is_paid": isPaid,
    "is_friend_favorite": isFriendFavorite,
    "isReviewed": isReviewed,
    "_id": id,
    "image": image,
  };
}
