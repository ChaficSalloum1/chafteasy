class GuestPublicChallengeModel {
  final bool? status;
  final String? message;
  final List<PublicChallenge>? data;
  final int? exeTime;

  GuestPublicChallengeModel({
    this.status,
    this.message,
    this.data,
    this.exeTime,
  });

  factory GuestPublicChallengeModel.fromJson(Map<String, dynamic> json) {
    return GuestPublicChallengeModel(
      status: json['status'],
      message: json['message'],
      data: (json['data'] as List?)
          ?.map((e) => PublicChallenge.fromJson(e))
          .toList(),
      exeTime: json['exeTime'],
    );
  }
}

class PublicChallenge {
  final String? id;
  final String? date;
  final String? skillLevel;
  final int? maxPlayer;
  final List<dynamic>? whoJoined;
  final Slot? slot;

  PublicChallenge({
    this.id,
    this.date,
    this.skillLevel,
    this.maxPlayer,
    this.whoJoined,
    this.slot,
  });

  factory PublicChallenge.fromJson(Map<String, dynamic> json) {
    return PublicChallenge(
      id: json['_id'],
      date: json['date'],
      skillLevel: json['skill_level'],
      maxPlayer: json['max_player'],
      whoJoined: json['who_joined'] as List<dynamic>?,
      slot: json['slot'] != null ? Slot.fromJson(json['slot']) : null,
    );
  }
}

class Slot {
  final String? id; // Add this

  final String? startTime;
  final String? endTime;
  final String? day;
  final Court? court;
  final double? price;

  Slot({
    this.id,
    this.startTime,
    this.endTime,
    this.day,
    this.court,
    this.price,
  });

  factory Slot.fromJson(Map<String, dynamic> json) {
    return Slot(
      startTime: json['startTime'],
      id: json['_id'],
      endTime: json['endTime'],
      day: json['day'],
      court: json['court'] != null ? Court.fromJson(json['court']) : null,
      price: (json['price'] as num?)?.toDouble(),
    );
  }
}

class Court {
  final String? image;
  final String? name;
  final Sport? sport;
  final Facility? facility;

  Court({
    this.image,
    this.name,
    this.sport,
    this.facility,
  });

  factory Court.fromJson(Map<String, dynamic> json) {
    return Court(
      image: json['image'],
      name: json['name'],
      sport: json['sport'] != null ? Sport.fromJson(json['sport']) : null,
      facility:
          json['facility'] != null ? Facility.fromJson(json['facility']) : null,
    );
  }
}

class Sport {
  final String? id;
  final String? name;
  final String? image;

  Sport({
    this.id,
    this.name,
    this.image,
  });

  factory Sport.fromJson(Map<String, dynamic> json) {
    return Sport(
      id: json['_id'],
      name: json['name'],
      image: json['image'],
    );
  }
}

class Facility {
  final double? latitude;
  final double? longitude;
  final String? address;

  Facility({
    this.latitude,
    this.longitude,
    this.address,
  });

  factory Facility.fromJson(Map<String, dynamic> json) {
    return Facility(
      latitude: (json['latitude'] as num?)?.toDouble(),
      longitude: (json['longitude'] as num?)?.toDouble(),
      address: json['address'],
    );
  }
}
