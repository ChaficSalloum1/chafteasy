class ChallengesGuestModel {
  final String id;
  final String name;
  final int maxPlayer;
  final String startTime;
  final String endTime;
  final String day;
  final int price;
  final String courtName;
  final String sportName;
  final String facilityName;
  final String facilityAddress;
  final String createdAt;
  final List<String> whoJoined;
  final String sportImage;
  final String facilityImage;

  ChallengesGuestModel({
    required this.id,
    required this.name,
    required this.maxPlayer,
    required this.startTime,
    required this.endTime,
    required this.day,
    required this.price,
    required this.courtName,
    required this.sportName,
    required this.facilityName,
    required this.facilityAddress,
    required this.createdAt,
    required this.whoJoined,
    required this.sportImage,
    required this.facilityImage,
  });

  factory ChallengesGuestModel.fromJson(Map<String, dynamic> json) {
    return ChallengesGuestModel(
      id: json['_id'] ?? '', // Null check for _id
      name: json['name'] ?? 'N/A', // Default to 'N/A' if name is null
      maxPlayer: json['max_player'] ?? 0, // Default to 0 if max_player is null
      startTime: json['slots']?['startTime'] ?? '', // Null check for startTime
      endTime: json['slots']?['endTime'] ?? '', // Null check for endTime
      day: json['slots']?['day'] ?? '', // Null check for day
      price: json['slots']?['price'] ?? 0, // Default to 0 if price is null
      courtName:
          json['slots']?['court']?['name'] ?? '', // Null check for courtName
      sportName:
          json['slots']?['court']?['sport']?['name'] ??
          '', // Null check for sportName
      facilityName:
          json['slots']?['court']?['facility']?['name'] ??
          '', // Null check for facilityName
      facilityAddress:
          json['slots']?['court']?['facility']?['address'] ??
          '', // Null check for facilityAddress
      createdAt: json['created_at'] ?? '', // Null check for createdAt
      whoJoined:
          (json['who_joined'] as List? ?? [])
              .map((e) => e['_id'] as String)
              .toList(), // Null-aware handling of who_joined list
      sportImage:
          json['slots']?['court']?['sport']?['image'] ??
          '', // Null check for sportImage
      facilityImage:
          json['slots']?['court']?['facility']?['image'] ??
          '', // Null check for facilityImage
    );
  }
}
