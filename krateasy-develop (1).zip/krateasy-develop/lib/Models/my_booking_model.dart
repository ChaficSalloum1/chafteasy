// class MyBookingModel {
//   bool? status;
//   String? message;
//   Data? data;
//   dynamic exeTime;

//   MyBookingModel({this.status, this.message, this.data, this.exeTime});

//   MyBookingModel.fromJson(Map<String, dynamic> json) {
//     status = json['status'];
//     message = json['message'];
//     data = json['data'] != null ? new Data.fromJson(json['data']) : null;
//     exeTime = json['exeTime'];
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['status'] = this.status;
//     data['message'] = this.message;
//     if (this.data != null) {
//       data['data'] = this.data!.toJson();
//     }
//     data['exeTime'] = this.exeTime;
//     return data;
//   }
// }

// class Data {
//   List<Docs>? docs;
//   dynamic totalDocs;
//   dynamic limit;
//   dynamic page;
//   dynamic totalPages;
//   dynamic pagingCounter;
//   bool? hasPrevPage;
//   bool? hasNextPage;
//   dynamic prevPage;
//   dynamic nextPage;

//   Data(
//       {this.docs,
//       this.totalDocs,
//       this.limit,
//       this.page,
//       this.totalPages,
//       this.pagingCounter,
//       this.hasPrevPage,
//       this.hasNextPage,
//       this.prevPage,
//       this.nextPage});

//   Data.fromJson(Map<String, dynamic> json) {
//     if (json['docs'] != null) {
//       docs = <Docs>[];
//       json['docs'].forEach((v) {
//         docs!.add(Docs.fromJson(v));
//       });
//     }
//     totalDocs = json['totalDocs'];
//     limit = json['limit'];
//     page = json['page'];
//     totalPages = json['totalPages'];
//     pagingCounter = json['pagingCounter'];
//     hasPrevPage = json['hasPrevPage'];
//     hasNextPage = json['hasNextPage'];
//     prevPage = json['prevPage'];
//     nextPage = json['nextPage'];
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     if (this.docs != null) {
//       data['docs'] = this.docs!.map((v) => v.toJson()).toList();
//     }
//     data['totalDocs'] = this.totalDocs;
//     data['limit'] = this.limit;
//     data['page'] = this.page;
//     data['totalPages'] = this.totalPages;
//     data['pagingCounter'] = this.pagingCounter;
//     data['hasPrevPage'] = this.hasPrevPage;
//     data['hasNextPage'] = this.hasNextPage;
//     data['prevPage'] = this.prevPage;
//     data['nextPage'] = this.nextPage;
//     return data;
//   }
// }

// class Docs {
//   String? sId;
//   String? bookingId;
//   String? userId;
//   String? courtId;
//   dynamic? slotId;
//   String? slotTime;
//   String? startTime;
//   String? endTime;
//   dynamic duration;
//   dynamic price;
//   bool? isRecorded;
//   String? status;
//   bool? isSplit;
//   String? date;
//   List<dynamic>? friends;
//   String? createdAt;
//   String? updatedAt;
//   dynamic iV;
//   Court? court;
//   Slot? slot;

//   Docs(
//       {this.sId,
//       this.bookingId,
//       this.userId,
//       this.courtId,
//       this.slotId,
//       this.slotTime,
//       this.startTime,
//       this.endTime,
//       this.duration,
//       this.price,
//       this.isRecorded,
//       this.status,
//       this.isSplit,
//       this.date,
//       this.friends,
//       this.createdAt,
//       this.updatedAt,
//       this.iV,
//       this.court,
//       this.slot});

//   Docs.fromJson(Map<String, dynamic> json) {
//     sId = json['_id'];
//     bookingId = json['booking_id'];
//     userId = json['user_id'];
//     courtId = json['court_id'];
//     slotId = json['slot_id'];
//     slotTime = json['slotTime'];
//     startTime = json['startTime'];
//     endTime = json['endTime'];
//     duration = json['duration'];
//     price = json['price'];
//     isRecorded = json['is_recorded'];
//     status = json['status'];
//     isSplit = json['is_split'];
//     date = json['date'];
//     // if (json['friends'] != null) {
//     //   friends = <dynamic>[];
//     //   json['friends'].forEach((v) {
//     //     friends!.add(new dynamic.fromJson(v));
//     //   });
//     // }
//     createdAt = json['created_at'];
//     updatedAt = json['updated_at'];
//     iV = json['__v'];
//     court = json['court'] != null ? new Court.fromJson(json['court']) : null;
//     slot = json['slot'] != null ? new Slot.fromJson(json['slot']) : null;
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['_id'] = this.sId;
//     data['booking_id'] = this.bookingId;
//     data['user_id'] = this.userId;
//     data['court_id'] = this.courtId;
//     data['slot_id'] = this.slotId;
//     data['slotTime'] = this.slotTime;
//     data['startTime'] = this.startTime;
//     data['endTime'] = this.endTime;
//     data['duration'] = this.duration;
//     data['price'] = this.price;
//     data['is_recorded'] = this.isRecorded;
//     data['status'] = this.status;
//     data['is_split'] = this.isSplit;
//     data['date'] = this.date;
//     if (this.friends != null) {
//       data['friends'] = this.friends!.map((v) => v.toJson()).toList();
//     }
//     data['created_at'] = this.createdAt;
//     data['updated_at'] = this.updatedAt;
//     data['__v'] = this.iV;
//     if (this.court != null) {
//       data['court'] = this.court!.toJson();
//     }
//     if (this.slot != null) {
//       data['slot'] = this.slot!.toJson();
//     }
//     return data;
//   }
// }

// class Court {
//   String? sId;
//   String? image;
//   dynamic price;
//   List<dynamic>? gallery;
//   dynamic averageRating;
//   Slots? slots;
//   String? sportId;
//   String? facilityId;
//   String? userId;
//   bool? isActive;
//   bool? isDelete;
//   bool? isFavorite;
//   String? name;
//   String? createdAt;
//   String? updatedAt;
//   dynamic iV;

//   Court(
//       {this.sId,
//       this.image,
//       this.price,
//       this.gallery,
//       this.averageRating,
//       this.slots,
//       this.sportId,
//       this.facilityId,
//       this.userId,
//       this.isActive,
//       this.isDelete,
//       this.isFavorite,
//       this.name,
//       this.createdAt,
//       this.updatedAt,
//       this.iV});

//   Court.fromJson(Map<String, dynamic> json) {
//     sId = json['_id'];
//     image = json['image'];
//     price = json['price'];
//     // if (json['gallery'] != null) {
//     //   gallery = <dynamic>[];
//     //   json['gallery'].forEach((v) {
//     //     gallery!.add(new dynamic.fromJson(v));
//     //   });
//     // }
//     averageRating = json['averageRating'];
//     slots = json['slots'] != null ? new Slots.fromJson(json['slots']) : null;
//     sportId = json['sport_id'];
//     facilityId = json['facility_id'];
//     userId = json['user_id'];
//     isActive = json['is_active'];
//     isDelete = json['is_delete'];
//     isFavorite = json['is_favorite'];
//     name = json['name'];
//     createdAt = json['created_at'];
//     updatedAt = json['updated_at'];
//     iV = json['__v'];
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['_id'] = this.sId;
//     data['image'] = this.image;
//     data['price'] = this.price;
//     if (this.gallery != null) {
//       data['gallery'] = this.gallery!.map((v) => v.toJson()).toList();
//     }
//     data['averageRating'] = this.averageRating;
//     if (this.slots != null) {
//       data['slots'] = this.slots!.toJson();
//     }
//     data['sport_id'] = this.sportId;
//     data['facility_id'] = this.facilityId;
//     data['user_id'] = this.userId;
//     data['is_active'] = this.isActive;
//     data['is_delete'] = this.isDelete;
//     data['is_favorite'] = this.isFavorite;
//     data['name'] = this.name;
//     data['created_at'] = this.createdAt;
//     data['updated_at'] = this.updatedAt;
//     data['__v'] = this.iV;
//     return data;
//   }
// }

// class Slots {
//   List<Friday>? friday;

//   Slots({this.friday});

//   Slots.fromJson(Map<String, dynamic> json) {
//     if (json['Friday'] != null) {
//       friday = <Friday>[];
//       json['Friday'].forEach((v) {
//         friday!.add(new Friday.fromJson(v));
//       });
//     }
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     if (this.friday != null) {
//       data['Friday'] = this.friday!.map((v) => v.toJson()).toList();
//     }
//     return data;
//   }
// }

// class Friday {
//   String? startTime;
//   String? endTime;
//   String? price;

//   Friday({this.startTime, this.endTime, this.price});

//   Friday.fromJson(Map<String, dynamic> json) {
//     startTime = json['start_time'];
//     endTime = json['end_time'];
//     price = json['price'];
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['start_time'] = this.startTime;
//     data['end_time'] = this.endTime;
//     data['price'] = this.price;
//     return data;
//   }
// }

// class Slot {
//   String? sId;
//   String? startTime;
//   String? endTime;
//   String? day;
//   dynamic price;
//   String? courtId;
//   bool? isActive;
//   bool? isDelete;
//   dynamic iV;
//   String? createdAt;
//   String? updatedAt;

//   Slot(
//       {this.sId,
//       this.startTime,
//       this.endTime,
//       this.day,
//       this.price,
//       this.courtId,
//       this.isActive,
//       this.isDelete,
//       this.iV,
//       this.createdAt,
//       this.updatedAt});

//   Slot.fromJson(Map<String, dynamic> json) {
//     sId = json['_id'];
//     startTime = json['startTime'];
//     endTime = json['endTime'];
//     day = json['day'];
//     price = json['price'];
//     courtId = json['court_id'];
//     isActive = json['is_active'];
//     isDelete = json['is_delete'];
//     iV = json['__v'];
//     createdAt = json['created_at'];
//     updatedAt = json['updated_at'];
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['_id'] = this.sId;
//     data['startTime'] = this.startTime;
//     data['endTime'] = this.endTime;
//     data['day'] = this.day;
//     data['price'] = this.price;
//     data['court_id'] = this.courtId;
//     data['is_active'] = this.isActive;
//     data['is_delete'] = this.isDelete;
//     data['__v'] = this.iV;
//     data['created_at'] = this.createdAt;
//     data['updated_at'] = this.updatedAt;
//     return data;
//   }
// }
class MyBookingModel {
  bool? status;
  String? message;
  Data? data;
  dynamic exeTime;

  MyBookingModel({this.status, this.message, this.data, this.exeTime});

  MyBookingModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
    exeTime = json['exeTime'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['status'] = status;
    data['message'] = message;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    data['exeTime'] = exeTime;
    return data;
  }
}

class Data {
  List<Docs>? docs;
  dynamic totalDocs;
  dynamic limit;
  dynamic page;
  dynamic totalPages;
  dynamic pagingCounter;
  bool? hasPrevPage;
  bool? hasNextPage;
  dynamic prevPage;
  dynamic nextPage;

  Data({
    this.docs,
    this.totalDocs,
    this.limit,
    this.page,
    this.totalPages,
    this.pagingCounter,
    this.hasPrevPage,
    this.hasNextPage,
    this.prevPage,
    this.nextPage,
  });

  Data.fromJson(Map<String, dynamic> json) {
    if (json['docs'] != null) {
      docs = <Docs>[];
      json['docs'].forEach((v) {
        docs!.add(Docs.fromJson(v));
      });
    }
    totalDocs = json['totalDocs'];
    limit = json['limit'];
    page = json['page'];
    totalPages = json['totalPages'];
    pagingCounter = json['pagingCounter'];
    hasPrevPage = json['hasPrevPage'];
    hasNextPage = json['hasNextPage'];
    prevPage = json['prevPage'];
    nextPage = json['nextPage'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (docs != null) {
      data['docs'] = docs!.map((v) => v.toJson()).toList();
    }
    data['totalDocs'] = totalDocs;
    data['limit'] = limit;
    data['page'] = page;
    data['totalPages'] = totalPages;
    data['pagingCounter'] = pagingCounter;
    data['hasPrevPage'] = hasPrevPage;
    data['hasNextPage'] = hasNextPage;
    data['prevPage'] = prevPage;
    data['nextPage'] = nextPage;
    return data;
  }
}

class Docs {
  String? sId;
  String? bookingId;
  String? userId;
  String? courtId;
  dynamic slotId;
  String? slotTime;
  String? startTime;
  String? endTime;
  dynamic duration;
  dynamic price;
  bool? isRecorded;
  String? status;
  bool? isSplit;
  String? date;
  List<dynamic>? friends;
  String? createdAt;
  String? updatedAt;
  dynamic iV;
  Court? court;
  List<Slot>? slot;
  String? challengeId;
  String? facilityId;
  String? facilityOwnerId;
  dynamic adminCommission;
  dynamic facilityOwnerAmount;
  String? type;
  String? paymentStatus;
  Facility? facility;
  Sport? sport;

  Docs({
    this.sId,
    this.bookingId,
    this.userId,
    this.courtId,
    this.slotId,
    this.slotTime,
    this.startTime,
    this.endTime,
    this.duration,
    this.price,
    this.isRecorded,
    this.status,
    this.isSplit,
    this.date,
    this.friends,
    this.createdAt,
    this.updatedAt,
    this.iV,
    this.court,
    this.slot,
    this.challengeId,
    this.facilityId,
    this.facilityOwnerId,
    this.adminCommission,
    this.facilityOwnerAmount,
    this.type,
    this.paymentStatus,
    this.facility,
    this.sport,
  });

  Docs.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    bookingId = json['booking_id'];
    userId = json['user_id'];
    courtId = json['court_id'];
    slotId = json['slot_id'];
    slotTime = json['slotTime'];
    startTime = json['startTime'];
    endTime = json['endTime'];
    duration = json['duration'];
    price = json['price'];
    isRecorded = json['is_recorded'];
    status = json['status'];
    isSplit = json['is_split'];
    date = json['date'];
    friends = json['friends']?.cast<dynamic>();
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    iV = json['__v'];
    court = json['court'] != null ? Court.fromJson(json['court']) : null;
    slot = json['slot'] != null
        ? List<Slot>.from(json['slot'].map((x) => Slot.fromJson(x)))
        : null;
    challengeId = json['challenge_id'];
    facilityId = json['facility_id'];
    facilityOwnerId = json['facility_owner_id'];
    adminCommission = json['admin_commission'];
    facilityOwnerAmount = json['facility_owner_amount'];
    type = json['type'];
    paymentStatus = json['payment_status'];
    facility =
        json['facility'] != null ? Facility.fromJson(json['facility']) : null;
    sport = json['sport'] != null ? Sport.fromJson(json['sport']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['_id'] = sId;
    data['booking_id'] = bookingId;
    data['user_id'] = userId;
    data['court_id'] = courtId;
    data['slot_id'] = slotId;
    data['slotTime'] = slotTime;
    data['startTime'] = startTime;
    data['endTime'] = endTime;
    data['duration'] = duration;
    data['price'] = price;
    data['is_recorded'] = isRecorded;
    data['status'] = status;
    data['is_split'] = isSplit;
    data['date'] = date;
    data['friends'] = friends;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    data['__v'] = iV;
    if (court != null) {
      data['court'] = court!.toJson();
    }
    if (slot != null) {
      data['slot'] =
          slot!.map((s) => s.toJson()).toList();
    }

    data['challenge_id'] = challengeId;
    data['facility_id'] = facilityId;
    data['facility_owner_id'] = facilityOwnerId;
    data['admin_commission'] = adminCommission;
    data['facility_owner_amount'] = facilityOwnerAmount;
    data['type'] = type;
    data['payment_status'] = paymentStatus;
    if (facility != null) {
      data['facility'] = facility!.toJson();
    }
    if (sport != null) {
      data['sport'] = sport!.toJson();
    }
    return data;
  }
}

class Court {
  String? sId;
  String? image;
  dynamic price;
  List<dynamic>? gallery;
  dynamic averageRating;
  Slots? slots;
  String? sportId;
  String? facilityId;
  String? userId;
  bool? isActive;
  bool? isDelete;
  bool? isFavorite;
  String? name;
  String? createdAt;
  String? updatedAt;
  dynamic iV;
  String? facilityOwnerId;

  Court({
    this.sId,
    this.image,
    this.price,
    this.gallery,
    this.averageRating,
    this.slots,
    this.sportId,
    this.facilityId,
    this.userId,
    this.isActive,
    this.isDelete,
    this.isFavorite,
    this.name,
    this.createdAt,
    this.updatedAt,
    this.iV,
    this.facilityOwnerId,
  });

  Court.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    image = json['image'];
    price = json['price'];
    gallery = json['gallery']?.cast<dynamic>();
    averageRating = json['averageRating'];
    slots = json['slots'] != null ? Slots.fromJson(json['slots']) : null;
    sportId = json['sport_id'];
    facilityId = json['facility_id'];
    userId = json['user_id'];
    isActive = json['is_active'];
    isDelete = json['is_delete'];
    isFavorite = json['is_favorite'];
    name = json['name'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    iV = json['__v'];
    facilityOwnerId = json['facility_owner_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['_id'] = sId;
    data['image'] = image;
    data['price'] = price;
    data['gallery'] = gallery;
    data['averageRating'] = averageRating;
    if (slots != null) {
      data['slots'] = slots!.toJson();
    }
    data['sport_id'] = sportId;
    data['facility_id'] = facilityId;
    data['user_id'] = userId;
    data['is_active'] = isActive;
    data['is_delete'] = isDelete;
    data['is_favorite'] = isFavorite;
    data['name'] = name;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    data['__v'] = iV;
    data['facility_owner_id'] = facilityOwnerId;
    return data;
  }
}

class Slots {
  List<DaySlot>? monday;
  List<DaySlot>? tuesday;
  List<DaySlot>? wednesday;
  List<DaySlot>? thursday;
  List<DaySlot>? friday;
  List<DaySlot>? saturday;
  List<DaySlot>? sunday;

  Slots({
    this.monday,
    this.tuesday,
    this.wednesday,
    this.thursday,
    this.friday,
    this.saturday,
    this.sunday,
  });

  Slots.fromJson(Map<String, dynamic> json) {
    if (json['Monday'] != null) {
      monday = <DaySlot>[];
      json['Monday'].forEach((v) {
        monday!.add(DaySlot.fromJson(v));
      });
    }
    if (json['Tuesday'] != null) {
      tuesday = <DaySlot>[];
      json['Tuesday'].forEach((v) {
        tuesday!.add(DaySlot.fromJson(v));
      });
    }
    if (json['Wednesday'] != null) {
      wednesday = <DaySlot>[];
      json['Wednesday'].forEach((v) {
        wednesday!.add(DaySlot.fromJson(v));
      });
    }
    if (json['Thursday'] != null) {
      thursday = <DaySlot>[];
      json['Thursday'].forEach((v) {
        thursday!.add(DaySlot.fromJson(v));
      });
    }
    if (json['Friday'] != null) {
      friday = <DaySlot>[];
      json['Friday'].forEach((v) {
        friday!.add(DaySlot.fromJson(v));
      });
    }
    if (json['Saturday'] != null) {
      saturday = <DaySlot>[];
      json['Saturday'].forEach((v) {
        saturday!.add(DaySlot.fromJson(v));
      });
    }
    if (json['Sunday'] != null) {
      sunday = <DaySlot>[];
      json['Sunday'].forEach((v) {
        sunday!.add(DaySlot.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (monday != null) {
      data['Monday'] = monday!.map((v) => v.toJson()).toList();
    }
    if (tuesday != null) {
      data['Tuesday'] = tuesday!.map((v) => v.toJson()).toList();
    }
    if (wednesday != null) {
      data['Wednesday'] = wednesday!.map((v) => v.toJson()).toList();
    }
    if (thursday != null) {
      data['Thursday'] = thursday!.map((v) => v.toJson()).toList();
    }
    if (friday != null) {
      data['Friday'] = friday!.map((v) => v.toJson()).toList();
    }
    if (saturday != null) {
      data['Saturday'] = saturday!.map((v) => v.toJson()).toList();
    }
    if (sunday != null) {
      data['Sunday'] = sunday!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class DaySlot {
  String? startTime;
  String? endTime;
  String? price;

  DaySlot({this.startTime, this.endTime, this.price});

  DaySlot.fromJson(Map<String, dynamic> json) {
    startTime = json['start_time'];
    endTime = json['end_time'];
    price = json['price'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['start_time'] = startTime;
    data['end_time'] = endTime;
    data['price'] = price;
    return data;
  }
}

class Slot {
  String? sId;
  String? startTime;
  String? endTime;
  String? day;
  dynamic price;
  String? courtId;
  bool? isActive;
  bool? isDelete;
  dynamic iV;
  String? createdAt;
  String? updatedAt;

  Slot({
    this.sId,
    this.startTime,
    this.endTime,
    this.day,
    this.price,
    this.courtId,
    this.isActive,
    this.isDelete,
    this.iV,
    this.createdAt,
    this.updatedAt,
  });

  Slot.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    startTime = json['startTime'];
    endTime = json['endTime'];
    day = json['day'];
    price = json['price'];
    courtId = json['court_id'];
    isActive = json['is_active'];
    isDelete = json['is_delete'];
    iV = json['__v'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['_id'] = sId;
    data['startTime'] = startTime;
    data['endTime'] = endTime;
    data['day'] = day;
    data['price'] = price;
    data['court_id'] = courtId;
    data['is_active'] = isActive;
    data['is_delete'] = isDelete;
    data['__v'] = iV;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    return data;
  }
}

class Facility {
  String? sId;
  String? name;
  String? image;
  String? description;
  String? bio;
  List<dynamic>? gallery;
  String? subscriptionStatus;
  dynamic latitude;
  dynamic longitude;
  String? address;
  List<dynamic>? amenities;
  String? facilityOwner;
  bool? isActive;
  bool? isDelete;
  Location? location;
  List<dynamic>? team;
  String? createdAt;
  String? updatedAt;
  dynamic iV;

  Facility({
    this.sId,
    this.name,
    this.image,
    this.description,
    this.bio,
    this.gallery,
    this.subscriptionStatus,
    this.latitude,
    this.longitude,
    this.address,
    this.amenities,
    this.facilityOwner,
    this.isActive,
    this.isDelete,
    this.location,
    this.team,
    this.createdAt,
    this.updatedAt,
    this.iV,
  });

  Facility.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    name = json['name'];
    image = json['image'];
    description = json['description'];
    bio = json['bio'];
    gallery = json['gallery']?.cast<dynamic>();
    subscriptionStatus = json['subscription_status'];
    latitude = json['latitude'];
    longitude = json['longitude'];
    address = json['address'];
    amenities = json['amenities']?.cast<dynamic>();
    facilityOwner = json['facility_owner'];
    isActive = json['is_active'];
    isDelete = json['is_delete'];
    location =
        json['location'] != null ? Location.fromJson(json['location']) : null;
    team = json['team']?.cast<dynamic>();
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    iV = json['__v'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['_id'] = sId;
    data['name'] = name;
    data['image'] = image;
    data['description'] = description;
    data['bio'] = bio;
    data['gallery'] = gallery;
    data['subscription_status'] = subscriptionStatus;
    data['latitude'] = latitude;
    data['longitude'] = longitude;
    data['address'] = address;
    data['amenities'] = amenities;
    data['facility_owner'] = facilityOwner;
    data['is_active'] = isActive;
    data['is_delete'] = isDelete;
    if (location != null) {
      data['location'] = location!.toJson();
    }
    data['team'] = team;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    data['__v'] = iV;
    return data;
  }
}

class Location {
  String? type;
  List<double>? coordinates;

  Location({this.type, this.coordinates});

  Location.fromJson(Map<String, dynamic> json) {
    type = json['type'];
    coordinates = json['coordinates']?.cast<double>();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['type'] = type;
    data['coordinates'] = coordinates;
    return data;
  }
}

class Sport {
  String? sId;
  String? name;
  String? image;
  List<String>? skillLevel;
  String? matchType;
  bool? isActive;
  bool? isDelete;
  String? createdAt;
  String? updatedAt;
  dynamic iV;

  Sport({
    this.sId,
    this.name,
    this.image,
    this.skillLevel,
    this.matchType,
    this.isActive,
    this.isDelete,
    this.createdAt,
    this.updatedAt,
    this.iV,
  });

  Sport.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    name = json['name'];
    image = json['image'];
    skillLevel = json['skill_level']?.cast<String>();
    matchType = json['match_type'];
    isActive = json['is_active'];
    isDelete = json['is_delete'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    iV = json['__v'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['_id'] = sId;
    data['name'] = name;
    data['image'] = image;
    data['skill_level'] = skillLevel;
    data['match_type'] = matchType;
    data['is_active'] = isActive;
    data['is_delete'] = isDelete;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    data['__v'] = iV;
    return data;
  }
}
