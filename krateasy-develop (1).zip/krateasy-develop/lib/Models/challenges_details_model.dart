import 'dart:convert';

ChallengesDetailsModel challengesDetailsModelFromJson(String str) =>
    ChallengesDetailsModel.fromJson(json.decode(str));

String challengesDetailsModelToJson(ChallengesDetailsModel data) =>
    json.encode(data.toJson());

class ChallengesDetailsModel {
  bool? status;
  String? message;
  Data? data;
  int? exeTime;

  ChallengesDetailsModel({
    this.status,
    this.message,
    this.data,
    this.exeTime,
  });

  factory ChallengesDetailsModel.fromJson(Map<String, dynamic> json) =>
      ChallengesDetailsModel(
        status: json["status"],
        message: json["message"],
        data: json["data"] == null ? null : Data.fromJson(json["data"]),
        exeTime: json["exeTime"],
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "message": message,
        "data": data?.toJson(),
        "exeTime": exeTime,
      };
}

class Data {
  String? id;
  String? skillLevel;
  int? maxPlayer;
  List<WhoJoined>? whoJoined;
  DateTime? date;
  List<Friend>? friends;
  CreatedBy? createdBy;
  Slots? slots;
  int? guestPayAmount;

  Data({
    this.id,
    this.skillLevel,
    this.maxPlayer,
    this.whoJoined,
    this.date,
    this.friends,
    this.createdBy,
    this.slots,
    this.guestPayAmount,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        id: json["_id"],
        skillLevel: json["skill_level"],
        maxPlayer: json["max_player"],
        whoJoined: json["who_joined"] == null
            ? []
            : List<WhoJoined>.from(
                json["who_joined"]!.map((x) => WhoJoined.fromJson(x))),
        date: json["date"] == null ? null : DateTime.parse(json["date"]),
        friends: json["friends"] == null
            ? []
            : List<Friend>.from(
                json["friends"]!.map((x) => Friend.fromJson(x))),
        createdBy: json["created_by"] == null
            ? null
            : CreatedBy.fromJson(json["created_by"]),
        slots: json["slots"] == null ? null : Slots.fromJson(json["slots"]),
        guestPayAmount: json["guestPayAmount"],
      );

  Map<String, dynamic> toJson() => {
        "_id": id,
        "skill_level": skillLevel,
        "max_player": maxPlayer,
        "who_joined": whoJoined == null
            ? []
            : List<dynamic>.from(whoJoined!.map((x) => x.toJson())),
        "date": date?.toIso8601String(),
        "friends": friends == null
            ? []
            : List<dynamic>.from(friends!.map((x) => x.toJson())),
        "created_by": createdBy?.toJson(),
        "slots": slots?.toJson(),
      };
}

class CreatedBy {
  String? id;
  Preferences? preferences;
  String? userType;
  String? password;
  dynamic uniqueId;
  dynamic dob;
  String? gender;
  dynamic address;
  dynamic cityId;
  bool? isActive;
  bool? isDelete;
  dynamic otp;
  bool? isApprove;
  String? loginType;
  String? deviceType;
  String? name;
  dynamic image;
  dynamic country;
  dynamic voipToken;
  int? latitude;
  int? longitude;
  dynamic deviceToken;
  dynamic socialId;
  bool? isVerify;
  bool? isNotificationOn;
  String? mobileNumber;
  String? countryCode;
  List<dynamic>? sports;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;

  CreatedBy({
    this.id,
    this.preferences,
    this.userType,
    this.password,
    this.uniqueId,
    this.dob,
    this.gender,
    this.address,
    this.cityId,
    this.isActive,
    this.isDelete,
    this.otp,
    this.isApprove,
    this.loginType,
    this.deviceType,
    this.name,
    this.image,
    this.country,
    this.voipToken,
    this.latitude,
    this.longitude,
    this.deviceToken,
    this.socialId,
    this.isVerify,
    this.isNotificationOn,
    this.mobileNumber,
    this.countryCode,
    this.sports,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  factory CreatedBy.fromJson(Map<String, dynamic> json) => CreatedBy(
        id: json["_id"],
        preferences: json["preferences"] == null
            ? null
            : Preferences.fromJson(json["preferences"]),
        userType: json["user_type"],
        password: json["password"],
        uniqueId: json["uniqueId"],
        dob: json["dob"],
        gender: json["gender"],
        address: json["address"],
        cityId: json["city_id"],
        isActive: json["is_active"],
        isDelete: json["is_delete"],
        otp: json["otp"],
        isApprove: json["isApprove"],
        loginType: json["loginType"],
        deviceType: json["deviceType"],
        name: json["name"],
        image: json["image"],
        country: json["country"],
        voipToken: json["voipToken"],
        latitude: json["latitude"],
        longitude: json["longitude"],
        deviceToken: json["deviceToken"],
        socialId: json["socialId"],
        isVerify: json["isVerify"],
        isNotificationOn: json["is_notification_on"],
        mobileNumber: json["mobile_number"],
        countryCode: json["country_code"],
        sports: json["sports"] == null
            ? []
            : List<dynamic>.from(json["sports"]!.map((x) => x)),
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        v: json["__v"],
      );

  Map<String, dynamic> toJson() => {
        "_id": id,
        "preferences": preferences?.toJson(),
        "user_type": userType,
        "password": password,
        "uniqueId": uniqueId,
        "dob": dob,
        "gender": gender,
        "address": address,
        "city_id": cityId,
        "is_active": isActive,
        "is_delete": isDelete,
        "otp": otp,
        "isApprove": isApprove,
        "loginType": loginType,
        "deviceType": deviceType,
        "name": name,
        "image": image,
        "country": country,
        "voipToken": voipToken,
        "latitude": latitude,
        "longitude": longitude,
        "deviceToken": deviceToken,
        "socialId": socialId,
        "isVerify": isVerify,
        "is_notification_on": isNotificationOn,
        "mobile_number": mobileNumber,
        "country_code": countryCode,
        "sports":
            sports == null ? [] : List<dynamic>.from(sports!.map((x) => x)),
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "__v": v,
      };
}

class Preferences {
  List<dynamic>? sportIds;
  int? latitude;
  int? longitude;
  int? radius;
  List<dynamic>? timeSlots;
  List<dynamic>? skillLevels;
  DateTime? updatedAt;

  Preferences({
    this.sportIds,
    this.latitude,
    this.longitude,
    this.radius,
    this.timeSlots,
    this.skillLevels,
    this.updatedAt,
  });

  factory Preferences.fromJson(Map<String, dynamic> json) => Preferences(
        sportIds: json["sportIds"] == null
            ? []
            : List<dynamic>.from(json["sportIds"]!.map((x) => x)),
        latitude: json["latitude"],
        longitude: json["longitude"],
        radius: json["radius"],
        timeSlots: json["timeSlots"] == null
            ? []
            : List<dynamic>.from(json["timeSlots"]!.map((x) => x)),
        skillLevels: json["skillLevels"] == null
            ? []
            : List<dynamic>.from(json["skillLevels"]!.map((x) => x)),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toJson() => {
        "sportIds":
            sportIds == null ? [] : List<dynamic>.from(sportIds!.map((x) => x)),
        "latitude": latitude,
        "longitude": longitude,
        "radius": radius,
        "timeSlots": timeSlots == null
            ? []
            : List<dynamic>.from(timeSlots!.map((x) => x)),
        "skillLevels": skillLevels == null
            ? []
            : List<dynamic>.from(skillLevels!.map((x) => x)),
        "updated_at": updatedAt?.toIso8601String(),
      };
}

class Friend {
  String? name;
  String? mobileNumber;
  String? countryCode;
  double? splitAmount;
  bool? isPaid;
  bool? isReviewed;
  bool? isFriendFavorite;
  String? id;

  Friend({
    this.name,
    this.mobileNumber,
    this.countryCode,
    this.splitAmount,
    this.isPaid,
    this.isReviewed,
    this.isFriendFavorite,
    this.id,
  });

  factory Friend.fromJson(Map<String, dynamic> json) => Friend(
        name: json["name"],
        mobileNumber: json["mobile_number"],
        countryCode: json["country_code"],
        splitAmount: json["split_amount"]?.toDouble(),
        isPaid: json["is_paid"],
        isReviewed: json["isReviewed"],
        isFriendFavorite: json["is_friend_favorite"],
        id: json["_id"],
      );

  Map<String, dynamic> toJson() => {
        "name": name,
        "mobile_number": mobileNumber,
        "country_code": countryCode,
        "split_amount": splitAmount,
        "is_paid": isPaid,
        "isReviewed": isReviewed,
        "is_friend_favorite": isFriendFavorite,
        "_id": id,
      };
}

class Slots {
  String? startTime;
  String? endTime;
  String? day;
  Court? court;
  double? price;

  Slots({
    this.startTime,
    this.endTime,
    this.day,
    this.court,
    this.price,
  });

  factory Slots.fromJson(Map<String, dynamic> json) => Slots(
        startTime: json["startTime"],
        endTime: json["endTime"],
        day: json["day"],
        court: json["court"] == null ? null : Court.fromJson(json["court"]),
        price: json["price"]?.toDouble(),
      );

  Map<String, dynamic> toJson() => {
        "startTime": startTime,
        "endTime": endTime,
        "day": day,
        "court": court?.toJson(),
        "price": price,
      };
}

class Court {
  String? id;
  String? image;
  dynamic? averageRating;
  String? name;
  Sport? sport;
  Facility? facility;
  int? totalBookingCount;

  Court({
    this.id,
    this.image,
    this.averageRating,
    this.name,
    this.sport,
    this.facility,
    this.totalBookingCount,
  });

  factory Court.fromJson(Map<String, dynamic> json) => Court(
        id: json["_id"],
        image: json["image"],
        averageRating: json["averageRating"],
        name: json["name"],
        sport: json["sport"] == null ? null : Sport.fromJson(json["sport"]),
        facility: json["facility"] == null
            ? null
            : Facility.fromJson(json["facility"]),
        totalBookingCount: json["totalBookingCount"],
      );

  Map<String, dynamic> toJson() => {
        "_id": id,
        "image": image,
        "averageRating": averageRating,
        "name": name,
        "sport": sport?.toJson(),
        "facility": facility?.toJson(),
        "totalBookingCount": totalBookingCount,
      };
}

class Facility {
  String? name;
  dynamic image;
  String? description;
  dynamic bio;
  List<String>? gallery;
  double? latitude;
  double? longitude;
  String? address;
  List<Amenity>? amenities;

  Facility({
    this.name,
    this.image,
    this.description,
    this.bio,
    this.gallery,
    this.latitude,
    this.longitude,
    this.address,
    this.amenities,
  });

  factory Facility.fromJson(Map<String, dynamic> json) => Facility(
        name: json["name"],
        image: json["image"],
        description: json["description"],
        bio: json["bio"],
        gallery: json["gallery"] == null
            ? []
            : List<String>.from(json["gallery"]!.map((x) => x)),
        latitude: json["latitude"]?.toDouble(),
        longitude: json["longitude"]?.toDouble(),
        address: json["address"],
        amenities: json["amenities"] == null
            ? []
            : List<Amenity>.from(
                json["amenities"]!.map((x) => Amenity.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "name": name,
        "image": image,
        "description": description,
        "bio": bio,
        "gallery":
            gallery == null ? [] : List<dynamic>.from(gallery!.map((x) => x)),
        "latitude": latitude,
        "longitude": longitude,
        "address": address,
        "amenities": amenities == null
            ? []
            : List<dynamic>.from(amenities!.map((x) => x.toJson())),
      };
}

class Amenity {
  String? id;
  bool? isActive;
  bool? isDelete;
  String? name;
  String? image;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;

  Amenity({
    this.id,
    this.isActive,
    this.isDelete,
    this.name,
    this.image,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  factory Amenity.fromJson(Map<String, dynamic> json) => Amenity(
        id: json["_id"],
        isActive: json["is_active"],
        isDelete: json["is_delete"],
        name: json["name"],
        image: json["image"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        v: json["__v"],
      );

  Map<String, dynamic> toJson() => {
        "_id": id,
        "is_active": isActive,
        "is_delete": isDelete,
        "name": name,
        "image": image,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "__v": v,
      };
}

class Sport {
  String? name;
  String? image;

  Sport({
    this.name,
    this.image,
  });

  factory Sport.fromJson(Map<String, dynamic> json) => Sport(
        name: json["name"],
        image: json["image"],
      );

  Map<String, dynamic> toJson() => {
        "name": name,
        "image": image,
      };
}

class WhoJoined {
  String? id;
  dynamic image;

  WhoJoined({
    this.id,
    this.image,
  });

  factory WhoJoined.fromJson(Map<String, dynamic> json) => WhoJoined(
        id: json["_id"],
        image: json["image"],
      );

  Map<String, dynamic> toJson() => {
        "_id": id,
        "image": image,
      };
}
