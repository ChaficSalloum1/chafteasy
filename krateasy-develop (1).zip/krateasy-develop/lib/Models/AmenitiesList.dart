class AmenitiesList {
  final String name;
  final String id;

  AmenitiesList({required this.id, required this.name});

  factory AmenitiesList.fromJson(Map<String, dynamic> json) {
    return AmenitiesList(id: json['_id'], name: json['name']);
  }
}
