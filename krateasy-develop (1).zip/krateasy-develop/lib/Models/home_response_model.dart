
class HomeDataResponse {
  bool? status;
  String? message;
  HomeData? data;
  dynamic exeTime;

  HomeDataResponse({
    this.status,
    this.message,
    this.data,
    this.exeTime,
  });

  HomeDataResponse.fromJson(Map<String, dynamic> json) {
    status = json['status'] as bool?;
    message = json['message'] as String?;
    data = json['data'] != null
        ? HomeData.fromJson(json['data'] as Map<String, dynamic>)
        : null;
    exeTime = json['exeTime'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {};
    data['status'] = status;
    data['message'] = message;
    data['data'] = this.data?.toJson();
    data['exeTime'] = exeTime;
    return data;
  }
}

class HomeData {
  List<Banner>? banners;
  List<Booking>? upcomingBookings;
  List<Booking>? completedBookings;

  HomeData({
    this.banners,
    this.upcomingBookings,
    this.completedBookings,
  });

  HomeData.fromJson(Map<String, dynamic> json) {
    banners = (json['banners'] as List<dynamic>?)
        ?.map((e) => Banner.fromJson(e as Map<String, dynamic>))
        .toList();
    upcomingBookings = (json['upcomingBookings'] as List<dynamic>?)
        ?.map((e) => Booking.fromJson(e as Map<String, dynamic>))
        .toList();
    completedBookings = (json['completedBookings'] as List<dynamic>?)
        ?.map((e) => Booking.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {};
    data['banners'] = banners?.map((e) => e.toJson()).toList();
    data['upcomingBookings'] =
        upcomingBookings?.map((e) => e.toJson()).toList();
    data['completedBookings'] =
        completedBookings?.map((e) => e.toJson()).toList();
    return data;
  }
}

class Banner {
  int? order;
  bool? isActive;
  bool? isDeleted;
  String? id;
  String? title;
  String? image;
  String? link;
  String? createdAt;
  String? updatedAt;
  dynamic v;

  Banner({
    this.order,
    this.isActive,
    this.isDeleted,
    this.id,
    this.title,
    this.image,
    this.link,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  Banner.fromJson(Map<String, dynamic> json) {
    order = json['order'] as int?;
    isActive = json['is_active'] as bool?;
    isDeleted = json['is_deleted'] as bool?;
    id = json['_id'] as String?;
    title = json['title'] as String?;
    image = json['image'] as String?;
    link = json['link'] as String?;
    createdAt = json['created_at'] as String?;
    updatedAt = json['updated_at'] as String?;
    v = json['__v'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {};
    data['order'] = order;
    data['is_active'] = isActive;
    data['is_deleted'] = isDeleted;
    data['_id'] = id;
    data['title'] = title;
    data['image'] = image;
    data['link'] = link;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    data['__v'] = v;
    return data;
  }
}

class Booking {
  String? id;
  String? bookingId;
  String? privatecode;
  String? challengeId;
  String? startTime;
  String? endTime;
  dynamic price;
  String? status;
  bool? isSplit;
  String? date;
  String? courtName;
  String? courtId;
  dynamic rating;
  String? courtImage;
  String? facilityName;
  String? facilityAddress;
  String? sportName;
  String? sportsIcon;
  String? slotStart;
  String? slotEnd;
  String? slotDay;
  dynamic slotPrice;
  String? distance;
  String ?type;
  String ? challengeType;

  Booking(
      {this.id,
      this.challengeId,
      this.bookingId,
      this.privatecode,
      this.startTime,
      this.endTime,
      this.price,
      this.status,
      this.isSplit,
      this.date,
      this.courtName,
      this.courtId,
      this.rating,
      this.courtImage,
      this.facilityName,
      this.facilityAddress,
      this.sportName,
      this.sportsIcon,
      this.slotStart,
      this.slotEnd,
      this.slotDay,
      this.slotPrice,
      this.type,
      this.challengeType,
      this.distance});

  Booking.fromJson(Map<String, dynamic> json) {
    id = json['_id'] as String?;
    bookingId = json['booking_id'] as String?;
    privatecode = json['private_code'] as String?;
    startTime = json['startTime'] as String?;
    endTime = json['endTime'] as String?;
    price = json['price'];
    challengeId=json["challenge_id"];
    status = json['status'] as String?;
    isSplit = json['is_split'] as bool?;
    date = json['date'] as String?;
    courtName = json['court_name'] as String?;
    courtId = json['court_id'] as String?;
    rating = json['rating'] ?? "";
    courtImage = json['court_image'] as String?;
    facilityName = json['facility_name'] as String?;
    facilityAddress = json['facility_address'] as String?;
    sportName = json['sport_name'] as String?;
    sportsIcon = json['sports_Icon'] as String?;
    slotStart = json['slot_start'] as String?;
    slotEnd = json['slot_end'] as String?;
    slotDay = json['slot_day'] as String?;
    slotPrice = json['slot_price'];
    distance = json["distance"];
    // distance = json["challenge_type"]??"";
    type = json['type'] as String;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {};
    data['_id'] = id;
    data['booking_id'] = bookingId;
    data['private_code'] = privatecode;
    data['startTime'] = startTime;
    data['challenge_id']=challengeId;
    data['endTime'] = endTime;
    data['price'] = price;
    data['status'] = status;
    data['is_split'] = isSplit;
    data['date'] = date;
    data['court_name'] = courtName;
    data['court_id'] = courtId;
    data['rating'] = rating;
    data['court_image'] = courtImage;
    data['facility_name'] = facilityName;
    data['facility_address'] = facilityAddress;
    data['sport_name'] = sportName;
    data['sports_Icon'] = sportsIcon;
    data['slot_start'] = slotStart;
    data['slot_end'] = slotEnd;
    data['slot_day'] = slotDay;
    data['slot_price'] = slotPrice;
    data["distance"] = distance;
    data['type']=type;
    data["challenge_type"]=challengeType;
    return data;
  }
}
