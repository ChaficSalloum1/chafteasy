//
// class AvailablePublicChallengesModel {
//   String? id;
//   String? date;
//   String? skillLevel;
//   dynamic maxPlayer;
//   List<dynamic>? whoJoined;
//   Slots? slots;
//
//   AvailablePublicChallengesModel({this.id, this.date, this.skillLevel, this.maxPlayer, this.whoJoined, this.slots});
//
//   AvailablePublicChallengesModel.fromJson(Map<String, dynamic> json) {
//     id = json["_id"];
//     date = json["date"];
//     skillLevel = json["skill_level"];
//     maxPlayer = json["max_player"];
//     whoJoined = json["who_joined"] ?? [];
//     slots = json["slot"] == null ? null : Slots.fromJson(json["slot"]);
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> _data = <String, dynamic>{};
//     _data["_id"] = id;
//     _data["date"] = date;
//     _data["skill_level"] = skillLevel;
//     _data["max_player"] = maxPlayer;
//     if(whoJoined != null) {
//       _data["who_joined"] = whoJoined;
//     }
//     if(slots != null) {
//       _data["slot"] = slots?.toJson();
//     }
//     return _data;
//   }
// }
//
// class Slots {
//   String? startTime;
//   String? endTime;
//   String? day;
//   dynamic price;
//   Court? court;
//
//   Slots({this.startTime, this.endTime, this.day, this.price, this.court});
//
//   Slots.fromJson(Map<String, dynamic> json) {
//     startTime = json["startTime"];
//     endTime = json["endTime"];
//     day = json["day"];
//     price = json["price"];
//     court = json["court"] == null ? null : Court.fromJson(json["court"]);
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> _data = <String, dynamic>{};
//     _data["startTime"] = startTime;
//     _data["endTime"] = endTime;
//     _data["day"] = day;
//     _data["price"] = price;
//     if(court != null) {
//       _data["court"] = court?.toJson();
//     }
//     return _data;
//   }
// }
//
// class Court {
//   String? image;
//   String? name;
//   Sport? sport;
//   Facility? facility;
//
//   Court({this.image, this.name, this.sport, this.facility});
//
//   Court.fromJson(Map<String, dynamic> json) {
//     image = json["image"];
//     name = json["name"];
//     sport = json["sport"] == null ? null : Sport.fromJson(json["sport"]);
//     facility = json["facility"] == null ? null : Facility.fromJson(json["facility"]);
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> _data = <String, dynamic>{};
//     _data["image"] = image;
//     _data["name"] = name;
//     if(sport != null) {
//       _data["sport"] = sport?.toJson();
//     }
//     if(facility != null) {
//       _data["facility"] = facility?.toJson();
//     }
//     return _data;
//   }
// }
//
// class Facility {
//   String? address;
//   double?  latitude;
//   double?  longtitude;
//
//   Facility({this.address, this.latitude,this.longtitude});
//
//   Facility.fromJson(Map<String, dynamic> json) {
//     address = json["address"];
//     latitude = json["latitude"];
//     longtitude = json["longitude"];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> _data = <String, dynamic>{};
//     _data["address"] = address;
//     _data["latitude"] = latitude;
//     _data["longitude"] = longtitude;
//     return _data;
//   }
// }
//
// class Sport {
//   String? name;
//   String? image;
//
//   Sport({this.name, this.image});
//
//   Sport.fromJson(Map<String, dynamic> json) {
//     name = json["name"];
//     image = json["image"];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> _data = <String, dynamic>{};
//     _data["name"] = name;
//     _data["image"] = image;
//     return _data;
//   }
// }

class AvailablePublicChallengesModel {
  String? id;
  String? date;
  String? skillLevel;
  dynamic? maxPlayer;
  List<dynamic>? whoJoined;
  Slots? slots;

  AvailablePublicChallengesModel({
    this.id,
    this.date,
    this.skillLevel,
    this.maxPlayer,
    this.whoJoined,
    this.slots,
  });

  AvailablePublicChallengesModel.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    date = json["date"];
    skillLevel = json["skill_level"];
    maxPlayer = _toDouble(json["max_player"]);
    whoJoined = json["who_joined"] ?? [];
    slots = json["slot"] == null ? null : Slots.fromJson(json["slot"]);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["date"] = date;
    _data["skill_level"] = skillLevel;
    _data["max_player"] = maxPlayer;
    if (whoJoined != null) {
      _data["who_joined"] = whoJoined;
    }
    if (slots != null) {
      _data["slot"] = slots?.toJson();
    }
    return _data;
  }
}

class Slots {
  String? startTime;
  String? endTime;
  String? day;
  double? price;
  Court? court;

  Slots({
    this.startTime,
    this.endTime,
    this.day,
    this.price,
    this.court,
  });

  Slots.fromJson(Map<String, dynamic> json) {
    startTime = json["startTime"];
    endTime = json["endTime"];
    day = json["day"];
    price = _toDouble(json["price"]);
    court = json["court"] == null ? null : Court.fromJson(json["court"]);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["startTime"] = startTime;
    _data["endTime"] = endTime;
    _data["day"] = day;
    _data["price"] = price;
    if (court != null) {
      _data["court"] = court?.toJson();
    }
    return _data;
  }
}

class Court {
  String? image;
  String? name;
  String? grname;
  Sport? sport;
  Facility? facility;

  Court({
    this.image,
    this.name,
    this.sport,this.grname,
    this.facility,
  });

  Court.fromJson(Map<String, dynamic> json) {
    image = json["image"];
    name = json["name"];
    grname = json["gr_name"];
    sport = json["sport"] == null ? null : Sport.fromJson(json["sport"]);
    facility =
    json["facility"] == null ? null : Facility.fromJson(json["facility"]);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["image"] = image;
    _data["name"] = name;
    _data["gr_name"] = grname;
    if (sport != null) {
      _data["sport"] = sport?.toJson();
    }
    if (facility != null) {
      _data["facility"] = facility?.toJson();
    }
    return _data;
  }
}

class Facility {
  String? address;
  double? latitude;
  double? longtitude;

  Facility({
    this.address,
    this.latitude,
    this.longtitude,
  });

  Facility.fromJson(Map<String, dynamic> json) {
    address = json["address"];
    latitude = _toDouble(json["latitude"]);
    longtitude = _toDouble(json["longitude"]);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["address"] = address;
    _data["latitude"] = latitude;
    _data["longitude"] = longtitude;
    return _data;
  }
}

class Sport {
  String? name;
  String? grname;
  String? image;


  Sport({this.name, this.image,this.grname});

  Sport.fromJson(Map<String, dynamic> json) {
    name = json["name"];
    image = json["image"];
    grname = json["gr_name"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["name"] = name;
    _data["image"] = image;
    _data["gr_name"] = grname;
    return _data;
  }
}

double? _toDouble(dynamic value) {
  if (value == null) return null;
  if (value is int) return value.toDouble();
  if (value is double) return value;
  if (value is String) return double.tryParse(value);
  return null;
}
