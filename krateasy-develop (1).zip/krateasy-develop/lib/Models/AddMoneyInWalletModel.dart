class AddMoneyInWalletModel {
  final bool success;
  final String message;
  final int? amount;

  AddMoneyInWalletModel({
    required this.success,
    required this.message,
    this.amount,
  });

  factory AddMoneyInWalletModel.fromJson(Map<String, dynamic> json) {
    return AddMoneyInWalletModel(
      success: json['status'] ?? false,
      message: json['message'] ?? 'Unknown error',
      amount: json['amount'],
    );
  }
}
