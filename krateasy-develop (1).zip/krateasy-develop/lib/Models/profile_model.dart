class ProfileModel {
  String? id;
  String? name;
  dynamic image;
  String? email;
  String? mobileNumber;
  String? skillSet;
  String? countryCode;
  bool? isNotificationOn;
  List<Sports>? sports;

  ProfileModel(
      {this.id,
      this.name,
      this.image,
      this.email,
      this.mobileNumber,
      this.countryCode,
      this.isNotificationOn,
      this.sports});

  ProfileModel.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    name = json["name"];
    image = json["image"];
    email = json["email"];
    skillSet = json["skillSet"];
    mobileNumber = json["mobile_number"];
    countryCode = json["country_code"];
    isNotificationOn = json["is_notification_on"];
    sports = json["sports"] == null
        ? null
        : (json["sports"] as List).map((e) => Sports.fromJson(e)).toList();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["name"] = name;
    _data["image"] = image;
    _data["email"] = email;
    _data["skillSet"] = skillSet;
    _data["mobile_number"] = mobileNumber;
    _data["country_code"] = countryCode;
    _data["is_notification_on"] = isNotificationOn;
    if (sports != null) {
      _data["sports"] = sports?.map((e) => e.toJson()).toList();
    }
    return _data;
  }
}

class Sports {
  String? id;
  String? name;
  String? image;
  String? skillLevel;

  Sports({this.id, this.name, this.image, this.skillLevel});

  Sports.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    name = json["name"];
    image = json["image"];
    skillLevel = json["skill_level"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["name"] = name;
    _data["image"] = image;
    _data["skill_level"] = skillLevel;
    return _data;
  }
}
