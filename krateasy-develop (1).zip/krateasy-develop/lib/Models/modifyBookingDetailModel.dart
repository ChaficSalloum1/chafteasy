class ModifyBookingDetailResponse {
  bool? status;
  String? message;
  BookingData? data;
  int? exeTime;

  ModifyBookingDetailResponse({
    this.status,
    this.message,
    this.data,
    this.exeTime,
  });

  factory ModifyBookingDetailResponse.fromJson(Map<String, dynamic> json) {
    return ModifyBookingDetailResponse(
      status: json['status'] as bool?,
      message: json['message'] as String?,
      data: json['data'] != null ? BookingData.fromJson(json['data']) : null,
      exeTime: json['exeTime'] as int?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'status': status,
      'message': message,
      'data': data?.toJson(),
      'exeTime': exeTime,
    };
  }
}

class BookingData {
  String? id;
  String? bookingId;
  String? userId;
  Court? courtId;
  String? challengeId;
  Facility? facilityId;
  String? facilityOwnerId;
  List<ModifySlots>? slotId;
  DateTime? bookingStartTime;
  String? slotTime;
  String? startTime;
  String? endTime;
  double? startTime24;
  double? endTime24;
  dynamic duration;
  int? adminCommission;
  int? facilityOwnerAmount;
  dynamic? price;
  String? type;
  String? discountId;
  int? discountAmount;
  bool? isRecorded;
  bool? isOfflineBooking;
  bool? isReview;
  bool? isModified;
  String? status;
  bool? isSplit;
  String? paymentStatus;
  String? date;
  List<Friend>? friends;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;
  int? courtBookingCount;

  BookingData({
    this.id,
    this.bookingId,
    this.userId,
    this.courtId,
    this.challengeId,
    this.facilityId,
    this.facilityOwnerId,
    this.slotId,
    this.bookingStartTime,
    this.slotTime,
    this.startTime,
    this.endTime,
    this.startTime24,
    this.endTime24,
    this.duration,
    this.adminCommission,
    this.facilityOwnerAmount,
    this.price,
    this.type,
    this.discountId,
    this.discountAmount,
    this.isRecorded,
    this.isOfflineBooking,
    this.isReview,
    this.isModified,
    this.status,
    this.isSplit,
    this.paymentStatus,
    this.date,
    this.friends,
    this.createdAt,
    this.updatedAt,
    this.v,
    this.courtBookingCount,
  });

  factory BookingData.fromJson(Map<String, dynamic> json) {
    return BookingData(
      id: json['_id'] as String?,
      bookingId: json['booking_id'] as String?,
      userId: json['user_id'] as String?,
      courtId: json['court_id'] != null ? Court.fromJson(json['court_id']) : null,
      challengeId: json['challenge_id'] as String?,
      facilityId: json['facility_id'] != null ? Facility.fromJson(json['facility_id']) : null,
      facilityOwnerId: json['facility_owner_id'] as String?,
      slotId: (json['slot_id'] as List<dynamic>?)?.map((e) => ModifySlots.fromJson(e)).toList(),
      bookingStartTime: json['bookingStartTime'] != null ? DateTime.tryParse(json['bookingStartTime']) : null,
      slotTime: json['slotTime'] as String?,
      startTime: json['startTime'] as String?,
      endTime: json['endTime'] as String?,
      startTime24: (json['startTime24'] as num?)?.toDouble(),
      endTime24: (json['endTime24'] as num?)?.toDouble(),
      duration: json['duration'],
      adminCommission: json['admin_commission'] as int?,
      facilityOwnerAmount: json['facility_owner_amount'] as int?,
      price: json['price'],
      type: json['type'] as String?,
      discountId: json['discountId'] as String?,
      discountAmount: json['discountAmount'] as int?,
      isRecorded: json['is_recorded'] as bool?,
      isOfflineBooking: json['isOfflineBooking'] as bool?,
      isReview: json['is_review'] as bool?,
      isModified: json['is_modified'] as bool?,
      status: json['status'] as String?,
      isSplit: json['is_split'] as bool?,
      paymentStatus: json['payment_status'] as String?,
      date: json['date'] as String,
      friends: (json['friends'] as List<dynamic>?)?.map((e) => Friend.fromJson(e)).toList(),
      createdAt: json['created_at'] != null ? DateTime.tryParse(json['created_at']) : null,
      updatedAt: json['updated_at'] != null ? DateTime.tryParse(json['updated_at']) : null,
      v: json['__v'] as int?,
      courtBookingCount: json['court_booking_count'] as int?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'booking_id': bookingId,
      'user_id': userId,
      'court_id': courtId?.toJson(),
      'challenge_id': challengeId,
      'facility_id': facilityId?.toJson(),
      'facility_owner_id': facilityOwnerId,
      'slot_id': slotId?.map((e) => e.toJson()).toList(),
      'bookingStartTime': bookingStartTime?.toIso8601String(),
      'slotTime': slotTime,
      'startTime': startTime,
      'endTime': endTime,
      'startTime24': startTime24,
      'endTime24': endTime24,
      'duration': duration,
      'admin_commission': adminCommission,
      'facility_owner_amount': facilityOwnerAmount,
      'price': price,
      'type': type,
      'discountId': discountId,
      'discountAmount': discountAmount,
      'is_recorded': isRecorded,
      'isOfflineBooking': isOfflineBooking,
      'is_review': isReview,
      'is_modified': isModified,
      'status': status,
      'is_split': isSplit,
      'payment_status': paymentStatus,
      'date': date,
      'friends': friends?.map((e) => e.toJson()).toList(),
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
      '__v': v,
      'court_booking_count': courtBookingCount,
    };
  }
}

class Court {
  String? id;
  String? image;
  int? startTime;
  int? endTime;
  int? price;
  int? minHours;
  List<String>? gallery;
  dynamic? averageRating;
  int? totalRating;
  Sport? sportId;
  Facility? facilityId;
  String? facilityOwnerId;
  String? userId;
  bool? isActive;
  bool? isDelete;
  bool? isFavorite;
  String? name;
  String? grName;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;
  int? totalBookings;

  Court({
    this.id,
    this.image,
    this.startTime,
    this.endTime,
    this.price,
    this.minHours,
    this.gallery,
    this.averageRating,
    this.totalRating,
    this.sportId,
    this.facilityId,
    this.facilityOwnerId,
    this.userId,
    this.isActive,
    this.isDelete,
    this.isFavorite,
    this.name,
    this.grName,
    this.createdAt,
    this.updatedAt,
    this.v,
    this.totalBookings,
  });

  factory Court.fromJson(Map<String, dynamic> json) {
    return Court(
      id: json['_id'] as String?,
      image: json['image'] as String?,
      startTime: json['startTime'] as int?,
      endTime: json['endTime'] as int?,
      price: json['price'] as int?,
      minHours: json['minHours'] as int?,
      gallery: (json['gallery'] as List<dynamic>?)?.cast<String>(),
      averageRating: json['averageRating'],
      totalRating: json['totalRating'] as int?,
      sportId: json['sport_id'] != null ? Sport.fromJson(json['sport_id']) : null,
      facilityId: json['facility_id'] != null ? Facility.fromJson(json['facility_id']) : null,
      facilityOwnerId: json['facility_owner_id'] as String?,
      userId: json['user_id'] as String?,
      isActive: json['is_active'] as bool?,
      isDelete: json['is_delete'] as bool?,
      isFavorite: json['is_favorite'] as bool?,
      name: json['name'] as String?,
      grName: json['gr_name'] as String?,
      createdAt: json['created_at'] != null ? DateTime.tryParse(json['created_at']) : null,
      updatedAt: json['updated_at'] != null ? DateTime.tryParse(json['updated_at']) : null,
      v: json['__v'] as int?,
      totalBookings: json['total_bookings'] as int?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'image': image,
      'startTime': startTime,
      'endTime': endTime,
      'price': price,
      'minHours': minHours,
      'gallery': gallery,
      'averageRating': averageRating,
      'totalRating': totalRating,
      'sport_id': sportId?.toJson(),
      'facility_id': facilityId?.toJson(),
      'facility_owner_id': facilityOwnerId,
      'user_id': userId,
      'is_active': isActive,
      'is_delete': isDelete,
      'is_favorite': isFavorite,
      'name': name,
      'gr_name': grName,
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
      '__v': v,
      'total_bookings': totalBookings,
    };
  }
}

class Sport {
  String? id;
  String? name;
  String? image;
  List<String>? skillLevel;
  String? matchType;
  bool? isActive;
  bool? isDelete;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;

  Sport({
    this.id,
    this.name,
    this.image,
    this.skillLevel,
    this.matchType,
    this.isActive,
    this.isDelete,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  factory Sport.fromJson(Map<String, dynamic> json) {
    return Sport(
      id: json['_id'] as String?,
      name: json['name'] as String?,
      image: json['image'] as String?,
      skillLevel: (json['skill_level'] as List<dynamic>?)?.cast<String>(),
      matchType: json['match_type'] as String?,
      isActive: json['is_active'] as bool?,
      isDelete: json['is_delete'] as bool?,
      createdAt: json['created_at'] != null ? DateTime.tryParse(json['created_at']) : null,
      updatedAt: json['updated_at'] != null ? DateTime.tryParse(json['updated_at']) : null,
      v: json['__v'] as int?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'name': name,
      'image': image,
      'skill_level': skillLevel,
      'match_type': matchType,
      'is_active': isActive,
      'is_delete': isDelete,
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
      '__v': v,
    };
  }
}

class Facility {
  String? id;
  String? name;
  String? image;
  String? description;
  String? bio;
  List<String>? gallery;
  String? subscriptionStatus;
  double? latitude;
  double? longitude;
  String? address;
  List<String>? amenities;
  String? facilityOwner;
  bool? isActive;
  bool? isDelete;
  Location? location;
  List<String>? team;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? v;

  Facility({
    this.id,
    this.name,
    this.image,
    this.description,
    this.bio,
    this.gallery,
    this.subscriptionStatus,
    this.latitude,
    this.longitude,
    this.address,
    this.amenities,
    this.facilityOwner,
    this.isActive,
    this.isDelete,
    this.location,
    this.team,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  factory Facility.fromJson(Map<String, dynamic> json) {
    return Facility(
      id: json['_id'] as String?,
      name: json['name'] as String?,
      image: json['image'] as String?,
      description: json['description'] as String?,
      bio: json['bio'] as String?,
      gallery: (json['gallery'] as List<dynamic>?)?.cast<String>(),
      subscriptionStatus: json['subscription_status'] as String?,
      latitude: (json['latitude'] as num?)?.toDouble(),
      longitude: (json['longitude'] as num?)?.toDouble(),
      address: json['address'] as String?,
      amenities: (json['amenities'] as List<dynamic>?)?.cast<String>(),
      facilityOwner: json['facility_owner'] as String?,
      isActive: json['is_active'] as bool?,
      isDelete: json['is_delete'] as bool?,
      location: json['location'] != null ? Location.fromJson(json['location']) : null,
      team: (json['team'] as List<dynamic>?)?.cast<String>(),
      createdAt: json['created_at'] != null ? DateTime.tryParse(json['created_at']) : null,
      updatedAt: json['updated_at'] != null ? DateTime.tryParse(json['updated_at']) : null,
      v: json['__v'] as int?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'name': name,
      'image': image,
      'description': description,
      'bio': bio,
      'gallery': gallery,
      'subscription_status': subscriptionStatus,
      'latitude': latitude,
      'longitude': longitude,
      'address': address,
      'amenities': amenities,
      'facility_owner': facilityOwner,
      'is_active': isActive,
      'is_delete': isDelete,
      'location': location?.toJson(),
      'team': team,
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
      '__v': v,
    };
  }
}

class Location {
  String? type;
  List<double>? coordinates;

  Location({
    this.type,
    this.coordinates,
  });

  factory Location.fromJson(Map<String, dynamic> json) {
    return Location(
      type: json['type'] as String?,
      coordinates: (json['coordinates'] as List<dynamic>?)?.cast<double>(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'type': type,
      'coordinates': coordinates,
    };
  }
}

class ModifySlots {
  String? id;
  String? startTime;
  String? endTime;
  double? startTime24;
  double? endTime24;
  String? day;
  int? price;
  String? courtId;
  bool? isActive;
  bool? isDelete;
  int? v;
  DateTime? createdAt;
  DateTime? updatedAt;

  ModifySlots({
    this.id,
    this.startTime,
    this.endTime,
    this.startTime24,
    this.endTime24,
    this.day,
    this.price,
    this.courtId,
    this.isActive,
    this.isDelete,
    this.v,
    this.createdAt,
    this.updatedAt,
  });

  factory ModifySlots.fromJson(Map<String, dynamic> json) {
    return ModifySlots(
      id: json['_id'] as String?,
      startTime: json['startTime'] as String?,
      endTime: json['endTime'] as String?,
      startTime24: (json['startTime24'] as num?)?.toDouble(),
      endTime24: (json['endTime24'] as num?)?.toDouble(),
      day: json['day'] as String?,
      price: json['price'] as int?,
      courtId: json['court_id'] as String?,
      isActive: json['is_active'] as bool?,
      isDelete: json['is_delete'] as bool?,
      v: json['__v'] as int?,
      createdAt: json['created_at'] != null ? DateTime.tryParse(json['created_at']) : null,
      updatedAt: json['updated_at'] != null ? DateTime.tryParse(json['updated_at']) : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'startTime': startTime,
      'endTime': endTime,
      'startTime24': startTime24,
      'endTime24': endTime24,
      'day': day,
      'price': price,
      'court_id': courtId,
      'is_active': isActive,
      'is_delete': isDelete,
      '__v': v,
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
    };
  }
}

class Friend {
  String? name;
  String? mobileNumber;
  String? countryCode;
  int? splitAmount;
  bool? isPaid;
  bool? isFriendFavorite;
  bool? isReviewed;
  String? id;

  Friend({
    this.name,
    this.mobileNumber,
    this.countryCode,
    this.splitAmount,
    this.isPaid,
    this.isFriendFavorite,
    this.isReviewed,
    this.id,
  });

  factory Friend.fromJson(Map<String, dynamic> json) {
    return Friend(
      name: json['name'] as String?,
      mobileNumber: json['mobile_number'] as String?,
      countryCode: json['country_code'] as String?,
      splitAmount: json['split_amount'] as int?,
      isPaid: json['is_paid'] as bool?,
      isFriendFavorite: json['is_friend_favorite'] as bool?,
      isReviewed: json['isReviewed'] as bool?,
      id: json['_id'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'mobile_number': mobileNumber,
      'country_code': countryCode,
      'split_amount': splitAmount,
      'is_paid': isPaid,
      'is_friend_favorite': isFriendFavorite,
      'isReviewed': isReviewed,
      '_id': id,
    };
  }
}// class ModifyBookingDetailResponse {
//   bool? status;
//   String? message;
//   BookingData? data;
//   int? exeTime;
//
//   ModifyBookingDetailResponse({
//     this.status,
//     this.message,
//     this.data,
//     this.exeTime,
//   });
//
//   factory ModifyBookingDetailResponse.fromJson(Map<String, dynamic> json) {
//     return ModifyBookingDetailResponse(
//       status: json['status'] as bool?,
//       message: json['message'] as String?,
//       data: json['data'] != null ? BookingData.fromJson(json['data']) : null,
//       exeTime: json['exeTime'] as int?,
//     );
//   }
// }
//
// class BookingData {
//   String? id;
//   String? bookingId;
//   String? userId;
//   Court? courtId;
//   String? challengeId;
//   Facility? facilityId;
//   String? facilityOwnerId;
//   List<ModifySlots>? slotId;
//   DateTime? bookingStartTime;
//   String? slotTime;
//   String? startTime;
//   String? endTime;
//   double? startTime24;
//   double? endTime24;
//   double? duration;
//   double? adminCommission;
//   double? facilityOwnerAmount;
//   double? price;
//   String? type;
//   String? discountId;
//   double? discountAmount;
//   bool? isRecorded;
//   bool? isOfflineBooking;
//   bool? isReview;
//   String? status;
//   bool? isSplit;
//   String? paymentStatus;
//   String? date;
//   List<dynamic>? friends;
//   DateTime? createdAt;
//   DateTime? updatedAt;
//   int? courtBookingCount;
//
//   BookingData({
//     this.id,
//     this.bookingId,
//     this.userId,
//     this.courtId,
//     this.challengeId,
//     this.facilityId,
//     this.facilityOwnerId,
//     this.slotId,
//     this.bookingStartTime,
//     this.slotTime,
//     this.startTime,
//     this.endTime,
//     this.startTime24,
//     this.endTime24,
//     this.duration,
//     this.adminCommission,
//     this.facilityOwnerAmount,
//     this.price,
//     this.type,
//     this.discountId,
//     this.discountAmount,
//     this.isRecorded,
//     this.isOfflineBooking,
//     this.isReview,
//     this.status,
//     this.isSplit,
//     this.paymentStatus,
//     this.date,
//     this.friends,
//     this.createdAt,
//     this.updatedAt,
//     this.courtBookingCount,
//   });
//
//   factory BookingData.fromJson(Map<String, dynamic> json) {
//     return BookingData(
//       id: json['_id'] as String?,
//       bookingId: json['booking_id'] as String?,
//       userId: json['user_id'] as String?,
//       courtId:
//           json['court_id'] != null ? Court.fromJson(json['court_id']) : null,
//       challengeId: json['challenge_id'] as String?,
//       facilityId: json['facility_id'] != null
//           ? Facility.fromJson(json['facility_id'])
//           : null,
//       facilityOwnerId: json['facility_owner_id'] as String?,
//       slotId: json['slot_id'] != null
//           ? (json['slot_id'] as List)
//               .map((e) => ModifySlots.fromJson(e))
//               .toList()
//           : null,
//       bookingStartTime: json['bookingStartTime'] != null
//           ? DateTime.parse(json['bookingStartTime'])
//           : null,
//       slotTime: json['slotTime'] as String?,
//       startTime: json['startTime'] as String?,
//       endTime: json['endTime'] as String?,
//       startTime24: (json['startTime24'] as num?)?.toDouble(),
//       endTime24: (json['endTime24'] as num?)?.toDouble(),
//       duration: (json['duration'] as num?)?.toDouble(),
//       adminCommission: (json['admin_commission'] as num?)?.toDouble(),
//       facilityOwnerAmount: (json['facility_owner_amount'] as num?)?.toDouble(),
//       price: (json['price'] as num?)?.toDouble(),
//       type: json['type'] as String?,
//       discountId: json['discountId'] as String?,
//       discountAmount: (json['discountAmount'] as num?)?.toDouble(),
//       isRecorded: json['is_recorded'] as bool?,
//       isOfflineBooking: json['isOfflineBooking'] as bool?,
//       isReview: json['is_review'] as bool?,
//       status: json['status'] as String?,
//       isSplit: json['is_split'] as bool?,
//       paymentStatus: json['payment_status'] as String?,
//       date: json['date'] as String,
//       friends: json['friends'] as List<dynamic>?,
//       createdAt: json['created_at'] != null
//           ? DateTime.parse(json['created_at'])
//           : null,
//       updatedAt: json['updated_at'] != null
//           ? DateTime.parse(json['updated_at'])
//           : null,
//       courtBookingCount: json['court_booking_count'] as int?,
//     );
//   }
// }
//
// class Court {
//   String? id;
//   String? image;
//   int? startTime;
//   int? endTime;
//   int? price;
//   int? minHours;
//   List<dynamic>? gallery;
//   double? averageRating;
//   int? totalRating;
//   Sport? sportId;
//   Facility? facilityId;
//   String? facilityOwnerId;
//   String? userId;
//   bool? isActive;
//   bool? isDelete;
//   bool? isFavorite;
//   String? name;
//   String? grName;
//   DateTime? createdAt;
//   DateTime? updatedAt;
//   int? totalBookings;
//
//   Court({
//     this.id,
//     this.image,
//     this.startTime,
//     this.endTime,
//     this.price,
//     this.minHours,
//     this.gallery,
//     this.averageRating,
//     this.totalRating,
//     this.sportId,
//     this.facilityId,
//     this.facilityOwnerId,
//     this.userId,
//     this.isActive,
//     this.isDelete,
//     this.isFavorite,
//     this.name,
//     this.grName,
//     this.createdAt,
//     this.updatedAt,
//     this.totalBookings,
//   });
//
//   factory Court.fromJson(Map<String, dynamic> json) {
//     return Court(
//       id: json['_id'] as String?,
//       image: json['image'] as String?,
//       startTime: json['startTime'] as int?,
//       endTime: json['endTime'] as int?,
//       price: json['price'] as int?,
//       minHours: json['minHours'] as int?,
//       gallery: json['gallery'] as List<dynamic>?,
//       averageRating: (json['averageRating'] as num?)?.toDouble(),
//       totalRating: json['totalRating'] as int?,
//       sportId:
//           json['sport_id'] != null ? Sport.fromJson(json['sport_id']) : null,
//       facilityId: json['facility_id'] != null
//           ? Facility.fromJson(json['facility_id'])
//           : null,
//       facilityOwnerId: json['facility_owner_id'] as String?,
//       userId: json['user_id'] as String?,
//       isActive: json['is_active'] as bool?,
//       isDelete: json['is_delete'] as bool?,
//       isFavorite: json['is_favorite'] as bool?,
//       name: json['name'] as String?,
//       grName: json['gr_name'] as String?,
//       createdAt: json['created_at'] != null
//           ? DateTime.parse(json['created_at'])
//           : null,
//       updatedAt: json['updated_at'] != null
//           ? DateTime.parse(json['updated_at'])
//           : null,
//       totalBookings: json['total_bookings'] as int?,
//     );
//   }
// }
//
// class Sport {
//   String? id;
//   String? name;
//   String? image;
//   List<String>? skillLevel;
//   String? matchType;
//   bool? isActive;
//   bool? isDelete;
//   DateTime? createdAt;
//   DateTime? updatedAt;
//
//   Sport({
//     this.id,
//     this.name,
//     this.image,
//     this.skillLevel,
//     this.matchType,
//     this.isActive,
//     this.isDelete,
//     this.createdAt,
//     this.updatedAt,
//   });
//
//   factory Sport.fromJson(Map<String, dynamic> json) {
//     return Sport(
//       id: json['_id'] as String?,
//       name: json['name'] as String?,
//       image: json['image'] as String?,
//       skillLevel: (json['skill_level'] as List<dynamic>?)?.cast<String>(),
//       matchType: json['match_type'] as String?,
//       isActive: json['is_active'] as bool?,
//       isDelete: json['is_delete'] as bool?,
//       createdAt: json['created_at'] != null
//           ? DateTime.parse(json['created_at'])
//           : null,
//       updatedAt: json['updated_at'] != null
//           ? DateTime.parse(json['updated_at'])
//           : null,
//     );
//   }
// }
//
// class Facility {
//   String? id;
//   String? name;
//   String? image;
//   String? description;
//   String? bio;
//   List<String>? gallery;
//   String? subscriptionStatus;
//   double? latitude;
//   double? longitude;
//   String? address;
//   List<String>? amenities;
//   String? facilityOwner;
//   bool? isActive;
//   bool? isDelete;
//   List<dynamic>? team;
//   Location? location;
//   DateTime? createdAt;
//   DateTime? updatedAt;
//
//   Facility({
//     this.id,
//     this.name,
//     this.image,
//     this.description,
//     this.bio,
//     this.gallery,
//     this.subscriptionStatus,
//     this.latitude,
//     this.longitude,
//     this.address,
//     this.amenities,
//     this.facilityOwner,
//     this.isActive,
//     this.isDelete,
//     this.team,
//     this.location,
//     this.createdAt,
//     this.updatedAt,
//   });
//
//   factory Facility.fromJson(Map<String, dynamic> json) {
//     return Facility(
//       id: json['_id'] as String?,
//       name: json['name'] as String?,
//       image: json['image'] as String?,
//       description: json['description'] as String?,
//       bio: json['bio'] as String?,
//       gallery: (json['gallery'] as List<dynamic>?)?.cast<String>(),
//       subscriptionStatus: json['subscription_status'] as String?,
//       latitude: (json['latitude'] as num?)?.toDouble(),
//       longitude: (json['longitude'] as num?)?.toDouble(),
//       address: json['address'] as String?,
//       amenities: (json['amenities'] as List<dynamic>?)?.cast<String>(),
//       facilityOwner: json['facility_owner'] as String?,
//       isActive: json['is_active'] as bool?,
//       isDelete: json['is_delete'] as bool?,
//       team: json['team'] as List<dynamic>?,
//       location:
//           json['location'] != null ? Location.fromJson(json['location']) : null,
//       createdAt: json['created_at'] != null
//           ? DateTime.parse(json['created_at'])
//           : null,
//       updatedAt: json['updated_at'] != null
//           ? DateTime.parse(json['updated_at'])
//           : null,
//     );
//   }
// }
//
// class Location {
//   String? type;
//   List<double>? coordinates;
//
//   Location({
//     this.type,
//     this.coordinates,
//   });
//
//   factory Location.fromJson(Map<String, dynamic> json) {
//     return Location(
//       type: json['type'] as String?,
//       coordinates: (json['coordinates'] as List<dynamic>?)?.cast<double>(),
//     );
//   }
// }
//
// class ModifySlots {
//   String? id;
//   String? startTime;
//   String? endTime;
//   double? startTime24;
//   double? endTime24;
//   String? day;
//   int? price;
//   String? courtId;
//   bool? isActive;
//   bool? isDelete;
//   DateTime? createdAt;
//   DateTime? updatedAt;
//
//   ModifySlots({
//     this.id,
//     this.startTime,
//     this.endTime,
//     this.startTime24,
//     this.endTime24,
//     this.day,
//     this.price,
//     this.courtId,
//     this.isActive,
//     this.isDelete,
//     this.createdAt,
//     this.updatedAt,
//   });
//
//   factory ModifySlots.fromJson(Map<String, dynamic> json) {
//     return ModifySlots(
//       id: json['_id'] as String?,
//       startTime: json['startTime'] as String?,
//       endTime: json['endTime'] as String?,
//       startTime24: (json['startTime24'] as num?)?.toDouble(),
//       endTime24: (json['endTime24'] as num?)?.toDouble(),
//       day: json['day'] as String?,
//       price: json['price'] as int?,
//       courtId: json['court_id'] as String?,
//       isActive: json['is_active'] as bool?,
//       isDelete: json['is_delete'] as bool?,
//       createdAt: json['created_at'] != null
//           ? DateTime.parse(json['created_at'])
//           : null,
//       updatedAt: json['updated_at'] != null
//           ? DateTime.parse(json['updated_at'])
//           : null,
//     );
//   }
// }
