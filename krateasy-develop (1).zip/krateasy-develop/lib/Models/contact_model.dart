class ContactModel {
  String name;
  String phoneNumber;
  String id;
  bool isActive;

  ContactModel({
    required this.name,
    required this.phoneNumber,
    required this.id,
    required this.isActive,
  });

  // Convert to Map (for Firebase or local storage)
  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'phoneNumber': phoneNumber,
      'id': id,
      'isActive': isActive,
    };
  }

  // Create model from Map
  factory ContactModel.fromMap(Map<String, dynamic> map) {
    return ContactModel(
      name: map['name'] ?? '',
      phoneNumber: map['phoneNumber'] ?? '',
      id: map['id'] ?? '',
      isActive: map['isActive'] ?? false,
    );
  }
}
