class WalletDetailModel {
  final bool? status;
  final String? message;
  final WalletData? wallet;
  final int? exeTime;

  WalletDetailModel({
    this.status,
    this.message,
    this.wallet,
    this.exeTime,
  });

  factory WalletDetailModel.fromJson(Map<String, dynamic> json) {
    return WalletDetailModel(
      status: json['status'],
      message: json['message'],
      wallet: json['wallet'] != null ? WalletData.fromJson(json['wallet']) : null,
      exeTime: json['exeTime'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'status': status,
      'message': message,
      'wallet': wallet?.toJson(),
      'exeTime': exeTime,
    };
  }
}

class WalletData {
  final String? userId;
  final String? facilityOwnerId;
  final int? amount;
  final int? totalTransactions;
  final String? id;
  final String? createdAt;
  final String? updatedAt;
  final int? v;

  WalletData({
    this.userId,
    this.facilityOwnerId,
    this.amount,
    this.totalTransactions,
    this.id,
    this.createdAt,
    this.updatedAt,
    this.v,
  });

  factory WalletData.fromJson(Map<String, dynamic> json) {
    return WalletData(
      userId: json['user_id'],
      facilityOwnerId: json['facility_owner_id'],
      amount: json['amount'],
      totalTransactions: json['total_transactions'],
      id: json['_id'],
      createdAt: json['created_at'],
      updatedAt: json['updated_at'],
      v: json['__v'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'user_id': userId,
      'facility_owner_id': facilityOwnerId,
      'amount': amount,
      'total_transactions': totalTransactions,
      '_id': id,
      'created_at': createdAt,
      'updated_at': updatedAt,
      '__v': v,
    };
  }
}
