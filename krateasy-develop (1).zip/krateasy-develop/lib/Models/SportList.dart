class SportList {
  final String id;
  final String name;
  final String image;
  bool isSelected  = false;

  SportList({required this.id, required this.name, required this.image,this.isSelected= false,});

  factory SportList.fromJson(Map<String, dynamic> json) {
    return SportList(
      id: json['_id'],
      name: json['name'],
      image: json['image'],
    );
  }
}
