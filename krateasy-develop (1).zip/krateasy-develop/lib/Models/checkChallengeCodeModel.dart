class CheckChallengeCodeModel {
    CheckChallengeCodeModel({
        required this.status,
        required this.message,
        required this.data,
        required this.exeTime,
    });

    final bool status;
    final String message;
    final Data? data;
    final int exeTime;

    factory CheckChallengeCodeModel.fromJson(Map<String, dynamic> json){ 
        return CheckChallengeCodeModel(
            status: json["status"] ?? false,
            message: json["message"] ?? "",
            data: json["data"] == null ? null : Data.fromJson(json["data"]),
            exeTime: json["exeTime"] ?? 0,
        );
    }

    Map<String, dynamic> toJson() => {
        "status": status,
        "message": message,
        "data": data?.toJson(),
        "exeTime": exeTime,
    };

    @override
    String toString(){
        return "$status, $message, $data, $exeTime, ";
    }
}

class Data {
    Data({
        required this.isPublic,
        required this.isRecorded,
        required this.date,
        required this.startTime,
        required this.endTime,
        required this.isDisabled,
        required this.sportId,
        required this.skillLevel,
        required this.status,
        required this.facilityId,
        required this.maxPlayer,
        required this.whoJoined,
        required this.courtId,
        required this.userId,
        required this.slotId,
        required this.privateCode,
        required this.isReview,
        required this.isActive,
        required this.isDelete,
        required this.id,
        required this.friends,
        required this.createdAt,
        required this.updatedAt,
        required this.v,
    });

    final bool isPublic;
    final bool isRecorded;
    final dynamic date;
    final String startTime;
    final String endTime;
    final bool isDisabled;
    final String sportId;
    final dynamic skillLevel;
    final String status;
    final String facilityId;
    final int maxPlayer;
    final List<String> whoJoined;
    final String courtId;
    final String userId;
    final List<String> slotId;
    final dynamic privateCode;
    final bool isReview;
    final bool isActive;
    final bool isDelete;
    final String id;
    final List<dynamic> friends;
    final DateTime? createdAt;
    final DateTime? updatedAt;
    final int v;

    factory Data.fromJson(Map<String, dynamic> json){ 
        return Data(
            isPublic: json["is_public"] ?? false,
            isRecorded: json["is_recorded"] ?? false,
            date: json["date"],
            startTime: json["startTime"] ?? "",
            endTime: json["endTime"] ?? "",
            isDisabled: json["is_disabled"] ?? false,
            sportId: json["sport_id"] ?? "",
            skillLevel: json["skill_level"],
            status: json["status"] ?? "",
            facilityId: json["facility_id"] ?? "",
            maxPlayer: json["max_player"] ?? 0,
            whoJoined: json["who_joined"] == null ? [] : List<String>.from(json["who_joined"]!.map((x) => x)),
            courtId: json["court_id"] ?? "",
            userId: json["user_id"] ?? "",
            slotId: json["slot_id"] == null ? [] : List<String>.from(json["slot_id"]!.map((x) => x)),
            privateCode: json["private_code"],
            isReview: json["is_review"] ?? false,
            isActive: json["is_active"] ?? false,
            isDelete: json["is_delete"] ?? false,
            id: json["_id"] ?? "",
            friends: json["friends"] == null ? [] : List<dynamic>.from(json["friends"]!.map((x) => x)),
            createdAt: DateTime.tryParse(json["created_at"] ?? ""),
            updatedAt: DateTime.tryParse(json["updated_at"] ?? ""),
            v: json["__v"] ?? 0,
        );
    }

    Map<String, dynamic> toJson() => {
        "is_public": isPublic,
        "is_recorded": isRecorded,
        "date": date,
        "startTime": startTime,
        "endTime": endTime,
        "is_disabled": isDisabled,
        "sport_id": sportId,
        "skill_level": skillLevel,
        "status": status,
        "facility_id": facilityId,
        "max_player": maxPlayer,
        "who_joined": whoJoined.map((x) => x).toList(),
        "court_id": courtId,
        "user_id": userId,
        "slot_id": slotId.map((x) => x).toList(),
        "private_code": privateCode,
        "is_review": isReview,
        "is_active": isActive,
        "is_delete": isDelete,
        "_id": id,
        "friends": friends.map((x) => x).toList(),
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "__v": v,
    };

    @override
    String toString(){
        return "$isPublic, $isRecorded, $date, $startTime, $endTime, $isDisabled, $sportId, $skillLevel, $status, $facilityId, $maxPlayer, $whoJoined, $courtId, $userId, $slotId, $privateCode, $isReview, $isActive, $isDelete, $id, $friends, $createdAt, $updatedAt, $v, ";
    }
}
