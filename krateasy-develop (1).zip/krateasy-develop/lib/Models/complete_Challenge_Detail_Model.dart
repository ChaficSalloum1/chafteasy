
// Root response class
class CompleteChallengeDetailModel {
  bool? status;
  String? message;
  ChallengeData? data;
  int? exeTime;

  CompleteChallengeDetailModel({
    this.status,
    this.message,
    this.data,
    this.exeTime,
  });

  // Factory constructor for JSON deserialization
  factory CompleteChallengeDetailModel.fromJson(Map<String, dynamic>? json) {
    if (json == null) {
      return CompleteChallengeDetailModel();
    }
    return CompleteChallengeDetailModel(
      status: json['status'] as bool?,
      message: json['message'] as String?,
      data: json['data'] != null
          ? ChallengeData.fromJson(json['data'] as Map<String, dynamic>?)
          : null,
      exeTime: json['exeTime'] ,
    );
  }

  // Method for JSON serialization
  Map<String, dynamic> toJson() {
    return {
      if (status != null) 'status': status,
      if (message != null) 'message': message,
      if (data != null) 'data': data?.toJson(),
      if (exeTime != null) 'exeTime': exeTime,
    };
  }
}

// Class for the 'data' field
class ChallengeData {
  String? id;
  bool? isPublic;
  bool? isRecorded;
  String? bookingStartTime;
  String? slotTime;
  String? startTime;
  String? endTime;
  var startTime24;
  var endTime24;
  bool? isDisabled;
  String? sportId;
  String? skillLevel;
  String? status;
  String? facilityId;
  int? maxPlayer;
  List<String>? whoJoined;
  String? courtId;
  String? userId;
  List<String>? slotId;
  String? privateCode;
  bool? isReview;
  bool? isActive;
  bool? isDelete;
  String? date;
  List<CompleteChallengeDetailModelFriend>? friends;
  String? createdAt;
  String? updatedAt;
  String? type;
  int? v;
  String? bookingId;

  ChallengeData({
    this.id,
    this.isPublic,
    this.isRecorded,
    this.bookingStartTime,
    this.slotTime,
    this.startTime,
    this.endTime,
    this.startTime24,
    this.endTime24,
    this.isDisabled,
    this.sportId,
    this.skillLevel,
    this.status,
    this.facilityId,
    this.maxPlayer,
    this.whoJoined,
    this.courtId,
    this.userId,
    this.slotId,
    this.privateCode,
    this.isReview,
    this.isActive,
    this.isDelete,
    this.date,
    this.friends,
    this.createdAt,
    this.updatedAt,
    this.type,
    this.v,
    this.bookingId,
  });

  // Factory constructor for JSON deserialization
  factory ChallengeData.fromJson(Map<String, dynamic>? json) {
    if (json == null) {
      return ChallengeData();
    }
    return ChallengeData(
      id: json['_id'] as String?,
      isPublic: json['is_public'] as bool?,
      isRecorded: json['is_recorded'] as bool?,
      bookingStartTime: json['bookingStartTime'] as String?,
      slotTime: json['slotTime'] as String?,
      startTime: json['startTime'] as String?,
      endTime: json['endTime'] as String?,
      startTime24: json['startTime24'] ,
      endTime24: json['endTime24'] ,
      isDisabled: json['is_disabled'] as bool?,
      sportId: json['sport_id'] as String?,
      skillLevel: json['skill_level'] as String?,
      status: json['status'] as String?,
      facilityId: json['facility_id'] as String?,
      maxPlayer: json['max_player'] ,
      whoJoined: json['who_joined'] != null
          ? List<String>.from(json['who_joined'] as List? ?? [])
          : null,
      courtId: json['court_id'] as String?,
      userId: json['user_id'] as String?,
      slotId: json['slot_id'] != null
          ? List<String>.from(json['slot_id'] as List? ?? [])
          : null,
      privateCode: json['private_code'] as String?,
      isReview: json['is_review'] as bool?,
      isActive: json['is_active'] as bool?,
      isDelete: json['is_delete'] as bool?,
      date: json['date'] as String?,
      friends: json['friends'] != null
          ? (json['friends'] as List?)
              ?.map((friend) => CompleteChallengeDetailModelFriend.fromJson(
                  friend as Map<String, dynamic>?))
              .toList()
          : null,
      createdAt: json['created_at'] as String?,
      updatedAt: json['updated_at'] as String?,
      type: json['type'] as String?,
      v: json['__v'] as int?,
      bookingId: json['booking_id'] as String?,
    );
  }

  // Method for JSON serialization
  Map<String, dynamic> toJson() {
    return {
      if (id != null) '_id': id,
      if (isPublic != null) 'is_public': isPublic,
      if (isRecorded != null) 'is_recorded': isRecorded,
      if (bookingStartTime != null) 'bookingStartTime': bookingStartTime,
      if (slotTime != null) 'slotTime': slotTime,
      if (startTime != null) 'startTime': startTime,
      if (endTime != null) 'endTime': endTime,
      if (startTime24 != null) 'startTime24': startTime24,
      if (endTime24 != null) 'endTime24': endTime24,
      if (isDisabled != null) 'is_disabled': isDisabled,
      if (sportId != null) 'sport_id': sportId,
      if (skillLevel != null) 'skill_level': skillLevel,
      if (status != null) 'status': status,
      if (facilityId != null) 'facility_id': facilityId,
      if (maxPlayer != null) 'max_player': maxPlayer,
      if (whoJoined != null) 'who_joined': whoJoined,
      if (courtId != null) 'court_id': courtId,
      if (userId != null) 'user_id': userId,
      if (slotId != null) 'slot_id': slotId,
      if (privateCode != null) 'private_code': privateCode,
      if (isReview != null) 'is_review': isReview,
      if (isActive != null) 'is_active': isActive,
      if (isDelete != null) 'is_delete': isDelete,
      if (date != null) 'date': date,
      if (friends != null)
        'friends': friends?.map((friend) => friend.toJson()).toList(),
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (type != null) 'type': updatedAt,
      if (v != null) '__v': v,
      if (bookingId != null) 'booking_id': bookingId,
    };
  }
}

// Class for the 'friends' array
class CompleteChallengeDetailModelFriend {
  String? name;
  String? mobileNumber;
  String? countryCode;
  var splitAmount;
  bool? isPaid;
  bool? isReviewed;
  bool? isFriendFavorite;
  String? id;
  String? playerid;

  CompleteChallengeDetailModelFriend({
    this.name,
    this.mobileNumber,
    this.countryCode,
    this.splitAmount,
    this.isPaid,
    this.isReviewed,
    this.isFriendFavorite,this.playerid,
    this.id,
  });

  // Factory constructor for JSON deserialization
  factory CompleteChallengeDetailModelFriend.fromJson(
      Map<String, dynamic>? json) {
    if (json == null) {
      return CompleteChallengeDetailModelFriend();
    }
    return CompleteChallengeDetailModelFriend(
      name: json['name'] as String?,
      mobileNumber: json['mobile_number'] as String?,
      countryCode: json['country_code'] as String?,
      splitAmount: json['split_amount'] ,
      isPaid: json['is_paid'] as bool?,
      isReviewed: json['isReviewed'] as bool?,
      isFriendFavorite: json['is_friend_favorite'] as bool?,
      id: json['_id'] as String?,
      playerid: json['player_id'] as String?,
    );
  }

  // Method for JSON serialization
  Map<String, dynamic> toJson() {
    return {
      if (name != null) 'name': name,
      if (mobileNumber != null) 'mobile_number': mobileNumber,
      if (countryCode != null) 'country_code': countryCode,
      if (splitAmount != null) 'split_amount': splitAmount,
      if (isPaid != null) 'is_paid': isPaid,
      if (isReviewed != null) 'isReviewed': isReviewed,
      if (isFriendFavorite != null) 'is_friend_favorite': isFriendFavorite,
      if (id != null) '_id': id,
      if (playerid != null) 'player_id': playerid,
    };
  }
}