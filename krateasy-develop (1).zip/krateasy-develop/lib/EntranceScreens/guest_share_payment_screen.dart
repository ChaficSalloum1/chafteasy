import 'dart:async';
import 'package:flutter/material.dart';
import 'package:kratEasyApp/EntranceScreens/friend_payment_scren.dart';
import 'package:kratEasyApp/GlobalUtils/app_text_field.dart';
import 'package:kratEasyApp/Models/booking_details_model.dart';
import 'package:kratEasyApp/Models/complete_Challenge_Detail_Model.dart';
import 'package:kratEasyApp/ViewModel/BottomNavViewModels/CreateChallengeViewModel/CreateChallengeViewModel.dart';
import 'package:kratEasyApp/ViewModel/BottomNavViewModels/HomeViewModel.dart';
import 'package:kratEasyApp/GlobalUtils/app_button.dart';
import 'package:kratEasyApp/GlobalUtils/app_colors.dart';
import 'package:kratEasyApp/GlobalUtils/common_share.dart';
import 'package:kratEasyApp/Screens/DashboardScreen.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:provider/provider.dart';

import '../GlobalUtils/app_constants.dart';
import '../ViewModel/EntranceViewModel/AvailableChallengeGuestViewModel.dart';

class GuestSharePaymentScreen extends StatefulWidget {
  const GuestSharePaymentScreen({
    super.key,
  });

  @override
  State<GuestSharePaymentScreen> createState() =>
      _GuestSharePaymentScreenState();
}

class _GuestSharePaymentScreenState extends State<GuestSharePaymentScreen> {
  String _timeLeft = '';
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final joinViewModel = Provider.of<HomeViewModel>(context, listen: false);

      context.read<AvailableChallengeGuestViewModel>().settime("");
      if (completeChallengeDetailModel?.data?.type == "Challenge") {
        await joinViewModel.getChalllengeBookingDetails(
            context: context,
            challenggid: completeChallengeDetailModel?.data?.id ?? "");
      } else {
        if (joinViewModel.bookingDetailsModel.data?.type == "Court") {
          await joinViewModel.getCourtBookingdetails(
              context: context,
              challenggid: joinViewModel.bookingDetailsModel.data?.id ?? "");
          timeDiffText = formatTimeDifference(
              joinViewModel.bookingDetailsModel?.data?.bookingstarttime ?? "");
        } else if (joinViewModel.bookingDetailsModel.data?.type ==
            "Challenge") {
          print("inside Challenge");
          await joinViewModel.getChalllengeBookingDetails(
              context: context,
              challenggid: joinViewModel.bookingDetailsModel.data?.id ?? "");
        }
      }

      {
        _updateTimeLeft();
        _timer = Timer.periodic(
            const Duration(seconds: 60), (_) => _updateTimeLeft());
      }
    });
  }

  String amt = "";
  String time = "";
  bool ischallenge = false;
  CompleteChallengeDetailModel? completeChallengeDetailModel;
  String? timeDiffText;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final joinViewModel = Provider.of<HomeViewModel>(context, listen: false);

    final args = ModalRoute.of(context)?.settings.arguments;

    if (args is Map && args.containsKey('amount')) {
      amt = args['amount'].toString();
      printLog("amount > $amt ");
    }
    if (args is Map && args.containsKey('bookingStartTime')) {
      time = args['bookingStartTime'].toString();
      printLog("bookingStartTime > $time ");
    }

    if (args is Map && args.containsKey('ischallenge')) {
      ischallenge = args['ischallenge'];
      printLog("ischallenge > $ischallenge ");
    }

    if (ischallenge) {
      if (args is Map && args.containsKey('data')) {
        completeChallengeDetailModel = args['data'];
        printLog("data > ${completeChallengeDetailModel?.data} ");
        timeDiffText = formatTimeDifference(
            completeChallengeDetailModel?.data?.bookingStartTime ?? "");
      }
    }
    if (joinViewModel.bookingDetailsModel.data?.type == "Court")
      timeDiffText = formatTimeDifference(
          joinViewModel.bookingDetailsModel?.data?.bookingstarttime ?? "");
  }

  void _updateTimeLeft() {
    final joinViewModel = Provider.of<HomeViewModel>(context, listen: false);
    print("---> ${joinViewModel.bookingDetailsModel.data?.startTime}");
    print("---> ${joinViewModel.bookingDetailsModel.data?.slotId?.day}");
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  double calculateRemainingToBePaidByFriends(BookingDetailsModel bookingData) {
    final data = bookingData.data;
    final double totalPrice = (data?.price ?? 0.0).toDouble();
    final List<Friend> friends = data?.friends ?? [];
    print(".......friends....$friends");

    if (friends.isEmpty) {
      return 0.0;
    }

    int totalPlayers = friends.length + 1; // 1 for the main user
    double perPlayerAmount = totalPrice / totalPlayers;

    double paidFriendsAmount = 0.0;

    for (var friend in friends) {
      bool isPaid = friend.isPaid ?? false;

      double splitAmount = (bookingData.data?.price ?? 0).toDouble();

      if (isPaid) {
        paidFriendsAmount += splitAmount;
      }
    }

    double remainingAmount = totalPrice - perPlayerAmount - paidFriendsAmount;
    return remainingAmount;
  }

  //new
  double calculateRemainingToBePaidByChallengeFriends(
      CompleteChallengeDetailModel? challengeData) {
    // Return 0.0 if challengeData or data is null
    if (challengeData?.data == null) {
      return 0.0;
    }

    final data = challengeData!.data!;
    // Return 0.0 if friends list is null or empty
    if (data.friends == null || data.friends!.isEmpty) {
      return 0.0;
    }

    // Calculate total by summing splitAmount for each friend, defaulting to 0 for null splitAmount
    final double remainingAmount = data.friends!
        .fold(0.0, (sum, friend) => sum + (friend.splitAmount ?? 0))
        .toDouble();

    return remainingAmount;
  }

  @override
  Widget build(BuildContext context) {
    final joinViewModel = Provider.of<HomeViewModel>(context);

    // final viewModel = Provider.of<BookingProvider>(context);

    double screenWidth = MediaQuery.of(context).size.width;
    return PopScope(
      canPop: true,
      child: Scaffold(
        bottomNavigationBar: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
            child: AppButtonCommon(
              onPressed: () {
                Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                        builder: (_) => DashboardScreen(
                              initialIndex: 0,
                            )),
                    (route) => false);
              },
              label: l10n.of(context).goToHome,
            ),
          ),
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.only(
                  left: screenWidth * 0.04, right: screenWidth * 0.04, top: 30),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    width: screenWidth,
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 24),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: AppColors.green8B2),
                    child: Column(
                      children: [
                        Text(l10n.of(context).sharePaymentLink,
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w700,
                                color: Colors.black)),
                        SizedBox(height: 16),
                        Text(
                          l10n
                              .of(context)
                              .allPlayersWillUseThisLinkToMakentheirSplitPayment,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.normal,
                              color: Colors.black),
                        ),
                        SizedBox(height: 16),
                        Container(
                          width: screenWidth - 100,
                          padding: EdgeInsets.symmetric(
                              horizontal: 15, vertical: 11),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Colors.white),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('KratEasy.com/LHYN20568231',
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.black)),
                              InkWell(
                                onTap: () {
                                  shareData('KratEasy.com/LHYN20568231');
                                },
                                child: SizedBox(
                                    height: 24,
                                    width: 24,
                                    child:
                                        Image.asset('assets/icons/share2.png')),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(height: 8),
                      // Text(
                      //     (joinViewModel.bookingDetailsModel.data?.friends
                      //                 ?.isEmpty ==
                      //             false)
                      //         ? "${joinViewModel.bookingDetailsModel.data!.friends!.length} ${S.of(context).players}"
                      //         : "",
                      //     style: TextStyle(
                      //         fontSize: 15,
                      //         fontWeight: FontWeight.w600,
                      //         color: AppColors.black555)),
                      SizedBox(height: 8),

                      SizedBox(height: 20),

                      /// circle data
                      if (completeChallengeDetailModel?.data?.type ==
                          "Challenge") ...{
                        if (timeDiffText != "-0 sec") ...{
                          Text(
                            "Remaining Start Time ",
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Text(timeDiffText ?? ""),
                        },
                        SizedBox(height: 20),
                        Stack(
                          children: [
                            Container(
                              width: 220,
                              height: 220,
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(
                                      colors: AppColors.dark348Green62ELg,
                                      begin: Alignment.topCenter,
                                      end: Alignment.bottomCenter)),
                            ),
                            Positioned(
                              left: 10,
                              top: 10,
                              child: Container(
                                width: 200,
                                height: 200,
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: AppColors.white),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(l10n.of(context).paid,
                                        style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.w500,
                                            color: AppColors.black555)),
                                    SizedBox(height: 8),
                                    Text(
                                        ischallenge
                                            ? '${AppConstants.appCurrency}${(completeChallengeDetailModel?.data?.friends == null || completeChallengeDetailModel!.data!.friends!.isEmpty) ? "$amt" : completeChallengeDetailModel?.data?.friends?[0].splitAmount}'
                                            : '${AppConstants.appCurrency}${joinViewModel.bookingDetailsModelNew.data?.paidAmount == null ? "$amt" : joinViewModel.bookingDetailsModelNew.data!.paidAmount}',
                                        style: TextStyle(
                                            fontSize: 23,
                                            fontWeight: FontWeight.w700,
                                            color: AppColors.green67B)),
                                    Divider(
                                        thickness: 2,
                                        color: AppColors.black555
                                            .withValues(alpha: .1)),
                                    if (completeChallengeDetailModel
                                            ?.data?.isPublic ==
                                        true) ...{
                                      Text(
                                          '${AppConstants.appCurrency}${(joinViewModel.challlengebookingDetailsModel.data?.leftAmount)?.toStringAsFixed(2)}',
                                          style: TextStyle(
                                              fontSize: 23,
                                              fontWeight: FontWeight.w700,
                                              color: AppColors.black)),
                                    } else
                                      Text(
                                          ischallenge
                                              ? '${AppConstants.appCurrency}${calculateRemainingToBePaidByChallengeFriends(completeChallengeDetailModel).toStringAsFixed(0)}'
                                              : '${AppConstants.appCurrency}${calculateRemainingToBePaidByFriends(joinViewModel.bookingDetailsModel).toStringAsFixed(2)}',
                                          style: TextStyle(
                                              fontSize: 23,
                                              fontWeight: FontWeight.w700,
                                              color: AppColors.black)),
                                    SizedBox(height: 8),
                                    Text(l10n.of(context).left,
                                        style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.w500,
                                            color: AppColors.black555)),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        )
                      } else ...[
                        Stack(
                          children: [
                            Container(
                              width: 220,
                              height: 220,
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(
                                      colors: AppColors.dark348Green62ELg,
                                      begin: Alignment.topCenter,
                                      end: Alignment.bottomCenter)),
                            ),
                            Positioned(
                              left: 10,
                              top: 10,
                              child: Container(
                                width: 200,
                                height: 200,
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: AppColors.white),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(l10n.of(context).paid,
                                        style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.w500,
                                            color: AppColors.black555)),
                                    SizedBox(height: 8),
                                    Text(
                                        ischallenge
                                            ? '${AppConstants.appCurrency}${(completeChallengeDetailModel?.data?.friends == null || completeChallengeDetailModel!.data!.friends!.isEmpty) ? "$amt" : completeChallengeDetailModel?.data?.friends?[0].splitAmount}'
                                            : '${AppConstants.appCurrency}${joinViewModel.bookingDetailsModelNew.data?.paidAmount == null ? "$amt" : joinViewModel.bookingDetailsModelNew.data!.paidAmount}',
                                        style: TextStyle(
                                            fontSize: 23,
                                            fontWeight: FontWeight.w700,
                                            color: AppColors.green67B)),
                                    Divider(
                                        thickness: 2,
                                        color: AppColors.black555
                                            .withValues(alpha: .1)),
                                    if (completeChallengeDetailModel
                                            ?.data?.isPublic ==
                                        true) ...{
                                      Text(
                                          '${AppConstants.appCurrency}${joinViewModel.bookingDetailsModelNew.data?.leftAmount == null ? "$amt" : joinViewModel.bookingDetailsModelNew.data!.paidAmount}',
                                          style: TextStyle(
                                              fontSize: 23,
                                              fontWeight: FontWeight.w700,
                                              color: AppColors.black)),
                                    } else
                                      Text(
                                          ischallenge
                                              ? '${AppConstants.appCurrency}${calculateRemainingToBePaidByChallengeFriends(completeChallengeDetailModel).toStringAsFixed(0)}'
                                              : '${AppConstants.appCurrency}${calculateRemainingToBePaidByFriends(joinViewModel.bookingDetailsModel).toStringAsFixed(2)}',
                                          style: TextStyle(
                                              fontSize: 23,
                                              fontWeight: FontWeight.w700,
                                              color: AppColors.black)),
                                    SizedBox(height: 8),
                                    Text(l10n.of(context).left,
                                        style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.w500,
                                            color: AppColors.black555)),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 10),
                        if (timeDiffText != "-0 sec") ...{
                          Text(
                            "Remaining Start Time ",
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Text(timeDiffText ?? ""),
                        },
                      ],
                      // SizedBox(height: 30),

                      if (completeChallengeDetailModel
                              ?.data?.friends?.isNotEmpty ??
                          false)
                        SizedBox(
                          height: 190,
                          child: ListView.builder(
                            itemCount: completeChallengeDetailModel
                                ?.data?.friends?.length,
                            scrollDirection: Axis.horizontal,
                            itemBuilder: (context, index) {
                              var item = completeChallengeDetailModel
                                  ?.data!.friends?[index];
                              return Padding(
                                padding: const EdgeInsets.only(right: 13),
                                child: SizedBox(
                                  width: 75,
                                  child: Column(
                                    children: [
                                      SizedBox(height: 5),
                                      Image.asset("assets/png/user_logo.png",
                                          width: 65, height: 65),
                                      Text(item?.name ?? "",
                                          maxLines: 2,
                                          style: TextStyle(
                                              overflow: TextOverflow.ellipsis,
                                              fontSize: 13,
                                              fontWeight: FontWeight.w500,
                                              color: AppColors.black555)),
                                      Spacer(),
                                      Text(
                                          '${AppConstants.appCurrency}${item?.splitAmount ?? 0}',
                                          style: TextStyle(
                                              fontSize: 18,
                                              fontWeight: FontWeight.w500,
                                              color: AppColors.black)),
                                      SizedBox(height: 5),
                                      AppButton(
                                        height: 30,
                                        width: 70,
                                        radius: 5,
                                        label: item?.isPaid == true
                                            ? 'Paid'
                                            : "Pay",
                                        textStyle: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.w600,
                                            color: AppColors.black),
                                        onPressed: () {
                                          if (item?.isPaid == false) {
                                            print("pay1ijii");
                                            print(completeChallengeDetailModel
                                                    ?.data?.bookingId ??
                                                "");
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        FriendPayment(
                                                          frienddid:
                                                              item?.id ?? "",
                                                          playerid:
                                                              item?.playerid ??
                                                                  "",
                                                          challlengeid:
                                                              completeChallengeDetailModel
                                                                      ?.data
                                                                      ?.id ??
                                                                  "",
                                                          amount:
                                                              item?.splitAmount,
                                                          bookingid:
                                                              completeChallengeDetailModel
                                                                      ?.data
                                                                      ?.bookingId ??
                                                                  "",
                                                        )));

                                            // context.read<HomeViewModel>().paymentfriendsApi(friendid: item?.id??"", context: context,id: completeChallengeDetailModel?.data?.id??"");
                                          }
                                        },
                                        bgColor: item?.isPaid == false
                                            ? AppColors.primaryColor
                                            : AppColors.grey3E3,
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                        )
                      else if (joinViewModel
                              .bookkingcourt.data?.friends?.isNotEmpty ??
                          false)
                        SizedBox(
                          height: 190,
                          child: ListView.builder(
                            itemCount: joinViewModel
                                .bookingDetailsModel.data?.friends?.length,
                            scrollDirection: Axis.horizontal,
                            itemBuilder: (context, index) {
                              var item = joinViewModel
                                  .bookingDetailsModel.data!.friends?[index];
                              return Padding(
                                padding: const EdgeInsets.only(right: 13),
                                child: SizedBox(
                                  width: 75,
                                  child: Column(
                                    children: [
                                      SizedBox(height: 5),
                                      Image.asset("assets/png/user_logo.png",
                                          width: 65, height: 65),
                                      Text(item?.name ?? "",
                                          maxLines: 2,
                                          style: TextStyle(
                                              overflow: TextOverflow.ellipsis,
                                              fontSize: 13,
                                              fontWeight: FontWeight.w500,
                                              color: AppColors.black555)),
                                      Spacer(),
                                      Text(
                                          '${AppConstants.appCurrency}${item?.splitAmount ?? 0}',
                                          style: TextStyle(
                                              fontSize: 18,
                                              fontWeight: FontWeight.w500,
                                              color: AppColors.black)),
                                      SizedBox(height: 5),
                                      AppButton(
                                        height: 30,
                                        width: 70,
                                        radius: 5,
                                        label: item?.isPaid == true
                                            ? 'Paid'
                                            : "Pay",
                                        textStyle: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.w600,
                                            color: AppColors.black),
                                        onPressed: () {
                                          if (item?.isPaid == false) {
                                            print("ffkffi");
                                            // context.read<HomeViewModel>().paymentfriendsApi(friendid: item?.id??"", context: context,id: joinViewModel.bookingDetailsModel.data?.id??"");
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) => FriendPayment(
                                                        frienddid:
                                                            item?.id ?? "",
                                                        playerid:
                                                            item?.playerid ??
                                                                "",
                                                        challlengeid: joinViewModel
                                                                ?.bookingDetailsModel
                                                                .data
                                                                ?.id ??
                                                            "",
                                                        amount:
                                                            item?.splitAmount ??
                                                                0)));
                                          }
                                        },
                                        bgColor: item?.isPaid == false
                                            ? AppColors.primaryColor
                                            : AppColors.grey3E3,
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                        ),

                      if (joinViewModel.bookingDetailsModel.data?.type ==
                              "Court" &&
                          (joinViewModel.bookingDetailsModel?.data?.friends
                                  ?.isNotEmpty ??
                              false))
                        if (completeChallengeDetailModel?.data?.type !=
                            "Challenge")
                          SizedBox(
                            height: 190,
                            child: ListView.builder(
                              itemCount: joinViewModel
                                  .bookingDetailsModel.data?.friends?.length,
                              scrollDirection: Axis.horizontal,
                              itemBuilder: (context, index) {
                                var item = joinViewModel
                                    .bookingDetailsModel.data!.friends?[index];
                                return Padding(
                                  padding: const EdgeInsets.only(right: 13),
                                  child: SizedBox(
                                    width: 75,
                                    child: Column(
                                      children: [
                                        SizedBox(height: 5),
                                        Image.asset("assets/png/user_logo.png",
                                            width: 65, height: 65),
                                        Text(item?.name ?? "",
                                            maxLines: 2,
                                            style: TextStyle(
                                                overflow: TextOverflow.ellipsis,
                                                fontSize: 13,
                                                fontWeight: FontWeight.w500,
                                                color: AppColors.black555)),
                                        Spacer(),
                                        Text(
                                            '${AppConstants.appCurrency}${item?.splitAmount ?? 0}',
                                            style: TextStyle(
                                                fontSize: 18,
                                                fontWeight: FontWeight.w500,
                                                color: AppColors.black)),
                                        SizedBox(height: 5),
                                        AppButton(
                                          height: 30,
                                          width: 70,
                                          radius: 5,
                                          label: item?.isPaid == true
                                              ? 'Paid'
                                              : "Pay",
                                          textStyle: TextStyle(
                                              fontSize: 15,
                                              fontWeight: FontWeight.w600,
                                              color: AppColors.black),
                                          onPressed: () {
                                            if (item?.isPaid == false) {
                                              printLog("text");
                                              printLog(
                                                  "${joinViewModel?.bookingDetailsModel.data?.bookingId ?? ""}");
                                              // context.read<HomeViewModel>().paymentfriendsApi(friendid: item?.id??"", context: context,id: joinViewModel.bookingDetailsModel.data?.id??"");
                                              Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                      builder: (context) =>
                                                          FriendPayment(
                                                            frienddid:
                                                                item?.id ?? "",
                                                            playerid:
                                                                item?.playerid ??
                                                                    "",
                                                            challlengeid:
                                                                joinViewModel
                                                                        ?.bookingDetailsModel
                                                                        .data
                                                                        ?.id ??
                                                                    "",
                                                            amount:
                                                                item?.splitAmount ??
                                                                    0,
                                                            booktype: 'booking',
                                                            bookingid:
                                                                "${joinViewModel?.bookingDetailsModel.data?.bookingId ?? ""}",
                                                          )));
                                            }
                                          },
                                          bgColor: item?.isPaid == false
                                              ? AppColors.primaryColor
                                              : AppColors.grey3E3,
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                    ],
                  ),
                  SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  String formatTimeDifference(String apiTimeString) {
    DateTime apiDate;

    if (apiTimeString.trim().isEmpty) {
      apiDate = DateTime.now().toUtc(); // Fallback to current time
      // context.read<AvailableChallengeGuestViewModel>().challengestarttime.isNotEmpty?
      //  apiDate = DateTime.parse(
      //   context.read<AvailableChallengeGuestViewModel>().challengestarttime,
      // ):apiDate = DateTime.now().toUtc();
    } else {
      apiDate = DateTime.parse(apiTimeString).toUtc();
    }

    final DateTime now = DateTime.now().toUtc();
    final Duration diff = apiDate.difference(now);
    final bool isNegative = diff.isNegative;
    final Duration absDiff = diff.abs();

    final int hours = absDiff.inHours;
    final int minutes = absDiff.inMinutes.remainder(60);
    final int seconds = absDiff.inSeconds.remainder(60);

    String formatted = '';
    if (hours > 0) formatted += '$hours hr ';
    if (minutes > 0) formatted += '$minutes min ';
    if (seconds > 0 || formatted.isEmpty) formatted += '$seconds sec';

    if (isNegative) {
      formatted = '-$formatted';
    }

    return formatted.trim();
  }
}
