
import 'dart:io';
import 'package:country_code_picker/country_code_picker.dart';
import 'package:country_picker/country_picker.dart';
import 'package:flutter/services.dart';
import 'package:kratEasyApp/API_CALLS/GlobalAPIUtils.dart';
import 'package:kratEasyApp/BottomNavScreens/FacilityBookingScreen/PaymentOption.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/repository/social_login_repository.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../paymentprovider.dart';
import 'ffriend_success_payment.dart';

class FriendPayment extends StatefulWidget {
  final String bookingid;
  final String frienddid;
  final String playerid;
  final String challlengeid;
  final String ?courtid;
  final String ?member;
  final dynamic amount;
  final String booktype;
  const FriendPayment({  this.courtid="", this.member ="",this.bookingid="",
    super.key, required this.frienddid, required this.challlengeid, required this.amount, required this.playerid,this.booktype = "challenge"
  });
  @override
  State<FriendPayment> createState() => _FriendPaymentState();
}

class _FriendPaymentState extends State<FriendPayment> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late String courtId;
  late String requestDate;
  late List<String> availableTimes;
  late List<String> selectedSlots;
  late String sportId;


  bool fromGuest = false;
  bool fromGuestChallenge = false;
  String? checkToken;
  String? challengeId;
  String amount = "";
  String type = "";

  // Default value
  bool forChallenge = false; // Default value
  late BookingProvider bookingViewModel;

  @override
  void initState() {
    super.initState();
    // Initialize BookingProvider and other non-context-dependent logic
    bookingViewModel = context.read<BookingProvider>();
    String dateOnly = DateFormat('dd-MM-yyyy').format(DateTime.now());
    print("dateonlue => $dateOnly");
    bookingViewModel.isChecked = false;
    bookingViewModel.phoneController.clear();
    bookingViewModel.otpController.clear();
    bookingViewModel.countryCodeController.text = "44"; // Default UK code
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      checkToken = await GlobalAPIUtils.getAuthToken();
     await payment();
      // This runs after the first frame is rendered
      final args = ModalRoute.of(context)?.settings.arguments as Map?;
      if (args != null) {
        setState(() {
          amount = args['amount']?.toString() ?? "0.0";
        });
      }
    });
  }

  SharedPreferences? pref;
  @override
  void didChangeDependencies() async {
    super.didChangeDependencies();
    String dateOnly = DateFormat('dd-MM-yyyy').format(DateTime.now());

    pref = await SharedPreferences.getInstance();
    // Retrieve arguments passed from the previous screen in `didChangeDependencies()`
    final args = ModalRoute.of(context)?.settings.arguments as Map?;
    if (args != null) {
      courtId = args['courtId'] ?? "";
      sportId = args['sportId'] ?? "";

      requestDate = args['requestDate'] ?? dateOnly;
      availableTimes = List<String>.from(args['availableTimes'] ?? []);
      selectedSlots = List<String>.from(args['selectedSlots'] ?? []);
      fromGuest = args['fromGuest'] ?? false;
      fromGuestChallenge = args['fromChallenge'] ?? false;
      amount = args['amount']?.toString() ??
          "0.0"; // Set default amount if not passed

      challengeId = args['challengeId'] ?? "";

      forChallenge = args['forChallenge'] == true;



    }
  }



  @override
  Widget build(BuildContext context) {
    print("bookingid ==>${widget.bookingid}");
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    final ValueNotifier<String?> selectedOption = ValueNotifier<String?>(null);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CommonAppBar(
        // title: S.of(context).choosePaymentMethod,
          title:"",
          backIconColor: Colors.white,
          backgroundColor: Colors.white,
          isBack: true),
      body: Center(child: CircularProgressIndicator())
    );
  }

  Future<dynamic> buildSendOtpShowModalBottomSheet(
      BuildContext context, countryCode, phoneNumber)
  {
    // Set values before showing
    final provider = Provider.of<BookingProvider>(context, listen: false);
    printLog("...../////  $countryCode ... $phoneNumber");
    provider.countryCodeController.text = countryCode;
    provider.phoneController.text = phoneNumber;
    provider.startResendOtpTimer();

    return showModalBottomSheet(
      isScrollControlled: true,
      backgroundColor: Colors.white,
      context: context,
      builder: (context) {
        return ListView(
          shrinkWrap: true,
          children: [
            Padding(
              padding: EdgeInsets.only(
                  bottom: MediaQuery.of(context).viewInsets.bottom),
              child: Consumer<BookingProvider>(
                builder:
                    (BuildContext context, viewModelGetUser, Widget? child) {
                  return Container(
                    color: Colors.transparent,
                    padding: EdgeInsets.only(top: 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Align(
                          alignment: Alignment.topRight,
                          child: InkWell(
                            onTap: () {
                              viewModelGetUser.otpController.clear();
                              Navigator.pop(context);
                            },
                            child: Container(
                              height: 30,
                              width: 30,
                              margin: EdgeInsets.only(right: 16),
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: AppColors.white),
                              child: Center(
                                  child: Icon(Icons.clear,
                                      color: AppColors.black)),
                            ),
                          ),
                        ),
                        SizedBox(height: 20),
                        Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 16, vertical: 16),
                          width: double.infinity,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(20),
                                  topRight: Radius.circular(20)),
                              color: AppColors.white),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(l10n.of(context).youreAlmostThere,
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.normal,
                                      color: AppColors.black)),
                              SizedBox(height: 20),
                              Row(
                                mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(l10n.of(context).enterOtp,
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.normal,
                                          color: AppColors.black555)),
                                  Text("+$countryCode $phoneNumber",
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.normal,
                                          color: AppColors.black555)),
                                ],
                              ),
                              SizedBox(height: 20),
                              StatefulBuilder(
                                builder: (context, StateSetter) {
                                  return Column(
                                    children: [
                                      OtpTextFormField(
                                        controller:
                                        viewModelGetUser.otpController,
                                        onchanged: (str) {
                                          setState(() {});
                                        },
                                        isValidator: true,
                                      ),
                                      if (viewModelGetUser.otpErrorMessage !=
                                          null)
                                        Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 8.0),
                                          child: Text(
                                            viewModelGetUser.otpErrorMessage!,
                                            style: TextStyle(
                                              color: Colors.red,
                                              fontSize: 14,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ),
                                      SizedBox(height: 20),
                                      AppButton(
                                        label: l10n.of(context).verifyOtp,
                                        onPressed: () async {
                                          String enteredOtp = viewModelGetUser
                                              .otpController.text;
                                          print('otp: $enteredOtp');

                                          if (enteredOtp.isNotEmpty) {
                                            try {
                                              int otpInt =
                                              int.parse(enteredOtp);
                                              bool isSuccess =
                                              await viewModelGetUser
                                                  .verifyOtp(
                                                context,
                                                otpInt,
                                              );

                                              if (isSuccess) {
                                                Navigator.pop(context);
                                                viewModelGetUser.phoneController
                                                    .clear();
                                                viewModelGetUser.otpController
                                                    .clear();
                                                print(
                                                    "OTP verified successfully!");
                                              } else {
                                                print(
                                                    "OTP verification failed!");
                                              }
                                            } catch (e) {
                                              print("Invalid OTP format: $e");
                                            }
                                          } else {
                                            print("OTP field is empty.");
                                          }
                                        },
                                        textColor: viewModelGetUser
                                            .otpController.text.length >
                                            4
                                            ? AppColors.white
                                            : AppColors.black555,
                                        bgColor: viewModelGetUser
                                            .otpController.text.length >
                                            4
                                            ? AppColors.primaryColor
                                            : AppColors.greyEFEF,
                                      ),
                                    ],
                                  );
                                },
                              ),
                              SizedBox(height: 20),
                              Consumer<BookingProvider>(
                                builder: (context, viewModelGetUser, _) {
                                  return Center(
                                    child: GestureDetector(
                                      onTap: viewModelGetUser.canResendOtp
                                          ? () {
                                        // TODO: trigger OTP resend API
                                        viewModelGetUser
                                            .startResendOtpTimer(); // restart timer
                                        print("Resending OTP...");
                                      }
                                          : null,
                                      child: Text(
                                        viewModelGetUser.canResendOtp
                                            ? l10n.of(context).resendOtp
                                            : "${l10n.of(context).resendIn} ${viewModelGetUser.remainingSeconds}s",
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w700,
                                          color: viewModelGetUser.canResendOtp
                                              ? AppColors.black
                                              : AppColors
                                              .grey8A8, // gray when disabled
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ), // Text("Resend OTP",
                              //     style: TextStyle(
                              //         fontSize: 14,
                              //         fontWeight: FontWeight.w700,
                              //         color: AppColors.black)),
                              SizedBox(height: 20),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  String? _tcErrorMessage;

  Future<dynamic> buildShowModalBottomSheet(BuildContext context) {
    List<String> imgList = [
      "assets/png/png_fb.png",
      if (Platform.isAndroid) "assets/png/png_google.png",
      if (Platform.isIOS) "assets/png/png_apple.png"
    ];
    return showModalBottomSheet(
      isScrollControlled: true,
      backgroundColor: Colors.white,

      context: context,
      isDismissible: false,
      builder: (context) {
        return StatefulBuilder(builder: (context, sateState) {
          return ListView(
            shrinkWrap: true,
            children: [
              Consumer<BookingProvider>(builder:
                  (BuildContext context, viewModelGetUser2, Widget? child) {
                return Padding(
                  padding: EdgeInsets.only(
                      bottom: MediaQuery.of(context).viewInsets.bottom),
                  child: Container(
                    color: Colors.transparent,
                    padding: EdgeInsets.only(top: 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Align(
                          alignment: Alignment.topRight,
                          child: InkWell(
                            onTap: () {
                              _tcErrorMessage = null;
                              Navigator.pop(context);
                            },
                            child: Container(
                              height: 30,
                              width: 30,
                              margin: EdgeInsets.only(right: 16),
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: AppColors.white),
                              child: Center(
                                  child: Icon(Icons.clear,
                                      color: AppColors.black)),
                            ),
                          ),
                        ),
                        SizedBox(height: 20),
                        Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 16, vertical: 16),
                            width: double.infinity,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(20),
                                topRight: Radius.circular(20),
                              ),
                              color: AppColors.white,
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(l10n.of(context).youreAlmostThere,
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.normal,
                                        color: AppColors.black)),
                                SizedBox(height: 20),
                                Text(
                                  l10n.of(context).enterMobileNumber,
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.normal,
                                    color: AppColors.black555,
                                  ),
                                ),
                                SizedBox(height: 20),
                                Form(
                                  key: _formKey,
                                  child: Column(
                                    children: [
                                      AppTextField(
                                        onchanged:
                                        viewModelGetUser2.updatePhoneNumber,
                                        borderColor:
                                        AppColors.teal747D.withOpacity(.5),
                                        controller:
                                        viewModelGetUser2.phoneController,
                                        prefixWidget: CountryCodePicker(
                                          padding: EdgeInsets.zero,
                                          margin: EdgeInsets.only(right: 5),
                                          initialSelection: '+44',
                                          showCountryOnly: false,
                                          showOnlyCountryWhenClosed: false,
                                          alignLeft: false,
                                          backgroundColor: AppColors.white,
                                          dialogBackgroundColor:
                                          AppColors.white,
                                          flagWidth: 25,
                                          flagDecoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                          ),
                                          searchPadding: EdgeInsets.zero,
                                          onInit: (value) {
                                            if (viewModelGetUser2
                                                .countryCodeController
                                                .text
                                                .isEmpty) {
                                              String? rawCode = value?.dialCode;
                                              if (rawCode != null &&
                                                  rawCode.startsWith("+")) {
                                                rawCode = rawCode.substring(1);
                                              }
                                              viewModelGetUser2
                                                  .countryCodeController
                                                  .text = rawCode ?? "44";
                                            }
                                          },
                                          onChanged: (value) {
                                            String? rawCode = value.dialCode;
                                            if (rawCode != null &&
                                                rawCode.startsWith("+")) {
                                              rawCode = rawCode.substring(1);
                                            }
                                            viewModelGetUser2
                                                .countryCodeController
                                                .text = rawCode ?? "44";
                                          }, // onChanged: (value) {

                                        ),
                                        validator: (value) {

                                          if (value == null || value.isEmpty) {
                                            return l10n
                                                .of(context)
                                                .pleaseEnterYourPhoneNumber;
                                          }
                                          if (!RegExp(r'^\d{8,12}$')
                                              .hasMatch(value)) {
                                            return l10n
                                                .of(context)
                                                .phoneNumberMustBe810Digits;
                                          }
                                          return null;
                                        },
                                        inputFormatters: [
                                          FilteringTextInputFormatter
                                              .digitsOnly,
                                          LengthLimitingTextInputFormatter(12)
                                        ],
                                        height: 42,
                                        hintText: l10n
                                            .of(context)
                                            .enter810DigitPhoneNumber,
                                        keyboardType: TextInputType.number,
                                      ),
                                      SizedBox(height: 20),
                                      StatefulBuilder(
                                          builder: (context, setState) {
                                            return AppButton(
                                              label: l10n.of(context).sendOtp,
                                              onPressed: () async {
                                                sateState(() {
                                                  _tcErrorMessage = null;
                                                  viewModelGetUser2
                                                      .otpErrorMessage = null;
                                                });

                                                if (!_formKey.currentState!
                                                    .validate()) {
                                                  return;
                                                }

                                                if (!viewModelGetUser2.isChecked) {
                                                  sateState(() {
                                                    _tcErrorMessage = l10n
                                                        .of(context)
                                                        .pleaseAcceptTheTermsConditionsToContinue;
                                                  });
                                                  return;
                                                }

                                                String phoneNumber =
                                                    viewModelGetUser2
                                                        .phoneController.text;
                                                String countryCode =
                                                    viewModelGetUser2
                                                        .countryCodeController.text;
                                                String fullPhoneNumber =
                                                    "$countryCode$phoneNumber";
                                                print(
                                                    "Full Phone Number GUEST FLOW: $fullPhoneNumber");
                                                print(
                                                    "CONTRY CODE GUEST FLOW: $countryCode");

                                                bool isSuccess =
                                                await viewModelGetUser2
                                                    .sendOtpRequest(countryCode1:   countryCode,
                                                    phoneNumber1:    phoneNumber);

                                                if (isSuccess) {
                                                  Navigator.pop(context);
                                                  buildSendOtpShowModalBottomSheet(
                                                      context,
                                                      countryCode,
                                                      phoneNumber);
                                                } else {
                                                  setState(() {
                                                    viewModelGetUser2
                                                        .otpErrorMessage =
                                                        l10n
                                                            .of(context)
                                                            .failedToSendOtpPleaseTryAgain;
                                                  });
                                                  _formKey.currentState!.validate();
                                                }
                                              },
                                              textColor: viewModelGetUser2.isFilled
                                                  ? AppColors.white
                                                  : AppColors.black555,
                                              bgColor: viewModelGetUser2.isFilled
                                                  ? AppColors.primaryColor
                                                  : AppColors.greyEFEF,
                                            );
                                          }),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 20),
                                Row(
                                  children: [
                                    SizedBox(
                                      height: 20,
                                      width: 20,
                                      child: Checkbox(
                                        checkColor: AppColors.white,
                                        overlayColor: WidgetStateProperty.all(
                                            AppColors.black),
                                        fillColor: WidgetStateProperty.all(
                                            viewModelGetUser2.isChecked == false
                                                ? AppColors.white
                                                : AppColors.black),
                                        value: viewModelGetUser2.isChecked,
                                        onChanged: (bool? value) {
                                          viewModelGetUser2
                                              .updateCheckedButton();
                                          setState(() {
                                            _tcErrorMessage = null;
                                          });
                                        },
                                      ),
                                    ),
                                    SizedBox(width: 5),
                                    RichText(
                                      text: TextSpan(
                                        text: l10n.of(context).agreeWith,
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.normal,
                                            color: AppColors.grey769),
                                        children: [
                                          TextSpan(
                                            text: l10n
                                                .of(context)
                                                .termsAndConditions,
                                            style: TextStyle(
                                                fontSize: 14,
                                                fontWeight: FontWeight.normal,
                                                color: AppColors.black),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 5),
                                if (_tcErrorMessage != null)
                                  Padding(
                                    padding: const EdgeInsets.only(left: 4),
                                    child: Text(
                                      _tcErrorMessage!,
                                      style: TextStyle(
                                          color: Colors.red, fontSize: 12),
                                    ),
                                  ),
                                SizedBox(height: 20),
                                Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded(
                                      child: Container(
                                        height: 1,
                                        width:
                                        (MediaQuery.of(context).size.width /
                                            2) -
                                            50,
                                        color: AppColors.greyBEBE,
                                      ),
                                    ),
                                    Padding(
                                      padding:
                                      EdgeInsets.symmetric(horizontal: 5),
                                      child: Text(l10n.of(context).or,
                                          style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.normal,
                                              color: AppColors.grey769)),
                                    ),
                                    Container(
                                      height: 1,
                                      width:
                                      (MediaQuery.of(context).size.width /
                                          2) -
                                          35,
                                      color: AppColors.greyBEBE,
                                    ),
                                  ],
                                ),
                                SizedBox(height: 20),
                                Row(
                                  spacing: 10,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children:
                                  List.generate(imgList.length, (index) {
                                    return InkWell(
                                      onTap: () async {
                                        switch (index) {
                                          case 0:


                                            await SocialLoginRepository
                                                .signInWithFacebook(context:context)
                                                .then(
                                                  (value) {
                                                /// TODO: implement sign in with facebook
                                              },
                                            );

                                            return;
                                          case 1:
                                            if (Platform.isIOS) {
                                              await SocialLoginRepository
                                                  .loginWithApple(context)
                                                  .then(
                                                    (value) {
                                                  /// TODO: implement sign in with facebook
                                                },
                                              );
                                            } else {
                                              await SocialLoginRepository
                                                  .signInWithGoogle(context)

                                                  .then(
                                                    (value) {
                                                  if (value["isSuccess"]) {
                                                  }
                                                },
                                              );
                                            }

                                            return;

                                          default:
                                            return;
                                        }
                                      },
                                      child: SizedBox(
                                        width: 54,
                                        height: 54,
                                        child: Image.asset(imgList[index],
                                            fit: BoxFit.fill),
                                      ),
                                    );
                                  }),
                                ),
                                SizedBox(height: 20),
                              ],
                            )),
                      ],
                    ),
                  ),
                );
              }),
            ],
          );
        });
      },
    );
  }


  Future<void> payment () async {


    try {
      printLog("Proceeding with payment...");
      printLog("Proceeding with payment...");

      final myaccount = context.read<MyAccountViewModel>();
      final booking = context.read<BookingProvider>();
      final paymentProvider = context.read<PaymentProvider>();
      print("==${widget.amount}");
      // await paymentProvider.createOrderWithToken(
      //     context,
      //     widget.amount,
      //     booking.isSplit,
      //     myaccount.email,
      //     myaccount.name,
      //     myaccount.mobileno,
      //     myaccount.countryCode,widget.challlengeid, widget.playerid,type: widget.booktype
      // );
      final details = await context
          .read<PaymentProvider>()
          .fetchPaymentDetails( widget.bookingid);

      if (details != null) {
      final result=  await context
            .read<PaymentProvider>()
            .stripePayment(context,
        context.read<PaymentProvider>().lastPaymentDetails?.amount??"",true,context.read<PaymentProvider>().lastPaymentDetails?.courtId??"",
          widget.playerid,context.read<PaymentProvider>().lastPaymentDetails?.member.toString()??"",context.read<PaymentProvider>().lastPaymentDetails?.slotId??[],
            context.read<PaymentProvider>().lastPaymentDetails?.date.toString(),context.read<PaymentProvider>().lastPaymentDetails?.bookingId);

        if(result){
          await context
              .read<HomeViewModel>()
              .paymentfriendsApi(
            friendid: widget.playerid,
            context: context,
            id: widget.challlengeid,
          );
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => FriendSuccessPayment(),
            ),
          );
        }
        // success — you can use details.amount, details.status, etc.
        // e.g., if you only want to proceed when status is "preauth" or "succeeded"
        // if (details.status.toLowerCase() == 'preauth') {
        //   // do next steps...
        // }
      } else {
        // handle null / show error
      }


      // if (paymentProvider.success == true) {
      //   await context
      //       .read<HomeViewModel>()
      //       .paymentfriendsApi(
      //     friendid: widget.playerid,
      //     context: context,
      //     id: widget.challlengeid,
      //   );
      //   Navigator.push(
      //     context,
      //     MaterialPageRoute(
      //       builder: (context) => FriendSuccessPayment(),
      //     ),
      //   );
      // } else {
      //   print("Payment failed.");
      // }
    } catch (e, stackTrace) {
      print("Error occurred: $e");
      print("Stacktrace: $stackTrace");
    }
  }
}
