// import 'package:easy_date_timeline/easy_date_timeline.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter_contacts/flutter_contacts.dart';
// import 'package:kratEasyApp/EntranceScreens/contact_model.dart';
// import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
// import 'package:kratEasyApp/utils/extension.dart';

// class BookingScreen extends StatefulWidget {
//   const BookingScreen({super.key});

//   @override
//   State<BookingScreen> createState() => _BookingScreenState();
// }

// class _BookingScreenState extends State<BookingScreen> {
//   final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

//   // late GuestUserProvider viewModel;
//   @override
//   void initState() {
//     BookingProvider viewModel = context.read<BookingProvider>();
//     super.initState();
//     viewModel.selectedDate = DateTime.now();
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       viewModel.getSlots();
//       viewModel.getContacts();
//       viewModel.phoneController.clear();
//       viewModel.otpController.clear();
//       viewModel.countryCodeController.clear();
//       Provider.of<BookingProvider>(context, listen: false).getContacts();
//     });
//   }

//   @override
//   void didChangeDependencies() {
//     // TODO: implement didChangeDependencies
//     super.didChangeDependencies();
//     BookingProvider viewModel = context.read<BookingProvider>();

//     viewModel.userData.clear();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Consumer<BookingProvider>(
//       builder: (context, viewModel, _) {
//         final courtName =
//             context.read<FacilitiesViewModel>().selectedCourt?.name ?? "";
//         return Scaffold(
//           backgroundColor: Colors.white,
//           appBar: CommonAppBar(title: "Booking", bg: Colors.white),
//           bottomNavigationBar: Container(
//             padding: EdgeInsets.only(left: 16, right: 16, bottom: 16, top: 16),
//             decoration: BoxDecoration(color: AppColors.white, boxShadow: [
//               BoxShadow(
//                   color: AppColors.black.withOpacity(.1),
//                   blurRadius: 10,
//                   offset: Offset(0, -4))
//             ]),
//             child: Row(
//               children: [
//                 Expanded(
//                   flex: 4,
//                   child: AppButton(
//                     label: viewModel.userData.isEmpty
//                         ? '£${viewModel.slotPrice.toStringAsFixed(2)}'
//                         : viewModel.friendsPrice
//                             .toString(), // Displaying as currency with 2 decimal places
//                     textColor: AppColors.black,
//                     disabledColor: AppColors.primaryColor.withOpacity(.2),
//                   ),
//                 ),
//                 SizedBox(width: 13),
//                 Expanded(
//                   flex: 6,
//                   child: AppButton(
//                     label: "Checkout",
//                     onPressed: () async {
//                       // viewModel.navigateToGuestPaymentScreen(context: context, fromGuest: false, amount: viewModel.bookingPrice.toString());
//                       //
//                       // String? authToken = await GlobalAPIUtils.getAuthToken();
//                       //
//                       // if (authToken == null || authToken.isEmpty) {
//                       //   buildShowModalBottomSheet(context);
//                       // } else {
//                       //   final viewModel = Provider.of<GuestUserProvider>(context, listen: false);
//                       //
//                       //   final responseMessage = await viewModel.callBookingAPI(context);
//                       //
//                       //   if (responseMessage == "Court already booked at this time. Wait until booking is completed.") {
//                       //     ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(responseMessage), backgroundColor: Colors.red));
//                       //   } else if (responseMessage == "Booking successful") {
//                       //     viewModel.navigateToGuestPaymentScreen(context);
//                       //   } else {
//                       //     ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(responseMessage), backgroundColor: Colors.orange));
//                       //   }
//                       // }
//                     },
//                     textColor: AppColors.black,
//                     bgColor: AppColors.white,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           body: SafeArea(
//             child: SingleChildScrollView(
//               child: Padding(
//                 padding: EdgeInsets.symmetric(horizontal: 16),
//                 child: Consumer<BookingProvider>(
//                   builder: (BuildContext context, viewModel, Widget? child) {
//                     return Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         SizedBox(
//                           height: 10,
//                         ),
//                         Row(
//                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                           children: [
//                             Text(courtName.capitalizeFirstLetter(),
//                                 style: TextStyle(
//                                     color: AppColors.black,
//                                     fontSize: 20,
//                                     fontWeight: FontWeight.w600)),
//                             Text(
//                               viewModel.userData.isEmpty
//                                   ? '£${viewModel.slotPrice.toStringAsFixed(2)}'
//                                   : viewModel.friendsPrice
//                                       .toString(), // Displaying as currency with 2 decimal places
//                               style: TextStyle(
//                                   fontSize: 20,
//                                   color: AppColors.black,
//                                   fontWeight: FontWeight.w600),
//                             ),
//                           ],
//                         ),
//                         const SizedBox(height: 10),
//                         Row(
//                           children: [
//                             Image.asset('assets/icons/clock.png',
//                                 width: 18, height: 18),
//                             const SizedBox(width: 5),
//                             const Text("Min. Time to Book: ",
//                                 style: TextStyle(
//                                     fontSize: 16,
//                                     fontWeight: FontWeight.normal,
//                                     color: AppColors.black555)),
//                             Text("1 Hour",
//                                 style: TextStyle(
//                                     fontSize: 16,
//                                     color: AppColors.black555,
//                                     fontWeight: FontWeight.w700)),
//                           ],
//                         ),
//                         const SizedBox(height: 10),
//                         Divider(),
//                         const SizedBox(height: 10),
//                         Align(
//                           alignment: Alignment.topRight,
//                           child: GestureDetector(
//                             onTap: () async {
//                               final DateTime? pickedDate = await showDatePicker(
//                                 context: context,
//                                 initialDate:
//                                     viewModel.selectedDate ?? DateTime.now(),
//                                 firstDate: DateTime.now(),
//                                 lastDate:
//                                     DateTime.now().add(Duration(days: 365)),
//                               );
//                               if (pickedDate != null) {
//                                 await viewModel.updateSelectedDate(pickedDate);
//                               }
//                             },
//                             child: Text("Select Date",
//                                 style: const TextStyle(
//                                     decoration: TextDecoration.underline,
//                                     fontSize: 14,
//                                     color: AppColors.black,
//                                     fontWeight: FontWeight.w600)),
//                           ),
//                         ),

//                         const SizedBox(height: 10),
//                         EasyDateTimeLinePicker.itemBuilder(
//                           firstDate: DateTime.now(),
//                           lastDate: DateTime.now().add(Duration(days: 30)),
//                           headerOptions:
//                               HeaderOptions(headerType: HeaderType.none),
//                           focusedDate: DateTime.now(),
//                           itemExtent: 56.0,
//                           itemBuilder: (context, date, isSelected, isDisabled,
//                               isToday, onTap) {
//                             bool isSelectedDate = viewModel.selectedDate == null
//                                 ? false
//                                 : (dateOnly(date) ==
//                                     dateOnly(viewModel.selectedDate!));
//                             return InkResponse(
//                               onTap: () async {
//                                 await viewModel.updateSelectedDate(date);
//                               },
//                               child: Container(
//                                 height: 80,
//                                 width: 50,
//                                 padding: EdgeInsets.all(10),
//                                 decoration: BoxDecoration(
//                                   border: Border.all(
//                                     width: 2,
//                                     color: isSelectedDate
//                                         ? AppColors.primaryColor
//                                         : Colors.transparent,
//                                   ),
//                                   borderRadius: BorderRadius.vertical(
//                                       top: Radius.circular(50),
//                                       bottom: Radius.circular(50)),
//                                 ),
//                                 child: Column(
//                                   mainAxisAlignment:
//                                       MainAxisAlignment.spaceBetween,
//                                   children: [
//                                     Text(date.day.toString(),
//                                         style: TextStyle(
//                                             fontSize: 23,
//                                             fontWeight: FontWeight.normal,
//                                             color: AppColors.black)),
//                                     Text(
//                                       DateFormat('E')
//                                           .format(date), // Format: Sun 25 Feb
//                                       style: TextStyle(
//                                           fontSize: 14,
//                                           fontWeight: FontWeight.normal,
//                                           color: AppColors.black555),
//                                     ),
//                                     Container(
//                                       height: 8,
//                                       width: 8,
//                                       decoration: BoxDecoration(
//                                         color: isSelectedDate
//                                             ? AppColors.primaryColor
//                                             : Colors
//                                                 .transparent, // Highlight dot on selected date
//                                         shape: BoxShape.circle,
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                             );
//                           },
//                           onDateChange: (date) async {
//                             printLog("Date Changed :${date}");
//                             await viewModel.updateSelectedDate(date);
//                           },
//                         ),

//                         const SizedBox(height: 10),
//                         if (viewModel.selectedDate != null)
//                           Align(
//                             alignment: Alignment.topCenter,
//                             child: Text(
//                                 DateFormat('E d MMM')
//                                     .format(viewModel.selectedDate!),
//                                 style: TextStyle(
//                                     fontSize: 18,
//                                     color: AppColors.black,
//                                     fontWeight: FontWeight.w700)),
//                           ),
//                         const SizedBox(height: 10),
//                         const Divider(),

//                         viewModel?.isLoadingSlots == true
//                             ? loaderWidget()
//                             : viewModel.slotsResponseModel?.data?.availableSlots
//                                         ?.length ==
//                                     0
//                                 ? noDataWidget(text: "Slots")
//                                 : GridView.builder(
//                                     shrinkWrap: true,
//                                     itemCount: viewModel.slotsResponseModel
//                                             ?.data?.availableSlots?.length ??
//                                         0,
//                                     physics: NeverScrollableScrollPhysics(),
//                                     gridDelegate:
//                                         SliverGridDelegateWithFixedCrossAxisCount(
//                                             crossAxisCount: 3,
//                                             mainAxisSpacing: 14,
//                                             crossAxisSpacing: 11,
//                                             childAspectRatio: 25 / 10),
//                                     itemBuilder: (context, index) {
//                                       final availableSlot = viewModel
//                                           .slotsResponseModel
//                                           ?.data
//                                           ?.availableSlots?[index];
//                                       final startTime =
//                                           availableSlot?.startTime ?? "";

//                                       final isSelected = viewModel
//                                               .selectedSlotForBooking?.sId ==
//                                           availableSlot?.sId;
//                                       printLog("isSelected $isSelected");

//                                       return GestureDetector(
//                                         onTap: () {
//                                           viewModel.updateSelectedSlot(
//                                               availableSlot);
//                                         },
//                                         child: Container(
//                                           decoration: BoxDecoration(
//                                               color: isSelected
//                                                   ? AppColors.primaryColor
//                                                   : AppColors
//                                                       .lightPrimaryColor9EC,
//                                               borderRadius:
//                                                   BorderRadius.circular(5)),
//                                           child: Center(
//                                               child: Text(startTime,
//                                                   style: TextStyle(
//                                                       fontSize: 17,
//                                                       fontWeight:
//                                                           FontWeight.w500,
//                                                       color: isSelected
//                                                           ? AppColors.white
//                                                           : AppColors
//                                                               .black555))),
//                                         ),
//                                       );
//                                     },
//                                   ),

//                         const Divider(),
//                         Row(
//                           children: [
//                             Container(
//                               width: 20,
//                               height: 20,
//                               child: Checkbox(
//                                 value: viewModel.isRecorded,
//                                 onChanged: (value) {
//                                   viewModel.setRecorded(value!);
//                                 },
//                                 activeColor: AppColors.black,
//                                 checkColor: AppColors.white,
//                               ),
//                             ),
//                             SizedBox(width: 10),
//                             Text('Do you want recorded or not ?',
//                                 style: TextStyle(
//                                     color: Color(0xFF555555),
//                                     fontSize: 16,
//                                     fontWeight: FontWeight.w500)),
//                           ],
//                         ),
//                         const SizedBox(height: 10),
//                         Row(
//                           children: [
//                             Container(
//                               width: 20,
//                               height: 20,
//                               child: Checkbox(
//                                 value: viewModel.isSplit,
//                                 onChanged: (value) {
//                                   viewModel.setSplit(value!);
//                                 },
//                                 activeColor: AppColors.black,
//                                 checkColor: AppColors.white,
//                               ),
//                             ),
//                             SizedBox(width: 10),
//                             Text('Split payment with friends',
//                                 style: TextStyle(
//                                     color: Color(0xFF555555),
//                                     fontSize: 16,
//                                     fontWeight: FontWeight.w500)),
//                           ],
//                         ),
//                         const SizedBox(height: 20),
//                         // Button at the bottom
//                         AppButton(
//                           height: 50,
//                           onPressed: () {
//                             addFriendShowModalBottomSheet(context);
//                           },
//                           bgColor: AppColors.black,
//                           prefixIcon: Image.asset('assets/icons/plus.png',
//                               width: 22, height: 22),
//                           label: "Add Friends",
//                           textColor: AppColors.white,
//                         ),
//                         SizedBox(height: 20),
//                         Center(
//                             child: Text('Add Friends & Split the Cost! ⚽🏀',
//                                 style: TextStyle(
//                                     fontSize: 14,
//                                     fontWeight: FontWeight.w600,
//                                     color: AppColors.black))),
//                         SizedBox(height: 10),
//                         // lisTile
//                         ListView.builder(
//                           itemCount: viewModel.userData.length,
//                           shrinkWrap: true,
//                           padding: EdgeInsets.zero,
//                           physics: NeverScrollableScrollPhysics(),
//                           itemBuilder: (context, index) {
//                             var data = viewModel.userData[index];
//                             return ListTile(
//                               contentPadding: EdgeInsets.zero,
//                               leading: CircleAvatar(
//                                 backgroundColor: AppColors.primaryColor,
//                                 child: Center(
//                                     child: Text(data.name.substring(0, 1),
//                                         style: TextStyle(
//                                             fontSize: 16,
//                                             fontWeight: FontWeight.w600,
//                                             color: AppColors.black))),
//                               ),
//                               title: Text(data.name,
//                                   style: TextStyle(
//                                       fontSize: 12,
//                                       fontWeight: FontWeight.w700,
//                                       color: AppColors.black)),
//                               subtitle: Text(data.phoneNumber,
//                                   style: TextStyle(
//                                       fontSize: 12,
//                                       fontWeight: FontWeight.w500,
//                                       color: AppColors.black555)),
//                               trailing: SizedBox(
//                                 width: 150,
//                                 child: Column(
//                                   mainAxisAlignment: MainAxisAlignment.end,
//                                   children: [
//                                     InkWell(
//                                       onTap: () {
//                                         viewModel.removeUserData(user: data);
//                                       },
//                                       child: Row(
//                                         mainAxisAlignment:
//                                             MainAxisAlignment.end,
//                                         children: [
//                                           Icon(CupertinoIcons.delete,
//                                               size: 20,
//                                               color: AppColors.red323),
//                                           SizedBox(width: 3),
//                                           Text("Remove",
//                                               style: TextStyle(
//                                                   fontSize: 12,
//                                                   fontWeight: FontWeight.w700,
//                                                   color: AppColors.red323)),
//                                         ],
//                                       ),
//                                     ),
//                                     SizedBox(height: 5),
//                                     Row(
//                                       mainAxisAlignment: MainAxisAlignment.end,
//                                       children: [
//                                         Text("Pay Amount",
//                                             style: TextStyle(
//                                                 fontSize: 10,
//                                                 fontWeight: FontWeight.w400,
//                                                 color: AppColors.black555)),
//                                         SizedBox(width: 3),
//                                         Container(
//                                             width: 1,
//                                             height: 10,
//                                             color: AppColors.black555),
//                                         SizedBox(width: 3),
//                                         Container(
//                                           padding: EdgeInsets.symmetric(
//                                               horizontal: 15, vertical: 3),
//                                           color: AppColors.primaryColor,
//                                           child: Center(
//                                             child: Text(
//                                               // viewModel.bookingPrice.toString(),
//                                               viewModel.friendsPrice
//                                                   .toStringAsFixed(
//                                                       2), // Format to 2 decimal places
//                                               style: TextStyle(
//                                                   fontSize: 12,
//                                                   fontWeight: FontWeight.w700,
//                                                   color: AppColors.black555),
//                                             ),
//                                           ),
//                                         ),
//                                       ],
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                             );
//                           },
//                         ),
//                         SizedBox(height: viewModel.userData.isEmpty ? 20 : 50),
//                       ],
//                     );
//                   },
//                 ),
//               ),
//             ),
//           ),
//         );
//       },
//     );
//   }

//   Future<dynamic> addFriendShowModalBottomSheet(BuildContext context) {
//     return showDialog(
//       context: context,
//       builder: (BuildContext context) {
//         return Dialog(
//           shape:
//               RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//           insetPadding: EdgeInsets.all(16),
//           child: Consumer<BookingProvider>(
//             builder: (BuildContext context, viewModel1, Widget? child) {
//               return Padding(
//                 padding: EdgeInsets.only(
//                     bottom: MediaQuery.of(context).viewInsets.bottom),
//                 child: SingleChildScrollView(
//                   child: ListView(
//                     shrinkWrap: true,
//                     padding: EdgeInsets.symmetric(horizontal: 16, vertical: 20),
//                     children: [
//                       Text("Add Friends",
//                           style: TextStyle(
//                               fontSize: 14,
//                               fontWeight: FontWeight.w700,
//                               color: AppColors.black)),
//                       SizedBox(height: 10),
//                       Container(
//                         decoration: BoxDecoration(
//                             color: AppColors.white,
//                             borderRadius: BorderRadius.circular(30)),
//                         child: AppTextField(
//                           onchanged: (val) {
//                             viewModel1.searchContactList(val);
//                           },
//                           hintTextStyle: TextStyle(
//                               fontWeight: FontWeight.w500,
//                               fontSize: 12,
//                               color: AppColors.black555),
//                           borderColor: AppColors.white,
//                           hintText: "Search Contact",
//                           suffix: Icon(CupertinoIcons.search,
//                               color: AppColors.black555),
//                         ),
//                       ),
//                       SizedBox(
//                         height: 300,
//                         child: viewModel1.searchContacts.isEmpty
//                             ? const Center(
//                                 child: Text("Contact List is empty !",
//                                     style: TextStyle(
//                                         fontSize: 15,
//                                         fontWeight: FontWeight.w600,
//                                         color: AppColors.black)))
//                             : ListView.builder(
//                                 itemCount: viewModel1.searchContacts.length,
//                                 padding: EdgeInsets.zero,
//                                 physics: AlwaysScrollableScrollPhysics(),
//                                 itemBuilder: (context, index) {
//                                   Contact contact =
//                                       viewModel1.searchContacts[index];
//                                   bool isAdded = viewModel1.userData.any(
//                                       (element) => element.id == contact.id);
//                                   ContactModel contactModel = ContactModel(
//                                     id: contact.id,
//                                     isActive: true,
//                                     name: contact.displayName,
//                                     phoneNumber:
//                                         contact.phones.firstOrNull?.number ??
//                                             "",
//                                   );
//                                   return ListTile(
//                                     onTap: () {
//                                       viewModel1.addUserData(
//                                           user: contactModel);
//                                     },
//                                     contentPadding: EdgeInsets.zero,
//                                     leading: ClipRRect(
//                                       borderRadius: BorderRadius.circular(30),
//                                       child: SizedBox(
//                                         height: 40,
//                                         width: 40,
//                                         child: (contact.photo != null)
//                                             ? CircleAvatar(
//                                                 backgroundImage:
//                                                     MemoryImage(contact.photo!))
//                                             : CircleAvatar(
//                                                 backgroundColor:
//                                                     AppColors.primaryColor,
//                                                 child: Center(
//                                                     child: Text(
//                                                         contact.displayName
//                                                             .substring(0, 1),
//                                                         style: TextStyle(
//                                                             fontSize: 16,
//                                                             fontWeight:
//                                                                 FontWeight.w600,
//                                                             color: AppColors
//                                                                 .black))),
//                                               ),
//                                       ),
//                                     ),
//                                     title: Text(contact.displayName,
//                                         style: TextStyle(
//                                             fontSize: 12,
//                                             fontWeight: FontWeight.w700,
//                                             color: AppColors.black)),
//                                     subtitle: Text(
//                                       contact.phones.isNotEmpty
//                                           ? contact.phones.first.number
//                                           : "No Number",
//                                       style: TextStyle(
//                                           fontSize: 12,
//                                           fontWeight: FontWeight.w500,
//                                           color: AppColors.black555),
//                                     ),
//                                     trailing: SizedBox(
//                                       height: 26,
//                                       width: 70,
//                                       child: isAdded
//                                           ? Text("Added",
//                                               style: TextStyle(
//                                                   fontSize: 12,
//                                                   fontWeight: FontWeight.w500,
//                                                   color: AppColors.red323))
//                                           : Row(
//                                               children: [
//                                                 Icon(
//                                                     Icons
//                                                         .add_circle_outline_outlined,
//                                                     color: AppColors.greenC748),
//                                                 SizedBox(width: 7),
//                                                 Text("Add",
//                                                     style: TextStyle(
//                                                         fontSize: 12,
//                                                         fontWeight:
//                                                             FontWeight.w500,
//                                                         color: AppColors
//                                                             .greenC748)),
//                                               ],
//                                             ),
//                                     ),
//                                   );
//                                 },
//                               ),
//                       ),
//                       SizedBox(height: 10),
//                       AppButtonCommon(
//                         onPressed: () {
//                           viewModel1.navigateToAddedFriendsScreen(context);
//                         },
//                         label: "Add",
//                       ),
//                     ],
//                   ),
//                 ),
//               );
//             },
//           ),
//         );
//       },
//     );
//   }
// }

// // Helper function to compare dates without time
// DateTime dateOnly(DateTime date) {
//   return DateTime(date.year, date.month, date.day);
// }
