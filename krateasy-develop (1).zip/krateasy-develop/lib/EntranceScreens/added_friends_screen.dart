import 'package:flutter/material.dart';
import 'package:kratEasyApp/ViewModel/EntranceViewModel/booking_provider.dart';
import 'package:kratEasyApp/GlobalUtils/app_button.dart';
import 'package:kratEasyApp/GlobalUtils/app_colors.dart';
import 'package:kratEasyApp/GlobalUtils/common_app_bar.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:provider/provider.dart';

class AddedFriendsScreen extends StatefulWidget {
  const AddedFriendsScreen({super.key});

  @override
  State<AddedFriendsScreen> createState() => _AddedFriendsScreenState();
}

class _AddedFriendsScreenState extends State<AddedFriendsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.white,
      appBar: CommonAppBar(title:l10n.of(context).addedFriends),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 20),
          child: SingleChildScrollView(
            child: Consumer<BookingProvider>(
              builder: (BuildContext context, viewModel, Widget? child) {
                return Column(
                  children: [
                    Container(
                      padding: EdgeInsets.all(15),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: AppColors.lightYellowF9EC),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(l10n.of(context).addFriends,
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.black)),
                          SizedBox(height: 10),
                          AppButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            fontWeight: FontWeight.w400,
                            label:l10n.of(context).addAnotherRecipient,
                          ),
                          SizedBox(height: 10),
                          viewModel.userData.isEmpty
                              ? SizedBox(
                                  height: 300,
                                  width: double.infinity,
                                  child: Center(
                                      child: Text(l10n.of(context).friendListIsEmpty,
                                          style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.w600,
                                              color: AppColors.black555))),
                                )
                              : ListView.builder(
                                  itemCount: viewModel.userData.length,
                                  shrinkWrap: true,
                                  padding: EdgeInsets.zero,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemBuilder: (context, index) {
                                    var data = viewModel.userData[index];
                                    return ListTile(
                                      contentPadding: EdgeInsets.zero,
                                      leading: CircleAvatar(
                                        backgroundColor: AppColors.primaryColor,
                                        child: Center(
                                            child: Text(
                                                data.name.substring(0, 1),
                                                style: TextStyle(
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.w600,
                                                    color: AppColors.black))),
                                      ),
                                      title: Text(data.name ?? "",
                                          style: TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.w700,
                                              color: AppColors.black)),
                                      subtitle: Text(data.phoneNumber ?? '',
                                          style: TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.w500,
                                              color: AppColors.black555)),
                                      trailing: SizedBox(
                                        height: 26,
                                        width: 85,
                                        child: InkWell(
                                          onTap: () {
                                            viewModel.removeUserData(context: context,
                                                user: data);
                                          },
                                          child: Row(
                                            children: [
                                              SizedBox(
                                                  height: 20,
                                                  width: 20,
                                                  child: Image.asset(
                                                      "assets/icons/delete.png",
                                                      fit: BoxFit.fill)),
                                              SizedBox(width: 7),
                                              Text(l10n.of(context).remove,
                                                  style: TextStyle(
                                                      fontSize: 12,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      color: AppColors.red323)),
                                            ],
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                        ],
                      ),
                    ),
                    SizedBox(height: 50),
                    AppButtonCommon(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.pop(context);
                      },
                      label: l10n.of(context).continues,
                    ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
