import 'dart:async';
import 'dart:developer';
import 'dart:io';
import 'package:country_picker/country_picker.dart';
import 'package:easy_date_timeline/easy_date_timeline.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:intl/intl.dart';
import 'package:kratEasyApp/Models/contact_model.dart';
import 'package:kratEasyApp/GlobalUtils/common.dart';
import 'package:kratEasyApp/Models/SlotsResponseModel.dart';
import 'package:kratEasyApp/ViewModel/BottomNavViewModels/FacilitiesViewModel.dart';
import 'package:kratEasyApp/ViewModel/EntranceViewModel/booking_provider.dart';
import 'package:kratEasyApp/GlobalUtils/app_button.dart';
import 'package:kratEasyApp/GlobalUtils/app_colors.dart';
import 'package:kratEasyApp/GlobalUtils/app_text_field.dart';
import 'package:kratEasyApp/GlobalUtils/common_app_bar.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/paymentprovider.dart';
import 'package:kratEasyApp/utils/extension.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../API_CALLS/GlobalAPIUtils.dart';
import '../GlobalUtils/app_constants.dart';
import '../ViewModel/BottomNavViewModels/HomeViewModel.dart';
import '../ViewModel/BottomNavViewModels/MyFavouriteViewModel.dart';
import '../ViewModel/NavBarViewModels/MyAccountViewModel.dart';
import '../repository/social_login_repository.dart';
import '../services/local/local_keys.dart';
import '../services/local/local_service.dart';

class GuestBookingScreen extends StatefulWidget {
  final String? courtId;
  final String? date;
  final String? facilityId;
  final List<String>? selectedTimeSlots;
  final String? sportId;

  GuestBookingScreen(
      {super.key,
      this.courtId,
      this.date,
      this.facilityId,
      this.selectedTimeSlots,
      this.sportId}) {
    log("init GuestBookingScreen ");
  }

  @override
  State<GuestBookingScreen> createState() => _GuestBookingScreenState();
}

class _GuestBookingScreenState extends State<GuestBookingScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  DateTime _selectedDate = DateTime.now();
  bool _showLoader = true;

  loading() {
    Timer(Duration(seconds: 3), () {
      setState(() {
        _showLoader = false;
      });
    });
  }

  String finaldate = "";

  @override
  void initState() {
    super.initState();

    log("widget.selectedTimeSlots ==>${widget.selectedTimeSlots}");
    loading();

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final bookingVM = Provider.of<BookingProvider>(context, listen: false);
      // await  _loadSavedData();
      // Clear all inputs and states
      bookingVM.onPrommoCodeChange(null);
      bookingVM.promoCodeController.clear();
      bookingVM.phoneController.clear();
      bookingVM.otpController.clear();
      bookingVM.countryCodeController.clear();
      bookingVM.availableSlots.clear();
      bookingVM.userData.clear();
      bookingVM.selectedSlotIds.clear();
      try {
        // Logging - won’t show in release unless using a logger
        log("selectedTimeSlots: ${widget.selectedTimeSlots}");
        final String formattedDate =
            widget.date ?? DateFormat("dd-MM-yyyy").format(DateTime.now());
        finaldate =
            widget.date ?? DateFormat("dd-MM-yyyy").format(DateTime.now());
        setState(() {});

        // Fetch contacts
        bookingVM.getContacts(context: context).then((_) async {
          final List<AvailableSlots> slots = await bookingVM.getSlotsNew(
            context: context,
            courtId: widget.courtId,
            formatedDate: formattedDate,
            facilityId: widget.facilityId,
          );

          // Set slots and optionally select one
          bookingVM.setAvailableSlots1(
            slots: slots,
            preSelectedIds: widget.selectedTimeSlots?.isNotEmpty ?? false
                ? widget.selectedTimeSlots
                : null,
          );
        });

        // Use local variable to avoid confusion

        log("Initial date: $formattedDate");

        final List<AvailableSlots> slots = await bookingVM.getSlotsNew(
          context: context,
          courtId: widget.courtId,
          formatedDate: formattedDate,
          facilityId: widget.facilityId,
        );

        // Set slots and optionally select one
        bookingVM.setAvailableSlots1(
          slots: slots,
          preSelectedIds: widget.selectedTimeSlots?.isNotEmpty ?? false
              ? widget.selectedTimeSlots
              : null,
        );

        if (widget.selectedTimeSlots != null &&
            widget.selectedTimeSlots!.isNotEmpty) {
          bookingVM.selectedSlotIds = widget.selectedTimeSlots!;

          ///FIXME: if needed
          // AvailableSlots? selectedSlot = slots.firstWhere((slot){
          //   return (slot.sId == (widget.selectedTimeSlots?.firstOrNull??"").toString());
          // });
          // bookingVM.updateSelectedSlot1(selectedSlot, context);
        }

        ///FIXME: if needed
        // if ((widget.selectedTimeSlots?.isEmpty ?? true) && slots.isNotEmpty) {
        //   bookingVM.updateSelectedSlot1(slots.first, context);
        // }

        bookingVM.calculatePrice();
      } catch (e, st) {
        debugPrint("⚠️ Error in initState: $e\n$st");
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<BookingProvider>(
      builder: (context, viewModel, _) {
        final courtName =
            context.read<FacilitiesViewModel>().selectedCourt.name ?? "Court";

        double discount =
            double.tryParse(viewModel.appliedDiscountAmount ?? "0") ?? 0;
        bool hasDiscount = viewModel.appliedDiscountAmount != null;

        double price = viewModel.userData.isEmpty
            ? viewModel.slotPrice
            : viewModel.friendsPrice;

        double basePrice =
            (price - (hasDiscount ? discount : 0)).clamp(0, double.infinity);

        double finalPrice = basePrice > 0 ? basePrice + 4 : basePrice;

        String displayPrice =
            '${AppConstants.appCurrency}${finalPrice.toStringAsFixed(2)}';

        String displayPrice1 = (finalPrice - 4).toStringAsFixed(2);

        return WillPopScope(
          onWillPop: () async {
            context.read<BookingProvider>().userData.clear();
            context.read<BookingProvider>().clearSelectedSlot();
            return true; // allow back navigation
          },
          child: Scaffold(
            // floatingActionButton: FloatingActionButton(onPressed: ()async{
            //   print(await LocalService.instance.getData(LocalKeys.instance.userId));
            // }),
            backgroundColor: Colors.white,
            appBar: CommonAppBar(title: l10n.of(context).booking),
            resizeToAvoidBottomInset: false,
            body: Stack(
              children: [
                SingleChildScrollView(
                  child: Padding(
                    padding: EdgeInsets.only(right: 16, left: 16, bottom: 150),
                    child: Consumer<BookingProvider>(
                      builder:
                          (BuildContext context, viewModel, Widget? child) {
                        return Column(
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: Text(courtName ?? "",
                                      style: TextStyle(
                                          color: AppColors.black,
                                          fontSize: 20,
                                          fontWeight: FontWeight.w600)),
                                ),
                                Text(
                                  displayPrice,
                                  style: TextStyle(
                                      fontSize: 20,
                                      color: AppColors.black,
                                      fontWeight: FontWeight.w600),
                                ),
                              ],
                            ),
                            if (basePrice > 0)
                            Row(
                              mainAxisAlignment:
                              MainAxisAlignment.spaceBetween,
                              children: [
                                Flexible(
                                  child: Text(
                                    'Service fee',
                                    style: TextStyle(
                                      color: AppColors.blackA2A,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  width: 20,
                                ),
                                Text(
                                  "${AppConstants.appCurrency}4.00",
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: AppColors.black,
                                    fontWeight: FontWeight.w500,
                                  ),
                                )
                              ],
                            ),
                            const SizedBox(height: 10),
                            Row(
                              children: [
                                Image.asset('assets/icons/clock.png',
                                    width: 18, height: 18),
                                const SizedBox(width: 5),
                                Text(l10n.of(context).minTimeToBook,
                                    style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.normal,
                                        color: AppColors.black555)),
                                Text(viewModel.minHours ?? "",
                                    style: TextStyle(
                                        fontSize: 16,
                                        color: AppColors.black555,
                                        fontWeight: FontWeight.w700)),
                              ],
                            ),
                            const SizedBox(height: 10),
                            Divider(),
                            const SizedBox(height: 10),
                            Align(
                              alignment: Alignment.topRight,
                              child: Text(l10n.of(context).selectDate,
                                  style: TextStyle(
                                      decoration: TextDecoration.underline,
                                      fontSize: 14,
                                      color: AppColors.black,
                                      fontWeight: FontWeight.w600)),
                            ),
                            const SizedBox(height: 10),
                            EasyDateTimeLinePicker.itemBuilder(
                              firstDate: DateTime.now(),
                              lastDate: DateTime.now().add(Duration(days: 30)),
                              headerOptions:
                                  HeaderOptions(headerType: HeaderType.none),
                              focusedDate: DateTime.now(),
                              itemExtent: 66.0,
                              itemBuilder: (context, date, isSelected,
                                  isDisabled, isToday, onTap) {
                                bool isSelectedDate = (dateOnly(date) ==
                                    dateOnly(viewModel.selectedDate));
                                debugPrint(
                                    "Condition of color change on selected date $isSelectedDate 1st ${dateOnly(date)} 2nd ${dateOnly(viewModel.selectedDate)}");
                                final bookingVM =
                                    context.read<BookingProvider>();

                                return GestureDetector(
                                  onTap: () async {
                                    print("abcd");
                                    setState(() {
                                      _showLoader = true;
                                    });
                                    loading();
                                    viewModel.onPrommoCodeChange(null);

                                    viewModel.clearSelectedSlot();
                                    await viewModel
                                        .updateSelectedDate2(date)
                                        .then((v) {
                                      finaldate =
                                          DateFormat("dd-MM-yyyy").format(date);
                                      setState(() {});
                                      log("final date $finaldate ${dateOnly(date)}");
                                      viewModel
                                          .getSlotsNew(
                                        context: context,
                                        courtId: widget.courtId,
                                        formatedDate: finaldate,
                                        facilityId: widget.facilityId,
                                      )
                                          .then(
                                        (List<AvailableSlots> slots) {
                                          bookingVM.setAvailableSlots1(
                                              slots: slots);
                                        },
                                      );
                                    });
                                  },
                                  child: Container(
                                    height: 80,
                                    width: 50,
                                    padding: EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                        width: 2,
                                        color: isSelectedDate
                                            ? AppColors.primaryColor
                                            : Colors
                                                .transparent, // Border only on selected date
                                      ),
                                      borderRadius: BorderRadius.vertical(
                                          top: Radius.circular(60),
                                          bottom: Radius.circular(60)),
                                    ),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(date.day.toString(),
                                            style: TextStyle(
                                                fontSize: 25,
                                                fontWeight: FontWeight.normal,
                                                color: AppColors.black)),
                                        Text(
                                          DateFormat('E').format(date),
                                          // Format: Sun 25 Feb
                                          style: TextStyle(
                                              fontSize: 15,
                                              fontWeight: FontWeight.normal,
                                              color: AppColors.black555),
                                        ),
                                        Container(
                                          height: 9,
                                          width: 9,
                                          decoration: BoxDecoration(
                                            color: isSelectedDate
                                                ? AppColors.primaryColor
                                                : Colors.transparent,
                                            // Highlight dot on selected date
                                            shape: BoxShape.circle,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                              onDateChange: (date) {
                                setState(() {
                                  finaldate =
                                      DateFormat("dd-MM-yyyy").format(date);
                                  printLog("final selected Date $finaldate");
                                  // Ensure selected date updates
                                });
                              },
                            ),

                            const SizedBox(height: 10),
                            Align(
                              alignment: Alignment.topCenter,
                              child: Text(
                                  DateFormat('E d MMM')
                                      .format(viewModel.selectedDate),
                                  style: TextStyle(
                                      fontSize: 18,
                                      color: AppColors.black,
                                      fontWeight: FontWeight.w700)),
                            ),
                            const SizedBox(height: 10),
                            const Divider(),

                            // viewModel.isLoadingSlotsNew ||
                            //     viewModel.isLoadingSlotsNew1
                            //     ? Center(
                            //     child: CircularProgressIndicator(
                            //       color: AppColors.primaryColor,
                            //     ))
                            //     : (viewModel.slotsResponseModel.data
                            //     ?.availableSlots?.isEmpty ??
                            //     true)
                            //     ? noDataWidget(text: S.of(context).slots)
                            //     :
                            _showLoader
                                ? Center(
                                    child: CircularProgressIndicator(),
                                  )
                                : Consumer<BookingProvider>(
                                    builder: (context, provider, _) {
                                      final slots = provider
                                          .availableSlots; // 🔑 Always from provider

                                      if (slots.isEmpty) {
                                        return Center(
                                            child: Text("No slots available"));
                                      }

                                      return GridView.builder(
                                        shrinkWrap: true,
                                        physics: NeverScrollableScrollPhysics(),
                                        itemCount: slots.length,
                                        gridDelegate:
                                            SliverGridDelegateWithFixedCrossAxisCount(
                                          crossAxisCount: 2,
                                          mainAxisSpacing: 12,
                                          crossAxisSpacing: 10,
                                          mainAxisExtent: 45,
                                        ),
                                        itemBuilder: (context, index) {
                                          final slot = slots[index];
                                          final startTime =
                                              slot.startTime ?? "";
                                          final endTime = slot.endTime ?? "";
                                          final isSelected = provider
                                              .selectedSlotIds
                                              .contains(slot.sId);

                                          return InkWell(
                                            onTap: () {
                                              provider.updateSelectedSlot1(
                                                  slot, context);
                                              setState(() {});
                                            },
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: isSelected
                                                    ? AppColors.primaryColor
                                                    : AppColors
                                                        .lightPrimaryColor9EC,
                                                borderRadius:
                                                    BorderRadius.circular(5),
                                              ),
                                              child: Center(
                                                child: Text(
                                                  "$startTime - $endTime",
                                                  style: TextStyle(
                                                    fontSize: 14,
                                                    fontWeight: FontWeight.w400,
                                                    color: isSelected
                                                        ? AppColors.white
                                                        : AppColors.black555,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          );
                                        },
                                      );
                                    },
                                  ),

                            // GridView.builder(
                            //   shrinkWrap: true,
                            //   physics: NeverScrollableScrollPhysics(),
                            //   itemCount: viewModel.slotsResponseModel.data?.availableSlots?.length ?? 0,
                            //   gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                            //     crossAxisCount: 2,
                            //     mainAxisSpacing: 12,
                            //     crossAxisSpacing: 10,
                            //     mainAxisExtent: 45,
                            //     childAspectRatio: 2.0,
                            //   ),
                            //   itemBuilder: (context, index) {
                            //     final availableSlot = viewModel.slotsResponseModel.data?.availableSlots?[index];
                            //
                            //     final startTime = availableSlot?.startTime ?? "";
                            //     final endTime = availableSlot?.endTime ?? "";
                            //
                            //     return InkWell(
                            //       onTap: () {
                            //         log("message");
                            //         debugPrint("message");
                            //         print("message");
                            //         // provider.updateSelectedSlot1(availableSlot!, context1);
                            //         context.read<BookingProvider>().updateSelectedSlot1(availableSlot!, context);
                            //       },
                            //       child:
                            //       Consumer<BookingProvider>(builder: (context, provider, child) {
                            //         final isSelected = provider.selectedSlotIds.contains(availableSlot?.sId ?? "");
                            //
                            //         return Container(
                            //           decoration: BoxDecoration(
                            //             color: isSelected ? AppColors.primaryColor : AppColors.lightPrimaryColor9EC,
                            //             borderRadius: BorderRadius.circular(5),
                            //           ),
                            //           child: Center(
                            //             child: Text(
                            //               "$startTime - $endTime",
                            //               style: TextStyle(
                            //                 fontSize: 14,
                            //                 fontWeight: FontWeight.w400,
                            //                 color: isSelected ? AppColors.white : AppColors.black555,
                            //               ),
                            //             ),
                            //           ),
                            //         );
                            //
                            //       },),
                            //     );
                            //   },
                            // ),

                            const Divider(),

                            Row(
                              children: [
                                GestureDetector(
                                  onTap: () {
                                    // Toggle the isSplit value in the viewModel
                                    viewModel.setSplit(!viewModel.isSplit);
                                    setState(() {});
                                  },
                                  child: Container(
                                    padding: EdgeInsets.symmetric(
                                        vertical: 8, horizontal: 12),
                                    // Optional: Add padding for better tap area
                                    child: Row(
                                      children: [
                                        Container(
                                          width: 20,
                                          height: 20,
                                          child: Checkbox(
                                            value: viewModel.isSplit,
                                            onChanged: (value) {
                                              viewModel.setSplit(value!);
                                              setState(() {});
                                            },
                                            activeColor: AppColors.black,
                                            checkColor: AppColors.white,
                                          ),
                                        ),
                                        SizedBox(width: 10),
                                        Text(
                                          l10n
                                              .of(context)
                                              .splitPaymentWithFriends,
                                          style: TextStyle(
                                            color: Color(0xFF555555),
                                            fontSize: 16,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                SizedBox(width: 5),
                                GestureDetector(
                                  onTap: () {
                                    // Show the alert dialog
                                    showDialog(
                                      context: context,
                                      builder: (BuildContext context) {
                                        return AlertDialog(
                                          shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(15),
                                            side: BorderSide(
                                              color: AppColors
                                                  .primaryColor, // Border color
                                              width: 2,
                                            ),
                                          ),
                                          title: Text(
                                            'Split Payment Info',
                                            style: TextStyle(
                                              fontSize: 18,
                                              fontWeight: FontWeight.w700,
                                              color: AppColors.black,
                                            ),
                                          ),
                                          content: Text(
                                            'If you add friends, your amount will be split with your friends.',
                                            style: TextStyle(
                                              fontSize: 16,
                                              color: Color(0xFF555555),
                                              fontWeight: FontWeight.w400,
                                            ),
                                          ),
                                          actions: [
                                            TextButton(
                                              onPressed: () {
                                                Navigator.of(context)
                                                    .pop(); // Close the dialog
                                              },
                                              child: Text(
                                                'OK',
                                                style: TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.w600,
                                                  color: AppColors.primaryColor,
                                                ),
                                              ),
                                            ),
                                          ],
                                          backgroundColor: AppColors.white,
                                          elevation: 8,
                                          contentPadding: EdgeInsets.symmetric(
                                              horizontal: 24, vertical: 10),
                                          titlePadding: EdgeInsets.fromLTRB(
                                              24, 24, 24, 0),
                                        );
                                      },
                                    );
                                    setState(() {});
                                  },
                                  child: Icon(
                                    Icons.info,
                                    size: 18,
                                    color: AppColors.primaryColor,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 30),
                            viewModel.isSplit
                                ? AppButton(
                                    height: 50,
                                    onPressed: () async {
                                      SharedPreferences prefs =
                                          await SharedPreferences.getInstance();
                                      prefs.getString("auth_token");

                                      prefs.getString("auth_token") != null
                                          ? context
                                              .read<MyFavouriteViewModel>()
                                              .getFavouritePlayerData(
                                                  context: context)
                                              .then((_) {
                                              addFriendShowModalBottomSheet(
                                                  context);
                                            })
                                          : addFriendShowModalBottomSheet(
                                              context,
                                            );
                                      setState(() {});
                                    },
                                    bgColor: AppColors.black,
                                    prefixIcon: Image.asset(
                                        'assets/icons/plus.png',
                                        width: 22,
                                        height: 22),
                                    label: l10n.of(context).addFriends,
                                    textColor: AppColors.white,
                                  )
                                : SizedBox(),
                            SizedBox(height: 10),
                            Text(l10n.of(context).addFriendsSplitTheCost,
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                    color: AppColors.black)),

                            viewModel.isSplit
                                ? SizedBox(height: 10)
                                : SizedBox(),
                            // lisTile
                            ListView.builder(
                              itemCount: viewModel.userData.length,
                              shrinkWrap: true,
                              padding: EdgeInsets.zero,
                              physics: NeverScrollableScrollPhysics(),
                              itemBuilder: (context, index) {
                                var data = viewModel.userData[index];
                                return ListTile(
                                  contentPadding: EdgeInsets.zero,
                                  leading: CircleAvatar(
                                    backgroundColor: AppColors.primaryColor,
                                    child: Center(
                                        child: Text(data.name.substring(0, 1),
                                            style: TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.w600,
                                                color: AppColors.black))),
                                  ),
                                  title: Text(data.name,
                                      style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w700,
                                          color: AppColors.black)),
                                  subtitle: Text(data.phoneNumber,
                                      style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w500,
                                          color: AppColors.black555)),
                                  trailing: SizedBox(
                                    width: 150,
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        GestureDetector(
                                          onTap: () {
                                            viewModel.removeUserData(
                                                context: context, user: data);
                                            setState(() {});
                                          },
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.end,
                                            children: [
                                              Icon(CupertinoIcons.delete,
                                                  size: 20,
                                                  color: AppColors.red323),
                                              SizedBox(width: 3),
                                              Text(l10n.of(context).remove,
                                                  style: TextStyle(
                                                    fontSize: 12,
                                                    fontWeight: FontWeight.w700,
                                                    color: AppColors.red323,
                                                  )),
                                            ],
                                          ),
                                        ),
                                        SizedBox(height: 5),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            Flexible(
                                              child: Text(
                                                  l10n.of(context).payAmount,
                                                  style: TextStyle(
                                                      fontSize: 10,
                                                      fontWeight:
                                                          FontWeight.w400,
                                                      color:
                                                          AppColors.black555)),
                                            ),
                                            SizedBox(width: 3),
                                            Container(
                                                width: 1,
                                                height: 10,
                                                color: AppColors.black555),
                                            SizedBox(width: 3),
                                            Container(
                                              decoration: BoxDecoration(
                                                color: AppColors.primaryColor,
                                                borderRadius:
                                                    BorderRadius.circular(2),
                                              ),
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 8, vertical: 3),
                                              child: Center(
                                                child: Text(
                                                  '${AppConstants.appCurrency}${viewModel.friendsPrice.toStringAsFixed(1)}',
                                                  // viewModel.totalPrice
                                                  //     .toString(), // Format to 2 decimal places
                                                  style: TextStyle(
                                                      fontSize: 12,
                                                      fontWeight:
                                                          FontWeight.w700,
                                                      color:
                                                          AppColors.black555),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                            SizedBox(
                                height: viewModel.userData.isEmpty ? 20 : 50),
                          ],
                        );
                      },
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Padding(
                    padding: EdgeInsets.only(
                      bottom: MediaQuery.of(context).viewInsets.bottom,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        viewModel.isSplit
                            ? SizedBox()
                            : Container(
                                color: Colors.white,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 14, vertical: 18),
                                  color:
                                      AppColors.primaryColor.withOpacity(0.1),
                                  child: Center(
                                    child: AppTextField(
                                      controller: viewModel.promoCodeController,
                                      fillColor: AppColors.primaryColor
                                          .withOpacity(0.05),
                                      hintText: l10n.of(context).promoCode,
                                      onchanged: viewModel.onPrommoCodeChange,
                                      hintTextStyle:
                                          const TextStyle(color: Colors.black),
                                      borderColor: const Color(0xff55555580),
                                      suffix: viewModel.isPromoApplied
                                          ? const SizedBox(
                                              width: 20,
                                              height: 20,
                                              child: CircularProgressIndicator(
                                                strokeWidth: 2,
                                                color: AppColors.primaryColor,
                                              ),
                                            )
                                          : viewModel.applied
                                              ? Row(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  children: [
                                                    const Icon(
                                                        Icons.check_circle,
                                                        color: Colors.green,
                                                        size: 18),
                                                    const SizedBox(width: 4),
                                                    Text(
                                                      l10n.of(context).applied,
                                                      style: TextStyle(
                                                          color: Colors.green),
                                                    ),
                                                  ],
                                                )
                                              : GestureDetector(
                                                  onTap: () {
                                                    final code = viewModel
                                                        .promoCodeController
                                                        .text
                                                        .trim();
                                                    if (code.isNotEmpty) {
                                                      viewModel.applyPromoCode(
                                                        context: context,
                                                        amount: viewModel
                                                                .userData
                                                                .isEmpty
                                                            ? viewModel
                                                                .slotPrice
                                                                .toStringAsFixed(
                                                                    2)
                                                            : viewModel
                                                                .friendsPrice
                                                                .toStringAsFixed(
                                                                    2),
                                                        code: code,
                                                      );
                                                    } else {
                                                      ScaffoldMessenger.of(
                                                              context)
                                                          .showSnackBar(
                                                        SnackBar(
                                                            content: Text(l10n
                                                                .of(context)
                                                                .pleaseEnterPromoCode)),
                                                      );
                                                    }
                                                  },
                                                  child: Text(
                                                    l10n.of(context).apply,
                                                    style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      color: AppColors
                                                          .primaryColor,
                                                    ),
                                                  ),
                                                ),
                                    ),
                                  ),
                                ),
                              ),
                        viewModel.promoCodErrorMsg != null
                            ? Padding(
                                padding:
                                    const EdgeInsets.only(left: 16, bottom: 40),
                                child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      viewModel.promoCodErrorMsg ?? "",
                                      style: TextStyle(color: Colors.red),
                                    )),
                              )
                            : SizedBox(),
                        Container(
                          decoration:
                              BoxDecoration(color: Colors.white, boxShadow: [
                            BoxShadow(
                                color: AppColors.black.withOpacity(0.1),
                                blurRadius: 10,
                                offset: Offset(0, -4))
                          ]),
                          padding: EdgeInsets.only(
                              left: 14, right: 14, bottom: 16, top: 8),
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: AppButton(
                                      label: displayPrice,
                                      // '£${viewModel.totalPrice.toStringAsFixed(2)}',
                                      textColor: AppColors.black,
                                      disabledColor: AppColors.primaryColor
                                          .withOpacity(.2),
                                    ),
                                  ),
                                  SizedBox(width: 10),
                                  Expanded(
                                    child: AppButton(
                                      label: l10n.of(context).checkout,
                                      onPressed: () async {
                                        if (viewModel.isSplit &&
                                            viewModel.userData.isEmpty) {
                                          ScaffoldMessenger.of(context)
                                              .showSnackBar(SnackBar(
                                            content: Text(
                                              l10n
                                                  .of(context)
                                                  .pleaseAddFriendsToSplitTheCost,
                                            ),
                                          ));
                                          return null;
                                        }

                                        final authToken =
                                            await GlobalAPIUtils.getAuthToken();

                                        if (authToken == null ||
                                            authToken.isEmpty) {
                                          context
                                              .read<BookingProvider>()
                                              .clearPhoneBottomSheet();
                                          context
                                              .read<BookingProvider>()
                                              .selectedCountryFlag = "🇬🇧";
                                          buildShowModalBottomSheet(context);
                                          return false;
                                        }
                                        {
                                          if (viewModel.isSplit &&
                                              viewModel.userData.isEmpty) {
                                            ScaffoldMessenger.of(context)
                                                .showSnackBar(SnackBar(
                                              content: Text(l10n
                                                  .of(context)
                                                  .pleaseAddFriendsToSplitTheCost),
                                            ));
                                            // return;
                                          }
                                          if (viewModel.slotPrice == 0.0) {
                                            ScaffoldMessenger.of(context)
                                                .showSnackBar(
                                              SnackBar(
                                                content: Text(l10n
                                                    .of(context)
                                                    .slotNotAvailable),
                                              ),
                                            );

                                            // return;
                                          }
                                          {
                                            // Ensure that we have the selected slots and times before passing them
                                            final selectedSlots = viewModel
                                                .selectedSlotIds; // Get selected slots from viewModel
                                            final availableTimes =
                                                selectedSlots.map((slotId) {
                                              final slot = viewModel
                                                  .slotsResponseModel
                                                  .data
                                                  ?.availableSlots
                                                  ?.firstWhere(
                                                      (slot) =>
                                                          slot.sId == slotId,
                                                      orElse: () =>
                                                          AvailableSlots(
                                                              sId: '',
                                                              startTime: '',
                                                              endTime: ''));

                                              // Check if the slot was found, then return the formatted string.
                                              return slot != null &&
                                                      slot.sId!.isNotEmpty
                                                  ? '${slot.startTime} - ${slot.endTime}'
                                                  : ''; // If no valid slot found, return empty string.
                                            }).toList();

                                            if (availableTimes.isEmpty) {
                                              ScaffoldMessenger.of(context)
                                                  .showSnackBar(SnackBar(
                                                      content: Text(l10n
                                                          .of(context)
                                                          .pleaseSelectASlotToContinue),
                                                      backgroundColor:
                                                          Colors.orange));
                                            } else {
                                              String id2 = LocalService.instance
                                                  .getData(LocalKeys
                                                      .instance.userId);

                                              //    ///FIXME:
                                              final result = await context
                                                  .read<PaymentProvider>()
                                                  .stripePayment(
                                                    context,
                                                    displayPrice1,
                                                    viewModel.isSplit,
                                                    widget.courtId ?? '',
                                                    "${LocalService.instance.getData(LocalKeys.instance.userId)}",
                                                    viewModel
                                                            .userData.isNotEmpty
                                                        ? (viewModel.userData
                                                                    .length +
                                                                1)
                                                            .toString()
                                                        : "1",
                                                    selectedSlots,
                                                    finaldate,
                                                    "",
                                                  );

                                              print("result api =>$result");
                                              if (result) {
                                                viewModel
                                                    .navigateToGuestPaymentScreen(
                                                  context: context,
                                                  fromGuest: true,
                                                  amount: displayPrice1,
                                                  // viewModel.totalPrice.toString(),
                                                  courtId: widget.courtId ?? '',
                                                  requestDate: finaldate,
                                                  sportId: widget.sportId,
                                                  availableTimes:
                                                      availableTimes,
                                                  selectedSlots: selectedSlots,
                                                  sessionid: context
                                                      .read<PaymentProvider>()
                                                      .sessionid,
                                                );
                                              }
                                            }
                                          }
                                        }
                                      },
                                      textColor: AppColors.black,
                                      bgColor: AppColors.primaryColor,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 30,
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),

            //    Stack(children: [
            //  ])
          ),
        );
      },
    );
  }

  Future<dynamic> addFriendShowModalBottomSheet(BuildContext context) {
    return showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: AppColors.lightPrimaryColor9EC,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          insetPadding: EdgeInsets.all(16),
          child:
              Consumer3<BookingProvider, MyFavouriteViewModel, HomeViewModel>(
            builder: (BuildContext context, viewModel1, myvviewModel, homeView,
                Widget? child) {
              final players = myvviewModel.favouritePlayerData;
              return Scaffold(
                bottomNavigationBar: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: AppButtonCommon(
                    onPressed: () {
                      viewModel1.navigateToAddedFriendsScreen(context);
                      setState(() {});
                    },
                    label: l10n.of(context).add,
                  ),
                ),
                body: Padding(
                  padding: EdgeInsets.only(
                      bottom: MediaQuery.of(context).viewInsets.bottom),
                  child: SingleChildScrollView(
                    child: ListView(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      padding:
                          EdgeInsets.symmetric(horizontal: 16, vertical: 20),
                      children: [
                        Text(l10n.of(context).addFriends,
                            style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                                color: AppColors.black)),
                        SizedBox(height: 10),
                        Container(
                          decoration: BoxDecoration(
                              color: AppColors.white,
                              borderRadius: BorderRadius.circular(30)),
                          child: AppTextField(
                            onchanged: (val) {
                              viewModel1.searchContactList(val);
                            },
                            hintTextStyle: TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 12,
                                color: AppColors.black555),
                            borderColor: AppColors.white,
                            hintText: l10n.of(context).searchContact,
                            suffix: Icon(CupertinoIcons.search,
                                color: AppColors.black555),
                          ),
                        ),

                        myvviewModel.isLoading
                            ? SizedBox(
                                height: MediaQuery.of(context).size.height * .1,
                                child: loaderWidget())
                            : Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  if (players.isEmpty)
                                    SizedBox(
                                      height:
                                          MediaQuery.of(context).size.height *
                                              .1,
                                      child: Center(
                                          child: Text(
                                              l10n
                                                  .of(context)
                                                  .noFavouritePlayersFound,
                                              style: TextStyle(
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 16,
                                                  color: AppColors.black555))),
                                    ),
                                  ListView.builder(
                                    shrinkWrap: true,
                                    physics: NeverScrollableScrollPhysics(),
                                    itemCount: players.length,
                                    itemBuilder: (context, index) {
                                      var player = players[index];
                                      bool isAdded = viewModel1.userData.any(
                                          (element) =>
                                              element?.id == player?.id);
                                      return GestureDetector(
                                        onTap: () {
                                          final contactModel = ContactModel(
                                            id: player.id ?? '',
                                            // assuming friend has `id`
                                            name: player.friend?.name ?? '',

                                            phoneNumber:
                                                player.friend?.mobileNumber ??
                                                    '',
                                            isActive: true,
                                            // Add other required fields if neededtr
                                          );

                                          viewModel1.addUserData(
                                              user: contactModel);
                                          setState(() {});
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 12, horizontal: 0),
                                          child: Row(
                                            children: [
                                              ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(8),
                                                child: Container(
                                                  height: 40,
                                                  width: 40,
                                                  decoration: BoxDecoration(
                                                      shape: BoxShape.circle,
                                                      color: AppColors
                                                          .primaryColor),
                                                  child: Center(
                                                      child: Text(
                                                          player.friend?.name
                                                                  ?.substring(
                                                                      0, 1)
                                                                  .capitalizeFirstLetter() ??
                                                              "".toString(),
                                                          style: TextStyle(
                                                              fontSize: 15,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w700,
                                                              color: AppColors
                                                                  .black))),
                                                ),
                                              ),
                                              const SizedBox(width: 16),
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                      (player.friend?.name ??
                                                              l10n
                                                                  .of(context)
                                                                  .na)
                                                          .capitalizeFirstLetter()
                                                          .toString(),
                                                      style: const TextStyle(
                                                          fontSize: 15,
                                                          color:
                                                              AppColors.black,
                                                          fontWeight:
                                                              FontWeight.w700)),
                                                  Text(
                                                      "+${player.friend?.countryCode ?? ""}  ${player.friend?.mobileNumber ?? "---"}",
                                                      style: const TextStyle(
                                                          fontSize: 13,
                                                          fontWeight:
                                                              FontWeight.w700,
                                                          color: AppColors
                                                              .black555)),
                                                ],
                                              ),
                                              const Spacer(),
                                              isAdded
                                                  ? Text(l10n.of(context).added,
                                                      style: TextStyle(
                                                          fontSize: 12,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          color:
                                                              AppColors.red323))
                                                  : InkWell(
                                                      onTap: () async {
                                                        await homeView
                                                            .removePlayerFromFavouriteApi(
                                                          context: context,
                                                          playerId:
                                                              player.playerid ??
                                                                  "",
                                                          players:
                                                              players, // pass the actual list being used in UI
                                                        );
                                                        setState(() {});
                                                      },

                                                      // onTap: () async {
                                                      //   homeView.removePlayerFromFavouriteApi(context: context,
                                                      //       playerId: player.id ?? "");
                                                      //   await viewModel.getFavouritePlayerData(context: context);
                                                      // },
                                                      child: ClipRRect(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(8),
                                                          child: Image.asset(
                                                              'assets/icons/heart.png',
                                                              width: 25,
                                                              height: 25,
                                                              color: AppColors
                                                                  .primaryColor,
                                                              fit:
                                                                  BoxFit.fill)),
                                                    ),
                                            ],
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ],
                              ),

                        SizedBox(
                          height: h,
                          child: viewModel1.searchContacts.isEmpty
                              ? Center(
                                  child: Text(
                                      l10n.of(context).contactListIsEmpty,
                                      style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w600,
                                          color: AppColors.black)))
                              : ListView.builder(
                                  itemCount: viewModel1.searchContacts.length,
                                  padding: EdgeInsets.zero,
                                  shrinkWrap: true,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemBuilder: (context, index) {
                                    Contact contact =
                                        viewModel1.searchContacts[index];
                                    bool isAdded = viewModel1.userData.any(
                                        (element) => element.id == contact.id);
                                    ContactModel contactModel = ContactModel(
                                      id: contact.id ?? "",
                                      isActive: true,
                                      name: contact.displayName ?? "",
                                      phoneNumber:
                                          contact.phones.firstOrNull?.number ??
                                              "",
                                    );
                                    return ListTile(
                                      onTap: () {
                                        viewModel1.addUserData(
                                            user: contactModel);
                                        setState(() {});
                                      },
                                      contentPadding: EdgeInsets.zero,
                                      leading: ClipRRect(
                                        borderRadius: BorderRadius.circular(30),
                                        child: SizedBox(
                                          height: 40,
                                          width: 40,
                                          child: (contact.photo != null)
                                              ? CircleAvatar(
                                                  backgroundImage: MemoryImage(
                                                      contact.photo!))
                                              : CircleAvatar(
                                                  backgroundColor:
                                                      AppColors.primaryColor,
                                                  child: Center(
                                                      child: Text(
                                                          contact.displayName
                                                              .substring(0, 1),
                                                          style: TextStyle(
                                                              fontSize: 16,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                              color: AppColors
                                                                  .black))),
                                                ),
                                        ),
                                      ),
                                      title: Text(contact.displayName,
                                          style: TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.w700,
                                              color: AppColors.black)),
                                      subtitle: Text(
                                        contact.phones.isNotEmpty
                                            ? contact.phones.first.number
                                            : l10n.of(context).noNumber,
                                        style: TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w500,
                                            color: AppColors.black555),
                                      ),
                                      trailing: SizedBox(
                                        height: 26,
                                        width: 70,
                                        child: isAdded
                                            ? Text(l10n.of(context).added,
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    fontWeight: FontWeight.w500,
                                                    color: AppColors.red323))
                                            : Row(
                                                children: [
                                                  Icon(
                                                      Icons
                                                          .add_circle_outline_outlined,
                                                      color:
                                                          AppColors.greenC748),
                                                  SizedBox(width: 7),
                                                  Text(l10n.of(context).add,
                                                      style: TextStyle(
                                                          fontSize: 12,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          color: AppColors
                                                              .greenC748)),
                                                ],
                                              ),
                                      ),
                                    );
                                  },
                                ),
                        ),
                        // SizedBox(height: 10),
                        // AppButtonCommon(
                        //   onPressed: () {
                        //     viewModel1.navigateToAddedFriendsScreen(context);
                        //   },
                        //   label: S.of(context).add,
                        // ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  String? _tcErrorMessage;

  Future<dynamic> buildShowModalBottomSheet(BuildContext context) {
    List<String> imgList = [
      "assets/png/png_fb.png",
      if (Platform.isAndroid) "assets/png/png_google.png",
      if (Platform.isIOS) "assets/png/png_apple.png"
    ];
    context.read<BookingProvider>().init();
    return showModalBottomSheet(
      isScrollControlled: true,
      backgroundColor: Colors.white,
      context: context,
      isDismissible: false,
      builder: (context) {
        return StatefulBuilder(builder: (context, sateState) {
          return ListView(
            shrinkWrap: true,
            children: [
              Consumer<BookingProvider>(builder:
                  (BuildContext context, viewModelGetUser2, Widget? child) {
                return Padding(
                  padding: EdgeInsets.only(
                      bottom: MediaQuery.of(context).viewInsets.bottom),
                  child: Container(
                    color: Colors.transparent,
                    padding: EdgeInsets.only(top: 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Align(
                          alignment: Alignment.topRight,
                          child: InkWell(
                            onTap: () {
                              _tcErrorMessage = null;
                              Navigator.pop(context);
                            },
                            child: Container(
                              height: 30,
                              width: 30,
                              margin: EdgeInsets.only(right: 16),
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: AppColors.white),
                              child: Center(
                                  child: Icon(Icons.clear,
                                      color: AppColors.black)),
                            ),
                          ),
                        ),
                        SizedBox(height: 20),
                        Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 16, vertical: 16),
                            width: double.infinity,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(20),
                                topRight: Radius.circular(20),
                              ),
                              color: AppColors.white,
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(l10n.of(context).youreAlmostThere,
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.normal,
                                        color: AppColors.black)),
                                SizedBox(height: 20),
                                Text(
                                  l10n.of(context).enterMobileNumber,
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.normal,
                                    color: AppColors.black555,
                                  ),
                                ),
                                SizedBox(height: 20),
                                Form(
                                  key: _formKey,
                                  child: Column(
                                    children: [
                                      AppTextField(
                                        onchanged:
                                            viewModelGetUser2.updatePhoneNumber,
                                        borderColor:
                                            AppColors.teal747D.withOpacity(.5),
                                        controller:
                                            viewModelGetUser2.phoneController,
                                        prefixWidget: GestureDetector(
                                          onTap: () {
                                            showCountryPicker(
                                              context: context,
                                              showPhoneCode: true,
                                              onSelect: (value) {
                                                String? rawCode =
                                                    value.phoneCode;
                                                if (rawCode != null &&
                                                    rawCode.startsWith("+")) {
                                                  rawCode =
                                                      rawCode.substring(1);
                                                }

                                                viewModelGetUser2
                                                    .countryCodeController
                                                    .text = rawCode ?? "44";
                                                viewModelGetUser2
                                                    .updateCountryCode(
                                                        rawCode ?? "44");

                                                // Set the flag emoji
                                                viewModelGetUser2
                                                        .selectedCountryFlag =
                                                    value
                                                        .flagEmoji; // <-- Set the flag here

                                                // modalSetState(() {});
                                              },
                                              moveAlongWithKeyboard: false,
                                              countryListTheme:
                                                  CountryListThemeData(
                                                borderRadius: BorderRadius.only(
                                                  topLeft:
                                                      Radius.circular(40.0),
                                                  topRight:
                                                      Radius.circular(40.0),
                                                ),
                                                inputDecoration:
                                                    InputDecoration(
                                                  labelText: 'Search',
                                                  hintText:
                                                      'Start typing to search',
                                                  prefixIcon:
                                                      const Icon(Icons.search),
                                                ),
                                                searchTextStyle:
                                                    const TextStyle(
                                                  color: Colors.blue,
                                                  fontSize: 18,
                                                ),
                                              ),
                                            );
                                          },
                                          child: Container(
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 12, vertical: 8),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Text(viewModelGetUser2
                                                        .selectedCountryFlag ??
                                                    "🇬🇧"), // Default UK flag

                                                // Icon(Icons.flag),
                                                SizedBox(width: 8),
                                                Text(
                                                    '+${viewModelGetUser2.countryCodeController.text}'),
                                                Icon(Icons.arrow_drop_down),
                                              ],
                                            ),
                                          ),
                                        ),
                                        validator: (value) {
                                          if (value == null || value.isEmpty) {
                                            return l10n
                                                .of(context)
                                                .pleaseEnterYourPhoneNumber;
                                          }
                                          if (!RegExp(r'^\d{8,12}$')
                                              .hasMatch(value)) {
                                            return l10n
                                                .of(context)
                                                .phoneNumberMustBe810Digits;
                                          }
                                          return null;
                                        },
                                        inputFormatters: [
                                          FilteringTextInputFormatter
                                              .digitsOnly,
                                          LengthLimitingTextInputFormatter(12),
                                        ],
                                        height: 42,
                                        hintText: l10n
                                            .of(context)
                                            .enter810DigitPhoneNumber,
                                        keyboardType: TextInputType.number,
                                      ),
                                      SizedBox(height: 20),
                                      StatefulBuilder(
                                          builder: (context, setState) {
                                        return AppButton(
                                          label: l10n.of(context).sendOtp,
                                          onPressed: () async {
                                            sateState(() {
                                              _tcErrorMessage = null;
                                              viewModelGetUser2
                                                  .otpErrorMessage = null;
                                            });

                                            if (!_formKey.currentState!
                                                .validate()) {
                                              return;
                                            }

                                            if (!viewModelGetUser2.isChecked) {
                                              sateState(() {
                                                _tcErrorMessage = l10n
                                                    .of(context)
                                                    .pleaseAcceptTheTermsConditionsToContinue;
                                              });
                                              return;
                                            }

                                            String phoneNumber =
                                                viewModelGetUser2
                                                    .phoneController.text;
                                            String countryCode =
                                                viewModelGetUser2
                                                    .countryCodeController.text;
                                            String fullPhoneNumber =
                                                "$countryCode$phoneNumber";
                                            print(
                                                "Full Phone Number GUEST FLOW: $fullPhoneNumber");
                                            print(
                                                "CONTRY CODE GUEST FLOW: $countryCode");

                                            bool isSuccess =
                                                await viewModelGetUser2
                                                    .sendOtpRequest(
                                                        countryCode1:
                                                            countryCode,
                                                        phoneNumber1:
                                                            phoneNumber);

                                            if (isSuccess) {
                                              Navigator.pop(context);
                                              buildSendOtpShowModalBottomSheet(
                                                  context,
                                                  countryCode,
                                                  phoneNumber);
                                            } else {
                                              setState(() {
                                                viewModelGetUser2
                                                        .otpErrorMessage =
                                                    l10n
                                                        .of(context)
                                                        .failedToSendOtpPleaseTryAgain;
                                              });
                                              _formKey.currentState!.validate();
                                            }
                                          },
                                          textColor: viewModelGetUser2.isFilled
                                              ? AppColors.white
                                              : AppColors.black555,
                                          bgColor: viewModelGetUser2.isFilled
                                              ? AppColors.primaryColor
                                              : AppColors.greyEFEF,
                                        );
                                      }),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 20),
                                Row(
                                  children: [
                                    SizedBox(
                                      height: 20,
                                      width: 20,
                                      child: Checkbox(
                                        checkColor: AppColors.white,
                                        overlayColor: WidgetStateProperty.all(
                                            AppColors.black),
                                        fillColor: WidgetStateProperty.all(
                                            viewModelGetUser2.isChecked == false
                                                ? AppColors.white
                                                : AppColors.black),
                                        value: viewModelGetUser2.isChecked,
                                        onChanged: (bool? value) {
                                          viewModelGetUser2
                                              .updateCheckedButton();
                                          setState(() {
                                            _tcErrorMessage = null;
                                          });
                                        },
                                      ),
                                    ),
                                    SizedBox(width: 5),
                                    RichText(
                                      text: TextSpan(
                                        text: l10n.of(context).agreeWith,
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.normal,
                                            color: AppColors.grey769),
                                        children: [
                                          TextSpan(
                                            text: l10n
                                                .of(context)
                                                .termsAndConditions,
                                            style: TextStyle(
                                                fontSize: 14,
                                                fontWeight: FontWeight.normal,
                                                color: AppColors.black),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 5),
                                if (_tcErrorMessage != null)
                                  Padding(
                                    padding: const EdgeInsets.only(left: 4),
                                    child: Text(
                                      _tcErrorMessage!,
                                      style: TextStyle(
                                          color: Colors.red, fontSize: 12),
                                    ),
                                  ),
                                SizedBox(height: 20),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded(
                                      child: Container(
                                        height: 1,
                                        width:
                                            (MediaQuery.of(context).size.width /
                                                    2) -
                                                50,
                                        color: AppColors.greyBEBE,
                                      ),
                                    ),
                                    Padding(
                                      padding:
                                          EdgeInsets.symmetric(horizontal: 5),
                                      child: Text(l10n.of(context).or,
                                          style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.normal,
                                              color: AppColors.grey769)),
                                    ),
                                    Container(
                                      height: 1,
                                      width:
                                          (MediaQuery.of(context).size.width /
                                                  2) -
                                              35,
                                      color: AppColors.greyBEBE,
                                    ),
                                  ],
                                ),
                                SizedBox(height: 20),
                                Row(
                                  spacing: 10,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children:
                                      List.generate(imgList.length, (index) {
                                    return InkWell(
                                      onTap: () async {
                                        switch (index) {
                                          case 0:
                                            await SocialLoginRepository
                                                    .signInWithFacebook(
                                                        context: context)
                                                .then(
                                              (value) {
                                                /// TODO: implement sign in with facebook
                                              },
                                            );

                                            return;
                                          case 1:
                                            if (Platform.isIOS) {
                                              await SocialLoginRepository
                                                      .loginWithApple(context)
                                                  .then(
                                                (value) {
                                                  /// TODO: implement sign in with facebook
                                                },
                                              );
                                            } else {
                                              await SocialLoginRepository
                                                      .signInWithGoogle(context)
                                                  .then(
                                                (value) {
                                                  if (value["isSuccess"]) {}
                                                },
                                              );
                                            }

                                            return;

                                          default:
                                            return;
                                        }
                                      },
                                      child: SizedBox(
                                        width: 54,
                                        height: 54,
                                        child: Image.asset(imgList[index],
                                            fit: BoxFit.fill),
                                      ),
                                    );
                                  }),
                                ),
                                SizedBox(height: 20),
                              ],
                            )),
                      ],
                    ),
                  ),
                );
              }),
            ],
          );
        });
      },
    );
  }

  Future<dynamic> buildSendOtpShowModalBottomSheet(
      BuildContext context, countryCode, phoneNumber) {
    // Set values before showing
    final provider = Provider.of<BookingProvider>(context, listen: false);
    printLog("...../////  $countryCode ... $phoneNumber");
    provider.countryCodeController.text = countryCode;
    provider.phoneController.text = phoneNumber;
    provider.startResendOtpTimer();

    return showModalBottomSheet(
      isScrollControlled: true,
      backgroundColor: Colors.white,
      context: context,
      builder: (context) {
        return ListView(
          shrinkWrap: true,
          children: [
            Padding(
              padding: EdgeInsets.only(
                  bottom: MediaQuery.of(context).viewInsets.bottom),
              child: Consumer<BookingProvider>(
                builder:
                    (BuildContext context, viewModelGetUser, Widget? child) {
                  return Container(
                    color: Colors.transparent,
                    padding: EdgeInsets.only(top: 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Align(
                          alignment: Alignment.topRight,
                          child: InkWell(
                            onTap: () {
                              viewModelGetUser.otpController.clear();
                              Navigator.pop(context);
                            },
                            child: Container(
                              height: 30,
                              width: 30,
                              margin: EdgeInsets.only(right: 16),
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: AppColors.white),
                              child: Center(
                                  child: Icon(Icons.clear,
                                      color: AppColors.black)),
                            ),
                          ),
                        ),
                        SizedBox(height: 20),
                        Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 16, vertical: 16),
                          width: double.infinity,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(20),
                                  topRight: Radius.circular(20)),
                              color: AppColors.white),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(l10n.of(context).youreAlmostThere,
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.normal,
                                      color: AppColors.black)),
                              SizedBox(height: 20),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(l10n.of(context).enterOtp,
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.normal,
                                          color: AppColors.black555)),
                                  Text("+$countryCode $phoneNumber",
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.normal,
                                          color: AppColors.black555)),
                                ],
                              ),
                              SizedBox(height: 20),
                              StatefulBuilder(
                                builder: (context, StateSetter) {
                                  return Column(
                                    children: [
                                      OtpTextFormField(
                                        controller:
                                            viewModelGetUser.otpController,
                                        onchanged: (str) {
                                          setState(() {});
                                        },
                                        isValidator: true,
                                      ),
                                      if (viewModelGetUser.otpErrorMessage !=
                                          null)
                                        Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 8.0),
                                          child: Text(
                                            viewModelGetUser.otpErrorMessage!,
                                            style: TextStyle(
                                              color: Colors.red,
                                              fontSize: 14,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ),
                                      SizedBox(height: 20),
                                      AppButton(
                                        label: l10n.of(context).verifyOtp,
                                        onPressed: () async {
                                          String enteredOtp = viewModelGetUser
                                              .otpController.text;
                                          print('otp: $enteredOtp');

                                          if (enteredOtp.isNotEmpty) {
                                            try {
                                              int otpInt =
                                                  int.parse(enteredOtp);
                                              bool isSuccess =
                                                  await viewModelGetUser
                                                      .verifyOtp(
                                                context,
                                                otpInt,
                                              );

                                              if (isSuccess) {
                                                setState(() {
                                                  final myaccount =
                                                      context.read<
                                                          MyAccountViewModel>();
                                                  myaccount.countryCode =
                                                      countryCode;
                                                  myaccount.mobileno =
                                                      phoneNumber;
                                                });
                                                Navigator.pop(context);

                                                // viewModelGetUser.phoneController
                                                //     .clear();
                                                viewModelGetUser.otpController
                                                    .clear();
                                                print(
                                                    "OTP verified successfully!");
                                              } else {
                                                print(
                                                    "OTP verification failed!");
                                              }
                                            } catch (e) {
                                              print("Invalid OTP format: $e");
                                            }
                                          } else {
                                            print("OTP field is empty.");
                                          }
                                        },
                                        textColor: viewModelGetUser
                                                    .otpController.text.length >
                                                4
                                            ? AppColors.white
                                            : AppColors.black555,
                                        bgColor: viewModelGetUser
                                                    .otpController.text.length >
                                                4
                                            ? AppColors.primaryColor
                                            : AppColors.greyEFEF,
                                      ),
                                    ],
                                  );
                                },
                              ),
                              SizedBox(height: 20),
                              Consumer<BookingProvider>(
                                builder: (context, viewModelGetUser, _) {
                                  return Center(
                                    child: GestureDetector(
                                      onTap: viewModelGetUser.canResendOtp
                                          ? () {
                                              // TODO: trigger OTP resend API
                                              viewModelGetUser
                                                  .startResendOtpTimer(); // restart timer
                                              print("Resending OTP...");
                                            }
                                          : null,
                                      child: Text(
                                        viewModelGetUser.canResendOtp
                                            ? l10n.of(context).resendOtp
                                            : "${l10n.of(context).resendIn} ${viewModelGetUser.remainingSeconds}s",
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w700,
                                          color: viewModelGetUser.canResendOtp
                                              ? AppColors.black
                                              : AppColors
                                                  .grey8A8, // gray when disabled
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ), // Text("Resend OTP",
                              //     style: TextStyle(
                              //         fontSize: 14,
                              //         fontWeight: FontWeight.w700,
                              //         color: AppColors.black)),
                              SizedBox(height: 20),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}

// Helper function to compare dates without time
DateTime dateOnly(DateTime date) {
  debugPrint("formatted date ${DateTime(date.year, date.month, date.day)}");
  return DateTime(date.year, date.month, date.day);
}
