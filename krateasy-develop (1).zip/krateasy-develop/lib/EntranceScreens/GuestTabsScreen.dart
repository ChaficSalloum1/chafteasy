import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import '../GlobalUtils/app_colors.dart';
import 'AvailableChallengesGuest.dart';
import 'AvailableCourtsGuest.dart';

class GuestTabsScreen extends StatefulWidget {
  const GuestTabsScreen({
    super.key,
  });

  @override
  State<GuestTabsScreen> createState() => _GuestTabsScreenState();
}

class _GuestTabsScreenState extends State<GuestTabsScreen> {
  List<String>? selectedTimeSlots;

  String? selectedSportId;
  String? selectedSport;
  String? date;
  // @override
  // void didChangeDependencies() {
  //   super.didChangeDependencies();
  //   final args =
  //       ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;

  //   if (args != null && selectedSportId == null) {
  //     // To avoid re-assigning on rebuild
  //     selectedSportId = args['sportId'];
  //     selectedSport = args['sportName'];
  //     log("Fetched from route: $selectedSportId - $selectedSport");
  //   }
  //   if (args != null && selectedSportId == null) {
  //     selectedSportId = args['sportId'];
  //     selectedSport = args['sportName'];
  //     selectedTimeSlots = (args['selectedTimeSlots'] as List?)?.cast<String>();
  //   }
  //   print ("fnl ...${selectedTimeSlots}");
  // }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args =
        ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;

    if (args != null && selectedSportId == null) {
      // This block runs only once
      selectedSportId = args['sportId'];
      selectedSport = args['sportName'];
      date = args['selectedDate'];
      selectedTimeSlots = (args['selectedTimeSlots'] as List?)?.cast<String>();

      log("Fetched from route: $selectedSportId - $selectedSport");
      log("Fetched selectedTimeSlots: $selectedTimeSlots");
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    return DefaultTabController(
      length: 2, // Number of tabs
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Padding(
            padding: EdgeInsets.only(top: 6),
            child: Stack(
              children: [
                Column(
                  children: [
                    const SizedBox(height: 60),
                    Expanded(
                      child: TabBarView(
                        children: [
                          Availablecourtsguest(
                            selectedSportId: selectedSportId ?? "",
                            selectedSport: selectedSport ?? "",
                            selectedTimes: selectedTimeSlots ?? [],
                          ),
                          Availablechallengesguest(
                            date: date,
                            sportId: selectedSportId ?? "",
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: EdgeInsets.only(left: 16, right: 16, top: 10),
                  child: SizedBox(
                    height: 50,
                    width: screenWidth,
                    child: Theme(
                      data: ThemeData(
                        tabBarTheme: TabBarThemeData(
                          labelColor: Colors.black,
                          dividerColor: AppColors.white,
                          unselectedLabelColor: AppColors.black555,
                          indicator: BoxDecoration(
                            color: Color(
                              0xFF8DC63F,
                            ),
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                          color: AppColors.lightPrimaryColorFFE5,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.08),
                              offset: Offset(0, 4),
                              blurRadius: 6,
                            ),
                          ],
                        ),
                        child: TabBar(
                          indicatorSize: TabBarIndicatorSize.tab,
                          tabs: [
                            Tab(
                              child: Text(
                                 l10n.of(context).nearbyCourts,
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                            Tab(
                              child: Text(
                                l10n.of(context).challenges,
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
