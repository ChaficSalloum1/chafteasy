
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:qr_flutter/qr_flutter.dart';

class FriendSuccessPayment extends StatefulWidget {
final String id;
final String amt;
final String bookingID;

  const FriendSuccessPayment({super.key,  this.id="", this.amt="", this.bookingID=""});

  @override
  State<FriendSuccessPayment> createState() =>
      _FriendSuccessPaymentState();
}

class _FriendSuccessPaymentState extends State<FriendSuccessPayment> {
  String ID = "";
  String amt = "";
  String bookingID = "";
  bool isGuest = false;

  @override
  // void didChangeDependencies() {
  //   super.didChangeDependencies();
  //
  //   final args = ModalRoute.of(context)?.settings.arguments;
  //
  //   if (args is Map && args.containsKey('id')) {
  //     ID = args['id'].toString();
  //     printLog("id--- > $ID ");
  //   }
  //
  //   if (args is Map && args.containsKey('bookingId')) {
  //     bookingID = args['bookingId'].toString();
  //     printLog("bookingID > $bookingID ");
  //   }
  //   if (args is Map && args.containsKey('isGuestBooking')) {
  //     isGuest = args['isGuestBooking'] == true;
  //     printLog("isGuestBooking > $isGuest ");
  //   }
  //   if (args is Map && args.containsKey('amount')) {
  //     amt = args['amount'].toString();
  //     printLog("amount > $amt ");
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    // final viewModel = Provider.of<ActiveChallengeViewModel>(context);
    final joinViewModel = Provider.of<HomeViewModel>(context);
    final createChallengeViewModel =
    Provider.of<CreateChallengeViewModel>(context);
    printLog("book1234567890ingID > $bookingID ");

    return PopScope(
      canPop: false,
      child: Scaffold(
        // floatingActionButton: FloatingActionButton(onPressed: (){Navigator.pop(context);}),
        backgroundColor: AppColors.white,
        body: Center(
          child: Consumer<BookingProvider>(
            builder: (BuildContext context, viewModel, Widget? child) {
              return Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(
                        width: 175,
                        height: 168,
                        child:
                        Image.asset(viewModel.logoPath, fit: BoxFit.fill)),
                    SizedBox(height: 5),
                    Text(l10n.of(context).paymentSuccessful,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: 30,
                            fontWeight: FontWeight.w600,
                            color: AppColors.black)),
                    SizedBox(height: 5),
                    Text( l10n.of(context).yourTransactionIsComplete,
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                            color: AppColors.black555)),
                    Text( l10n.of(context).enjoyYourBooking,
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                            color: AppColors.black555)),
                    SizedBox(height: 5),

                    SizedBox(height: 20),

                    SizedBox(height: 20),

                    SizedBox(height: 20),
                    Consumer<BookingProvider>(
                      builder:
                          (BuildContext context, viewModel1, Widget? child) {
                        return AppButtonCommon(
                            isLoading: joinViewModel.isLoading,
                            onPressed: () {
                              Navigator.pop(context);
                              Navigator.pushAndRemoveUntil(
                                  context,
                                  MaterialPageRoute(builder: (_) => DashboardScreen(initialIndex: 0,)),
                                      (route) => false);

                            },
                            label:
                            l10n.of(context).continues
                          // : "Go To Home",
                        );
                      },
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
