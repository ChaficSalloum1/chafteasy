import 'dart:developer';
import 'package:easy_date_timeline/easy_date_timeline.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:kratEasyApp/Models/serach_Court_Payload_Model.dart';
import 'package:kratEasyApp/ViewModel/EntranceViewModel/ChooseSportsViewModel.dart';
import 'package:kratEasyApp/ViewModel/EntranceViewModel/MyLocationViewModel.dart';
import 'package:kratEasyApp/ViewModel/EntranceViewModel/SearchCourtViewModel.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../API_CALLS/Helper.dart';
import '../BottomNavScreens/CreateChallengeScreen/CreateChallengeScreen.dart';
import '../GlobalUtils/app_button.dart';
import '../GlobalUtils/app_colors.dart';
import '../GlobalUtils/common_app_bar.dart';
import '../Models/SportList.dart';

class SearchCourtScreen extends StatefulWidget {
  const SearchCourtScreen({super.key});

  @override
  _SearchCourtScreenState createState() => _SearchCourtScreenState();
}

class _SearchCourtScreenState extends State<SearchCourtScreen> {
  DateTime _selectedDate = DateTime.now();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final viewModel =
          Provider.of<SearchCourtViewModel>(context, listen: false);
      Provider.of<ChooseSportsViewModel>(context, listen: false).fetchSports();
      viewModel.getSportsDataApi(context: context).then((_) {
        log('Sports list length: ${viewModel.sportsList.length}');
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = Provider.of<SearchCourtViewModel>(context);
    final locationModel = Provider.of<MyLocationViewModel>(context);
    // final locationViewModel = context.read<MyLocationViewModel>();

    // double screenWidth = MediaQuery.of(context).size.width;

    return SafeArea(bottom: true,top: false,
      child: Scaffold(
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.only(bottom: 16.0, right: 16.0, left: 16.0),
          child: AppButtonCommon(
            isLoading: _isLoading,
            isLoadingColor: AppColors.white,
            label: l10n.of(context).apply,
            fontWeight: FontWeight.w600,
            onPressed: () async {
              if (mounted) {
                setState(() => _isLoading = false);
              }

              final selectedSportName = viewModel.selectedSport;
              final selectedAmenityNames = viewModel.selectedAmenitie;
              final selectedLocation = locationModel.locationController.text;
              final selectedDate = _selectedDate;
              final selectedTimeSlots = viewModel.selectedTimeGrids
                  .map((index) => viewModel.availableTimes[index])
                  .toList();

              if (selectedSportName == null) {
                ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(l10n.of(context).pleaseSelectASport)));
                return;
              }

              if (selectedLocation.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content:
                        Text(l10n.of(context).locationNotFetchedPleaseTryAgain)));
                return;
              }

              if (selectedTimeSlots.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text(l10n.of(context).pleaseSelectAtLeastOneTimeSlot)));
                return;
              }

              setState(() => _isLoading = true);

              try {
                final sportId = Helper.sports
                    .firstWhere((sport) => sport.name == selectedSportName,
                        orElse: () => SportList(id: '', name: '', image: ''))
                    .id;

                final amenitiesIds = Helper.amenities
                    .where(
                        (amenity) => selectedAmenityNames.contains(amenity.name))
                    .map((amenity) => amenity.id)
                    .toList();
                SharedPreferences prefs = await SharedPreferences.getInstance();
                var lat = prefs.getDouble("current_lat");
                var long = prefs.getDouble("current_long");

                log('Selected Sport ID: $sportId');
                log('Selected Amenity IDs: $amenitiesIds');
                log('Selected Time Slots: $selectedTimeSlots');
                log('Selected lat: $lat');
                log('Selected long: $long');

                if (sportId.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text(l10n.of(context).invalidSportSelection)));
                  setState(() => _isLoading = false);
                  return;
                }
                var timeZone =
                    await prefs.getString("timeZone") ?? "Asia/Kolkata";
                final bookingRequest = BookingRequest(
                  timeZone: timeZone,
                  lat: lat.toString(),
                  long: long.toString(),
                  date: DateFormat('dd-MM-yyyy').format(selectedDate),
                  time: selectedTimeSlots,
                  sportId: sportId,
                  amenityId: amenitiesIds,
                );
                log("test..bookingRequest.. $bookingRequest");
                final success =
                    await viewModel.newSearchCourt(bookingRequest, context);

                log("success..... ${success?.message}");
                final hasCourts =
                    success?.data != null && success!.data!.isNotEmpty;

                if (success != null && success.success == true && hasCourts) {
                  viewModel.navigateToGuestBookingScreen(
                    context: context,
                    sportId: sportId,
                    sportName: selectedSportName,
                    selectedTimeSlots: selectedTimeSlots,
                    date: DateFormat('dd-MM-yyyy').format(selectedDate),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                        content:
                            Text(viewModel.error ?? l10n.of(context).noDataFound)),
                  );
                  print("Not navigating — search failed");
                }
              } catch (error) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                        content:
                            Text("${l10n.of(context).error}: ${error.toString()}")),
                  );
                }
              } finally {
                setState(() => _isLoading = false);
              }
            },
          ),
        ),
        backgroundColor: Colors.white,
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(kToolbarHeight + 4),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CommonAppBar(
                  title: l10n.of(context).searchCourts,
                  fontsize: 20,
                  backIconColor: Colors.white,
                  backgroundColor: Colors.white,
                  fontWeight: FontWeight.w400),
              LinearProgressIndicator(
                  value: 3 / 3,
                  backgroundColor: const Color(0xFFE5E5E5),
                  valueColor:
                      const AlwaysStoppedAnimation<Color>(Color(0xFF8DC63F))),
            ],
          ),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // if (viewModel.sportsList.isEmpty)
                DropdownButtonFormField<String>(
                  value: viewModel.selectedSport,
                  hint: Text(l10n.of(context).selectSport),
                  icon: Image.asset("assets/icons/lowarrow.png",
                      height: 16, width: 14),
                  items: viewModel.sportsList.map((sport) {
                    return DropdownMenuItem<String>(
                        value: sport, child: Text(sport));
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      log("sporttttttt $value");
                      viewModel.selectedSport = value;
                    });
                  },
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: AppColors.lightGreen,
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: Colors.transparent)),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: Colors.transparent)),
                    contentPadding:
                        EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  ),
                ),
                SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: viewModel.selectedAmenitie.isEmpty
                      ? null
                      : viewModel.selectedAmenitie.last,
                  hint: Text(l10n.of(context).amenities),
                  icon: Image.asset("assets/icons/lowarrow.png",
                      height: 16, width: 14),
                  items: viewModel.amenititesList.map((sport) {
                    return DropdownMenuItem<String>(
                        value: sport.id, child: Text(sport.name));
                  }).toList(),
                  onChanged: (value) {
                    if (value != null &&
                        !viewModel.selectedAmenitie.contains(value)) {
                      setState(() {
                        viewModel.selectedAmenitie.add(value);
                      });
                    }
                  },
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Color(0xFFF4F9EC),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: Colors.transparent)),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: Colors.transparent)),
                    contentPadding:
                        EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  ),
                ),
                SizedBox(height: 16),
                Wrap(
                  spacing: 8.0,
                  children: viewModel.selectedAmenitie.map((id) {
                    final amenity = viewModel.amenititesList.firstWhere(
                      (a) => a.id == id,
                    );

                    if (amenity == null) return SizedBox();

                    return Chip(
                      label: Text(
                        amenity.name,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      backgroundColor: AppColors.deepTeal,
                      deleteIcon: Image.asset('assets/icons/crosscircle.png'),
                      onDeleted: () {
                        setState(() {
                          viewModel.selectedAmenitie.remove(id);
                        });
                      },
                    );
                  }).toList(),
                ),

                viewModel.selectedAmenitie.isEmpty
                    ? SizedBox()
                    : SizedBox(height: 16),
                TextField(
                  controller: locationModel.locationController,
                  readOnly: true,
                  onTap: locationModel.isLoadingManually
                      ? () {}
                      : () {
                          locationModel.getAndNavigateToMapScreen(context, true);
                        },
                  // Make it non-editable
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Color(0xFFF4F9EC),
                    hintText: l10n.of(context).fetchingCurrentLocation,
                    suffixIcon: SizedBox(
                        height: 20,
                        width: 20,
                        child: Center(
                          child: locationModel.isLoadingManually
                              ? CircularProgressIndicator(
                                  strokeWidth: 0.5,
                                  color: AppColors.primaryColor,
                                )
                              : Image.asset("assets/icons/location.png",
                                  fit: BoxFit.fill, height: 20, width: 20),
                        )),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: Colors.transparent)),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: Colors.transparent)),
                    contentPadding:
                        EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  ),
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: Text(l10n.of(context).selectDate,
                      style: TextStyle(
                          fontSize: 14,
                          color: AppColors.black,
                          fontWeight: FontWeight.w600,
                          decoration: TextDecoration.underline)),
                ),
                const SizedBox(height: 5),
                EasyDateTimeLinePicker.itemBuilder(
                  firstDate: DateTime.now(),
                  lastDate: DateTime.now().add(Duration(days: 30)),
                  headerOptions: HeaderOptions(headerType: HeaderType.none),
                  focusedDate: DateTime.now(),
                  itemExtent: 60.0,
                  itemBuilder:
                      (context, date, isSelected, isDisabled, isToday, onTap) {
                    bool isSelectedDate =
                        dateOnly(date) == dateOnly(_selectedDate);
                    return InkResponse(
                      onTap: () {
                        setState(() {
                          _selectedDate = date; // Update selected date
                          Provider.of<SearchCourtViewModel>(context, listen: false)
                              .clearSelectedTimeSlots(); // Clear time slots
                        });
                      },      // onTap: () {
                      //   setState(() {
                      //     _selectedDate = date; // Update selected date
                      //   });
                      // },
                      child: Container(
                        height: 80,
                        width: 50,
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          border: Border.all(
                            width: 2,
                            color: isSelectedDate
                                ? AppColors.primaryColor
                                : Colors
                                    .transparent, // Border only on selected date
                          ),
                          borderRadius: BorderRadius.vertical(
                              top: Radius.circular(60),
                              bottom: Radius.circular(60)),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(date.day.toString(),
                                style: TextStyle(
                                    fontSize: 25,
                                    fontWeight: FontWeight.normal,
                                    color: AppColors.black)),
                            Text(
                              DateFormat('E').format(date),
                              // Format: Sun 25 Feb
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.normal,
                                  color: AppColors.black555),
                            ),
                            Container(
                              height: 9,
                              width: 9,
                              decoration: BoxDecoration(
                                color: isSelectedDate
                                    ? AppColors.primaryColor
                                    : Colors.transparent,
                                // Highlight dot on selected date
                                shape: BoxShape.circle,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                  onDateChange: (date) {
                    setState(() {
                      _selectedDate = date; // Update selected date
                      Provider.of<SearchCourtViewModel>(context, listen: false)
                          .clearSelectedTimeSlots(); // Clear time slots
                    });
                  },  // onDateChange: (date) {
                  //   setState(() {
                  //     _selectedDate = date; // Ensure selected date updates
                  //   });
                  // },
                ),
                const SizedBox(height: 10),
                Align(
                    alignment: Alignment.topCenter,
                    child: Text(DateFormat('E d MMM').format(_selectedDate),
                        style: TextStyle(
                            fontSize: 20,
                            color: AppColors.black,
                            fontWeight: FontWeight.w700))),
                const SizedBox(height: 14),
                const Divider(),
                const SizedBox(height: 10),
      //Select Time List
         GridView.builder(
        shrinkWrap: true,
        itemCount: viewModel.availableTimes.length,
        physics: NeverScrollableScrollPhysics(),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
      crossAxisCount: 3,
      mainAxisSpacing: 14,
      crossAxisSpacing: 11,
      childAspectRatio: 25 / 10,
        ),
        itemBuilder: (context, index) {
      bool isSelected = viewModel.selectedTimeGrids.contains(index);
      bool isPast = viewModel.isTimeSlotPast(index, _selectedDate); // Pass selected date

      return GestureDetector(
        onTap: isPast
            ? null // Disable tap if past
            : () {
                viewModel.toggleTimeGrid(index, context);
              },
        child: Container(
          decoration: BoxDecoration(
            color: isPast
                ? Colors.grey[300] // Grey out background
                : isSelected
                    ? AppColors.primaryColor
                    : AppColors.lightPrimaryColor9EC,
            borderRadius: BorderRadius.circular(5),
          ),
          child: Center(
            child: Text(
              // viewModel.availableTimes[index],
              viewModel.availableTimes[index],
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w500,
                color: isPast
                    ? Colors.grey[600] // Grey out text
                    : isSelected
                        ? AppColors.white
                        : AppColors.black555,
              ),
            ),
          ),
        ),
      );
        },
      ),
                // GridView.builder(
                //   shrinkWrap: true,
                //   itemCount: viewModel.availableTimes.length,
                //   physics: NeverScrollableScrollPhysics(),
                //   gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                //     crossAxisCount: 3,
                //     mainAxisSpacing: 14,
                //     crossAxisSpacing: 11,
                //     childAspectRatio: 25 / 10,
                //   ),
                //   itemBuilder: (context, index) {
                //     bool isSelected = viewModel.selectedTimeGrids.contains(index);
                //     bool isPast = viewModel.isTimeSlotPast(index); // ✅ NEW

                //     return GestureDetector(
                //       onTap: isPast
                //           ? null // ✅ Disable tap if past
                //           : () {
                //               viewModel.toggleTimeGrid(index, context);
                //             },
                //       child: Container(
                //         decoration: BoxDecoration(
                //           color: isPast
                //               ? Colors.grey[300] // ✅ grey out background
                //               : isSelected
                //                   ? AppColors.primaryColor
                //                   : AppColors.lightPrimaryColor9EC,
                //           borderRadius: BorderRadius.circular(5),
                //         ),
                //         child: Center(
                //           child: Text(
                //             viewModel.availableTimes[index],
                //             style: TextStyle(
                //               fontSize: 18,
                //               fontWeight: FontWeight.w500,
                //               color: isPast
                //                   ? Colors.grey[600] // ✅ grey out text
                //                   : isSelected
                //                       ? AppColors.white
                //                       : AppColors.black555,
                //             ),
                //           ),
                //         ),
                //       ),
                //     );
                //   },
                // ),
                // // GridView.builder(
                //   shrinkWrap: true,
                //   itemCount: viewModel.availableTimes.length,
                //   physics: NeverScrollableScrollPhysics(),
                //   gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                //       crossAxisCount: 3,
                //       mainAxisSpacing: 14,
                //       crossAxisSpacing: 11,
                //       childAspectRatio: 25 / 10),
                //   itemBuilder: (context, index) {
                //     bool isSelected = viewModel.selectedTimeGrids.contains(index);

                //     return GestureDetector(
                //       onTap: () {
                //         viewModel.toggleTimeGrid(index, context);
                //       },
                //       child: Container(
                //         decoration: BoxDecoration(
                //             color: isSelected
                //                 ? AppColors.primaryColor
                //                 : AppColors.lightPrimaryColor9EC,
                //             borderRadius: BorderRadius.circular(5)),
                //         child: Center(
                //           child: Text(viewModel.availableTimes[index],
                //               style: TextStyle(
                //                   fontSize: 18,
                //                   fontWeight: FontWeight.w500,
                //                   color: isSelected
                //                       ? AppColors.white
                //                       : AppColors.black555)),
                //         ),
                //       ),
                //     );
                //   },
                // ),
                // const SizedBox(height: 10),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
