import 'package:country_code_picker/country_code_picker.dart';
import 'package:flutter/services.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../GlobalUtils/CircularImageStack.dart';
import '../GlobalUtils/app_imports.dart';
import '../paymentprovider.dart';

class Availablechallengesguest extends StatefulWidget {
  final String? sportId;
  final String? date;
  const Availablechallengesguest({super.key, this.sportId, this.date});

  @override
  State<Availablechallengesguest> createState() =>
      _AvailablechallengesguestState();
}

class _AvailablechallengesguestState extends State<Availablechallengesguest> {
  TextEditingController _dateController = TextEditingController();
  TextEditingController _locationController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late AvailableChallengeGuestViewModel viewModel;
  late SearchCourtViewModel searchCourtViewModel;
  // @override
  // void initState() {
  //   super.initState();
  //   viewModel = context.read<AvailableChallengeGuestViewModel>();
  //   searchCourtViewModel = context.read<SearchCourtViewModel>();
  //   WidgetsBinding.instance.addPostFrameCallback((_) async {
  //     await searchCourtViewModel.getSportsDataApi();
  //     viewModel.fetchChallengesNew(
  //         sportId: widget.sportId ?? "",
  //         date: widget.date ?? '',
  //         context: context);
  //   });
  //   _loadSavedLocation();
  // }
  @override
  void initState() {
    super.initState();
    viewModel = context.read<AvailableChallengeGuestViewModel>();
    searchCourtViewModel = context.read<SearchCourtViewModel>();

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await searchCourtViewModel.getSportsDataApi(context: context);

      if (!mounted) return; // <- Safeguard

      viewModel.fetchChallengesNew(
        sportId: widget.sportId ?? "",
        date: widget.date ?? '',
        context: context,
      );
    });

    _loadSavedLocation();
  }

  Future<void> _loadSavedLocation() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? savedLocation = prefs.getString('saved_location');
    if (savedLocation != null) {
      setState(() {
        _locationController.text = savedLocation;
      });
    } else {
      setState(() {
        _locationController.text = l10n.of(context).locationNotAvailable;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = Provider.of<AvailableChallengeGuestViewModel>(context);
    return Scaffold(
      backgroundColor: Colors.white,
      body: viewModel.isLoadingDataNew
          ? Center(
              child: CircularProgressIndicator(
                color: AppColors.primaryColor,
              ),
            )
          : Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  //if user are not able to
                  viewModel.challengeDataList.isEmpty
                      ? SizedBox()
                      : Padding(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(l10n.of(context).availableChallenges,
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold)),
                              SizedBox(
                                  height: 24,
                                  width: 25,
                                  child: InkWell(
                                      onTap: () {
                                        _showFilter(context);
                                      },
                                      child: Image.asset(
                                          "assets/icons/filter.png",
                                          fit: BoxFit.fill))),
                            ],
                          ),
                        ),

                  /// listview data
                  viewModel.challengeDataList.isEmpty
                      ? Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Image.asset(
                              "assets/icons/footer.png",
                              height: 200,
                              width: 200,
                            ),
                            noDataWidget(text: l10n.of(context).challenges)
                          ],
                        )
                      : Expanded(
                          child: ListView.builder(
                            shrinkWrap: true,
                            padding: EdgeInsets.zero,
                            physics: AlwaysScrollableScrollPhysics(),
                            itemCount: viewModel.challengeDataList.length,
                            itemBuilder: (BuildContext context, int index) {
                              var challenge =
                                  viewModel.challengeDataList[index];
                              List<String>? imageUrls = challenge.whoJoined
                                  ?.map((x) => x['image']?.toString())
                                  .where((url) => url != null && url.isNotEmpty)
                                  .cast<String>()
                                  .toList();

                              final sportImage =
                                  challenge.slot?.court?.sport?.image;
                              print(
                                  "imagggg  ${challenge.slot?.court?.image ?? ""}");
                              return Container(
                                width: double.infinity,
                                padding: EdgeInsets.all(8),
                                margin: EdgeInsets.only(bottom: 10),
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(5),
                                    border: Border.all(
                                        width: 1, color: Color(0xffD0D0D0))),
                                child: Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        /// image
                                        ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            child: NetworkImageWidget(
                                                image: (challenge.slot?.court
                                                            ?.image ??
                                                        "")
                                                    .toString(),
                                                height: 100,
                                                width: 95)),
                                        SizedBox(width: 8.0),

                                        /// text and sub text data
                                        Expanded(
                                          child: Column(
                                            children: [
                                              Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Expanded(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text(
                                                          (challenge.slot?.court
                                                                      ?.name ??
                                                                  l10n
                                                                      .of(context)
                                                                      .na)
                                                              .toString(),
                                                          style: TextStyle(
                                                              fontSize: 14,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600),
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          maxLines: 2,
                                                        ),
                                                        SizedBox(height: 3),
                                                        Text(
                                                          (challenge
                                                                      .slot
                                                                      ?.court
                                                                      ?.sport
                                                                      ?.name ??
                                                                  l10n
                                                                      .of(context)
                                                                      .na)
                                                              .toString(),
                                                          style: TextStyle(
                                                              fontSize: 14,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                              color: Color(
                                                                  0XFF3B747D)),
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          maxLines: 1,
                                                        ),
                                                      ],
                                                    ),
                                                  ),

                                                  // Transform.translate(
                                                  //       offset: Offset(0, -12),
                                                  //       child:
                                                  //     ),
                                                ],
                                              ),
                                              // Row(
                                              //   mainAxisAlignment: MainAxisAlignment.start,
                                              //   children: [
                                              //     Icon(challenge?.isPublic==true ? Icons.people : Icons.person, size: 12,color: AppColors.grey585,),
                                              //     SizedBox(width: 3),
                                              // Expanded(child: Text(challenge?.isPublic==true ? "Public" : "Private", style: TextStyle(fontSize: 10, color: Colors.black54), overflow: TextOverflow.ellipsis)),
                                              //   ],
                                              // ),
                                              // SizedBox(height: 3),
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: [
                                                  Image.asset(
                                                      'assets/icons/calender.png',
                                                      width: 15,
                                                      height: 12),
                                                  SizedBox(width: 3),
                                                  Text(
                                                      (challenge?.date ?? "")
                                                          .toString(),
                                                      style: TextStyle(
                                                          fontSize: 10,
                                                          color:
                                                              Colors.black54),
                                                      overflow: TextOverflow
                                                          .ellipsis),
                                                  Container(
                                                      margin:
                                                          EdgeInsets.symmetric(
                                                              horizontal: 4),
                                                      height: 12,
                                                      width: 2,
                                                      color:
                                                          AppColors.greyD0D0),
                                                  Expanded(
                                                    child: Text(
                                                      '${challenge.slot?.startTime} - ${challenge.slot?.endTime}',
                                                      style: TextStyle(
                                                          fontSize: 10,
                                                          color:
                                                              Colors.black54),
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              SizedBox(height: 3),
                                              Row(
                                                children: [
                                                  Image.asset(
                                                      'assets/icons/location.png',
                                                      width: 15,
                                                      height: 12),
                                                  SizedBox(width: 3),
                                                  Expanded(
                                                    child: Text(
                                                      (challenge
                                                                  .slot
                                                                  ?.court
                                                                  ?.facility
                                                                  ?.address ??
                                                              l10n.of(context).na)
                                                          .toString(),
                                                      style: TextStyle(
                                                          fontSize: 10,
                                                          color:
                                                              Colors.black54),
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),

                                        Container(
                                          height: 35,
                                          width: 35,
                                          // padding: EdgeInsets.all(4),
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            border: Border.all(
                                                color: Colors.green, width: 1),
                                          ),
                                          child: sportImage == null ||
                                                  sportImage.isEmpty
                                              ? ClipOval(
                                                  child: Image.asset(
                                                    "assets/icons/sportsicon.png",
                                                    height: 100,
                                                    width: 95,
                                                    fit: BoxFit.contain,
                                                  ),
                                                )
                                              : ClipOval(
                                                  // borderRadius: BorderRadius.circular(20),
                                                  child: NetworkImageWidget(
                                                    image:
                                                        sportImage.toString(),
                                                    fit: BoxFit.fill,
                                                    height: 18,
                                                    width: 18,
                                                  ),
                                                ),
                                        ), // Container(
                                        //   height: 35,
                                        //   width: 35,
                                        //   padding: EdgeInsets.all(4),
                                        //   decoration: BoxDecoration(
                                        //       shape: BoxShape.circle,
                                        //       border: Border.all(
                                        //           color: Colors.green, width: 1)),
                                        //   child: challenge.slots?.court?.image ==
                                        //           null
                                        //       ? ClipRRect(
                                        //           borderRadius:
                                        //               BorderRadius.circular(5),
                                        //           child: Image.asset(
                                        //             "assets/icons/sportsicon.png",
                                        //             height: 100,
                                        //             width: 95,
                                        //             fit: BoxFit.contain,
                                        //           ))
                                        //       : Center(
                                        //           child: ClipRRect(
                                        //               borderRadius:
                                        //                   BorderRadius.circular(
                                        //                       20),
                                        //               child: NetworkImageWidget(
                                        //                   image: (
                                        //                     challenge
                                        //                             .slots
                                        //                             ?.court
                                        //                             ?.sport
                                        //                             ?.image ??
                                        //                         "",
                                        //                   ).toString(),
                                        //                   fit: BoxFit.contain,
                                        //                   height: 18,
                                        //                   width: 18)),
                                        //         ),
                                        // ),
                                      ],
                                    ),
                                    Divider(),
                                    SizedBox(height: 3),
                                    Stack(
                                      children: [
                                        Container(
                                            height: 5,
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width -
                                                32,
                                            decoration: BoxDecoration(
                                                color: AppColors.greyD0D0,
                                                borderRadius:
                                                    BorderRadius.circular(5))),
                                        Container(
                                          height: 5,
                                          width: ((MediaQuery.of(context)
                                                          .size
                                                          .width -
                                                      32) /
                                                  challenge.maxPlayer!) *
                                              challenge.whoJoined!.length,
                                          decoration: BoxDecoration(
                                              color: AppColors.primaryColor,
                                              borderRadius:
                                                  BorderRadius.circular(5)),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: 3),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Expanded(
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                      "${challenge.whoJoined?.length ?? 0} Player going",
                                                      style: TextStyle(
                                                          fontSize: 16,
                                                          fontWeight:
                                                              FontWeight.normal,
                                                          color: AppColors
                                                              .blackA2A)),
                                                  Center(
                                                      child: CircularImageStackOld(
                                                          imageUrls: imageUrls,
                                                          maxImages: challenge
                                                                  .whoJoined
                                                                  ?.length ??
                                                              0)),
                                                ],
                                              ),
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                children: [
                                                  Text(
                                                      "${l10n.of(context).outOf} ${challenge.maxPlayer.toString()}",
                                                      style: TextStyle(
                                                          fontSize: 16,
                                                          fontWeight:
                                                              FontWeight.normal,
                                                          color: AppColors
                                                              .blackA2A)),
                                                  SizedBox(height: 8),
                                                  Transform.translate(
                                                    offset: Offset(8, 8),
                                                    child: InkWell(
                                                      onTap: () {
                                                        if (viewModel.isLoad !=
                                                            true) {
                                                          viewModel
                                                              .setLoadingChallengeIndex(
                                                                  index);
                                                          viewModel
                                                              .getChallengesDetails(
                                                                  ispublic:
                                                                      true,
                                                                  cancelChallenge:
                                                                      false,
                                                                  challengesId:
                                                                      (challenge.id ??
                                                                              "")
                                                                          .toString(),isbuttonshow: true,

                                                                  context:
                                                                      context)
                                                              .then((_) {
                                                            viewModel
                                                                .setLoadingChallengeIndex(
                                                                    null);
                                                          });
                                                        }
                                                      },
                                                      child: Container(
                                                        padding: EdgeInsets
                                                            .symmetric(
                                                                horizontal: 7,
                                                                vertical: 3),
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius: BorderRadius.only(
                                                              topLeft: Radius
                                                                  .circular(5),
                                                              bottomLeft: Radius
                                                                  .circular(5),
                                                              bottomRight:
                                                                  Radius
                                                                      .circular(
                                                                          5)),
                                                          color:
                                                              AppColors.black,
                                                        ),
                                                        child: Row(
                                                          children: [
                                                            viewModel.loadingChallengeIndex ==
                                                                    index
                                                                ? viewModel
                                                                        .isLoad
                                                                    ? Center(
                                                                        child: SizedBox(
                                                                            height:
                                                                                16,
                                                                            width:
                                                                                16,
                                                                            child: CircularProgressIndicator(
                                                                                color: AppColors
                                                                                    .white)))
                                                                    : Text(
                                                                        "${AppConstants.appCurrency}${(challenge.slot?.price ?? 0).toString()}",
                                                                        style: TextStyle(
                                                                            fontSize:
                                                                                16,
                                                                            color: AppColors
                                                                                .white,
                                                                            fontWeight: FontWeight
                                                                                .normal))
                                                                : Text(
                                                                    "${AppConstants.appCurrency}${(challenge.slot?.price ?? 0).toString()}",
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            16,
                                                                        color: AppColors
                                                                            .white,
                                                                        fontWeight:
                                                                            FontWeight.normal)),
                                                            Container(
                                                                height: 15,
                                                                width: 2,
                                                                color: AppColors
                                                                    .white,
                                                                margin: EdgeInsets
                                                                    .symmetric(
                                                                        horizontal:
                                                                            8)),
                                                            Text(
                                                                l10n
                                                                    .of(context)
                                                                    .joinUs,
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        16,
                                                                    color: AppColors
                                                                        .white,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold)),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                ],
              ),
            ),
    );
  }

  void _showFilter(BuildContext context) async {
    final result = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        String? date;
        return Consumer<SearchCourtViewModel>(
          builder: (context, searchCourtViewModel, child) {
            return Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 16,
                bottom: MediaQuery.of(context).viewInsets.bottom + 16,
              ),
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Title Row
                    Row(
                      children: [
                        Text(l10n.of(context).filter,
                            style: TextStyle(
                                fontSize: 20, fontWeight: FontWeight.w700)),
                        Spacer(),
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Image.asset(
                            'assets/icons/cross.png',
                            width: 28,
                            height: 28,
                          ),
                        ),
                      ],
                    ),
                    Divider(),
                    SizedBox(height: 8),

                    // Sport Dropdown
                    DropdownButtonFormField<String>(
                      value: searchCourtViewModel.selectedPublicSport,
                      hint: Text(l10n.of(context).selectSport,
                          style: TextStyle(fontSize: 12)),
                      icon: Image.asset("assets/icons/lowarrow.png",
                          height: 14, width: 12),
                      items: searchCourtViewModel.sportsListModel.map((sport) {
                        return DropdownMenuItem<String>(
                            value: sport.id,
                            child: Text(sport.name ?? "",
                                style: TextStyle(
                                    fontSize: 12, color: Colors.black)));
                      }).toList(),
                      onChanged: searchCourtViewModel.setselectedPublicSport,
                      style: TextStyle(fontSize: 12),
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Color(0xFFF4F9EC),
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide(color: Colors.transparent)),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide(color: Colors.transparent)),
                        contentPadding:
                            EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        hintStyle: TextStyle(fontSize: 12),
                      ),
                      validator: (value) => value == null
                          ? l10n.of(context).pleaseSelectASport
                          : null,
                    ),

                    SizedBox(height: 12),

// Location
                    TextFormField(
                      controller: _locationController,
                      readOnly: true,
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Color(0xFFF4F9EC),
                        hintText: l10n.of(context).fetchingCurrentLocation,
                        suffixIcon: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Image.asset("assets/icons/location.png",
                              height: 20, width: 20),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(color: Colors.transparent),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(color: Colors.transparent),
                        ),
                        contentPadding:
                            EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                      ),
                      validator: (value) => value == null || value.isEmpty
                          ? l10n.of(context).locationNotFetchedPleaseTryAgain
                          : null,
                    ),

                    SizedBox(height: 12),

// Date Picker
                    TextFormField(
                      controller: _dateController,
                      readOnly: true,
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Color(0xFFF4F9EC),
                        hintText: l10n.of(context).date,
                        suffixIcon: Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: Image.asset('assets/icons/calender.png',
                              height: 24, width: 24),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide:
                              const BorderSide(color: Colors.transparent),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide:
                              const BorderSide(color: Colors.transparent),
                        ),
                      ),
                      validator: (value) => value == null || value.isEmpty
                          ? l10n.of(context).pleaseSelectADate
                          : null,
                      onTap: () async {
                        DateTime? pickedDate = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime.now(),
                          lastDate: DateTime(2100),
                        );
                        if (pickedDate != null) {
                          String formattedDate =
                              "${pickedDate.day}/${pickedDate.month}/${pickedDate.year}";
                          _dateController.text = formattedDate;
                          date =
                              "${pickedDate.day}-${pickedDate.month}-${pickedDate.year}";
                        }
                      },
                    ),

                    SizedBox(height: 12),

                    // Time Dropdown
                    DropdownButtonFormField<String>(
                      decoration: InputDecoration(
                        hintText: l10n.of(context).time,
                        hintStyle: TextStyle(fontSize: 12),
                        filled: true,
                        fillColor: Color(0xFFF4F9EC),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: BorderSide.none),
                      ),
                      style: TextStyle(fontSize: 12, color: Colors.black),
                      items: [
                        "12:00 AM",
                        "01:00 AM",
                        "02:00 AM",
                        "03:00 AM",
                        "04:00 AM",
                        "05:00 AM",
                        "06:00 AM",
                        "07:00 AM",
                        "08:00 AM",
                        "09:00 AM",
                        "10:00 AM",
                        "11:00 AM",
                        "12:00 PM",
                        "01:00 PM",
                        "02:00 PM",
                        "03:00 PM",
                        "04:00 PM",
                        "05:00 PM",
                        "06:00 PM",
                        "07:00 PM",
                        "08:00 PM",
                        "09:00 PM",
                        "10:00 PM",
                        "11:00 PM"
                      ]
                          .map((time) => DropdownMenuItem(
                              value: time,
                              child:
                                  Text(time, style: TextStyle(fontSize: 12))))
                          .toList(),
                      onChanged: (v) {
                        print('Selected time: $v');
                        searchCourtViewModel.setSelectedPublicFltTimeSlot(v);
                      },
                      validator: (value) => value == null
                          ? l10n.of(context).pleaseSelectATime
                          : null,
                    ),
                    SizedBox(height: 16),

                    // Apply Button
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 0),
                      child: Stack(
                        children: [
                          Container(
                            height: 52,
                            width: double.infinity,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: Color(0xFF72A033)),
                          ),
                          GestureDetector(
                            onTap: viewModel.isLoadingDataNew
                                ? () {}
                                : () {
                                    // String sportId = searchCourtViewModel
                                    //         .selectedPublicSport ??
                                    // '';
                                    // List<String> sportIds = [sportId];

                                    if (_formKey.currentState?.validate() ==
                                        true) {
                                      viewModel
                                          .fetchChallengesNew(
                                        context: context,
                                        sportId: searchCourtViewModel
                                                .selectedPublicSport ??
                                            "",
                                        date: date ?? '',
                                      )
                                          .then((onValue) {
                                        Navigator.pop(context, true);
                                      });
                                    }
                                  },
                            child: Container(
                              height: 47,
                              width: double.infinity,
                              decoration: BoxDecoration(
                                  color: Color(0xFF8DC63F),
                                  borderRadius: BorderRadius.circular(10)),
                              child: Center(
                                child: viewModel.isLoadingDataNew
                                    ? CircularProgressIndicator(
                                        color: Colors.white,
                                      )
                                    : Text(
                                        l10n.of(context).filterApply,
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 16,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );

    if (result == true) {
      // Refresh the main page if needed
      // Example:
      print("Filter applied, refresh your data here.");
      // await viewModel.fetchCourts();
    }
  }

  Future<dynamic> buildSendOtpShowModalBottomSheet(BuildContext context) {
    final rootContext = context;
    bool isTermsAccepted = false;

    return showModalBottomSheet(
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      context: context,
      builder: (context) {
        return StatefulBuilder(
          // <-- Add this to manage checkbox state
          builder: (BuildContext context, StateSetter setState) {
            return ListView(
              shrinkWrap: true,
              children: [
                Padding(
                  padding: EdgeInsets.only(
                      bottom: MediaQuery.of(context).viewInsets.bottom),
                  child: Consumer<BookingProvider>(
                    builder: (BuildContext context, viewModel, Widget? child) {
                      return Container(
                        color: Colors.transparent,
                        padding: EdgeInsets.only(top: 50),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Align(
                              alignment: Alignment.topRight,
                              child: InkWell(
                                onTap: () {
                                  Navigator.pop(context);
                                },
                                child: Container(
                                  height: 30,
                                  width: 30,
                                  margin: EdgeInsets.only(right: 16),
                                  decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: AppColors.white),
                                  child: Center(
                                      child: Icon(Icons.clear,
                                          color: AppColors.black)),
                                ),
                              ),
                            ),
                            SizedBox(height: 20),
                            Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 16),
                              width: double.infinity,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                    topRight: Radius.circular(20)),
                                color: AppColors.white,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(l10n.of(context).youreAlmostThere,
                                      style: TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.normal,
                                          color: AppColors.black)),
                                  SizedBox(height: 20),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(l10n.of(context).enterMobileNumber,
                                          style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.normal,
                                              color: AppColors.black555)),
                                      Text("+44 5862 59686",
                                          style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.normal,
                                              color: AppColors.black555)),
                                    ],
                                  ),
                                  SizedBox(height: 20),
                                  OtpTextFormField(
                                      controller: viewModel.otpController,
                                      onchanged: (str) {},
                                      isValidator: true),
                                  SizedBox(height: 20),

                                  // Terms & Conditions checkbox
                                  Row(
                                    children: [
                                      Checkbox(
                                        value: isTermsAccepted,
                                        onChanged: (value) {
                                          setState(() {
                                            isTermsAccepted = value ?? false;
                                          });
                                        },
                                      ),
                                      Expanded(
                                        child: Text(
                                          l10n
                                              .of(context)
                                              .iAgreeToTheTermsConditions,
                                          style: TextStyle(
                                              color: AppColors.black555),
                                        ),
                                      ),
                                    ],
                                  ),

                                  SizedBox(height: 10),
                                  GestureDetector(
                                    onTap: () async {
                                      if (!isTermsAccepted) {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          SnackBar(
                                              content: Text(l10n
                                                  .of(context)
                                                  .pleaseAcceptTheTermsConditionsToContinue)),
                                        );
                                        return;
                                      }

                                      String enteredOtp =
                                          viewModel.otpController.text;
                                      print('otp: $enteredOtp');
                                      if (enteredOtp.isNotEmpty) {
                                        try {
                                          int otpInt = int.parse(
                                              enteredOtp); // Convert string to int safely
                                          bool isSuccess =
                                              await viewModel.verifyOtp(
                                            rootContext,
                                            otpInt,
                                          );

                                          if (isSuccess) {
                                            Navigator.of(context)
                                                .pop(); // Ensure correct context
                                            print("OTP verified successfully!");
                                            viewModel
                                                .navigateToGuestPaymentScreen(
                                                    context: context,
                                                    fromGuest: true,sessionid: context.read<PaymentProvider>().sessionid);
                                          } else {
                                            print("OTP verification failed!");
                                          }
                                        } catch (e) {
                                          print("Invalid OTP format: $e");
                                        }
                                      } else {
                                        print("OTP field is empty.");
                                      }
                                    },
                                    child: Container(
                                      padding:
                                          EdgeInsets.symmetric(vertical: 16),
                                      width: double.infinity,
                                      decoration: BoxDecoration(
                                          color: AppColors.greyEFEF,
                                          borderRadius:
                                              BorderRadius.circular(8)),
                                      child: Center(
                                        child: Text(
                                         l10n.of(context).verifyOtp,
                                          style: TextStyle(
                                              color: AppColors.black555,
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 20),

                                  Consumer<BookingProvider>(
                                    builder: (context, viewModelGetUser, _) {
                                      return Center(
                                        child: GestureDetector(
                                          onTap: viewModelGetUser.canResendOtp
                                              ? () {
                                                  // TODO: trigger OTP resend API
                                                  viewModelGetUser
                                                      .startResendOtpTimer(); // restart timer
                                                  print("Resending OTP...");
                                                }
                                              : null,
                                          child: Text(
                                            viewModelGetUser.canResendOtp
                                                ?l10n.of(context).resendOtp
                                                : "${l10n.of(context).resendIn} ${viewModelGetUser.remainingSeconds}s",
                                            style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w700,
                                              color: viewModelGetUser
                                                      .canResendOtp
                                                  ? AppColors.black
                                                  : AppColors
                                                      .grey8A8, // gray when disabled
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                  // Text("Resend OTP",
                                  //     style: TextStyle(
                                  //         fontSize: 14,
                                  //         fontWeight: FontWeight.w700,
                                  //         color: AppColors.black)),
                                  SizedBox(height: 20),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  ///old code
  // Future<dynamic> buildSendOtpShowModalBottomSheet(BuildContext context) {
  //   final rootContext = context; // Capture the correct context
  //   return showModalBottomSheet(
  //     isScrollControlled: true,
  //     backgroundColor: Colors.transparent,
  //     context: context,
  //     builder: (context) {
  //       return ListView(
  //         shrinkWrap: true,
  //         children: [
  //           Padding(
  //             padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
  //             child: Consumer<BookingProvider>(
  //               builder: (BuildContext context, viewModel, Widget? child) {
  //                 return Container(
  //                   color: Colors.transparent,
  //                   padding: EdgeInsets.only(top: 50),
  //                   child: Column(
  //                     mainAxisAlignment: MainAxisAlignment.start,
  //                     children: [
  //                       Align(
  //                         alignment: Alignment.topRight,
  //                         child: InkWell(
  //                           onTap: () {
  //                             Navigator.pop(context);
  //                           },
  //                           child: Container(
  //                             height: 30,
  //                             width: 30,
  //                             margin: EdgeInsets.only(right: 16),
  //                             decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.white),
  //                             child: Center(child: Icon(Icons.clear, color: AppColors.black)),
  //                           ),
  //                         ),
  //                       ),
  //                       SizedBox(height: 20),
  //                       Container(
  //                         padding: EdgeInsets.symmetric(horizontal: 16, vertical: 16),
  //                         width: double.infinity,
  //                         decoration: BoxDecoration(borderRadius: BorderRadius.only(topLeft: Radius.circular(20), topRight: Radius.circular(20)), color: AppColors.white),
  //                         child: Column(
  //                           crossAxisAlignment: CrossAxisAlignment.center,
  //                           children: [
  //                             Text("You’re Almost There!", style: TextStyle(fontSize: 18, fontWeight: FontWeight.normal, color: AppColors.black)),
  //                             SizedBox(height: 20),
  //                             Row(
  //                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                               children: [
  //                                 Text("Enter Mobile Number", style: TextStyle(fontSize: 16, fontWeight: FontWeight.normal, color: AppColors.black555)),
  //                                 Text("+44 5862 59686", style: TextStyle(fontSize: 16, fontWeight: FontWeight.normal, color: AppColors.black555)),
  //                               ],
  //                             ),
  //                             SizedBox(height: 20),
  //                             OtpTextFormField(controller: viewModel.otpController, onchanged: (str) {}, isValidator: true),
  //                             SizedBox(height: 20),
  //                             // AppButton(
  //                             //   label: "Verify OTP",
  //                             //   onPressed: () async {
  //                             //     String enteredOtp =
  //                             //         viewModel.otpController.text;
  //                             //     print('otp: $enteredOtp');
  //                             //
  //                             //     if (enteredOtp.isNotEmpty) {
  //                             //       try {
  //                             //         int otpInt = int.parse(
  //                             //           enteredOtp,
  //                             //         ); // Convert string to int safely
  //                             //         bool isSuccess = await viewModel
  //                             //             .verifyOtp(rootContext, otpInt);
  //                             //
  //                             //         if (isSuccess) {
  //                             //           Navigator.of(
  //                             //             context,
  //                             //           ).pop(); // Ensure correct context
  //                             //           print("OTP verified successfully!");
  //                             //           viewModel.navigateToGuestPaymentScreen(
  //                             //             context,
  //                             //           );
  //                             //           // Navigate to the next screen or perform any required action
  //                             //         } else {
  //                             //           print("OTP verification failed!");
  //                             //           Navigator.of(
  //                             //             context,
  //                             //           ).pop(); // Ensure correct contextFCr
  //                             //         }
  //                             //       } catch (e) {
  //                             //         print("Invalid OTP format: $e");
  //                             //       }
  //                             //     } else {
  //                             //       print("OTP field is empty.");
  //                             //     }
  //                             //   },
  //                             //   textColor: AppColors.black555,
  //                             //   bgColor: AppColors.greyEFEF,
  //                             // ),
  //                             GestureDetector(
  //                               onTap: () async {
  //                                 String enteredOtp = viewModel.otpController.text;
  //                                 print('otp: $enteredOtp');
  //                                 if (enteredOtp.isNotEmpty) {
  //                                   try {
  //                                     int otpInt = int.parse(enteredOtp); // Convert string to int safely
  //                                     bool isSuccess = await viewModel.verifyOtp(rootContext, otpInt);

  //                                     if (isSuccess) {
  //                                       Navigator.of(context).pop(); // Ensure correct context
  //                                       print("OTP verified successfully!");
  //                                       viewModel.navigateToGuestPaymentScreen(context:context,fromGuest:  true);
  //                                     } else {
  //                                       print("OTP verification failed!");
  //                                     }
  //                                   } catch (e) {
  //                                     print("Invalid OTP format: $e");
  //                                   }
  //                                 } else {
  //                                   print("OTP field is empty.");
  //                                 }
  //                               },
  //                               child: Container(
  //                                 padding: EdgeInsets.symmetric(vertical: 16),
  //                                 width: double.infinity,
  //                                 decoration: BoxDecoration(color: AppColors.greyEFEF, borderRadius: BorderRadius.circular(8)),
  //                                 child: Center(child: Text("Verify OTP", style: TextStyle(color: AppColors.black555, fontSize: 16, fontWeight: FontWeight.bold))),
  //                               ),
  //                             ),
  //                             SizedBox(height: 20),
  //                             Text("Resend OTP", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.black)),
  //                             SizedBox(height: 20),
  //                           ],
  //                         ),
  //                       ),
  //                     ],
  //                   ),
  //                 );
  //               },
  //             ),
  //           ),
  //         ],
  //       );
  //     },
  //   );
  // }

  Future<dynamic> buildShowModalBottomSheet(BuildContext context) {
    return showModalBottomSheet(
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      context: context,
      builder: (context) {
        return ListView(
          shrinkWrap: true,
          children: [
            Padding(
              padding: EdgeInsets.only(
                  bottom: MediaQuery.of(context).viewInsets.bottom),
              child: Container(
                color: Colors.transparent,
                padding: EdgeInsets.only(top: 50),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Align(
                      alignment: Alignment.topRight,
                      child: InkWell(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Container(
                          height: 30,
                          width: 30,
                          margin: EdgeInsets.only(right: 16),
                          decoration: BoxDecoration(
                              shape: BoxShape.circle, color: AppColors.white),
                          child: Center(
                              child: Icon(Icons.clear, color: AppColors.black)),
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                    Container(
                      padding:
                          EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                      width: double.infinity,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(20),
                              topRight: Radius.circular(20)),
                          color: AppColors.white),
                      child: Consumer<BookingProvider>(
                        builder:
                            (BuildContext context, viewModel, Widget? child) {
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(l10n.of(context).youreAlmostThere,
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.normal,
                                      color: AppColors.black)),
                              SizedBox(height: 20),
                              Text(l10n.of(context).enterMobileNumber,
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.normal,
                                      color: AppColors.black555)),
                              SizedBox(height: 20),
                              // Define GlobalKey for FormState

                              // Inside your widget tree
                              Form(
                                key: _formKey,
                                child: Column(
                                  children: [
                                    AppTextField(
                                      borderColor:
                                          AppColors.teal747D.withOpacity(.5),
                                      controller: viewModel.phoneController,
                                      prefixWidget: CountryCodePicker(
                                        padding: EdgeInsets.zero,
                                        margin: EdgeInsets.only(right: 5),
                                        initialSelection: '+44',
                                        showCountryOnly: false,
                                        showOnlyCountryWhenClosed: false,
                                        alignLeft: false,
                                        backgroundColor: AppColors.white,
                                        dialogBackgroundColor: AppColors.white,
                                        flagWidth: 25,
                                        searchPadding: EdgeInsets.zero,
                                        flagDecoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                        ),
                                        onChanged: (value) {
                                          viewModel.countryCodeController.text =
                                              value.dialCode ?? "44";
                                          print(
                                              "Selected Country Code: ${viewModel.countryCodeController.text}");
                                        },
                                      ),
                                      validator: (value) {
                                        if (viewModel.otpErrorMessage != null) {
                                          return viewModel
                                              .otpErrorMessage; // Show OTP error if set
                                        }
                                        if (value == null || value.isEmpty) {
                                          return l10n.of(context).pleaseEnterYourPhoneNumber;
                                        }
                                        if (!RegExp(r'^\d{8,12}$')
                                            .hasMatch(value)) {
                                          return l10n.of(context).phoneNumberMustBe810Digits;
                                        }
                                        return null;
                                      },
                                      inputFormatters: [
                                        FilteringTextInputFormatter.digitsOnly,
                                        LengthLimitingTextInputFormatter(12)
                                      ],
                                      height: 42,
                                      hintText:l10n.of(context).enter810DigitPhoneNumber,
                                      keyboardType: TextInputType.number,
                                    ),
                                    SizedBox(height: 20),
                                    AppButton(
                                      label:l10n.of(context).sendOtp,
                                      onPressed: () async {
                                        setState(() {
                                          viewModel.otpErrorMessage =
                                              null; // Reset error before validation
                                        });

                                        if (!_formKey.currentState!
                                            .validate()) {
                                          return;
                                        }

                                        String phoneNumber =
                                            viewModel.phoneController.text;
                                        String countryCode = viewModel
                                            .countryCodeController.text;
                                        String fullPhoneNumber =
                                            "$countryCode$phoneNumber";

                                        print(
                                            "Full Phone Number challemge guest: $fullPhoneNumber");
                                        print(
                                            "countryCodecountryCode challemge guest: $countryCode");

                                        bool isSuccess =
                                            await viewModel.sendOtpRequest(countryCode1:
                                                countryCode,phoneNumber1:  phoneNumber);

                                        if (isSuccess) {
                                          Navigator.pop(
                                              context); // Close on success
                                          buildSendOtpShowModalBottomSheet(
                                              context);
                                        } else {
                                          setState(() {
                                            viewModel.otpErrorMessage =
                                               l10n.of(context).failedToSendOtpPleaseTryAgain; // Set OTP error
                                          });
                                          _formKey.currentState!
                                              .validate(); // Trigger re-validation to show error
                                        }
                                      },
                                      textColor: AppColors.black555,
                                      bgColor: AppColors.greyEFEF,
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: 20),
                              Row(
                                children: [
                                  SizedBox(
                                    height: 20,
                                    width: 20,
                                    child: Checkbox(
                                      checkColor: AppColors
                                          .white, // Check mark color when checked
                                      overlayColor: WidgetStateProperty.all(
                                          AppColors.black),
                                      fillColor: WidgetStateProperty.all(
                                          viewModel.isChecked == false
                                              ? AppColors.white
                                              : AppColors.black),
                                      value: viewModel.isChecked,
                                      onChanged: (bool? value) {
                                        viewModel.updateCheckedButton();
                                      },
                                    ),
                                  ),
                                  SizedBox(width: 5),
                                  RichText(
                                    text: TextSpan(
                                      text: l10n.of(context).agreeWith,
                                      style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.normal,
                                          color: AppColors.grey769),
                                      children: [
                                        TextSpan(
                                            text:l10n.of(context).termsAndConditions,
                                            style: TextStyle(
                                                fontSize: 14,
                                                fontWeight: FontWeight.normal,
                                                color: AppColors.black))
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 20),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                      child: Container(
                                          height: 1,
                                          width: (MediaQuery.of(context)
                                                      .size
                                                      .width /
                                                  2) -
                                              50,
                                          color: AppColors.greyBEBE)),
                                  Padding(
                                      padding:
                                          EdgeInsets.symmetric(horizontal: 5),
                                      child: Text(l10n.of(context).or,
                                          style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.normal,
                                              color: AppColors.grey769))),
                                  Container(
                                      height: 1,
                                      width:
                                          (MediaQuery.of(context).size.width /
                                                  2) -
                                              35,
                                      color: AppColors.greyBEBE),
                                ],
                              ),
                              SizedBox(height: 20),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  InkWell(
                                    onTap: () {
                                      print("Facebook");
                                    },
                                    child: SizedBox(
                                        width: 54,
                                        height: 54,
                                        child: Image.asset(
                                            "assets/png/png_fb.png",
                                            fit: BoxFit.fill)),
                                  ),
                                  InkWell(
                                    onTap: () {
                                      print("Google");
                                    },
                                    child: SizedBox(
                                        width: 54,
                                        height: 54,
                                        child: Image.asset(
                                            "assets/png/png_google.png",
                                            fit: BoxFit.fill)),
                                  ),
                                  InkWell(
                                    onTap: () {
                                      print("Apple");
                                    },
                                    child: SizedBox(
                                        width: 54,
                                        height: 54,
                                        child: Image.asset(
                                            "assets/png/png_apple.png",
                                            fit: BoxFit.fill)),
                                  ),
                                ],
                              ),
                              SizedBox(height: 20),
                            ],
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  InputDecoration _inputDecoration(String hintText) {
    return InputDecoration(
      hintText: hintText,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.transparent), // Transparent border
      ),
      enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: Colors.transparent)),
      focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: Colors.transparent)),
      filled: true,
      fillColor: Colors.white, // Background color
      contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 14),
    );
  }
}
