import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:qr_flutter/qr_flutter.dart';

class GuestSuccessPaymentScreen extends StatefulWidget {
  const GuestSuccessPaymentScreen({super.key});

  @override
  State<GuestSuccessPaymentScreen> createState() =>
      _GuestSuccessPaymentScreenState();
}

class _GuestSuccessPaymentScreenState extends State<GuestSuccessPaymentScreen> {
  String ID = "";
  String amt = "";
  String time = "";
  String bookingID = "";
  bool isGuest = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    final args = ModalRoute.of(context)?.settings.arguments;

    if (args is Map && args.containsKey('id')) {
      ID = args['id'].toString();
      printLog("id--- > $ID ");
    }

    if (args is Map && args.containsKey('bookingId')) {
      bookingID = args['bookingId'].toString();
      printLog("bookingID > $bookingID ");
    }
    if (args is Map && args.containsKey('bookingStartTime')) {
      time = args['bookingStartTime'].toString();
      printLog("bookingStartTime > $time ");
    }
    if (args is Map && args.containsKey('isGuestBooking')) {
      isGuest = args['isGuestBooking'] == true;
      printLog("isGuestBooking > $isGuest ");
    }
    if (args is Map && args.containsKey('amount')) {
      amt = args['amount'].toString();
      printLog("amount > $amt ");
    }
  }

  @override
  Widget build(BuildContext context) {
    // final viewModel = Provider.of<ActiveChallengeViewModel>(context);
    final joinViewModel = Provider.of<HomeViewModel>(context);
    final createChallengeViewModel =
        Provider.of<CreateChallengeViewModel>(context);
      printLog("book1234567890ingID > $bookingID ");

    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: AppColors.white,
        appBar: CommonAppBar(),
        body: SafeArea(
          child: Center(
            child: Consumer<BookingProvider>(
              builder: (BuildContext context, viewModel, Widget? child) {
                return Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(
                          width: 175,
                          height: 160,
                          child:
                              Image.asset(viewModel.logoPath, fit: BoxFit.fill)),
                      SizedBox(height: 5),
                      Text(l10n.of(context).paymentSuccessful,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 30,
                              fontWeight: FontWeight.w600,
                              color: AppColors.black)),
                      SizedBox(height: 5),
                      Text( l10n.of(context).yourTransactionIsComplete,
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              color: AppColors.black555)),
                      Text( l10n.of(context).enjoyYourBooking,
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              color: AppColors.black555)),
                      SizedBox(height: 5),
                      RichText(
                        text: TextSpan(
                          text: l10n.of(context).bookingId,
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              color: AppColors.black555),
                          children: [

                            TextSpan(
                                text: bookingID,
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                    color: AppColors.black)),
                          ],
                        ),
                      ),
                      SizedBox(height: 20),


                      QrImageView(
                        data:
                        bookingID?? l10n.of(context).unableToFetchBookingId,
                        version: QrVersions.auto,
                        size: 120,
                        backgroundColor: Colors.white,
                        eyeStyle: const QrEyeStyle(
                          eyeShape: QrEyeShape.square,
                          color: AppColors.primaryColor,
                        ),
                        dataModuleStyle: const QrDataModuleStyle(
                          dataModuleShape: QrDataModuleShape.square,
                          color: AppColors.primaryColor,
                        ),
                      ),

                      SizedBox(height: 20),
                      Text(
                        l10n.of(context).weHaveSuccessfullySendTheQrCodeToYourEmailuse,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                            color: AppColors.black),
                      ),
                      SizedBox(height: 20),
                      Consumer<BookingProvider>(
                        builder:
                            (BuildContext context, viewModel1, Widget? child) {
                          return joinViewModel.isTapLoading?Center(child: CircularProgressIndicator(),): AppButtonCommon(

                              onPressed: () {
                                joinViewModel.setTapLoading(true);
                                // viewModel.updateLoadingStatus(context: context, navigation: "/guestSharePaymentScreen");
                                if (isGuest) {
                                  print("true----?");
                                  joinViewModel
                                      .getBookingDetails(
                                    bookingId: ID,context: context
                                  )
                                      .then((_) {
                                    viewModel.navigateToGuestSharePaymentScreen(
                                      isChallenge: false,
                                      amount: amt,
                                      context: context,
                                    );
                                  });
                                }
                                else {
                                  debugPrint("false----? ${createChallengeViewModel
                                      .completeChallengeDetailModel?.data?.friends?.length}");
                                  viewModel.navigateToGuestSharePaymentScreen(
                                      isChallenge: true,
                                      context: context,
                                      joinChallengeModelData:
                                          createChallengeViewModel
                                              .completeChallengeDetailModel,

                                      amount:
                                          amt); // Navigator.pushAndRemoveUntil(

                                }
                                joinViewModel.setTapLoading(false);
                              },
                              label:
                               l10n.of(context).viewDetail
                              // : "Go To Home",
                              );
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
