
import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:kratEasyApp/API_CALLS/API/AmenitiesListAPI.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';

import 'dart:convert';
import 'package:http/http.dart' as http;

class SelectLocationManuallyScreen extends StatefulWidget {
  final double initialLat;
  final double initialLng;
  final bool fromSearch;
  const SelectLocationManuallyScreen({
    super.key,
    required this.initialLat,
    required this.initialLng,
    required this.fromSearch,
  });

  @override
  State<SelectLocationManuallyScreen> createState() =>
      _SelectLocationManuallyScreen();
}

class _SelectLocationManuallyScreen extends State<SelectLocationManuallyScreen> {
  GoogleMapController? _mapController;
  final TextEditingController _searchController = TextEditingController();
  late LatLng _currentMarkerPosition;
  bool _isMapCreated = false;
  String? fullLoaction;
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    _currentMarkerPosition = LatLng(widget.initialLat, widget.initialLng);
    _setPlaceName(_currentMarkerPosition);
  }

  Future<void> _setPlaceName(LatLng position) async {
    try {
      final placemarks =
          await placemarkFromCoordinates(position.latitude, position.longitude);
      if (placemarks.isNotEmpty) {
        final place = placemarks.first;

        fullLoaction = [
          if (place.street != null && place.street!.isNotEmpty) place.street,
          if (place.subLocality != null && place.subLocality!.isNotEmpty)
            place.subLocality,
          if (place.locality != null && place.locality!.isNotEmpty)
            place.locality,
          if (place.administrativeArea != null &&
              place.administrativeArea!.isNotEmpty)
            place.administrativeArea,
          if (place.postalCode != null && place.postalCode!.isNotEmpty)
            place.postalCode,
          if (place.country != null && place.country!.isNotEmpty) place.country,
        ].whereType<String>().join(', ');

        _searchController.text = fullLoaction!;
      }
    } catch (e) {
      print("Failed to get place name: $e");
    }
  }

  Future<void> _searchPlace() async {
    final query = _searchController.text;
    try {
      final locations = await locationFromAddress(query);
      if (locations.isNotEmpty) {
        final LatLng found =
            LatLng(locations.first.latitude, locations.first.longitude);
        _currentMarkerPosition = found;
        await _setPlaceName(found);

        if (_isMapCreated && _mapController != null && mounted) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            _mapController!.animateCamera(CameraUpdate.newLatLng(found));
          });
        }
      }
    } catch (e) {
      print("Search failed: $e");
    }
  }



  Future<List<String>> _getSuggestions(String query) async {
    final apiKey = "AIzaSyDQ2DCe8qS4qVCkMtRZRnZZ_TF2qq1HSvs";
    final url =
        "https://maps.googleapis.com/maps/api/place/autocomplete/json?input=$query&key=$apiKey";
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        final predictions = json['predictions'] as List;
        return predictions.map((p) => p['description'] as String).toList();
      } else {
        print("Failed to fetch suggestions: ${response.body}");
        return [];
      }
    } catch (e) {
      print("Autocomplete error: $e");
      return [];
    }
  }


  Future<void> _goToCurrentLocation() async {
    try {
      final position = await Geolocator.getCurrentPosition();
      final LatLng current = LatLng(position.latitude, position.longitude);
      _currentMarkerPosition = current;
      await _setPlaceName(current);

      if (_isMapCreated && _mapController != null && mounted) {
        _mapController!.animateCamera(CameraUpdate.newLatLng(current));
      }
    } catch (e) {
      print("Location error: $e");
    }
  }

  void _updateCameraLocation(CameraPosition position) {
    _currentMarkerPosition = position.target;
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), () {
      if (mounted) {
        _setPlaceName(position.target);
      }
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _mapController?.dispose();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = Provider.of<MyLocationViewModel>(context);

    return SafeArea(
      bottom: true,top: false,
      child: Scaffold(
        appBar: AppBar(
          title: Text(l10n.of(context).selectLocation),
          backgroundColor: AppColors.primaryColor,
        ),
        body: Column(
          children: [
            Padding(
              padding: EdgeInsets.all(8.0),
              child: TypeAheadField(onSelected: (String suggestion) async {
                _searchController.text = suggestion;

                try {
                  final locations = await locationFromAddress(suggestion);
                  if (locations.isNotEmpty) {
                    final found = LatLng(locations.first.latitude, locations.first.longitude);
                    setState(() {
                      _currentMarkerPosition = found;
                    });
                    _setPlaceName(found);
                    if (_isMapCreated && _mapController != null) {
                      _mapController!.animateCamera(CameraUpdate.newLatLng(found));
                    }
                  }
                } catch (e) {
                  print("Failed to get location from selected address: $e");
                }
              },


                suggestionsCallback: _getSuggestions,
                itemBuilder: (context, suggestion) => ListTile(
                  title: Text(suggestion),
                ),

              ),
            ),
            Expanded(
              child: Stack(
                children: [
                  GoogleMap(
                    initialCameraPosition: CameraPosition(
                      target: _currentMarkerPosition,
                      zoom: 14,
                    ),
                    onCameraMove: (position) {
                      _currentMarkerPosition = position.target;
                    },
                    onCameraIdle: () {
                      _updateCameraLocation(CameraPosition(
                        target: _currentMarkerPosition,
                        zoom: 14,
                      ));
                    },
                    onMapCreated: (controller) {
                      _mapController = controller;
                      _isMapCreated = true;
                    },
                    myLocationEnabled: true,
                    myLocationButtonEnabled: false,
                    zoomControlsEnabled: false,
                  ),
                  Center(
                    child: Icon(
                      Icons.location_on,
                      size: 40,
                      color: Colors.red,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        floatingActionButton: SafeArea(
          bottom: true,
          child: FloatingActionButton(
            backgroundColor: AppColors.primaryColor,
            onPressed: _goToCurrentLocation,
            child: Icon(Icons.my_location),
          ),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.startFloat,
        bottomNavigationBar: SafeArea(
          child: Padding(
            padding: EdgeInsets.only(
              left: 16.0,
              right: 16.0,
              bottom: MediaQuery.of(context).viewInsets.bottom + 30, // Adjust based on system navigation bar
            ),
            child: ElevatedButton(
              onPressed: () async {
                // Your existing code
                if (_currentMarkerPosition.latitude != 0.0 &&
                _currentMarkerPosition.longitude != 0.0 &&
                fullLoaction != null &&
                fullLoaction!.isNotEmpty) {
              try {
                viewModel.setLoading(true);
                widget.fromSearch
                    ? null
                    : await AmenitiesListApi().fetchAndSaveAmenities();

                SharedPreferences prefs = await SharedPreferences.getInstance();
                await prefs.setString('saved_location', fullLoaction!);

                await prefs.setDouble(
                    'current_lat', _currentMarkerPosition.latitude);
                await prefs.setDouble(
                  'current_long',
                  _currentMarkerPosition.longitude,
                );
                viewModel.setLocation(fullLoaction!);
                widget.fromSearch
                    ? Navigator.pop(context)
                    : viewModel.searchCourts(context);
              } catch (e) {
                print("Error when fetching location: $e");
                viewModel.setLoading(false);
              } finally {
                viewModel.setLoading(false);
              }
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(l10n.of(context).pleaseSelectAValidLocation)),
              );
            }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryColor,
                foregroundColor: Colors.black,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(6),
                ),
              ),
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 10),
                child: viewModel.isLoading
                    ? CircularProgressIndicator(color: AppColors.white)
                    : Text(
                  l10n.of(context).confirm,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
          ),
        ),

      ),
    );
  }
}

