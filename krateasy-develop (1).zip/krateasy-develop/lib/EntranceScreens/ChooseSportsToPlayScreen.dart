import 'package:kratEasyApp/generated/l10n.dart';

import '../GlobalUtils/app_imports.dart';

class ChooseSportsToPlayScreen extends StatefulWidget {
  const ChooseSportsToPlayScreen({super.key});

  @override
  State<ChooseSportsToPlayScreen> createState() => _ChooseSportsToPlayState();
}

class _ChooseSportsToPlayState extends State<ChooseSportsToPlayScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<ChooseSportsViewModel>(context, listen: false).fetchSports();
    });
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = Provider.of<ChooseSportsViewModel>(context);
    final Size screenSize = MediaQuery.of(context).size;
    final List<Map<String, dynamic>> layoutConfig = [
      {'dx': 0.04, 'dy': 0.025, 'w': 110.0, 'h': 110.0},
      {'dx': 0.66, 'dy': 0.009, 'w': 95.0, 'h': 95.0},
      {'dx': 0.40, 'dy': 0.15, 'w': 85.0, 'h': 85.0},
      {'dx': 0.04, 'dy': 0.28, 'w': 120.0, 'h': 120.0},
      {'dx': 0.66, 'dy': 0.28, 'w': 95.0, 'h': 95.0},
      {'dx': 0.40, 'dy': 0.45, 'w': 105.0, 'h': 105.0},
      {'dx': 0.06, 'dy': 0.60, 'w': 105.0, 'h': 105.0},
      {'dx': 0.58, 'dy': 0.66, 'w': 115.0, 'h': 115.0},
    ];
    final defaultConfig = {
      'dx': 0.1,
      'dy': 0.1,
      'w': 100.0,
      'h': 100.0,
    };
    return Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
        color: AppColors.white,
        image: DecorationImage(
          image: AssetImage(AppImages.pngFeedsBg),
          fit: BoxFit.fill,
        ),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          title: Text(
            l10n.of(context).whatSportDoYouWantToPlay,
            style: TextStyle(
              fontWeight: FontWeight.w400,
              fontSize: 18,
              color: AppColors.black,
            ),
          ),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(4.0),
            child: LinearProgressIndicator(
              value: 1 / 3,
              backgroundColor: const Color(0xFFE5E5E5),
              valueColor: const AlwaysStoppedAnimation<Color>(
                Color(0xFF8DC63F),
              ),
            ),
          ),
        ),
        body: viewModel.sports.isEmpty
            ? const Center(
                child: CircularProgressIndicator(
                color: AppColors.primaryColor,
              ))
            : Padding(
                padding: EdgeInsets.only(top: 10),
                child: ListView.builder(
                  itemCount: (viewModel.sports.length / 8).ceil(),
                  itemBuilder: (context, pageIndex) {
                    final startIndex = pageIndex * 8;
                    final endIndex = (startIndex + 8) > viewModel.sports.length
                        ? viewModel.sports.length
                        : (startIndex + 8);
                    final currentSports = viewModel.sports.sublist(
                      startIndex,
                      endIndex,
                    );
                    final currentLayoutHeights =
                        currentSports.asMap().entries.map((entry) {
                      final i = entry.key;
                      final layout = i < layoutConfig.length
                          ? layoutConfig[i]
                          : defaultConfig;
                      return screenSize.height * layout['dy'] + layout['h'];
                    }).toList();
                    final stackHeight = currentLayoutHeights.isNotEmpty
                        ? currentLayoutHeights
                                .reduce((a, b) => a > b ? a : b)
                                .toDouble() +
                            40
                        : 700.0;
                    return SizedBox(
                      height: stackHeight,
                      child: Stack(
                        children: List.generate(currentSports.length, (index) {
                          SportList sport = currentSports[index];
                          return Positioned(
                            top: screenSize.height * layoutConfig[index]['dy'],
                            left: screenSize.width * layoutConfig[index]['dx'],
                            child: _floatingSportIcon(
                              imagePath: sport.image,
                              imageName: sport.name,
                              width: layoutConfig[index]['w'],
                              height: layoutConfig[index]['h'],
                              onTap: viewModel.isLoading
                                  ? () {}
                                  : () => viewModel.selectSport(
                                      sport.name, context),
                            ),
                          );
                        }),
                      ),
                    );
                  },
                ),
              ),
      ),
    );
  }

  Widget _floatingSportIcon({
    required String imagePath,
    required String imageName,
    required double width,
    required double height,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(5),
            decoration: BoxDecoration(
              color: AppColors.greyE5E5 ,
              shape: BoxShape.circle,
              // border: Border.all(color: const Color(0xFFE5E5E5), width: 1),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.150),
                  spreadRadius: 1.5,
                  blurRadius: 5,
                  offset: Offset(0, 3),
                ),
              ],
            ),
            child: ClipOval(
              child: SizedBox(
                width: width,
                height: height,
                child: NetworkImageWidget(
                  image: imagePath,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            imageName,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: Colors.black,
            ),
          ),
        ],
      ),
    );
  }
}
