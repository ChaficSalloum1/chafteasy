import 'dart:developer';
import 'dart:io';
import 'package:country_code_picker/country_code_picker.dart';
import 'package:country_picker/country_picker.dart';
import 'package:flutter/services.dart';
import 'package:kratEasyApp/API_CALLS/GlobalAPIUtils.dart';
import 'package:kratEasyApp/BottomNavScreens/FacilityBookingScreen/PaymentOption.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/confirm_button.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/main.dart';
import 'package:kratEasyApp/paymentprovider.dart';
import 'package:kratEasyApp/repository/social_login_repository.dart';
import 'package:shared_preferences/shared_preferences.dart';

class GuestPaymentScreen extends StatefulWidget {
  const GuestPaymentScreen({
    super.key,
  });

  @override
  State<GuestPaymentScreen> createState() => _GuestPaymentScreenState();
}

class _GuestPaymentScreenState extends State<GuestPaymentScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String? courtId;
  String? sessionid;
  String? sportId;
  String? requestDate;
  String? amount;
  String? challengeId;
  bool fromGuest = false;
  bool fromGuestChallenge = false;
  bool forChallenge = false;

  // late String courtId;
  // late String requestDate;
  List<String>? availableTimes;
  List<String>? selectedSlots;

  // late String sportId;

  // bool fromGuest = false;
  // bool fromGuestChallenge = false;
  String? checkToken;

  // String? challengeId;
  // String amount = "";
  String type = "";

  // Default value
  // bool forChallenge = false; // Default value
  late BookingProvider bookingViewModel;

  @override
  void initState() {
    super.initState();
    bookingViewModel = context.read<BookingProvider>();
    bookingViewModel.isChecked = false;
    bookingViewModel.phoneController.clear();
    bookingViewModel.otpController.clear();
    bookingViewModel.countryCodeController.text = "44"; // UK default

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      checkToken = await GlobalAPIUtils.getAuthToken();

      // Trigger payment only after all build and dependency work
      await Future.delayed(Duration(milliseconds: 500));
      await payment(context); // This auto-triggers the flow
    });
  }

  SharedPreferences? pref;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    // Don’t use async here directly — Flutter doesn't support it cleanly in didChangeDependencies
    Future.microtask(() async {
      String dateOnly = DateFormat('dd-MM-yyyy').format(DateTime.now());
      pref = await SharedPreferences.getInstance();

      final args = ModalRoute.of(context)?.settings.arguments as Map?;
      if (args != null) {
        courtId = args['courtId'] ?? "";
        sportId = args['sportId'] ?? "";
        requestDate = args['requestDate'] ?? dateOnly;
        availableTimes = List<String>.from(args['availableTimes'] ?? []);
        selectedSlots = List<String>.from(args['selectedSlots'] ?? []);
        fromGuest = args['fromGuest'] ?? false;
        fromGuestChallenge = args['fromChallenge'] ?? false;
        amount = args['amount']?.toString() ?? "0.0";
        challengeId = args['challengeId'] ?? "";
        forChallenge = args['forChallenge'] == true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final myaccount = context.read<MyAccountViewModel>();
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    final ValueNotifier<String?> selectedOption = ValueNotifier<String?>(null);
    return context.read<PaymentProvider>().loading
        ? Center(
            child: CircularProgressIndicator(),
          )
        : Scaffold(
            backgroundColor: Colors.white,
            body: Padding(
              padding: EdgeInsets.symmetric(
                  horizontal: screenWidth * 0.05,
                  vertical: screenHeight * 0.02),
              child: Consumer2<BookingProvider, CreateChallengeViewModel>(
                builder: (context, viewModel, createChallengeViewModel, child) {
                  return SingleChildScrollView(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Card(
                        //   elevation: 4,
                        //   margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
                        //   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        //   child: Padding(
                        //     padding: const EdgeInsets.all(10.0),
                        //     child: Row(
                        //       children: [
                        //         Icon(Icons.lock, color: AppColors.primaryColor, size: 32),
                        //         const SizedBox(width: 16),
                        //         Expanded(
                        //           child: Text(
                        //             " To join this event, you need to make a payment of £$amount",
                        //             style: const TextStyle(
                        //               fontSize: 16,
                        //               fontWeight: FontWeight.w600,
                        //             ),
                        //           ),
                        //         ),
                        //       ],
                        //     ),
                        //   ),
                        // ),
                        SizedBox(
                          height: h * .5,
                        ),
                        Center(
                          child: CircularProgressIndicator(),
                        ),
                        SizedBox(
                          height: h * 1,
                        ),
                        ConfirmPaymentButton(
                          amount: amount.toString(),
                          challengeId: challengeId,
                          courtId: courtId,
                          requestDate: requestDate ?? "",
                          availableTimes: availableTimes ?? [],
                          selectedSlots: selectedSlots ?? [],
                          fromGuest: fromGuest,
                          fromGuestChallenge: fromGuestChallenge,
                          forChallenge: forChallenge,
                        ),

                        SizedBox(height: 20),
                      ],
                    ),
                  );
                },
              ),
            ),
          );
  }

  Future<bool> payment(BuildContext contexxt) async {
    final viewModel = context.read<BookingProvider>();

    if (forChallenge == true) {
      final myaccount = context.read<MyAccountViewModel>();
      final booking = context.read<BookingProvider>();

      await context.read<CreateChallengeViewModel>().createChallenge(
            context: context,
            amount: amount ?? "",
            name: myaccount.name,
            mobile: myaccount.mobileno,
            email: myaccount.email,
            sessonid: sessionid ?? "",
          );
      return true;
    } else {
      final authToken = await GlobalAPIUtils.getAuthToken();

      if (authToken == null || authToken.isEmpty) {
        context.read<BookingProvider>().clearPhoneBottomSheet();
        context.read<BookingProvider>().selectedCountryFlag = "🇬🇧";
        buildShowModalBottomSheet(context);
        return false;
      }

      final myaccount = context.read<MyAccountViewModel>();
      final booking = context.read<BookingProvider>();
      final paymentProvider = context.read<PaymentProvider>();

      final phone = (myaccount.mobileno.isEmpty)
          ? booking.phoneController.text
          : myaccount.mobileno;

      final countryCode = myaccount.countryCode.isEmpty
          ? booking.countryCode
          : myaccount.countryCode;

      if (fromGuestChallenge == true) {
        await context
            .read<AvailableChallengeGuestViewModel>()
            .joinChallengePostApis(
              amount: amount ?? "",
              challengeId: challengeId ?? '',
              context: context,
            );
        return true;
      }

      if (fromGuest == true) {
        log('widget.courtId .....${courtId.toString()}');

        final responseMessage = await viewModel.newCallBookingAPI(
          context: NavigationService.navigatorKey.currentState!.context,
          trxnid: paymentProvider.trnid.toString(),
          selectedCourtId: courtId ?? "",
          requestDate: requestDate,
          availableTimes: availableTimes ?? [],
          selectedSlots: selectedSlots ?? [],
          discountAmount: viewModel.appliedDiscountAmount,
          discountId: viewModel.appliedDiscountId,
          isRecorded: viewModel.isRecorded,
          isSplit: viewModel.isSplit,
        );

        if (responseMessage ==
            "Court already booked at this time. Wait until booking is completed.") {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(responseMessage),
            backgroundColor: Colors.red,
          ));
          return false;
        } else if (responseMessage == "Booking successful") {
          viewModel.navigateToGuestSuccessPaymentScreen(
            amt: amount ?? "",
            context: context,
            id: viewModel.ID ?? "",
            isGuestBooking: true,
            bookingID: viewModel.bookingId ?? "",
          );
          return true;
        } else {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(responseMessage),
            backgroundColor: Colors.orange,
          ));
          return false;
        }
      }

      return false;
    }
  }

  Future<dynamic> buildSendOtpShowModalBottomSheet(
      BuildContext context, countryCode, phoneNumber) {
    // Set values before showing
    final provider = Provider.of<BookingProvider>(context, listen: false);
    printLog("...../////  $countryCode ... $phoneNumber");
    provider.countryCodeController.text = countryCode;
    provider.phoneController.text = phoneNumber;
    provider.startResendOtpTimer();

    return showModalBottomSheet(
      isScrollControlled: true,
      backgroundColor: Colors.white,
      context: context,
      builder: (context) {
        return ListView(
          shrinkWrap: true,
          children: [
            Padding(
              padding: EdgeInsets.only(
                  bottom: MediaQuery.of(context).viewInsets.bottom),
              child: Consumer<BookingProvider>(
                builder:
                    (BuildContext context, viewModelGetUser, Widget? child) {
                  return Container(
                    color: Colors.transparent,
                    padding: EdgeInsets.only(top: 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Align(
                          alignment: Alignment.topRight,
                          child: InkWell(
                            onTap: () {
                              viewModelGetUser.otpController.clear();
                              Navigator.pop(context);
                            },
                            child: Container(
                              height: 30,
                              width: 30,
                              margin: EdgeInsets.only(right: 16),
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: AppColors.white),
                              child: Center(
                                  child: Icon(Icons.clear,
                                      color: AppColors.black)),
                            ),
                          ),
                        ),
                        SizedBox(height: 20),
                        Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 16, vertical: 16),
                          width: double.infinity,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(20),
                                  topRight: Radius.circular(20)),
                              color: AppColors.white),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(l10n.of(context).youreAlmostThere,
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.normal,
                                      color: AppColors.black)),
                              SizedBox(height: 20),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(l10n.of(context).enterOtp,
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.normal,
                                          color: AppColors.black555)),
                                  Text("+$countryCode $phoneNumber",
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.normal,
                                          color: AppColors.black555)),
                                ],
                              ),
                              SizedBox(height: 20),
                              StatefulBuilder(
                                builder: (context, StateSetter) {
                                  return Column(
                                    children: [
                                      OtpTextFormField(
                                        controller:
                                            viewModelGetUser.otpController,
                                        onchanged: (str) {
                                          setState(() {});
                                        },
                                        isValidator: true,
                                      ),
                                      if (viewModelGetUser.otpErrorMessage !=
                                          null)
                                        Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 8.0),
                                          child: Text(
                                            viewModelGetUser.otpErrorMessage!,
                                            style: TextStyle(
                                              color: Colors.red,
                                              fontSize: 14,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ),
                                      SizedBox(height: 20),
                                      AppButton(
                                        label: l10n.of(context).verifyOtp,
                                        onPressed: () async {
                                          String enteredOtp = viewModelGetUser
                                              .otpController.text;
                                          print('otp: $enteredOtp');

                                          if (enteredOtp.isNotEmpty) {
                                            try {
                                              int otpInt =
                                                  int.parse(enteredOtp);
                                              bool isSuccess =
                                                  await viewModelGetUser
                                                      .verifyOtp(
                                                context,
                                                otpInt,
                                              );

                                              if (isSuccess) {
                                                Navigator.pop(context);
                                                // viewModelGetUser.phoneController
                                                //     .clear();
                                                viewModelGetUser.otpController
                                                    .clear();
                                                print(
                                                    "OTP verified successfully!");
                                              } else {
                                                print(
                                                    "OTP verification failed!");
                                              }
                                            } catch (e) {
                                              print("Invalid OTP format: $e");
                                            }
                                          } else {
                                            print("OTP field is empty.");
                                          }
                                        },
                                        textColor: viewModelGetUser
                                                    .otpController.text.length >
                                                4
                                            ? AppColors.white
                                            : AppColors.black555,
                                        bgColor: viewModelGetUser
                                                    .otpController.text.length >
                                                4
                                            ? AppColors.primaryColor
                                            : AppColors.greyEFEF,
                                      ),
                                    ],
                                  );
                                },
                              ),
                              SizedBox(height: 20),
                              Consumer<BookingProvider>(
                                builder: (context, viewModelGetUser, _) {
                                  return Center(
                                    child: GestureDetector(
                                      onTap: viewModelGetUser.canResendOtp
                                          ? () {
                                              // TODO: trigger OTP resend API
                                              viewModelGetUser
                                                  .startResendOtpTimer(); // restart timer
                                              print("Resending OTP...");
                                            }
                                          : null,
                                      child: Text(
                                        viewModelGetUser.canResendOtp
                                            ? l10n.of(context).resendOtp
                                            : "${l10n.of(context).resendIn} ${viewModelGetUser.remainingSeconds}s",
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w700,
                                          color: viewModelGetUser.canResendOtp
                                              ? AppColors.black
                                              : AppColors
                                                  .grey8A8, // gray when disabled
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ), // Text("Resend OTP",
                              //     style: TextStyle(
                              //         fontSize: 14,
                              //         fontWeight: FontWeight.w700,
                              //         color: AppColors.black)),
                              SizedBox(height: 20),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  String? _tcErrorMessage;

  Future<dynamic> buildShowModalBottomSheet(BuildContext context) {
    List<String> imgList = [
      "assets/png/png_fb.png",
      if (Platform.isAndroid) "assets/png/png_google.png",
      if (Platform.isIOS) "assets/png/png_apple.png"
    ];
    context.read<BookingProvider>().init();
    return showModalBottomSheet(
      isScrollControlled: true,
      backgroundColor: Colors.white,
      context: context,
      isDismissible: false,
      builder: (context) {
        return StatefulBuilder(builder: (context, sateState) {
          return ListView(
            shrinkWrap: true,
            children: [
              Consumer<BookingProvider>(builder:
                  (BuildContext context, viewModelGetUser2, Widget? child) {
                return Padding(
                  padding: EdgeInsets.only(
                      bottom: MediaQuery.of(context).viewInsets.bottom),
                  child: Container(
                    color: Colors.transparent,
                    padding: EdgeInsets.only(top: 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Align(
                          alignment: Alignment.topRight,
                          child: InkWell(
                            onTap: () {
                              _tcErrorMessage = null;
                              Navigator.pop(context);
                            },
                            child: Container(
                              height: 30,
                              width: 30,
                              margin: EdgeInsets.only(right: 16),
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: AppColors.white),
                              child: Center(
                                  child: Icon(Icons.clear,
                                      color: AppColors.black)),
                            ),
                          ),
                        ),
                        SizedBox(height: 20),
                        Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 16, vertical: 16),
                            width: double.infinity,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(20),
                                topRight: Radius.circular(20),
                              ),
                              color: AppColors.white,
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(l10n.of(context).youreAlmostThere,
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.normal,
                                        color: AppColors.black)),
                                SizedBox(height: 20),
                                Text(
                                  l10n.of(context).enterMobileNumber,
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.normal,
                                    color: AppColors.black555,
                                  ),
                                ),
                                SizedBox(height: 20),
                                Form(
                                  key: _formKey,
                                  child: Column(
                                    children: [
                                      AppTextField(
                                        onchanged:
                                            viewModelGetUser2.updatePhoneNumber,
                                        borderColor:
                                            AppColors.teal747D.withOpacity(.5),
                                        controller:
                                            viewModelGetUser2.phoneController,
                                        prefixWidget: GestureDetector(
                                          onTap: () {
                                            showCountryPicker(
                                              context: context,
                                              showPhoneCode: true,
                                              onSelect: (value) {
                                                String? rawCode =
                                                    value.phoneCode;
                                                if (rawCode != null &&
                                                    rawCode.startsWith("+")) {
                                                  rawCode =
                                                      rawCode.substring(1);
                                                }

                                                viewModelGetUser2
                                                    .countryCodeController
                                                    .text = rawCode ?? "44";
                                                viewModelGetUser2
                                                    .updateCountryCode(
                                                        rawCode ?? "44");

                                                // Set the flag emoji
                                                viewModelGetUser2
                                                        .selectedCountryFlag =
                                                    value
                                                        .flagEmoji; // <-- Set the flag here

                                                // modalSetState(() {});
                                              },
                                              moveAlongWithKeyboard: false,
                                              countryListTheme:
                                                  CountryListThemeData(
                                                borderRadius: BorderRadius.only(
                                                  topLeft:
                                                      Radius.circular(40.0),
                                                  topRight:
                                                      Radius.circular(40.0),
                                                ),
                                                inputDecoration:
                                                    InputDecoration(
                                                  labelText: 'Search',
                                                  hintText:
                                                      'Start typing to search',
                                                  prefixIcon:
                                                      const Icon(Icons.search),
                                                ),
                                                searchTextStyle:
                                                    const TextStyle(
                                                  color: Colors.blue,
                                                  fontSize: 18,
                                                ),
                                              ),
                                            );
                                          },
                                          child: Container(
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 12, vertical: 8),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Text(viewModelGetUser2
                                                        .selectedCountryFlag ??
                                                    "🇬🇧"), // Default UK flag

                                                // Icon(Icons.flag),
                                                SizedBox(width: 8),
                                                Text(
                                                    '+${viewModelGetUser2.countryCodeController.text}'),
                                                Icon(Icons.arrow_drop_down),
                                              ],
                                            ),
                                          ),
                                        ),
                                        validator: (value) {
                                          if (value == null || value.isEmpty) {
                                            return l10n
                                                .of(context)
                                                .pleaseEnterYourPhoneNumber;
                                          }
                                          if (!RegExp(r'^\d{8,12}$')
                                              .hasMatch(value)) {
                                            return l10n
                                                .of(context)
                                                .phoneNumberMustBe810Digits;
                                          }
                                          return null;
                                        },
                                        inputFormatters: [
                                          FilteringTextInputFormatter
                                              .digitsOnly,
                                          LengthLimitingTextInputFormatter(12),
                                        ],
                                        height: 42,
                                        hintText: l10n
                                            .of(context)
                                            .enter810DigitPhoneNumber,
                                        keyboardType: TextInputType.number,
                                      ),
                                      SizedBox(height: 20),
                                      StatefulBuilder(
                                          builder: (context, setState) {
                                        return AppButton(
                                          label: l10n.of(context).sendOtp,
                                          onPressed: () async {
                                            sateState(() {
                                              _tcErrorMessage = null;
                                              viewModelGetUser2
                                                  .otpErrorMessage = null;
                                            });

                                            if (!_formKey.currentState!
                                                .validate()) {
                                              return;
                                            }

                                            if (!viewModelGetUser2.isChecked) {
                                              sateState(() {
                                                _tcErrorMessage = l10n
                                                    .of(context)
                                                    .pleaseAcceptTheTermsConditionsToContinue;
                                              });
                                              return;
                                            }

                                            String phoneNumber =
                                                viewModelGetUser2
                                                    .phoneController.text;
                                            String countryCode =
                                                viewModelGetUser2
                                                    .countryCodeController.text;
                                            String fullPhoneNumber =
                                                "$countryCode$phoneNumber";
                                            print(
                                                "Full Phone Number GUEST FLOW: $fullPhoneNumber");
                                            print(
                                                "CONTRY CODE GUEST FLOW: $countryCode");

                                            bool isSuccess =
                                                await viewModelGetUser2
                                                    .sendOtpRequest(
                                                        countryCode1:
                                                            countryCode,
                                                        phoneNumber1:
                                                            phoneNumber);

                                            if (isSuccess) {
                                              Navigator.pop(context);
                                              buildSendOtpShowModalBottomSheet(
                                                  context,
                                                  countryCode,
                                                  phoneNumber);
                                            } else {
                                              setState(() {
                                                viewModelGetUser2
                                                        .otpErrorMessage =
                                                    l10n
                                                        .of(context)
                                                        .failedToSendOtpPleaseTryAgain;
                                              });
                                              _formKey.currentState!.validate();
                                            }
                                          },
                                          textColor: viewModelGetUser2.isFilled
                                              ? AppColors.white
                                              : AppColors.black555,
                                          bgColor: viewModelGetUser2.isFilled
                                              ? AppColors.primaryColor
                                              : AppColors.greyEFEF,
                                        );
                                      }),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 20),
                                Row(
                                  children: [
                                    SizedBox(
                                      height: 20,
                                      width: 20,
                                      child: Checkbox(
                                        checkColor: AppColors.white,
                                        overlayColor: WidgetStateProperty.all(
                                            AppColors.black),
                                        fillColor: WidgetStateProperty.all(
                                            viewModelGetUser2.isChecked == false
                                                ? AppColors.white
                                                : AppColors.black),
                                        value: viewModelGetUser2.isChecked,
                                        onChanged: (bool? value) {
                                          viewModelGetUser2
                                              .updateCheckedButton();
                                          setState(() {
                                            _tcErrorMessage = null;
                                          });
                                        },
                                      ),
                                    ),
                                    SizedBox(width: 5),
                                    RichText(
                                      text: TextSpan(
                                        text: l10n.of(context).agreeWith,
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.normal,
                                            color: AppColors.grey769),
                                        children: [
                                          TextSpan(
                                            text: l10n
                                                .of(context)
                                                .termsAndConditions,
                                            style: TextStyle(
                                                fontSize: 14,
                                                fontWeight: FontWeight.normal,
                                                color: AppColors.black),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 5),
                                if (_tcErrorMessage != null)
                                  Padding(
                                    padding: const EdgeInsets.only(left: 4),
                                    child: Text(
                                      _tcErrorMessage!,
                                      style: TextStyle(
                                          color: Colors.red, fontSize: 12),
                                    ),
                                  ),
                                SizedBox(height: 20),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded(
                                      child: Container(
                                        height: 1,
                                        width:
                                            (MediaQuery.of(context).size.width /
                                                    2) -
                                                50,
                                        color: AppColors.greyBEBE,
                                      ),
                                    ),
                                    Padding(
                                      padding:
                                          EdgeInsets.symmetric(horizontal: 5),
                                      child: Text(l10n.of(context).or,
                                          style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.normal,
                                              color: AppColors.grey769)),
                                    ),
                                    Container(
                                      height: 1,
                                      width:
                                          (MediaQuery.of(context).size.width /
                                                  2) -
                                              35,
                                      color: AppColors.greyBEBE,
                                    ),
                                  ],
                                ),
                                SizedBox(height: 20),
                                Row(
                                  spacing: 10,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children:
                                      List.generate(imgList.length, (index) {
                                    return InkWell(
                                      onTap: () async {
                                        switch (index) {
                                          case 0:
                                            await SocialLoginRepository
                                                    .signInWithFacebook(
                                                        context: context)
                                                .then(
                                              (value) {
                                                /// TODO: implement sign in with facebook
                                              },
                                            );

                                            return;
                                          case 1:
                                            if (Platform.isIOS) {
                                              await SocialLoginRepository
                                                      .loginWithApple(context)
                                                  .then(
                                                (value) {
                                                  /// TODO: implement sign in with facebook
                                                },
                                              );
                                            } else {
                                              await SocialLoginRepository
                                                      .signInWithGoogle(context)
                                                  .then(
                                                (value) {
                                                  if (value["isSuccess"]) {}
                                                },
                                              );
                                            }

                                            return;

                                          default:
                                            return;
                                        }
                                      },
                                      child: SizedBox(
                                        width: 54,
                                        height: 54,
                                        child: Image.asset(imgList[index],
                                            fit: BoxFit.fill),
                                      ),
                                    );
                                  }),
                                ),
                                SizedBox(height: 20),
                              ],
                            )),
                      ],
                    ),
                  ),
                );
              }),
            ],
          );
        });
      },
    );
  }
}
