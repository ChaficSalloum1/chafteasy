import 'dart:async';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:kratEasyApp/GlobalUtils/CircularImageStack.dart';
import 'package:kratEasyApp/GlobalUtils/RuleItem.dart';
import 'package:kratEasyApp/GlobalUtils/app_routes.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/utils/widgets/common_widgets.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../GlobalUtils/app_imports.dart';
import '../paymentprovider.dart';
import '../services/local/local_keys.dart';
import 'friend_payment_scren.dart';

class GuestJoinChallenge extends StatefulWidget {
  final bool isPlayAgain;
  final bool? isPublic;
  final bool? isNotGuestView;
  final bool isShowButton;

  const GuestJoinChallenge({
    super.key,
    this.isPublic,
    this.isNotGuestView,
    this.isShowButton = true,
    this.isPlayAgain = false,
  });

  @override
  State<GuestJoinChallenge> createState() => _GuestJoinChallengeState();
}

class _GuestJoinChallengeState extends State<GuestJoinChallenge> {
  bool get _isNotGuestView => widget.isNotGuestView ?? false;
  String _timeLeft = '';
  Timer? _timer;
  String? sport;
  int maxPlayers = 2;

  void _updateTimeLeft() {
    final joinViewModel = Provider.of<HomeViewModel>(context, listen: false);
    final availableChallengeGuestViewModel =
        Provider.of<AvailableChallengeGuestViewModel>(context, listen: false);
    final result = joinViewModel.getTimeUntilBookingStarts(
      startTime: availableChallengeGuestViewModel
              .challengesDetailsModel.data?.slots?.startTime ??
          "",
      day: availableChallengeGuestViewModel
              .challengesDetailsModel.data?.slots?.day ??
          "",
    );
    setState(() {
      _timeLeft = result;
    });
  }

  GoogleMapController? mapController;
  LatLng? _center;

  final Set<Marker> _markers = {};

  void _onMapCreated(GoogleMapController controller) {
    if (_center == null) return;

    mapController = controller;

    setState(() {
      _markers.add(
        Marker(
          markerId: MarkerId('api_marker'),
          position: _center!,
          infoWindow: InfoWindow(title: 'Court Location'),
        ),
      );
    });
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      // await _loadSavedData();
      var challengeData = context
          .read<AvailableChallengeGuestViewModel>()
          .challengesDetailsModel
          .data;
      context.read<HomeViewModel>().getChalllengeBookingDetails(
          context: context, challenggid: challengeData?.id ?? "");
      _updateTimeLeft();
      _timer =
          Timer.periodic(const Duration(seconds: 60), (_) => _updateTimeLeft());
    });
    final viewModel1 = context.read<AvailableChallengeGuestViewModel>();

    final dynamic latRaw = viewModel1
            .challengesDetailsModel.data?.slots?.court?.facility?.latitude ??
        0.0;
    final dynamic lngRaw = viewModel1
            .challengesDetailsModel.data?.slots?.court?.facility?.longitude ??
        0.0;

    final lat = latRaw is String ? double.tryParse(latRaw) : latRaw as double?;
    final lng = lngRaw is String ? double.tryParse(lngRaw) : lngRaw as double?;

    if (lat != null && lng != null) {
      _center = LatLng(lat, lng);
      _updateMapLocation(_center!);
    }
  }

  void _updateMapLocation(LatLng target) {
    if (mapController != null) {
      mapController!.animateCamera(CameraUpdate.newCameraPosition(
        CameraPosition(target: target, zoom: 15),
      ));
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = Provider.of<ActiveChallengeViewModel>(context);
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: AppColors.white,
      appBar: CommonAppBar(
        title: _isNotGuestView
            ? 'Challenge Details'
            : widget.isPlayAgain
                ? 'Challenge Details'
                : l10n.of(context).joinChallenge,
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: widget.isShowButton
          ? Consumer2<AvailableChallengeGuestViewModel, HomeViewModel>(
              builder: (BuildContext context, challengeViewModel, homeview,
                  Widget? child) {
                final model = challengeViewModel.challengesDetailsModel.data;
                return (model?.whoJoined?.length == model?.maxPlayer)
                    ? SizedBox()
                    : Padding(
                        padding: const EdgeInsets.only(bottom: 20),
                        child: Stack(
                          children: [
                            Container(
                              height: 52,
                              width: screenWidth - screenWidth * 0.08,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: AppColors.green033,
                              ),
                            ),
                            GestureDetector(
                              onTap: _isNotGuestView
                                  ? () {
                                      showDialog(
                                        context: context,
                                        builder: (BuildContext context) {
                                          return Dialog(
                                            backgroundColor: AppColors.white,
                                            child: ListView(
                                              shrinkWrap: true,
                                              physics:
                                                  NeverScrollableScrollPhysics(),
                                              children: [
                                                Container(
                                                  width: double.infinity,
                                                  padding: EdgeInsets.symmetric(
                                                      horizontal: 16,
                                                      vertical: 20),
                                                  decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              12)),
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                    children: [
                                                      SizedBox(
                                                        height: 100,
                                                        width: 100,
                                                        child: Image.asset(
                                                          AppImages
                                                              .pngDialogCancel,
                                                          fit: BoxFit.fill,
                                                        ),
                                                      ),
                                                      SizedBox(height: 10),
                                                      Text(
                                                        l10n
                                                            .of(context)
                                                            .areYouSure,
                                                        style: TextStyle(
                                                          color:
                                                              AppColors.black,
                                                          fontSize: 20,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                        ),
                                                      ),
                                                      SizedBox(height: 10),
                                                      Text(
                                                        l10n
                                                            .of(context)
                                                            .areYouSureYouWantToCancelThisChallengeIf,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: TextStyle(
                                                            color: AppColors
                                                                .grey769,
                                                            fontSize: 16,
                                                            fontWeight:
                                                                FontWeight
                                                                    .normal),
                                                      ),
                                                      SizedBox(height: 10),
                                                      Row(
                                                        children: [
                                                          Stack(
                                                            children: [
                                                              Container(
                                                                height: 36,
                                                                width: 130,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              10),
                                                                  color: AppColors
                                                                      .green033,
                                                                ),
                                                              ),
                                                              GestureDetector(
                                                                onTap: context
                                                                        .read<
                                                                            MyBookingsViewModel>()
                                                                        .isCancelChallengeLoading
                                                                    ? () {}
                                                                    : () async {
                                                                        final result = await context.read<MyBookingsViewModel>().cancelPayment(
                                                                            courtId: homeview.challlengebookingDetailsModel.data?.data?.courtId ??
                                                                                "",
                                                                            bookingid:
                                                                                homeview.challlengebookingDetailsModel.data?.data?.bookingId ?? "");
                                                                        if (result) {
                                                                          context
                                                                              .read<MyBookingsViewModel>()
                                                                              .cancelChallenge(challengeID: context.read<AvailableChallengeGuestViewModel>().challengesDetailsModel.data?.id ?? "", context: context)
                                                                              .then((onValue) {
                                                                            Navigator.pushNamed(
                                                                              context,
                                                                              '/dashboard',
                                                                            );
                                                                          });
                                                                        } else {
                                                                          Navigator.pop(
                                                                              context);
                                                                        }
                                                                      },
                                                                child:
                                                                    Container(
                                                                  height: 32,
                                                                  width: 130,
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10),
                                                                    color: AppColors
                                                                        .primaryColor,
                                                                  ),
                                                                  child: Center(
                                                                    child: context
                                                                            .read<MyBookingsViewModel>()
                                                                            .isCancelChallengeLoading
                                                                        ? CircularProgressIndicator(
                                                                            color:
                                                                                Colors.white,
                                                                          )
                                                                        : Text(
                                                                            l10n.of(context).yesConfirm,
                                                                            style:
                                                                                TextStyle(
                                                                              color: AppColors.white,
                                                                              fontSize: 12,
                                                                              fontWeight: FontWeight.w600,
                                                                            ),
                                                                          ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                          SizedBox(width: 6),
                                                          Expanded(
                                                            child: AppButton(
                                                              borderColor: AppColors
                                                                  .primaryColor,
                                                              height: 35,
                                                              label: l10n
                                                                  .of(context)
                                                                  .cancel,
                                                              bgColor: AppColors
                                                                  .white,
                                                              textStyle:
                                                                  TextStyle(
                                                                color: AppColors
                                                                    .primaryColor,
                                                                fontSize: 12,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w600,
                                                              ),
                                                              onPressed: () {
                                                                Navigator.pop(
                                                                    context);
                                                              },
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          );
                                        },
                                      );
                                    }
                                  : widget.isPlayAgain
                                      ? () {
                                          context
                                              .read<
                                                  AvailableChallengeGuestViewModel>()
                                              .addChallenge(
                                                context,
                                                courtId: challengeViewModel
                                                    .challengesDetailsModel
                                                    .data
                                                    ?.slots
                                                    ?.court
                                                    ?.id,
                                                selectedSport: sport,
                                                facilityId: homeview
                                                    .challlengebookingDetailsModel
                                                    .data
                                                    ?.data
                                                    ?.facilityId,
                                              );
                                        }
                                      : () async {
                                          bool result = false;
                                          if ((challengeViewModel
                                                      .challengesDetailsModel
                                                      .data
                                                      ?.guestPayAmount ??
                                                  0) >
                                              0) {
                                            result = await context
                                                .read<PaymentProvider>()
                                                .stripePayment(
                                                    context,

                                                    ///price
                                                    challengeViewModel
                                                        .challengesDetailsModel
                                                        .data
                                                        ?.guestPayAmount,
                                                    true,
                                                    challengeViewModel
                                                            .challengesDetailsModel
                                                            .data
                                                            ?.slots
                                                            ?.court
                                                            ?.id ??
                                                        '',
                                                    "${LocalService.instance.getData(LocalKeys.instance.userId)}",
                                                    ((model?.whoJoined!
                                                                    .length ??
                                                                1) +
                                                            1)
                                                        .toString(),
                                                    [],
                                                    model?.date.toString(),
                                                    "");
                                          } else {
                                            result = true;
                                          }
                                          double paymentAmount =
                                              (challengeViewModel
                                                          .challengesDetailsModel
                                                          .data
                                                          ?.guestPayAmount ??
                                                      0) +
                                                  4 / maxPlayers;

                                          print('payment: $paymentAmount');

                                          if (result) {
                                            context
                                                .read<BookingProvider>()
                                                .setownerid(homeview
                                                        .challlengebookingDetailsModel
                                                        .data
                                                        ?.data
                                                        ?.facilityOwnerId ??
                                                    "");
                                            Navigator.pushNamed(
                                              context,
                                              RouteNames.guestPayment,
                                              arguments: {
                                                "fromChallenge": true,
                                                "challengeId":
                                                    challengeViewModel
                                                        .challengesDetailsModel
                                                        .data
                                                        ?.id,
                                                "amount":
                                                    paymentAmount.toString(),
                                              },
                                            );
                                          }
                                        },
                              child: Container(
                                height: 47,
                                width: screenWidth - screenWidth * 0.08,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: AppColors.primaryColor,
                                ),
                                child: _isNotGuestView
                                    ? Center(
                                        child: Text(
                                          l10n.of(context).cancelChallenge,
                                          style: TextStyle(
                                            color: AppColors.black,
                                            fontSize: 16,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      )
                                    : Center(
                                        child: Text(
                                          widget.isPlayAgain
                                              ? l10n.of(context).quickRebook
                                              : challengeViewModel
                                                          .challengesDetailsModel
                                                          .data
                                                          ?.guestPayAmount ==
                                                      0
                                                  ? l10n
                                                      .of(context)
                                                      .joinChallenge
                                                  : "${l10n.of(context).joinChallenge} ${AppConstants.appCurrency} ${(challengeViewModel.challengesDetailsModel.data?.guestPayAmount ?? "0.0").toString()}",
                                          style: TextStyle(
                                            color: AppColors.black,
                                            fontSize: 16,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ),
                              ),
                            ),
                          ],
                        ),
                      );
              },
            )
          : SizedBox(),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Consumer2<AvailableChallengeGuestViewModel, HomeViewModel>(
            builder: (BuildContext context, challengeDetailsModel, homeview,
                Widget? child) {
              var challengeData =
                  challengeDetailsModel.challengesDetailsModel.data;
              maxPlayers = challengeData?.maxPlayer ?? 2;
              final bookingDetails =
                  homeview.challlengebookingDetailsModel.data;
              final bool isCurrentBooking =
                  bookingDetails?.challenge?.id == challengeData?.id;
              sport = challengeData?.slots?.court?.sport?.name;
              return challengeDetailsModel.isLoad == true
                  ? SizedBox(
                      width: screenWidth,
                      height: screenHeight * .7,
                      child: Center(
                        child: CircularProgressIndicator(
                          color: AppColors.primaryColor,
                        ),
                      ),
                    )
                  : Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        /// top image data
                        ///
                        Stack(
                          children: [
                            NetworkImageWidget(
                                image:
                                    (challengeData?.slots?.court?.image ?? "")
                                        .toString(),
                                width: screenWidth,
                                height: screenWidth * 0.6,
                                fit: BoxFit.cover),
                            Positioned(
                              top: 14,
                              right: 14,
                              child: Container(
                                padding: EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: AppColors.primaryColor,
                                ),
                                child: Row(
                                  children: [
                                    SizedBox(
                                      height: 13,
                                      width: 13,
                                      child: Image.asset(
                                        AppImages.pngPrivateIcon,
                                        color: AppColors.white,
                                      ),
                                    ),
                                    SizedBox(width: 4),
                                    Text(
                                      homeview.challlengebookingDetailsModel
                                                  .data?.challenge?.isPublic ==
                                              true
                                          ? l10n.of(context).public
                                          : l10n.of(context).private,
                                      style: TextStyle(
                                        fontWeight: FontWeight.w500,
                                        fontSize: 14,
                                        color: AppColors.white,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                              bottom: 10,
                              left: 10,
                              right: 10,
                              child: SizedBox(
                                height: 50,
                                child: ListView.builder(
                                  scrollDirection: Axis.horizontal,
                                  itemCount: challengeData?.slots?.court
                                          ?.facility?.gallery?.length ??
                                      0,
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    final imagesUrl = challengeData?.slots
                                        ?.court?.facility?.gallery?[index];

                                    return InkWell(
                                      onTap: () {
                                        final List<String?> galleryList =
                                            (challengeData?.slots?.court
                                                        ?.facility?.gallery ??
                                                    [])
                                                .cast<String?>();
                                        showDialog(
                                          context: context,
                                          builder: (_) => ImageCarouselDialog(
                                            imageUrls: galleryList,
                                            initialIndex: index,
                                          ),
                                        );
                                      },
                                      child: Padding(
                                        padding: EdgeInsets.symmetric(
                                            horizontal: 4.0),
                                        child: Container(
                                          margin: EdgeInsets.only(right: 5),
                                          height: 47,
                                          width: 47,
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            border: Border.all(
                                                color: Colors.white,
                                                width: 1.5),
                                          ),
                                          child: ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(5),
                                              child: NetworkImageWidget(
                                                width: 47,
                                                height: 50,
                                                fit: BoxFit.cover,
                                                image: imagesUrl ?? "",
                                              )),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),

                        SizedBox(height: 15),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 12),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              // Content of the card

                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          (challengeData?.slots?.court?.sport
                                                      ?.name ??
                                                  l10n.of(context).na)
                                              .toString(),
                                          style: TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.w600,
                                            color: AppColors.black,
                                          ),
                                        ),
                                        SizedBox(height: 8),
                                        Text(
                                          (challengeData?.slots?.court?.name ??
                                                  "")
                                              .toString(),
                                          style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w600,
                                            color: AppColors.greyGreen47D,
                                          ),
                                        ),
                                        SizedBox(height: 8),
                                        Row(
                                          children: [
                                            Image.asset(
                                              "assets/png/calender.png",
                                              width: 15,
                                              height: 15,
                                              fit: BoxFit.cover,
                                            ),
                                            SizedBox(width: 10),
                                            Text(
                                              formatDateToDayMonthYear(
                                                  challengeData?.date
                                                          .toString() ??
                                                      ""),
                                              style: TextStyle(
                                                fontSize: 12,
                                                fontWeight: FontWeight.w400,
                                                color: Color(0xFF555555),
                                              ),
                                            ),
                                            SizedBox(
                                                width: screenWidth * 0.007),
                                            Container(
                                              width: 1,
                                              height: screenHeight * 0.03,
                                              color: Color(0xFFDD9D9D9),
                                            ),
                                            SizedBox(
                                                width: screenWidth * 0.007),
                                            Text(
                                              " ${(challengeData?.slots?.startTime ?? "").toString()} - ${challengeData?.slots?.endTime.toString()}",
                                              style: TextStyle(
                                                fontSize: 12,
                                                fontWeight: FontWeight.w400,
                                                color: Color(0xFF555555),
                                              ),
                                            ),
                                          ],
                                        ),
                                        SizedBox(height: 8),
                                        Row(
                                          children: [
                                            Image.asset(
                                              "assets/icons/rate.png",
                                              width: 15,
                                              height: 15,
                                              fit: BoxFit.cover,
                                            ),
                                            SizedBox(width: 10),
                                            Text(
                                              " ${(challengeData?.slots?.court?.averageRating ?? 0).toString()}",
                                              style: TextStyle(
                                                fontSize: 14,
                                                fontWeight: FontWeight.w700,
                                                color: Color(0xFF555555),
                                              ),
                                            ),
                                            SizedBox(
                                                width: screenWidth * 0.009),
                                            Container(
                                              width: 1,
                                              height: screenHeight * 0.03,
                                              color: Color(0xFFDD9D9D9),
                                            ),
                                            SizedBox(
                                                width: screenWidth * 0.009),
                                            Text(
                                              "${(challengeData?.slots?.court?.totalBookingCount ?? "").toString()}+ ${l10n.of(context).booking}",
                                              style: TextStyle(
                                                fontSize: 14,
                                                fontWeight: FontWeight.w400,
                                                color: Color(0xFF555555),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(height: 8),
                                  Container(
                                    height: 50,
                                    width: 50,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                        color: AppColors.primaryColor,
                                      ),
                                    ),
                                    child: ClipRRect(
                                        borderRadius: BorderRadius.circular(35),
                                        child: NetworkImageWidget(
                                            image: (challengeData?.slots?.court
                                                        ?.sport?.image ??
                                                    "")
                                                .toString(),
                                            fit: BoxFit.cover,
                                            width: 40,
                                            height: 40)),
                                  ),
                                ],
                              ),
                              SizedBox(height: 8),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Image.asset(
                                    'assets/icons/location.png',
                                    width: 15,
                                    height: 15,
                                  ),
                                  SizedBox(width: 10),
                                  Expanded(
                                    child: Text(
                                      (challengeData?.slots?.court?.facility
                                                  ?.address ??
                                              "")
                                          .toString(),
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w400,
                                        color: Color(0xFF555555),
                                      ),
                                    ),
                                  ),
                                  Transform.translate(
                                    offset: Offset(0, 4),
                                    child: Image.asset(
                                      'assets/icons/coins.png',
                                      width: 16,
                                      height: 16,
                                    ),
                                  ),
                                  SizedBox(width: 10),
                                  Text(
                                    "${AppConstants.appCurrency} ${(challengeData?.slots?.price ?? 0).toString()}",
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      color: AppColors.black,
                                    ),
                                  ),
                                ],
                              ),

                              if (challengeData?.createdBy?.name != null &&
                                  !widget.isPlayAgain) ...[
                                SizedBox(height: 8),
                                Row(
                                  children: [
                                    Image.asset(
                                      AppImages.pngPrivateIcon,
                                      width: 15,
                                      height: 15,
                                    ),
                                    SizedBox(width: 10),
                                    Text(
                                      l10n.of(context).createdBy,
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w400,
                                        color: Color(0xFF555555),
                                      ),
                                    ),
                                    Spacer(),
                                    SizedBox(width: screenWidth * 0.002),
                                    Text(
                                      (challengeData?.createdBy?.name ??
                                              l10n.of(context).na)
                                          .toString(),
                                      style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w400,
                                        color: AppColors.black,
                                      ),
                                    ),
                                  ],
                                ),
                              ],

                              SizedBox(height: 10),
                              Divider(),
                              if (!widget.isPlayAgain) SizedBox(height: 10),
                              if (!widget.isPlayAgain)
                                Stack(
                                  children: [
                                    Container(
                                      height: 6,
                                      width: screenWidth,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(3),
                                        color: AppColors.grey1E1,
                                      ),
                                    ),
                                    Container(
                                      height: 6,
                                      width:
                                          // widget.cancelChallenge == true
                                          // ?
                                          (challengeData?.maxPlayer != null &&
                                                  challengeData!.maxPlayer != 0)
                                              ? (((challengeData.whoJoined
                                                                  ?.isNotEmpty ??
                                                              false
                                                          ? challengeData
                                                              .whoJoined!.length
                                                          : 1) *
                                                      screenWidth) /
                                                  challengeData.maxPlayer!)
                                              : 1,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(3),
                                        color: AppColors.greyGreen47D,
                                      ),
                                    ),
                                  ],
                                ),
                              SizedBox(height: 10),
                              if (!widget.isPlayAgain)
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      // widget.cancelChallenge == true
                                      // ?
                                      "${(challengeData?.whoJoined?.isNotEmpty ?? false) ? challengeData!.whoJoined!.length : 1} ${l10n.of(context).players}${(challengeData?.whoJoined?.length ?? 1) > 1 ? 's' : ''} ${l10n.of(context).going}",
                                      // : "${challengeData?.whoJoined?.length ?? 1} Player going",
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w400,
                                        color: AppColors.blackA2A,
                                      ),
                                    ),
                                    Text(
                                      "${l10n.of(context).outOf} ${(challengeData?.maxPlayer ?? 1).toString()}",
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w400,
                                        color: AppColors.blackA2A,
                                      ),
                                    ),
                                  ],
                                ),
                              if (!widget.isPlayAgain) SizedBox(height: 7),
                              if (!widget.isPlayAgain)
                                Align(
                                  alignment: Alignment.bottomLeft,
                                  child: CircularImageStackOld(
                                    imageUrls: challengeData?.whoJoined
                                            ?.map((user) =>
                                                (user.image ?? "").toString())
                                            .toList() ??
                                        [],
                                    maxImages: 4,
                                  ),
                                ),
                            ],
                          ),
                        ),
                        if (!widget.isPlayAgain) Divider(),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          child: Column(
                            children: [
                              challengeData?.slots?.court?.facility
                                          ?.description !=
                                      null
                                  ? Align(
                                      alignment: Alignment.topLeft,
                                      child: RichText(
                                        text: TextSpan(
                                          children: [
                                            TextSpan(
                                              text:
                                                  l10n.of(context).description,
                                              style: TextStyle(
                                                fontSize: 15,
                                                fontWeight: FontWeight.w600,
                                                color: AppColors.black555,
                                              ),
                                            ),
                                            TextSpan(
                                              text: (challengeData
                                                          ?.slots
                                                          ?.court
                                                          ?.facility
                                                          ?.description ??
                                                      "")
                                                  .toString(),
                                              style: TextStyle(
                                                fontSize: 15,
                                                fontWeight: FontWeight.w400,
                                                color: AppColors.black555,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    )
                                  : SizedBox(),
                              challengeData?.slots?.court?.facility
                                          ?.description !=
                                      null
                                  ? SizedBox(height: 7)
                                  : SizedBox(),
                              challengeData
                                          ?.slots?.court?.facility?.amenities !=
                                      null
                                  ? Align(
                                      alignment: Alignment.topLeft,
                                      child: Text(
                                        l10n.of(context).amenitiesclg,
                                        style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                          fontSize: 16,
                                          color: AppColors.black555,
                                        ),
                                      ),
                                    )
                                  : SizedBox(),
                              challengeData
                                          ?.slots?.court?.facility?.amenities !=
                                      null
                                  ? SizedBox(height: 7)
                                  : SizedBox(),
                              challengeData
                                          ?.slots?.court?.facility?.amenities !=
                                      null
                                  ? Align(
                                      alignment: Alignment.topLeft,
                                      child: SingleChildScrollView(
                                        scrollDirection: Axis.horizontal,
                                        child: Row(
                                          children: List.generate(
                                              challengeData
                                                      ?.slots
                                                      ?.court
                                                      ?.facility
                                                      ?.amenities
                                                      ?.length ??
                                                  0, (index) {
                                            var amenities = challengeData
                                                ?.slots
                                                ?.court
                                                ?.facility
                                                ?.amenities?[index];
                                            return CommonAmenities(
                                              text: (amenities?.name ?? "")
                                                  .toString(),
                                              image: (amenities?.image ?? "")
                                                  .toString(),
                                            );
                                          }),
                                        ),
                                      ),
                                    )
                                  : SizedBox(),
                              challengeData
                                          ?.slots?.court?.facility?.amenities !=
                                      null
                                  ? SizedBox(height: 10)
                                  : SizedBox(),
                              challengeData?.slots?.court?.facility?.bio != null
                                  ? Align(
                                      alignment: Alignment.topLeft,
                                      child: Text(
                                        l10n.of(context).rules,
                                        style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                          fontSize: 18,
                                          color: AppColors.black555,
                                        ),
                                      ),
                                    )
                                  : SizedBox(),
                              challengeData?.slots?.court?.facility?.bio != null
                                  ? SizedBox(height: 10)
                                  : SizedBox(),
                              challengeData?.slots?.court?.facility?.bio != null
                                  ? Align(
                                      alignment: Alignment.topLeft,
                                      child: RuleList(
                                        text: (challengeData
                                                ?.slots?.court?.facility?.bio)
                                            .toString(),
                                      ),
                                    )
                                  : SizedBox(),
                            ],
                          ),
                        ),
                        if (!widget.isPlayAgain)
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(height: 12),

                              Text(
                                // widget.cancelChallenge == true
                                // ?
                                "${(challengeData?.whoJoined?.isNotEmpty ?? false) ? challengeData!.whoJoined!.length : 1} ${l10n.of(context).players}",
                                // : '${challengeData?.whoJoined?.length ?? 0} Players',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.black555,
                                ),
                              ),
                              SizedBox(height: 8),

                              homeview.challlengebookingDetailsModel.data
                                          ?.challenge?.status ==
                                      "Completed"
                                  ? SizedBox()
                                  : Text(
                                      _timeLeft,
                                      style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.black,
                                      ),
                                    ),
                              SizedBox(height: 20),

                              // /// circle data
                              // Stack(
                              //   children: [
                              //     Container(
                              //       width: 220,
                              //       height: 220,
                              //       decoration: BoxDecoration(
                              //         shape: BoxShape.circle,
                              //         gradient: LinearGradient(
                              //           colors: AppColors.dark348Green62ELg,
                              //           begin: Alignment.topCenter,
                              //           end: Alignment.bottomCenter,
                              //         ),
                              //       ),
                              //     ),
                              //     Positioned(
                              //       left: 12,
                              //       top: 12,
                              //       child: Container(
                              //         width: 196,
                              //         height: 196,
                              //         decoration: BoxDecoration(
                              //           shape: BoxShape.circle,
                              //           color: AppColors.white,
                              //         ),
                              //         child: (bookingDetails == null ||
                              //                 !isCurrentBooking)
                              //             ? Center(
                              //                 child: CircularProgressIndicator(
                              //                   color: AppColors.primaryColor,
                              //                 ),
                              //               )
                              //             : Column(
                              //                 mainAxisAlignment:
                              //                     MainAxisAlignment.center,
                              //                 children: [
                              //                   Text(
                              //                     l10n.of(context).paid,
                              //                     style: TextStyle(
                              //                       fontSize: 16,
                              //                       fontWeight: FontWeight.w500,
                              //                       color: AppColors.black555,
                              //                     ),
                              //                   ),
                              //                   SizedBox(height: 8),
                              //                   Text(
                              //                     bookingDetails.paidAmount
                              //                             ?.toStringAsFixed(1) ??
                              //                         "",
                              //                     style: TextStyle(
                              //                       fontSize: 25,
                              //                       fontWeight: FontWeight.w700,
                              //                       color: AppColors.green67B,
                              //                     ),
                              //                   ),
                              //                   Divider(
                              //                     thickness: 2,
                              //                     color: AppColors.black555
                              //                         .withOpacity(.1),
                              //                   ),
                              //                   Text(
                              //                     bookingDetails.leftAmount
                              //                             ?.toStringAsFixed(2) ??
                              //                         "",
                              //                     style: TextStyle(
                              //                       fontSize: 25,
                              //                       fontWeight: FontWeight.w700,
                              //                       color: AppColors.black,
                              //                     ),
                              //                   ),
                              //                   SizedBox(height: 8),
                              //                   Text(
                              //                     l10n.of(context).left,
                              //                     style: TextStyle(
                              //                       fontSize: 16,
                              //                       fontWeight: FontWeight.w500,
                              //                       color: AppColors.black555,
                              //                     ),
                              //                   ),
                              //                 ],
                              //               ),
                              //       ),
                              //     ),
                              //   ],
                              // ),

                              /// circle data
                              Stack(
                                children: [
                                  Container(
                                    width: 220,
                                    height: 220,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      gradient: LinearGradient(
                                        colors: AppColors.dark348Green62ELg,
                                        begin: Alignment.topCenter,
                                        end: Alignment.bottomCenter,
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    left: 12,
                                    top: 12,
                                    child: Container(
                                      width: 196,
                                      height: 196,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: AppColors.white,
                                      ),
                                      child: (bookingDetails == null ||
                                              !isCurrentBooking)
                                          ? Center(
                                              child: CircularProgressIndicator(
                                                color: AppColors.primaryColor,
                                              ),
                                            )
                                          : Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Text(
                                                  l10n.of(context).paid,
                                                  style: TextStyle(
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.w500,
                                                    color: AppColors.black555,
                                                  ),
                                                ),
                                                SizedBox(height: 8),
                                                Text(
                                                  bookingDetails.paidAmount
                                                          ?.toStringAsFixed(
                                                              1) ??
                                                      "",
                                                  style: TextStyle(
                                                    fontSize: 25,
                                                    fontWeight: FontWeight.w700,
                                                    color: AppColors.green67B,
                                                  ),
                                                ),
                                                Divider(
                                                  thickness: 2,
                                                  color: AppColors.black555
                                                      .withOpacity(.1),
                                                ),
                                                Text(
                                                  bookingDetails.leftAmount
                                                          ?.toStringAsFixed(
                                                              2) ??
                                                      "",
                                                  style: TextStyle(
                                                    fontSize: 25,
                                                    fontWeight: FontWeight.w700,
                                                    color: AppColors.black,
                                                  ),
                                                ),
                                                SizedBox(height: 8),
                                                Text(
                                                  l10n.of(context).left,
                                                  style: TextStyle(
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.w500,
                                                    color: AppColors.black555,
                                                  ),
                                                ),
                                              ],
                                            ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 24),

                              // Padding(
                              //   padding: EdgeInsets.symmetric(horizontal: 20),
                              //   child: Align(
                              //     alignment: Alignment.centerLeft,
                              //     child: Text(
                              //       "Your Payment",
                              //       style: TextStyle(
                              //         fontSize: 18,
                              //         fontWeight: FontWeight.w600,
                              //         color: AppColors.black,
                              //       ),
                              //     ),
                              //   ),
                              // ),
                              //
                              // SizedBox(height: 10),
                              // Container(
                              //   margin: EdgeInsets.symmetric(horizontal: 20),
                              //   padding: EdgeInsets.all(16),
                              //   decoration: BoxDecoration(
                              //     color: Colors.white,
                              //     borderRadius: BorderRadius.circular(12),
                              //     border: Border.all(
                              //         color: AppColors.grey1E1, width: 1),
                              //     boxShadow: [
                              //       BoxShadow(
                              //         color: Colors.black.withOpacity(0.05),
                              //         blurRadius: 8,
                              //         offset: Offset(0, 2),
                              //       ),
                              //     ],
                              //   ),
                              //   child: Column(
                              //     children: [
                              //       // Subtotal
                              //       Row(
                              //         mainAxisAlignment:
                              //             MainAxisAlignment.spaceBetween,
                              //         children: [
                              //           Text(
                              //             "Subtotal",
                              //             style: TextStyle(
                              //               fontSize: 15,
                              //               fontWeight: FontWeight.w400,
                              //               color: AppColors.black555,
                              //             ),
                              //           ),
                              //           Text(
                              //             ((bookingDetails?.paidAmount ?? 0) /
                              //                     ((challengeData?.whoJoined
                              //                                     ?.length ??
                              //                                 1) ==
                              //                             0
                              //                         ? 1
                              //                         : challengeData?.whoJoined
                              //                                 ?.length ??
                              //                             1))
                              //                 .toStringAsFixed(1),
                              //             style: TextStyle(
                              //               fontSize: 15,
                              //               fontWeight: FontWeight.w600,
                              //               color: AppColors.black,
                              //             ),
                              //           ),
                              //         ],
                              //       ),
                              //       SizedBox(height: 12),
                              //
                              //       // Service Fee / Commission
                              //       Row(
                              //         mainAxisAlignment:
                              //             MainAxisAlignment.spaceBetween,
                              //         children: [
                              //           Row(
                              //             children: [
                              //               Text(
                              //                 "Service Fee",
                              //                 style: TextStyle(
                              //                   fontSize: 15,
                              //                   fontWeight: FontWeight.w400,
                              //                   color: AppColors.black555,
                              //                 ),
                              //               ),
                              //               SizedBox(width: 6),
                              //               Icon(
                              //                 Icons.info_outline,
                              //                 size: 16,
                              //                 color: AppColors.primaryColor,
                              //               ),
                              //             ],
                              //           ),
                              //           Text(
                              //             bookingDetails?.commission
                              //                     ?.toStringAsFixed(1) ??
                              //                 "",
                              //             style: TextStyle(
                              //               fontSize: 15,
                              //               fontWeight: FontWeight.w600,
                              //               color: AppColors.black,
                              //             ),
                              //           ),
                              //         ],
                              //       ),
                              //
                              //       SizedBox(height: 12),
                              //       Divider(
                              //           thickness: 1, color: AppColors.grey1E1),
                              //       SizedBox(height: 12),
                              //
                              //       // Total
                              //       Row(
                              //         mainAxisAlignment:
                              //             MainAxisAlignment.spaceBetween,
                              //         children: [
                              //           Text(
                              //             "Total",
                              //             style: TextStyle(
                              //               fontSize: 17,
                              //               fontWeight: FontWeight.w700,
                              //               color: AppColors.black,
                              //             ),
                              //           ),
                              //           Text(
                              //             (((bookingDetails?.paidAmount ?? 0) /
                              //                         ((challengeData?.whoJoined
                              //                                         ?.length ??
                              //                                     1) ==
                              //                                 0
                              //                             ? 1
                              //                             : challengeData
                              //                                     ?.whoJoined
                              //                                     ?.length ??
                              //                                 1)) +
                              //                     (bookingDetails?.commission ??
                              //                         0))
                              //                 .toStringAsFixed(2),
                              //             style: TextStyle(
                              //               fontSize: 17,
                              //               fontWeight: FontWeight.w700,
                              //               color: AppColors.primaryColor,
                              //             ),
                              //           ),
                              //         ],
                              //       ),
                              //     ],
                              //   ),
                              // ),

                              SizedBox(height: 20),
                              QrcodeView(
                                id: homeview.challlengebookingDetailsModel.data
                                        ?.data?.bookingId ??
                                    '',
                              ),

                              if (homeview.challlengebookingDetailsModel.data
                                      ?.challenge?.friends?.isNotEmpty ??
                                  false)
                                SizedBox(
                                  height: 190,
                                  child: ListView.builder(
                                    itemCount: homeview
                                        .challlengebookingDetailsModel
                                        .data
                                        ?.challenge
                                        ?.friends
                                        ?.length,
                                    scrollDirection: Axis.horizontal,
                                    itemBuilder: (context, index) {
                                      var item = homeview
                                          .challlengebookingDetailsModel
                                          .data
                                          ?.challenge
                                          ?.friends?[index];
                                      return Padding(
                                        padding:
                                            const EdgeInsets.only(right: 13),
                                        child: SizedBox(
                                          width: 75,
                                          child: Column(
                                            children: [
                                              SizedBox(height: 5),
                                              Image.asset(
                                                  "assets/png/user_logo.png",
                                                  width: 65,
                                                  height: 65),

                                              Text(item?.name ?? "",
                                                  maxLines: 1,
                                                  style: TextStyle(
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      fontSize: 13,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      color:
                                                          AppColors.black555)),
                                              // Spacer(),
                                              Text(
                                                  '${AppConstants.appCurrency}${item?.splitAmount ?? 0}',
                                                  style: TextStyle(
                                                      fontSize: 18,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      color: AppColors.black)),
                                              SizedBox(height: 5),
                                              AppButton(
                                                height: 30,
                                                width: 70,
                                                radius: 5,
                                                label: item?.isPaid == true
                                                    ? 'Paid'
                                                    : "Pay",
                                                textStyle: TextStyle(
                                                    fontSize: 15,
                                                    fontWeight: FontWeight.w600,
                                                    color: AppColors.black),
                                                onPressed: () {
                                                  if (item?.isPaid == false) {
                                                    Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                        builder: (context) =>
                                                            FriendPayment(
                                                          frienddid:
                                                              item?.id ?? "",
                                                          playerid:
                                                              item?.playerid ??
                                                                  "",
                                                          challlengeid:
                                                              challengeData
                                                                      ?.id ??
                                                                  "",
                                                          amount:
                                                              item?.splitAmount ??
                                                                  0,
                                                          bookingid:
                                                              "${homeview.challlengebookingDetailsModel.data?.data?.bookingId}",
                                                        ),
                                                      ),
                                                    );
                                                  }
                                                },
                                                bgColor: item?.isPaid == false
                                                    ? AppColors.primaryColor
                                                    : AppColors.grey3E3,
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                )
                            ],
                          ),

                        Stack(
                          children: [
                            SizedBox(
                              height: screenHeight * .3,
                              width: screenWidth,
                              child: _center == null
                                  ? Center(child: CircularProgressIndicator())
                                  : GestureDetector(
                                      onTap: () {
                                        print("object");
                                      },
                                      child: GoogleMap(
                                        mapType: MapType.normal,
                                        onMapCreated: _onMapCreated,
                                        initialCameraPosition: CameraPosition(
                                            target: _center!, zoom: 14),
                                        markers: _markers,
                                        myLocationEnabled: true,
                                        myLocationButtonEnabled: true,
                                        zoomGesturesEnabled: true,
                                        scrollGesturesEnabled: true,
                                        tiltGesturesEnabled: true,
                                        rotateGesturesEnabled: true,
                                      ),
                                    ),
                            ),
                            Positioned(
                              bottom: 18,
                              left: screenWidth * 0.04,
                              right: screenWidth * 0.04,
                              child: GestureDetector(
                                onTap: () {
                                  final lat = _center?.latitude;
                                  final lng = _center?.longitude;

                                  if (lat != null && lng != null) {
                                    openMap(lat, lng);
                                  }
                                },
                                child: Container(
                                  height: 52,
                                  padding: EdgeInsets.symmetric(horizontal: 10),
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(5)),
                                  child: Row(
                                    children: [
                                      SizedBox(
                                          width: 17,
                                          height: 17,
                                          child: Image.asset(
                                              AppImages.pngLocationGrey,
                                              fit: BoxFit.fill)),
                                      SizedBox(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              .7,
                                          child: Text(
                                              (challengeData?.slots?.court
                                                          ?.facility?.address ??
                                                      "")
                                                  .toString(),
                                              style: TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.normal,
                                                  color: AppColors.black555))),
                                      Spacer(),
                                      SizedBox(
                                          width: 24,
                                          height: 24,
                                          child: Image.asset(
                                              AppImages.pngLocationCircle,
                                              fit: BoxFit.fill)),
                                    ],
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),

                        SizedBox(height: 100),
                      ],
                    );
            },
          ),
        ),
      ),
    );
  }

  Future<void> openMap(double latitude, double longitude) async {
    final url = Uri.parse(
        'https://www.google.com/maps/search/?api=1&query=$latitude,$longitude');

    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    } else {
      throw 'Could not open the map.';
    }
  }
}

class QrcodeView extends StatelessWidget {
  final String id;

  const QrcodeView({super.key, required this.id});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return Dialog(
              backgroundColor: Colors.transparent,
              child: Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppColors.primaryColor,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 15,
                      offset: Offset(0, 5),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      "Scan to Check In",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 20),
                    QrImageView(
                      data: id,
                      version: QrVersions.auto,
                      size: 220,
                      backgroundColor: Colors.white,
                      eyeStyle: const QrEyeStyle(
                        eyeShape: QrEyeShape.square,
                        color: AppColors.primaryColor,
                      ),
                      dataModuleStyle: const QrDataModuleStyle(
                        dataModuleShape: QrDataModuleShape.square,
                        color: AppColors.primaryColor,
                      ),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      "Booking ID: $id",
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton.icon(
                      onPressed: () => Navigator.of(context).pop(),
                      icon: Icon(Icons.close),
                      label: Text("Close"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: AppColors.primaryColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            );
          },
        );
      },
      child: Container(
          margin: EdgeInsets.all(15),
          // height: 110,
          // width: 110,
          decoration: BoxDecoration(
            border: Border.all(color: AppColors.primaryColor, width: 2),
            borderRadius: BorderRadius.circular(12),
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.3),
                blurRadius: 8,
                offset: Offset(2, 4),
              ),
            ],
          ),
          padding: const EdgeInsets.all(8),
          child: Text(
            "Share QR Code",
            style: TextStyle(fontWeight: FontWeight.bold),
          )),
    );
  }
}

class ImageCarouselDialog extends StatelessWidget {
  final List<String?> imageUrls;
  final int initialIndex;

  const ImageCarouselDialog({
    super.key,
    required this.imageUrls,
    required this.initialIndex,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.transparent,
      contentPadding: EdgeInsets.zero,
      content: SizedBox(
        height: h * .4,
        width: MediaQuery.of(context).size.width * 0.8,
        child: CarouselSlider.builder(
          options: CarouselOptions(
            initialPage: initialIndex,
            reverse: true,
            enlargeCenterPage: true,
            enableInfiniteScroll: false,
          ),
          itemCount: imageUrls.length,
          itemBuilder: (context, index, realIndex) {
            return Image.network(
              imageUrls[index] ?? '',
              fit: BoxFit.contain,
              errorBuilder: (_, __, ___) =>
                  Icon(Icons.broken_image, color: Colors.white),
            );
          },
        ),
      ),
    );
  }
}
