import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import '../API_CALLS/API/AmenitiesListAPI.dart';

class MyLocationScreen extends StatefulWidget {
  const MyLocationScreen({super.key});

  @override
  State<MyLocationScreen> createState() => _MyLocationScreenState();
}

class _MyLocationScreenState extends State<MyLocationScreen> {
  @override
  Widget build(BuildContext context) {
    final viewModel = context.read<MyLocationViewModel>();

    //     context.read<AvailableChallengeGuestViewModel>();
    // final viewModel = Provider.read<MyLocationViewModel>(context);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(kToolbarHeight + 4),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CommonAppBar(
              backIconColor: Colors.white,
              backgroundColor: Colors.white,
            ),
            LinearProgressIndicator(
              value: 2 / 3,
              backgroundColor: const Color(0xFFE5E5E5),
              valueColor: const AlwaysStoppedAnimation<Color>(
                Color(0xFF8DC63F),
              ),
            ),
          ],
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(height: MediaQuery.of(context).size.height * .085),
          Image.asset(
            'assets/entranceImg/location.png',
            height: 220,
            width: 300,
            fit: BoxFit.fill,
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                l10n.of(context).welcomeTo,
                style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
              SizedBox(width: 5),
              Text(
                l10n.of(context).kratEasy,
                style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF8DC63F),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.0),
            child: Text(
              l10n
                  .of(context)
                  .setYourLocationToStartExploringnSportsCourtsAroundYou,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w400,
                color: Colors.black,
              ),
            ),
          ),
          const SizedBox(height: 35),
          // Usage in the widget
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 45),
            child: Consumer<MyLocationViewModel>(
              builder: (context, viewModel, child) {
                return AppButton(
                  onPressed: viewModel.isLoading
                      ? null
                      : () async {
                          try {
                            viewModel.setLoading(true);
                            await AmenitiesListApi().fetchAndSaveAmenities();
                            await viewModel.getCurrentLocation(
                                context: context);
                            viewModel.searchCourts(context);
                          } catch (e) {
                            debugPrint('Fetch location Button Error : $e');
                          } finally {
                            viewModel.setLoading(false);
                          }
                        },
                  isLoadingColor: AppColors.white,
                  prefixIcon: Padding(
                    padding: const EdgeInsets.only(right: 4),
                    child: Image.asset(
                      'assets/icons/gps.png',
                      height: 27,
                      width: 27,
                    ),
                  ),
                  label:l10n.of(context).detectMyLocation,
                );
              },
            ),
          ),


          const SizedBox(height: 15),
          Row(
            children: [
              Flexible(
                child: Divider(
                  color: Color(0Xff858585),
                  thickness: 1,
                  indent: 50,
                  endIndent: 10,
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 10),
                child: Text(
                  l10n.of(context).or,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: Color(0Xff555555),
                  ),
                ),
              ),
              Flexible(
                child: Divider(
                  color: Color(0Xff858585),
                  thickness: 1,
                  indent: 10,
                  endIndent: 50,
                ),
              ),
            ],
          ),
          const SizedBox(height: 15),
          Consumer<MyLocationViewModel>(
            builder: (context, viewModel, child) {
              return GestureDetector(
                onTap: viewModel.isLoadingManually
                    ? null
                    : () {
                        viewModel.getAndNavigateToMapScreen(context, false);
                      },
                child: viewModel.isLoadingManually
                    ? CircularProgressIndicator(
                        color: AppColors.primaryColor,
                      )
                    : Text(
                        l10n.of(context).selectLocationManually,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: AppColors.black555,
                        ),
                      ),
              );
            },
          ),
        ],
      ),
    );
  }

  //add manual location bottom sheet
  void _showFilter(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      isScrollControlled: true,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Title Row
              Row(
                children: [
                  Text(l10n.of(context).addAddress,
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                  Spacer(),
                  GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Image.asset('assets/icons/cross.png',
                          width: 28, height: 28)),
                ],
              ),
              Divider(),
              SizedBox(height: 8),

// Date Selection
              TextFormField(
                // controller: _dateController,
                readOnly: true,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Color(0xFFF4F9EC),
                  hintText: l10n.of(context).address,
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(color: Colors.transparent)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(color: Colors.transparent)),
                ),
                onTap: () async {
                  DateTime? pickedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2100));

                  if (pickedDate != null) {
                    // _dateController.text =
                    // "${pickedDate.day.toString().padLeft(2, '0')}-${pickedDate.month.toString().padLeft(2, '0')}-${pickedDate.year}";
                  }
                },
              ),

              //date should be in this format "27-03-2025"
              SizedBox(height: 12),
              // Date Selection
              TextFormField(
                // controller: _dateController,
                readOnly: true,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Color(0xFFF4F9EC),
                  hintText: l10n.of(context).city,
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(color: Colors.transparent)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(color: Colors.transparent)),
                ),
                onTap: () async {
                  DateTime? pickedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2100));

                  if (pickedDate != null) {
                    // _dateController.text =
                    // "${pickedDate.day.toString().padLeft(2, '0')}-${pickedDate.month.toString().padLeft(2, '0')}-${pickedDate.year}";
                  }
                },
              ),

              //date should be in this format "27-03-2025"
              SizedBox(height: 12), // Date Selection
              TextFormField(
                // controller: _dateController,
                readOnly: true,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Color(0xFFF4F9EC),
                  hintText: l10n.of(context).country,
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(color: Colors.transparent)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(color: Colors.transparent)),
                ),
                onTap: () async {
                  DateTime? pickedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2100));

                  if (pickedDate != null) {
                    // _dateController.text =
                    // "${pickedDate.day.toString().padLeft(2, '0')}-${pickedDate.month.toString().padLeft(2, '0')}-${pickedDate.year}";
                  }
                },
              ),

              //date should be in this format "27-03-2025"
              SizedBox(height: 12),

              // Apply Filter Button
              GestureDetector(
                onTap: () {
                  // if (selectedSportId != null && selectedTime != null) {
                  //   print('Sport: $selectedSportId');
                  //   print('Time: $selectedTime');
                  //   print('Amenities: $selectedAmenities');

                  //   final bookingRequest = SearchCourtModel(
                  //     date: _dateController.text,
                  //     time: [selectedTime!],
                  //     sportId: selectedSportId!,
                  //     amenityId:
                  //         selectedAmenities.isNotEmpty ? selectedAmenities : [],
                  //   );

                  //   SearchCourtsApi()
                  //       .filterBookingData(bookingRequest)
                  //       .then((_) {
                  //     setState(() {}); // Refresh the screen
                  //     Navigator.pop(context);
                  //     _dateController.clear();
                  //   });
                  // } else {
                  //   print("Please select sport and time");
                  // }

                  //  Navigator.pop(context);
                },
                child: Container(
                  height: 47,
                  width: double.infinity,
                  decoration: BoxDecoration(
                      color: Color(0xFF8DC63F),
                      borderRadius: BorderRadius.circular(10)),
                  child: Center(
                      child: Text(l10n.of(context).filterApply,
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 16,
                              fontWeight: FontWeight.w600))),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
