// import 'package:flutter/material.dart';
// import 'package:kratEasyApp/GlobalUtils/app_button.dart';
// import 'package:kratEasyApp/GlobalUtils/app_colors.dart';
// import 'package:kratEasyApp/GlobalUtils/common_app_bar.dart';
// import 'package:kratEasyApp/ViewModel/ChallengeViewMode/ActiveChallengeViewModel.dart';
// import 'package:provider/provider.dart';

// class ChallengeSuccessScreen extends StatefulWidget {
//   const ChallengeSuccessScreen({super.key});

//   @override
//   State<ChallengeSuccessScreen> createState() => _ChallengeSuccessScreenState();
// }

// class _ChallengeSuccessScreenState extends State<ChallengeSuccessScreen> {
//   @override
//   Widget build(BuildContext context) {
//     final viewModel = Provider.of<ActiveChallengeViewModel>(context);
//     double screenWidth = MediaQuery.of(context).size.width;
//     double screenHeight = MediaQuery.of(context).size.height;
//     return Scaffold(
//       backgroundColor: AppColors.white,
//       appBar: CommonAppBar(title: "Back"),
//       body: Center(
//         child: Padding(
//           padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.04),
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             crossAxisAlignment: CrossAxisAlignment.center,
//             children: [
//               SizedBox(child: Image.asset("assets/successImg/success.png")),
//               SizedBox(height: 22),
//               Text("F", style: TextStyle(fontSize: 40, fontWeight: FontWeight.w600, color: AppColors.black)),
//               Text("Your transaction is complete.\nEnjoy your booking! ✅", textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, color: AppColors.black555)),
//               SizedBox(height: 4),
//               RichText(
//                 text: TextSpan(
//                   text: "Booking ID: ",
//                   style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, color: AppColors.black555),
//                   children: [
//                     TextSpan(text: "#", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.black)),
//                     TextSpan(text: viewModel.bookingId, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, color: AppColors.black)),
//                   ],
//                 ),
//               ),
//               SizedBox(height: 22),
//               AppButton(
//                 onPressed: () {
//                   viewModel.navigateToSharePaymentLinkScreen(context);
//                 },
//                 label: "View Booking Details",
//                 textStyle: TextStyle(color: AppColors.black, fontWeight: FontWeight.w600, fontSize: 18),
//                 bgColor: AppColors.primaryColor,
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
