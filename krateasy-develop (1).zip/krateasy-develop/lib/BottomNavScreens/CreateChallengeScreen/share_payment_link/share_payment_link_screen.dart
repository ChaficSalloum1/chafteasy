// import 'package:flutter/material.dart';
// import 'package:kratEasyApp/GlobalUtils/app_button.dart';
// import 'package:kratEasyApp/GlobalUtils/app_colors.dart';
// import 'package:kratEasyApp/GlobalUtils/app_images.dart';
// import 'package:kratEasyApp/GlobalUtils/common_share.dart';
// import 'package:kratEasyApp/ViewModel/ChallengeViewMode/ActiveChallengeViewModel.dart';
// import 'package:kratEasyApp/generated/l10n.dart';
// import 'package:provider/provider.dart';

// class SharePaymentLinkScreen extends StatefulWidget {
//   const SharePaymentLinkScreen({super.key});

//   @override
//   State<SharePaymentLinkScreen> createState() => _SharePaymentLinkScreenState();
// }

// class _SharePaymentLinkScreenState extends State<SharePaymentLinkScreen> {
//   @override
//   Widget build(BuildContext context) {
//     final viewModel = Provider.of<ActiveChallengeViewModel>(context);
//     double screenWidth = MediaQuery.of(context).size.width;
//     double screenHeight = MediaQuery.of(context).size.height;
//     return Scaffold(
//       body: SafeArea(
//         child: SingleChildScrollView(
//           child: Padding(
//             padding: EdgeInsets.only(
//                 left: screenWidth * 0.04, right: screenWidth * 0.04, top: 30),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.center,
//               children: [
//                 /// header data
//                 Container(
//                   width: screenWidth,
//                   padding: EdgeInsets.symmetric(horizontal: 16, vertical: 24),
//                   decoration: BoxDecoration(
//                       borderRadius: BorderRadius.circular(20),
//                       color: AppColors.primaryColor.withOpacity(.4)),
//                   child: Column(
//                     children: [
//                       Text(S.of(context).sharePaymentLink,
//                           style: TextStyle(
//                               fontSize: 18,
//                               fontWeight: FontWeight.w700,
//                               color: AppColors.black)),
//                       SizedBox(height: 16),
//                       Text(
//                        S.of(context).allPlayersWillUseThisLinkToMakentheirSplitPayment,
//                         textAlign: TextAlign.center,
//                         style: TextStyle(
//                             fontSize: 14,
//                             fontWeight: FontWeight.normal,
//                             color: AppColors.black),
//                       ),
//                       SizedBox(height: 16),
//                       Container(
//                         width: screenWidth - 100,
//                         padding:
//                             EdgeInsets.symmetric(horizontal: 15, vertical: 10),
//                         decoration: BoxDecoration(
//                             borderRadius: BorderRadius.circular(20),
//                             color: Colors.white),
//                         child: Row(
//                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                           children: [
//                             Text('KratEasy.com/LHYN20568231',
//                                 style: TextStyle(
//                                     fontSize: 13,
//                                     fontWeight: FontWeight.w600,
//                                     color: AppColors.black)),
//                             SizedBox(
//                               width: 10,
//                             ),
//                             InkWell(
//                                 onTap: () {
//                                   shareData('KratEasy.com/LHYN20568231');
//                                 },
//                                 child: SizedBox(
//                                     height: 22,
//                                     width: 22,
//                                     child: Image.asset(
//                                         'assets/icons/share2.png'))),
//                           ],
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//                 Column(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     SizedBox(height: 8),
//                     Text('5 Players',
//                         style: TextStyle(
//                             fontSize: 15,
//                             fontWeight: FontWeight.w600,
//                             color: AppColors.black555)),
//                     SizedBox(height: 8),
//                     Text('1hr 23 mins left',
//                         style: TextStyle(
//                             fontSize: 18,
//                             fontWeight: FontWeight.w600,
//                             color: Colors.black)),
//                     SizedBox(height: 20),

//                     /// circle data
//                     Stack(
//                       children: [
//                         Container(
//                           width: 220,
//                           height: 220,
//                           decoration: BoxDecoration(
//                               shape: BoxShape.circle,
//                               gradient: LinearGradient(
//                                   colors: AppColors.dark348Green62ELg,
//                                   begin: Alignment.topCenter,
//                                   end: Alignment.bottomCenter)),
//                         ),
//                         Positioned(
//                           left: 10,
//                           top: 10,
//                           child: Container(
//                             width: 200,
//                             height: 200,
//                             decoration: BoxDecoration(
//                                 shape: BoxShape.circle, color: AppColors.white),
//                             child: Column(
//                               mainAxisAlignment: MainAxisAlignment.center,
//                               children: [
//                                 Text('Paid',
//                                     style: TextStyle(
//                                         fontSize: 15,
//                                         fontWeight: FontWeight.w500,
//                                         color: AppColors.black555)),
//                                 SizedBox(height: 8),
//                                 Text('£20.00',
//                                     style: TextStyle(
//                                         fontSize: 23,
//                                         fontWeight: FontWeight.w700,
//                                         color: AppColors.green67B)),
//                                 Divider(
//                                     thickness: 2,
//                                     color: AppColors.black555.withOpacity(.1)),
//                                 Text('£0.00',
//                                     style: TextStyle(
//                                         fontSize: 23,
//                                         fontWeight: FontWeight.w700,
//                                         color: AppColors.black)),
//                                 SizedBox(height: 8),
//                                 Text('Left',
//                                     style: TextStyle(
//                                         fontSize: 15,
//                                         fontWeight: FontWeight.w500,
//                                         color: AppColors.black555)),
//                               ],
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                     SizedBox(height: 30),
//                     SizedBox(
//                       height: 190,
//                       child: ListView.builder(
//                         itemCount: 5,
//                         scrollDirection: Axis.horizontal,
//                         itemBuilder: (context, index) {
//                           return Padding(
//                             padding: const EdgeInsets.only(right: 13),
//                             child: SizedBox(
//                               width: 75,
//                               child: Column(
//                                 children: [
//                                   Stack(
//                                     children: [
//                                       ClipRRect(
//                                           borderRadius:
//                                               BorderRadius.circular(80),
//                                           child: Image.asset(AppImages.pngUser,
//                                               width: 65, height: 65)),
//                                       Positioned(
//                                         top: 0,
//                                         right: 0,
//                                         child: Container(
//                                           height: 22,
//                                           width: 22,
//                                           decoration: BoxDecoration(
//                                               shape: BoxShape.circle,
//                                               color: AppColors.primaryColor),
//                                           child: Center(
//                                               child: Image.asset(
//                                                   AppImages.pngRightClick,
//                                                   width: 16,
//                                                   height: 16)),
//                                         ),
//                                       ),
//                                     ],
//                                   ),
//                                   SizedBox(height: 5),
//                                   Text('You',
//                                       maxLines: 2,
//                                       style: TextStyle(
//                                           overflow: TextOverflow.ellipsis,
//                                           fontSize: 13,
//                                           fontWeight: FontWeight.w500,
//                                           color: AppColors.black555)),
//                                   Spacer(),
//                                   Text('£5',
//                                       style: TextStyle(
//                                           fontSize: 18,
//                                           fontWeight: FontWeight.w500,
//                                           color: AppColors.black)),
//                                   SizedBox(height: 5),
//                                   AppButton(
//                                     height: 30,
//                                     width: 70,
//                                     radius: 5,
//                                     label: 'Paid',
//                                     textStyle: TextStyle(
//                                         fontSize: 15,
//                                         fontWeight: FontWeight.w600,
//                                         color: AppColors.black),
//                                     onPressed: () {},
//                                     bgColor: AppColors.primaryColor,
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           );
//                         },
//                       ),
//                     ),
//                   ],
//                 ),
//                 SizedBox(height: 20),

//                 /// go to home button
//                 AppButtonCommon(
//                     label: 'Go to Home',
//                     onPressed: () {
//                       viewModel.navigateToHomeScreen(context);
//                     }),
//                 SizedBox(height: 30),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
