import 'package:easy_date_timeline/easy_date_timeline.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_contacts/contact.dart';
import 'package:intl/intl.dart';
import 'package:kratEasyApp/BottomNavScreens/CreateChallengeScreen/FacilityScreen/create_Challenge_Facility.dart';
import 'package:kratEasyApp/Models/contact_model.dart';
import 'package:kratEasyApp/GlobalUtils/app_button.dart';
import 'package:kratEasyApp/GlobalUtils/app_colors.dart';
import 'package:kratEasyApp/GlobalUtils/app_text_field.dart';
import 'package:kratEasyApp/GlobalUtils/common.dart';
import 'package:kratEasyApp/ViewModel/EntranceViewModel/booking_provider.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/utils.dart';
import 'package:kratEasyApp/utils/extension.dart';
import 'package:provider/provider.dart';
import '../../GlobalUtils/app_constants.dart';
import '../../GlobalUtils/common_app_bar.dart';
import '../../ViewModel/BottomNavViewModels/CreateChallengeViewModel/CreateChallengeViewModel.dart';
import '../../ViewModel/BottomNavViewModels/HomeViewModel.dart';
import '../../ViewModel/BottomNavViewModels/MyFavouriteViewModel.dart';
import '../../paymentprovider.dart';
import '../../services/local/local_keys.dart';
import '../../services/local/local_service.dart';

class CreateChallengeScreen extends StatefulWidget {
  const CreateChallengeScreen({super.key});

  @override
  State<CreateChallengeScreen> createState() => _CreateChallengeScreenState();
}

class _CreateChallengeScreenState extends State<CreateChallengeScreen> {
  late CreateChallengeViewModel viewModel;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      viewModel = context.read<CreateChallengeViewModel>();
      viewModel.userData.clear();
      viewModel.slotsResponseModel = null;
      viewModel.selectedSport = null;
      viewModel.slotPrice = 0.0;
      viewModel.friendsPrice = 0.0;
      viewModel.challengeCreateFacilityController.text = "";
      viewModel.getSportsDataApi(context);
      viewModel.clearCreateChallengeData();
      viewModel.getContacts(context);

      final args =
          ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;

      if (args != null) {
        // if (args['selectedSport'] != null) {
        //   viewModel.setSelectedSport(args['selectedSport']);
        // }

        // if (args['facilityId'] != null) {
        //   viewModel.setfacilityiid(args['facilityId']);
        // }
        //
        // if (args['courtId'] != null) {
        //   viewModel.courtId = args['courtId'];
        // }
        //
        // // Cargar datos necesarios
        // if (viewModel.selectedSport != null && viewModel.facilityId != "") {
        //   viewModel.getSlotsNew(context, viewModel.facilityId);
        // }
      }
    });
  }

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  double _calculateSlotPrice(CreateChallengeViewModel viewModel) {
    final int privateMembers =
        int.parse(viewModel.joinRequestController.text) ?? 2;

    if (viewModel.isPublic) {
      // Public slot logic
      if (viewModel.isSplit) {
        final int joinCount =
            int.tryParse(viewModel.joinRequestController.text) ?? 2;
        return viewModel.slotPrice / joinCount;
      } else {
        return viewModel.slotPrice / 2;
      }
    } else {
      // Private slot logic
      return viewModel.slotPrice / viewModel.userData.length;
    }
  }

  double serviceFee = 4.00;

  @override
  Widget build(BuildContext context) {
    // double screenWidth = MediaQuery.of(context).size.width;
    return Consumer2<CreateChallengeViewModel, BookingProvider>(
      builder: (context, viewModel, bookingViewModel, child) {
        final text = viewModel.joinRequestController.text.trim();

        final double baseAmount = viewModel.userData.isEmpty
            ? (viewModel.isSplit
                ? (viewModel.slotPrice /
                    (int.tryParse(viewModel.joinRequestController.text) ?? 2))
                : viewModel.slotPrice)
            : viewModel.friendsPrice;

        final double displayAmount = baseAmount > 0
            ? baseAmount +
                (viewModel.isSplit
                    ? serviceFee /
                        int.parse(viewModel.joinRequestController.text)
                    : serviceFee)
            : baseAmount;

        return Form(
          key: _formKey,
          child: GestureDetector(
            onTap: () {
              FocusScope.of(context).unfocus();
            },
            child: Scaffold(
              backgroundColor: Colors.white,
              appBar: CommonAppBar(
                  title: l10n.of(context).createChallengeBt,
                  backIconColor: Colors.white,
                  backgroundColor: Colors.white),
              body: viewModel.isLoadingSports
                  ? Center(child: loaderWidget())
                  : SafeArea(
                      child: SingleChildScrollView(
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Flexible(
                                    child: Text(
                                        l10n.of(context).createChallengeBt,
                                        style: TextStyle(
                                            color: AppColors.black,
                                            fontSize: 20,
                                            fontWeight: FontWeight.w600)),
                                  ),
                                  viewModel.userData.isEmpty
                                      ? Text(
                                          "${AppConstants.appCurrency}${(viewModel.isSplit ? (viewModel.slotPrice / (int.tryParse(viewModel.joinRequestController.text) ?? 2)) : viewModel.slotPrice).toStringAsFixed(1)}",
                                          style: TextStyle(
                                              fontSize: 18,
                                              color: AppColors.black,
                                              fontWeight: FontWeight.w500))
                                      : Text(
                                          "${AppConstants.appCurrency}${viewModel.friendsPrice.toStringAsFixed(1)}",
                                          style: TextStyle(
                                              fontSize: 18,
                                              color: AppColors.black,
                                              fontWeight: FontWeight.w500)),
                                ],
                              ),
                              if (baseAmount > 0)
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Flexible(
                                      child: Text(
                                        'Service fee',
                                        style: TextStyle(
                                          color: AppColors.blackA2A,
                                          fontSize: 16,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 20,
                                    ),
                                    Text(
                                      "${AppConstants.appCurrency}${viewModel.isSplit ? (serviceFee / (int.parse(viewModel.joinRequestController.text))) : serviceFee}",
                                      style: TextStyle(
                                        fontSize: 16,
                                        color: AppColors.black,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    )
                                  ],
                                ),
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  Image.asset('assets/icons/clock.png',
                                      width: 17, height: 17),
                                  const SizedBox(width: 5),
                                  Text(l10n.of(context).minTimeToBook,
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w400,
                                          color: AppColors.black555)),
                                  if (viewModel.slotsResponseModel?.data
                                              ?.availableSlots !=
                                          null &&
                                      viewModel.slotsResponseModel?.data
                                              ?.availableSlots !=
                                          [] &&
                                      viewModel.slotsResponseModel?.data
                                              ?.availableSlots!.isNotEmpty ==
                                          true)
                                    viewModel.slotsResponseModel?.data
                                                ?.availableSlots?[0] !=
                                            null
                                        ? Text(
                                            viewModel.getTimeDifference(
                                              viewModel
                                                      .slotsResponseModel
                                                      ?.data!
                                                      .availableSlots?[0]
                                                      .startTime ??
                                                  "",
                                              viewModel
                                                      .slotsResponseModel
                                                      ?.data
                                                      ?.availableSlots?[0]
                                                      .endTime ??
                                                  "",
                                            ),
                                          )
                                        : SizedBox(),
                                ],
                              ),
                              const SizedBox(height: 11),
                              const Divider(
                                color: Color(0xffE3E3E3),
                              ),
                              const SizedBox(height: 19),
                              DropdownButtonFormField<String>(
                                value: viewModel.selectedSport,
                                hint: Text(l10n.of(context).selectSport,
                                    style: TextStyle(fontSize: 14)),
                                icon: Image.asset("assets/icons/lowarrow.png",
                                    height: 14, width: 12),
                                items: viewModel.sportsListModel.map((sport) {
                                  return DropdownMenuItem<String>(
                                      value: sport.id,
                                      child: Text(sport.name ?? "",
                                          style: TextStyle(
                                              fontSize: 14,
                                              color: Colors.black)));
                                }).toList(),
                                onChanged: viewModel.setSelectedSport,
                                style: TextStyle(fontSize: 14),
                                decoration: InputDecoration(
                                  filled: true,
                                  fillColor: Color(0xFFF4F9EC),
                                  enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide(
                                          color: Colors.transparent)),
                                  focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide(
                                          color: Colors.transparent)),
                                  contentPadding: EdgeInsets.symmetric(
                                      horizontal: 12, vertical: 10),
                                  hintStyle: TextStyle(fontSize: 14),
                                ),
                                validator: (value) => value == null
                                    ? l10n.of(context).pleaseSelectASport
                                    : null,
                              ),

                              const SizedBox(height: 15),
                              InkWell(
                                onTap: () {
                                  if (viewModel.selectedSport == null ||
                                      viewModel.selectedSport == "") {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                          content: Text(l10n
                                              .of(context)
                                              .pleaseSelectASportFirst)),
                                    );
                                    return;
                                  }

                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => CreateChallengeFacility(
                                        sportId: viewModel.selectedSport,
                                      ),
                                    ),
                                  ).then((value) {
                                    if (viewModel.selectedSport != null &&
                                        viewModel.selectedSport != "" &&
                                        viewModel.courtId != "") {
                                      viewModel.getSlotsNew(
                                        context,
                                        context
                                            .read<CreateChallengeViewModel>()
                                            .facilityId,
                                      );
                                    }
                                  });
                                },
                                child: IgnorePointer(
                                  ignoring: true,
                                  child: AppTextField(
                                    controller: viewModel
                                        .challengeCreateFacilityController,
                                    fillColor: Color(0xFFF4F9EC),
                                    borderColor:
                                        AppColors.lightPrimaryColorFFE5,
                                    isReadOnly: true,
                                    suffix: Icon(CupertinoIcons.search,
                                        color: AppColors.grey769),
                                    hintText: l10n.of(context).searchFacility,
                                    textstyle: TextStyle(
                                        fontSize: 14, color: Colors.black),
                                    hintTextStyle:
                                        TextStyle(color: AppColors.grey769),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 15),
                              DropdownButtonFormField<String>(
                                decoration: InputDecoration(
                                  filled: true,
                                  hintText: l10n.of(context).skillLevel,
                                  fillColor: Color(0xFFF4F9EC),
                                  border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8),
                                      borderSide: BorderSide.none),
                                ),
                                style: TextStyle(fontSize: 14),
                                items: ['Beginner', 'Intermediate', 'Advanced']
                                    .map((skill) => DropdownMenuItem(
                                        value: skill,
                                        child: Text(skill,
                                            style: TextStyle(
                                                fontSize: 14,
                                                color: Colors.black))))
                                    .toList(),
                                onChanged: (v) {
                                  if (viewModel.selectedSport == null) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(
                                            content: Text(l10n
                                                .of(context)
                                                .pleaseSelectASportFirst)));
                                    return;
                                  }
                                  if (viewModel.selectedSport == "") {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(
                                            content: Text(l10n
                                                .of(context)
                                                .pleaseSelectASportFirst)));
                                    return;
                                  }

                                  if (viewModel
                                      .challengeCreateFacilityController.text
                                      .trim()
                                      .isEmpty) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(
                                            content: Text(l10n
                                                .of(context)
                                                .pleaseSelectAFacilityFirst)));
                                    return;
                                  }

                                  viewModel.setSelectedSkillLevel(v);
                                },
                                // Utils.toastMessage( S.of(context).pleaseSelectSkillLevel)
                                validator: (value) => value == null
                                    ? l10n.of(context).pleaseSelectSkillLevel
                                    : null,
                              ),
                              const SizedBox(height: 17),
                              Align(
                                alignment: Alignment.topRight,
                                child: Text(l10n.of(context).selectDate,
                                    style: TextStyle(
                                        decoration: TextDecoration.underline,
                                        fontSize: 14,
                                        color: AppColors.black,
                                        fontWeight: FontWeight.w600)),
                              ),
                              const SizedBox(height: 4),
                              EasyDateTimeLinePicker.itemBuilder(
                                firstDate: DateTime.now(),
                                lastDate:
                                    DateTime.now().add(Duration(days: 30)),
                                headerOptions:
                                    HeaderOptions(headerType: HeaderType.none),
                                focusedDate: DateTime.now(),
                                itemExtent: 56.0,
                                itemBuilder: (context, date, isSelected,
                                    isDisabled, isToday, onTap) {
                                  bool isSelectedDate = (dateOnly(date) ==
                                      dateOnly(viewModel.selectedDate));

                                  return InkResponse(
                                    onTap: () async {
                                      if (viewModel.selectedSport == null) {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(SnackBar(
                                                content: Text(l10n
                                                    .of(context)
                                                    .pleaseSelectASportFirst)));
                                        return;
                                      }
                                      if (viewModel.selectedSport == "") {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(SnackBar(
                                                content: Text(l10n
                                                    .of(context)
                                                    .pleaseSelectASportFirst)));
                                        return;
                                      }

                                      if (viewModel
                                          .challengeCreateFacilityController
                                          .text
                                          .trim()
                                          .isEmpty) {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(SnackBar(
                                                content: Text(l10n
                                                    .of(context)
                                                    .pleaseSelectAFacilityFirst)));
                                        return;
                                      }

                                      await viewModel.updateSelectedDateNew(
                                          date, context);
                                    },
                                    child: Row(
                                      children: [
                                        Container(
                                          height: 80,
                                          width: 50,
                                          padding: EdgeInsets.all(6),
                                          decoration: BoxDecoration(
                                            border: Border.all(
                                              width: 2,
                                              color: isSelectedDate
                                                  ? AppColors.primaryColor
                                                  : Colors
                                                      .transparent, // Border only on selected date
                                            ),
                                            borderRadius: BorderRadius.vertical(
                                                top: Radius.circular(50),
                                                bottom: Radius.circular(50)),
                                          ),
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(date.day.toString(),
                                                  style: TextStyle(
                                                      fontSize: 23,
                                                      fontWeight:
                                                          FontWeight.normal,
                                                      color: AppColors.black)),
                                              Text(
                                                DateFormat('E').format(
                                                    date), // Format: Sun 25 Feb
                                                style: TextStyle(
                                                    fontSize: 14,
                                                    fontWeight:
                                                        FontWeight.normal,
                                                    color: AppColors.black555),
                                              ),
                                              Container(
                                                height: 8,
                                                width: 8,
                                                decoration: BoxDecoration(
                                                  color: isSelectedDate
                                                      ? AppColors.primaryColor
                                                      : Colors.transparent,
                                                  // Highlight dot on selected date
                                                  shape: BoxShape.circle,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                                onDateChange: (date) async {
                                  printLog("Date Changed :${date}");
                                  await bookingViewModel.updateSelectedDate(
                                      date: date, context: context);
                                },
                              ),
                              const SizedBox(height: 8),
                              Align(
                                alignment: Alignment.topCenter,
                                child: Text(
                                    DateFormat('E d MMM')
                                        .format(viewModel.selectedDate),
                                    style: TextStyle(
                                        fontSize: 18,
                                        color: AppColors.black,
                                        fontWeight: FontWeight.w700)),
                              ),
                              const SizedBox(height: 10),
                              const Divider(
                                color: Color(0xffE3E3E3),
                              ),
                              // const SizedBox(height: 7),

                              viewModel.getSlotsloadig == true
                                  ? loaderWidget()
                                  : viewModel.slotsResponseModel?.data
                                                  ?.availableSlots?.isEmpty ==
                                              true ||
                                          (viewModel
                                                      .slotsResponseModel
                                                      ?.data
                                                      ?.availableSlots
                                                      ?.length ??
                                                  0) ==
                                              0
                                      ? noDataWidget(
                                          text: l10n.of(context).slots)
                                      : SizedBox(
                                          height: (viewModel
                                                          .slotsResponseModel
                                                          ?.data
                                                          ?.availableSlots
                                                          ?.length ??
                                                      0) >
                                                  6
                                              ? 220
                                              : null,
                                          child: GridView.builder(
                                            shrinkWrap: true,
                                            itemCount: viewModel
                                                    .slotsResponseModel
                                                    ?.data
                                                    ?.availableSlots
                                                    ?.length ??
                                                0,
                                            physics: (viewModel
                                                            .slotsResponseModel
                                                            ?.data
                                                            ?.availableSlots
                                                            ?.length ??
                                                        0) >
                                                    6
                                                ? BouncingScrollPhysics()
                                                : NeverScrollableScrollPhysics(),
                                            gridDelegate:
                                                SliverGridDelegateWithFixedCrossAxisCount(
                                              crossAxisCount: 2,
                                              mainAxisSpacing: 12,
                                              crossAxisSpacing: 10,
                                              mainAxisExtent: 45,
                                              childAspectRatio: 2.0,
                                            ),
                                            itemBuilder: (context1, index) {
                                              final availableSlot = viewModel
                                                  .slotsResponseModel
                                                  ?.data
                                                  ?.availableSlots?[index];
                                              final isSelected = viewModel
                                                  .selectedSlotIds
                                                  .contains(
                                                      availableSlot?.sId ?? "");

                                              final startTime =
                                                  availableSlot?.startTime ??
                                                      "";
                                              final endTime =
                                                  availableSlot?.endTime ?? "";

                                              return GestureDetector(
                                                onTap: () {
                                                  viewModel.updateSelectedSlot1(
                                                      availableSlot!, context1);
                                                },
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    color: isSelected
                                                        ? AppColors.primaryColor
                                                        : AppColors
                                                            .lightPrimaryColor9EC,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5),
                                                  ),
                                                  child: Center(
                                                    child: Text(
                                                      "$startTime - $endTime",
                                                      style: TextStyle(
                                                        fontSize: 14,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        color: isSelected
                                                            ? AppColors.white
                                                            : AppColors
                                                                .black555,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              );
                                            },
                                          ),
                                        ),
                              const Divider(),
                              const SizedBox(height: 12),

                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Image.asset('assets/icons/challenge.png',
                                          width: 21,
                                          height: 21,
                                          fit: BoxFit.fill,
                                          color: AppColors.black555),
                                      const SizedBox(width: 10),
                                      Text(
                                        l10n.of(context).challengeType,
                                        style: TextStyle(
                                          fontSize: 16,
                                          color: Color(0xff555555),
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 15),
                                  Row(
                                    children: [
                                      CheckboxTheme(
                                        data: CheckboxThemeData(
                                          shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                          ),
                                          fillColor: WidgetStateProperty
                                              .resolveWith<Color>(
                                                  (Set<WidgetState> states) {
                                            return states.contains(
                                                    WidgetState.selected)
                                                ? Colors.black
                                                : Colors.white;
                                          }),
                                          checkColor: WidgetStateProperty.all(
                                              Colors.white),
                                          side: const BorderSide(
                                              color: Colors.black),
                                        ),
                                        child: SizedBox(
                                          height: 20,
                                          width: 20,
                                          child: Checkbox(
                                              value: viewModel.isPublic,
                                              onChanged: (value) {
                                                viewModel.setChallengeType(
                                                  isPublic: value!,
                                                );
                                                viewModel.setSplitType(
                                                  isSplit: false,
                                                );
                                              }),
                                        ),
                                      ),
                                      SizedBox(width: 10),
                                      Text(
                                        l10n.of(context).public,
                                        style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w500,
                                          color: AppColors.black555,
                                        ),
                                      ),
                                      const SizedBox(width: 20),
                                      CheckboxTheme(
                                        data: CheckboxThemeData(
                                          shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                          ),
                                          fillColor: WidgetStateProperty
                                              .resolveWith<Color>(
                                                  (Set<WidgetState> states) {
                                            return states.contains(
                                                    WidgetState.selected)
                                                ? Colors.black
                                                : Colors.white;
                                          }),
                                          checkColor: WidgetStateProperty.all(
                                              Colors.white),
                                          side: const BorderSide(
                                            color: Colors.black,
                                            width: 2,
                                          ),
                                        ),
                                        child: SizedBox(
                                          height: 20,
                                          width: 20,
                                          child: Checkbox(
                                            value: !viewModel.isPublic,
                                            onChanged: (value) =>
                                                viewModel.setChallengeType(
                                              isPublic: !value!,
                                            ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(width: 10),
                                      Text(
                                        l10n.of(context).private,
                                        style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w500,
                                          color: AppColors.black555,
                                        ),
                                      ),
                                      SizedBox(width: 10),
                                      viewModel.isPublic
                                          ? CheckboxTheme(
                                              data: CheckboxThemeData(
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(5),
                                                ),
                                                fillColor: WidgetStateProperty
                                                    .resolveWith<Color>(
                                                        (states) {
                                                  return states.contains(
                                                          WidgetState.selected)
                                                      ? Colors.black
                                                      : Colors.white;
                                                }),
                                                checkColor:
                                                    WidgetStateProperty.all(
                                                        Colors.white),
                                                side: const BorderSide(
                                                  color: Colors.black,
                                                  width: 2,
                                                ),
                                              ),
                                              child: SizedBox(
                                                  height: 20,
                                                  width: 20,
                                                  child: Checkbox(
                                                    value: viewModel.isSplit,
                                                    onChanged: (value) {
                                                      viewModel.setSplitType(
                                                        isSplit: value!,
                                                      );
                                                    },
                                                  )),
                                            )
                                          : SizedBox(),
                                      viewModel.isPublic
                                          ? Text(
                                              " Split with Members",
                                              style: TextStyle(
                                                fontSize: 15,
                                                fontWeight: FontWeight.w500,
                                                color: AppColors.black555,
                                              ),
                                            )
                                          : SizedBox(),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(height: 18),
                              RichText(
                                text: TextSpan(
                                  text: l10n.of(context).noteHeader,
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500,
                                      color: AppColors.red323),
                                  children: [
                                    TextSpan(
                                      text: viewModel.isPublic == true
                                          ? l10n.of(context).openForAnyoneToJoin
                                          : l10n
                                              .of(context)
                                              .selectSpecificUsersToChallenge,
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w500,
                                          color: AppColors.black),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: 20),
                              if (viewModel.isPublic != true) ...[
                                context.read<MyFavouriteViewModel>().isLoading
                                    ? Center(
                                        child: CircularProgressIndicator(),
                                      )
                                    : AppButton(
                                        onPressed: () async {
                                          context
                                              .read<MyFavouriteViewModel>()
                                              .getFavouritePlayerData(
                                                  context: context)
                                              .then((_) {
                                            addFriendShowModalBottomSheet(
                                              context,
                                            );
                                          });
                                        },
                                        textColor: AppColors.white,
                                        radius: 5,
                                        prefixIcon: Image.asset(
                                            'assets/icons/plus.png',
                                            width: 22,
                                            height: 22),
                                        label: l10n.of(context).addFriends,
                                        textSize: 20,
                                        fontWeight: FontWeight.w600,
                                        bgColor: AppColors.black,
                                      ),
                                // SizedBox(height: 30),
                                Padding(
                                  padding: const EdgeInsets.only(
                                      top: 15, bottom: 30),
                                  child: ListView.builder(
                                    itemCount: viewModel.userData.length,
                                    shrinkWrap: true,
                                    padding: EdgeInsets.zero,
                                    physics: NeverScrollableScrollPhysics(),
                                    itemBuilder: (context, index) {
                                      var contactData =
                                          viewModel.userData[index];
                                      return ListTile(
                                        contentPadding: EdgeInsets.zero,
                                        leading: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(30),
                                          child: SizedBox(
                                            height: 40,
                                            width: 40,
                                            child: CircleAvatar(
                                              backgroundColor:
                                                  AppColors.primaryColor,
                                              child: Center(
                                                  child: Text(
                                                      contactData.name
                                                          .substring(0, 1),
                                                      style: TextStyle(
                                                          fontSize: 16,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: AppColors
                                                              .black))),
                                            ),
                                          ),
                                        ),
                                        title: Text(contactData.name,
                                            style: TextStyle(
                                                fontSize: 12,
                                                fontWeight: FontWeight.w700,
                                                color: AppColors.black)),
                                        subtitle: Text(contactData.phoneNumber,
                                            style: TextStyle(
                                                fontSize: 12,
                                                fontWeight: FontWeight.w500,
                                                color: AppColors.black555)),
                                        trailing: SizedBox(
                                          width: 150,
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.end,
                                            children: [
                                              InkWell(
                                                onTap: () {
                                                  viewModel.removeUserData(
                                                      user: contactData);
                                                },
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.end,
                                                  children: [
                                                    Icon(CupertinoIcons.delete,
                                                        size: 16,
                                                        color:
                                                            AppColors.red323),
                                                    SizedBox(width: 3),
                                                    Text(
                                                      "Remove",
                                                      style: TextStyle(
                                                        fontSize: 12,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        color: AppColors.red323,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              SizedBox(height: 5),
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.end,
                                                children: [
                                                  Flexible(
                                                    child: Text(
                                                      l10n
                                                          .of(context)
                                                          .payAmount,
                                                      style: TextStyle(
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        color:
                                                            AppColors.black555,
                                                      ),
                                                    ),
                                                  ),
                                                  SizedBox(width: 3),
                                                  Container(
                                                      width: 1,
                                                      height: 10,
                                                      color:
                                                          AppColors.black555),
                                                  SizedBox(width: 5),
                                                  Container(
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            horizontal: 6,
                                                            vertical: 3),
                                                    color:
                                                        AppColors.primaryColor,
                                                    child: Center(
                                                      child: Text(
                                                        viewModel.userData
                                                                .isEmpty
                                                            ? "${AppConstants.appCurrency}${viewModel.slotPrice.toStringAsFixed(1)}"
                                                            : "${AppConstants.appCurrency}${viewModel.friendsPrice.toStringAsFixed(1)}",
                                                        style: TextStyle(
                                                          fontSize: 12,
                                                          fontWeight:
                                                              FontWeight.w700,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ] else if (viewModel.isPublic == true) ...[
                                TextFormField(
                                  controller: viewModel.joinRequestController,
                                  // define this controller in your widget
                                  decoration: InputDecoration(
                                    labelText: 'Add the number of players',
                                    border: OutlineInputBorder(),
                                  ),
                                  inputFormatters: [
                                    FilteringTextInputFormatter.digitsOnly
                                  ],

                                  maxLines: 1,
                                  keyboardType: TextInputType.number,

                                  validator: (value) {
                                    if (value == null || value.trim().isEmpty) {
                                      return 'Please enter a number';
                                    }

                                    final number =
                                        int.tryParse(value.trim()) ?? 0;

                                    if (number == null) {
                                      return 'Please enter a valid number';
                                    }

                                    if (number < 2) {
                                      return 'Number must be at least 2';
                                    }

                                    return null;
                                  },
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                              ],
                              Row(
                                children: [
                                  Expanded(
                                    child: AppButton(
                                      label:
                                          "${AppConstants.appCurrency}${displayAmount.toStringAsFixed(1)}",
                                      textColor: AppColors.black,
                                      disabledColor: AppColors.primaryColor
                                          .withOpacity(.2),
                                    ),
                                  ),
                                  SizedBox(width: 13),
                                  Expanded(
                                    child: AppButton(
                                      label: l10n.of(context).checkout,
                                      onPressed: () async {
                                        if (viewModel.userData.isEmpty &&
                                            viewModel.isPublic == false) {
                                          ScaffoldMessenger.of(context)
                                              .showSnackBar(
                                            SnackBar(
                                              content: Text(l10n
                                                  .of(context)
                                                  .pleaseAddFriendsToSplitTheCost),
                                            ),
                                          );
                                        } else if (viewModel.isPublic ==
                                            false) {
                                          final result = await context
                                              .read<PaymentProvider>()
                                              .stripePayment(
                                                  context,

                                                  ///price
                                                  viewModel.userData.isEmpty
                                                      ? viewModel.slotPrice
                                                          .toStringAsFixed(1)
                                                      : viewModel.friendsPrice
                                                          .toStringAsFixed(1)
                                                  // displayPrice1
                                                  ,
                                                  true,
                                                  viewModel.courtId ?? '',
                                                  "${LocalService.instance.getData(LocalKeys.instance.userId)}",
                                                  // (viewModel.isSplit? int.parse(viewModel.joinRequestController.text):2).toString(),
                                                  (viewModel.userData.length +
                                                          1)
                                                      .toString(),
                                                  viewModel.selectedSlotIds,
                                                  viewModel.selectedDate
                                                      .toString(),
                                                  "");

                                          if (result) {
                                            viewModel
                                                .navigateToPaymentScreenWithChallengeValidation(
                                                    context,
                                                    viewModel.userData.isEmpty
                                                        ? viewModel.slotPrice
                                                            .toStringAsFixed(1)
                                                        : viewModel.friendsPrice
                                                            .toStringAsFixed(1),
                                                    "Challenge");
                                          }
                                        } else {
                                          if (viewModel.isSplit == true) {
                                            print(
                                                "ispublic false issplit true");

                                            if (_formKey.currentState!
                                                .validate()) {
                                              final result = await context
                                                  .read<PaymentProvider>()
                                                  .stripePayment(
                                                      context,

                                                      ///price
                                                      viewModel.userData.isEmpty
                                                          ? (viewModel.slotPrice /
                                                                  (int.tryParse(viewModel
                                                                          .joinRequestController
                                                                          .text) ??
                                                                      2))
                                                              .toStringAsFixed(
                                                                  1)
                                                          : viewModel
                                                              .friendsPrice
                                                              .toStringAsFixed(
                                                                  1)
                                                      // displayPrice1
                                                      ,
                                                      true,
                                                      viewModel.courtId ?? '',
                                                      "${LocalService.instance.getData(LocalKeys.instance.userId)}",
                                                      (viewModel.isSplit
                                                              ? int.parse(viewModel
                                                                  .joinRequestController
                                                                  .text)
                                                              : 2)
                                                          .toString(),
                                                      viewModel.selectedSlotIds,
                                                      viewModel.selectedDate
                                                          .toString(),
                                                      "");
                                              if (result) {
                                                viewModel.navigateToPaymentScreenWithChallengeValidation(
                                                    context,
                                                    viewModel.userData.isEmpty
                                                        ? (viewModel.slotPrice /
                                                                (int.parse(viewModel
                                                                    .joinRequestController
                                                                    .text)))
                                                            .toStringAsFixed(1)
                                                        : viewModel.friendsPrice
                                                            .toStringAsFixed(1),
                                                    "Challenge");
                                              }
                                            } else if (viewModel
                                                        .selectedSkillLevel ==
                                                    null ||
                                                viewModel.selectedSkillLevel ==
                                                    "") {
                                              Utils.toastMessage(l10n
                                                  .of(context)
                                                  .pleaseSelectSkillLevel);
                                            }
                                          } else {
                                            final result = await context
                                                .read<PaymentProvider>()
                                                .stripePayment(
                                                  context,

                                                  ///price
                                                  viewModel.userData.isEmpty
                                                      ? viewModel.slotPrice
                                                          .toStringAsFixed(1)
                                                      : viewModel.friendsPrice
                                                          .toStringAsFixed(1),
                                                  false,
                                                  viewModel.courtId ?? '',
                                                  "${LocalService.instance.getData(LocalKeys.instance.userId)}",
                                                  viewModel.userData.length > 0
                                                      ? (viewModel.userData
                                                                  .length +
                                                              1)
                                                          .toString()
                                                      : "2",
                                                  viewModel.selectedSlotIds,
                                                  viewModel.selectedDate
                                                      .toString(),
                                                  "",
                                                );

                                            if (result) {
                                              viewModel
                                                  .navigateToPaymentScreenWithChallengeValidation(
                                                context,
                                                viewModel.userData.isEmpty
                                                    ? viewModel.slotPrice
                                                        .toStringAsFixed(1)
                                                    : viewModel.friendsPrice
                                                        .toStringAsFixed(1),
                                                "Challenge",
                                              );
                                            }
                                          }
                                        }
                                      },
                                      textColor: AppColors.black,
                                      bgColor: AppColors.primaryColor,
                                    ),
                                  ),
                                ],
                              ),
                              viewModel.isPublic == true
                                  ? SizedBox()
                                  : SizedBox(height: 17),
                              viewModel.isPublic == true
                                  ? SizedBox()
                                  : SizedBox() ??
                                      Container(
                                        padding:
                                            EdgeInsets.symmetric(vertical: 8),
                                        width:
                                            MediaQuery.of(context).size.width,
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            color: AppColors.primaryColor
                                                .withValues(alpha: 0.2)),
                                        child: Center(
                                          child: Text(
                                            l10n
                                                .of(context)
                                                .refundMinusASmallConvenienceFee,
                                            style: TextStyle(
                                              fontWeight: FontWeight.w600,
                                              fontSize: 14,
                                            ),
                                          ),
                                        ),
                                      ),
                              SizedBox(height: 30),
                            ],
                          ),
                        ),
                      ),
                    ),
            ),
          ),
        );
      },
    );
  }
}

Future<dynamic> addFriendShowModalBottomSheet(BuildContext context) {
  return showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        insetPadding: EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: SizedBox(
            height:
                MediaQuery.of(context).size.height * 0.8, // Limit modal height
            child: Consumer3<CreateChallengeViewModel, MyFavouriteViewModel,
                HomeViewModel>(
              builder: (BuildContext context, viewModel, myvviewModel, homeView,
                  Widget? child) {
                final players = myvviewModel.favouritePlayerData;
                final isSearching = viewModel.searchText.isNotEmpty;

                return Column(
                  children: [
                    Expanded(
                      child: SingleChildScrollView(
                        padding: EdgeInsets.only(
                            bottom: MediaQuery.of(context).viewInsets.bottom),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(l10n.of(context).addFriends,
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                      color: AppColors.black)),
                              SizedBox(height: 10),
                              Container(
                                decoration: BoxDecoration(
                                    color: AppColors.white,
                                    borderRadius: BorderRadius.circular(30)),
                                child: AppTextField(
                                  onchanged: (val) {
                                    viewModel.searchContactList(val);
                                  },
                                  hintTextStyle: TextStyle(
                                      fontWeight: FontWeight.w500,
                                      fontSize: 12,
                                      color: AppColors.black555),
                                  borderColor: AppColors.white,
                                  hintText: l10n.of(context).searchContact,
                                  suffix: Icon(CupertinoIcons.search,
                                      color: AppColors.black555),
                                ),
                              ),
                              SizedBox(height: 16),

                              // Loader or Player List
                              myvviewModel.isLoading
                                  ? SizedBox(
                                      height: 100,
                                      child: Center(child: loaderWidget()))
                                  : players.isEmpty
                                      ? Center(
                                          child: Text(
                                              l10n
                                                  .of(context)
                                                  .noFavouritePlayersFound,
                                              style: TextStyle(
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 16,
                                                  color: AppColors.black555)))
                                      : ListView.builder(
                                          itemCount: players.length,
                                          shrinkWrap: true,
                                          physics:
                                              NeverScrollableScrollPhysics(),
                                          itemBuilder: (context, index) {
                                            var player = players[index];
                                            bool isAdded = viewModel.userData
                                                .any((element) =>
                                                    element?.id == player?.id);
                                            return GestureDetector(
                                              onTap: () {
                                                final contactModel =
                                                    ContactModel(
                                                  id: player.id ?? '',
                                                  name:
                                                      player.friend?.name ?? '',
                                                  phoneNumber: player.friend
                                                          ?.mobileNumber ??
                                                      '',
                                                  isActive: true,
                                                );
                                                viewModel.addUserData(
                                                    user: contactModel);
                                              },
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        vertical: 12),
                                                child: Row(
                                                  children: [
                                                    ClipRRect(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              8),
                                                      child: Container(
                                                        height: 40,
                                                        width: 40,
                                                        decoration: BoxDecoration(
                                                            shape:
                                                                BoxShape.circle,
                                                            color: AppColors
                                                                .primaryColor),
                                                        child: Center(
                                                            child: Text(
                                                                player.friend
                                                                        ?.name
                                                                        ?.substring(
                                                                            0, 1)
                                                                        .capitalizeFirstLetter() ??
                                                                    "",
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        15,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w700,
                                                                    color: AppColors
                                                                        .black))),
                                                      ),
                                                    ),
                                                    const SizedBox(width: 16),
                                                    Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text(
                                                            (player.friend
                                                                        ?.name ??
                                                                    l10n
                                                                        .of(
                                                                            context)
                                                                        .na)
                                                                .capitalizeFirstLetter()
                                                                .toString(),
                                                            style: const TextStyle(
                                                                fontSize: 15,
                                                                color: AppColors
                                                                    .black,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w700)),
                                                        Text(
                                                            "+${player.friend?.countryCode ?? ""}  ${player.friend?.mobileNumber ?? "---"}",
                                                            style: const TextStyle(
                                                                fontSize: 13,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w700,
                                                                color: AppColors
                                                                    .black555)),
                                                      ],
                                                    ),
                                                    const Spacer(),
                                                    isAdded
                                                        ? Text(
                                                            l10n
                                                                .of(context)
                                                                .added,
                                                            style: TextStyle(
                                                                fontSize: 12,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                                color: AppColors
                                                                    .red323))
                                                        : InkWell(
                                                            onTap: () async {
                                                              await homeView
                                                                  .removePlayerFromFavouriteApi(
                                                                context:
                                                                    context,
                                                                playerId: player
                                                                        .playerid ??
                                                                    "",
                                                                players:
                                                                    players,
                                                              );
                                                            },
                                                            child: ClipRRect(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            8),
                                                                child: Image.asset(
                                                                    'assets/icons/heart.png',
                                                                    width: 25,
                                                                    height: 25,
                                                                    color: AppColors
                                                                        .primaryColor,
                                                                    fit: BoxFit
                                                                        .fill)),
                                                          ),
                                                  ],
                                                ),
                                              ),
                                            );
                                          },
                                        ),
                              const SizedBox(height: 16),

                              // Contact List
                              viewModel.searchContacts.isEmpty
                                  ? Center(
                                      child: Text(
                                          l10n.of(context).contactListIsEmpty,
                                          style: TextStyle(
                                              fontSize: 15,
                                              fontWeight: FontWeight.w600,
                                              color: AppColors.black)))
                                  : ListView.builder(
                                      itemCount:
                                          viewModel.searchContacts.length,
                                      padding: EdgeInsets.zero,
                                      shrinkWrap: true,
                                      physics: NeverScrollableScrollPhysics(),
                                      itemBuilder: (context, index) {
                                        Contact contact =
                                            viewModel.searchContacts[index];
                                        ContactModel contactModel =
                                            ContactModel(
                                          id: contact.id ?? "",
                                          isActive: true,
                                          name: contact.displayName ?? "",
                                          phoneNumber: contact
                                                  .phones.firstOrNull?.number ??
                                              "",
                                        );
                                        bool isAdded = viewModel.userData.any(
                                            (element) =>
                                                element?.id == contact?.id);
                                        return ListTile(
                                          onTap: () {
                                            viewModel.addUserData(
                                                user: contactModel);
                                          },
                                          contentPadding: EdgeInsets.zero,
                                          leading: CircleAvatar(
                                            backgroundColor:
                                                AppColors.primaryColor,
                                            backgroundImage: contact.photo !=
                                                    null
                                                ? MemoryImage(contact.photo!)
                                                : null,
                                            child: contact.photo == null
                                                ? Text(
                                                    contact.displayName
                                                        .substring(0, 1)
                                                        .toUpperCase(),
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        fontSize: 16,
                                                        color: AppColors.black),
                                                  )
                                                : null,
                                          ),
                                          title: Text(contact.displayName,
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w700,
                                                  color: AppColors.black)),
                                          subtitle: Text(
                                            contact.phones.isNotEmpty
                                                ? contact.phones.first.number
                                                : l10n.of(context).noNumber,
                                            style: TextStyle(
                                                fontSize: 12,
                                                fontWeight: FontWeight.w500,
                                                color: AppColors.black555),
                                          ),
                                          trailing: isAdded
                                              ? Text(l10n.of(context).added,
                                                  style: TextStyle(
                                                      fontSize: 12,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      color: AppColors.red323))
                                              : Row(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  children: [
                                                    Icon(
                                                        Icons
                                                            .add_circle_outline_outlined,
                                                        color: AppColors
                                                            .greenC748),
                                                    SizedBox(width: 7),
                                                    Text(l10n.of(context).add,
                                                        style: TextStyle(
                                                            fontSize: 12,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            color: AppColors
                                                                .greenC748)),
                                                  ],
                                                ),
                                        );
                                      },
                                    ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: AppButtonCommon(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        label: l10n.of(context).add,
                      ),
                    ),
                    SizedBox(height: 10),
                  ],
                );
              },
            ),
          ),
        ),
      );
    },
  );
}

// Helper function to compare dates without time
DateTime dateOnly(DateTime date) {
  return DateTime(date.year, date.month, date.day);
}
