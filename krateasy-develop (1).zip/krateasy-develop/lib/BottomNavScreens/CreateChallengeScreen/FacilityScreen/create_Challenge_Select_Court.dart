import 'dart:async';
import 'dart:developer';

import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/Models/create_Challenge_Facility_Model.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:shimmer/shimmer.dart';

class CreateChallengeSelectCourt extends StatefulWidget {
  List<Court> courts;
  String name;
  String facilityId;
  CreateChallengeSelectCourt(
      {super.key,
      required this.courts,
      required this.name,
      required this.facilityId});

  @override
  State<CreateChallengeSelectCourt> createState() =>
      _CreateChallengeSelectCourtState();
}

class _CreateChallengeSelectCourtState
    extends State<CreateChallengeSelectCourt> {

  @override
  Widget build(BuildContext context) {
    print("courts==>${widget.courts}");
    log("courts==>${widget.courts}");
    print("facilityId==>${widget.facilityId}");
    log("facilityId==>${widget.facilityId}");
    return Consumer<CreateChallengeViewModel>(
        builder: (context, viewModel, child) {
      return LayoutBuilder(
        builder: (context, constraints) {
          double screenWidth = constraints.maxWidth;
          double screenHeight = constraints.maxHeight;

          return Scaffold(
            backgroundColor: Colors.white,
            appBar: CommonAppBar(
              title: l10n.of(context).searchCourts,
              backIconColor: Colors.white,
              backgroundColor: Colors.white,
            ),
            body: SafeArea(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Divider(
                      height: 1, thickness: 1, color: Color(0xFF8DC63F)),
                  SizedBox(height: 20),
                  Expanded(
                    child: ListView.builder(
                      padding:
                          EdgeInsets.symmetric(horizontal: screenWidth * 0.04),
                      itemCount: widget.courts.length,
                      itemBuilder: (context, index) {
                        return viewModel.iscourtLoading?Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Shimmer.fromColors(
                            baseColor: Colors.grey[300]!,
                            highlightColor: Colors.grey[100]!,
                            child: Container(
                              width: w,
                              height: w*.2,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(9),
                              ),
                            ),
                          ),
                        ) :  Stack(
                          children: [
                          viewModel.iscourtLoading?Shimmer.fromColors(
                            baseColor: Colors.grey[300]!,
                            highlightColor: Colors.grey[100]!,
                            child: Container(
                              width: w,
                              height: w*.2,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(9),
                              ),
                            ),
                          ) : InkWell(
                            onTap: () async {
                              viewModel.setfacilityiid(widget.facilityId);
                              // viewModel.setid(widget.facilityId);
                              viewModel.setCourtLoading(true);
                              print("setfacilityiid");
                          final selectedCourtName = widget.courts[index].name ?? "";

                          // Set values first
                          viewModel.setcourt(selectedCourtName); // still set it for later use
                          viewModel.challengeCreateFacilityController.text =
                          '${widget.name} → $selectedCourtName';

                          viewModel.courtId = widget.courts[index].id.toString();
                          viewModel.facilityId = widget.courts[index].facilityId.toString();


                          // Pop after 1 second
                          WidgetsBinding.instance.addPostFrameCallback((_) {
                            Timer(Duration(seconds: 1), () {
                              viewModel.setCourtLoading(false);
                              Navigator.pop(context);
                              Navigator.pop(context);
                            });
                          });
                        },



                              child: Card(
                                color: Colors.white,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12)),
                                elevation: 0.1,
                                margin: EdgeInsets.only(
                                    bottom: screenHeight * 0.015),
                                child: Padding(
                                  padding: EdgeInsets.all(screenWidth * 0.03),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(8),
                                            child: NetworkImageWidget(
                                              height: screenWidth * 0.29,
                                              width: screenWidth * 0.26,
                                              fit: BoxFit.fill,
                                              image:
                                                  (widget.courts[index].image ??
                                                          "")
                                                      .toString(),
                                            ),
                                          ),
                                          SizedBox(width: screenWidth * 0.025),
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                    (widget.courts[index]
                                                                .name ??
                                                            "")
                                                        .toString(),
                                                    style: TextStyle(
                                                        fontSize:
                                                            screenWidth * 0.035,
                                                        fontWeight:
                                                            FontWeight.bold)),
                                                SizedBox(height: 4),
                                                Row(
                                                  children: [
                                                    Image.asset(
                                                        "assets/icons/rate.png",
                                                        width:
                                                            screenWidth * 0.04,
                                                        height:
                                                            screenWidth * 0.04),
                                                    SizedBox(
                                                        width: screenWidth *
                                                            0.012),
                                                    Text("0",
                                                        // widget.courts[index]
                                                        //     .averageRating
                                                        //     .toString(),
                                                        style: TextStyle(
                                                            fontSize:
                                                                screenWidth *
                                                                    0.035,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            color: Colors
                                                                .grey[700])),
                                                  ],
                                                ),
                                                SizedBox(height: 4),
                                                // Text(
                                                //     "${S.of(context).level}${(widget.courts[index].sport?.skillLevel?[0] ?? S.of(context).na).toString()}",
                                                //     style: TextStyle(
                                                //         fontSize:
                                                //             screenWidth * 0.035,
                                                //         color:
                                                //             Colors.grey[700])),
                                                SizedBox(height: 4),

                                                Text(
                                                    "${l10n.of(context).matchType}${(widget.courts[index].sport?.matchType ?? l10n.of(context).na).toString()}",
                                                    style: TextStyle(
                                                        fontSize:
                                                            screenWidth * 0.035,
                                                        color:
                                                            Colors.grey[700])),
                                                SizedBox(height: 4),
                                                Row(
                                                  children: [
                                                    widget.courts[index].sport
                                                                ?.image ==
                                                            null
                                                        ? ClipOval(
                                                            child: Image.asset(
                                                              "assets/icons/sportsicon.png",
                                                              width: 20,
                                                              height: 20,
                                                              fit: BoxFit.fill,
                                                            ),
                                                          )
                                                        : ClipOval(
                                                            child:
                                                                Image.network(
                                                              widget
                                                                  .courts[index]
                                                                  .sport!
                                                                  .image!,
                                                              width: 20,
                                                              height: 20,
                                                              fit: BoxFit.fill,
                                                            ),
                                                          ),
                                                    SizedBox(
                                                        width: screenWidth *
                                                            0.012),
                                                    Text(
                                                        (widget
                                                                    .courts[
                                                                        index]
                                                                    .sport!
                                                                    .name ??
                                                                l10n.of(context).na)
                                                            .toString(),
                                                        style: TextStyle(
                                                            fontSize: 12,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                            color: Color(
                                                                0xFF3B747B))),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              top: screenHeight * 0.01,
                              right: screenWidth * 0.02,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [

                                  widget.courts[index].sport?.isActive ==true
                                      ? Text(l10n.of(context).active,
                                          style: TextStyle(
                                              fontSize: screenWidth * 0.032,
                                              color: Colors.black))
                                      : Text(
                                          l10n.of(context).inactive
                                          ,
                                        ),
                                ],
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                  )
                ],
              ),
            ),
          );
        },
      );
    });
  }
}
