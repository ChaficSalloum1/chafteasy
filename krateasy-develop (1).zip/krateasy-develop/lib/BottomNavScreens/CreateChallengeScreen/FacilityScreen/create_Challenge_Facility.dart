import 'package:kratEasyApp/BottomNavScreens/CreateChallengeScreen/FacilityScreen/create_Challenge_Select_Court.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/utils/extension.dart';

class CreateChallengeFacility extends StatefulWidget {
  final String? sportId;
  // final VoidCallback? onSelect;

  CreateChallengeFacility({
    super.key,
    this.sportId,
  });

  @override
  State<CreateChallengeFacility> createState() =>
      _CreateChallengeFacilityState();
}

class _CreateChallengeFacilityState extends State<CreateChallengeFacility> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      Provider.of<FacilitiesViewModel>(NavigationService.context, listen: false)
          .getCreateChallengeFacilities(context: context,
        date: DateTime.now().toString(),
        sportId: widget.sportId,
      );
    });
  }


  @override
  Widget build(BuildContext context) {
    print("sportid==>${widget.sportId}");
    return LayoutBuilder(
      builder: (context, constraints) {

        double screenWidth = constraints.maxWidth;
        double screenHeight = constraints.maxHeight;

        return Consumer2<FacilitiesViewModel, CreateChallengeViewModel>(
          builder: (context, viewModel, createChallengeViewModel, child) {
            final sortedFacilities = List.of(viewModel.createFacilitiesData)
              ..sort((a, b) {
                final distA = a.distance ?? double.infinity;
                final distB = b.distance ?? double.infinity;
                return distA.compareTo(distB); // ascending order
              });
            return Scaffold(

              backgroundColor: Colors.white,
              appBar: CommonAppBar(
                title:l10n.of(context).selectFacility,
                backIconColor: Colors.white,
                backgroundColor: Colors.white,
              ),
              body: viewModel.isFacilityLoading
                  ? Center(
                      child: CircularProgressIndicator(
                          color: AppColors.primaryColor))
                  : viewModel.createFacilitiesData.isEmpty
                      ? Center(
                          child: Text(
                           l10n.of(context).facilitiesNotAvailable,
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: AppColors.black555,
                            ),
                          ),
                        )
                      : SafeArea(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Divider(
                                  height: 1,
                                  thickness: 1,
                                  color: Color(0xFF8DC63F)),
                              SizedBox(height: 20),
                              Expanded(
                                child: ListView.builder(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: screenWidth * 0.04),
                                  itemCount:
                                      viewModel.createFacilitiesData.length,
                                  itemBuilder: (context, index) {
                                    final facility = sortedFacilities[index];

                                    // final facility =
                                    //     viewModel.createFacilitiesData[index];
                                    return InkWell(
                                      onTap: () {
                                        context.read<BookingProvider>().setownerid(facility.id ?? "");
                                        print("${context.read<BookingProvider>().ownerid}");
                                        context.read<CreateChallengeViewModel>().setfacilityiid(facility.id??"");
                                        // print("Faciilityid ${context.read<CreateChallengeViewModel>().facilityId}");
                                        context.read<BookingProvider>().setownerid(facility.courts?[0].facilityOwnerId??"");
                                        print(
                                            "Court ownerid is ${facility.courts?[0].facilityOwnerId??""}");
                                        print("Faciilityid ${context.read<CreateChallengeViewModel>().facilityId}");
                                        if (viewModel
                                            .createFacilitiesData[index]
                                            .courts !=
                                            null &&
                                            viewModel
                                                .createFacilitiesData[index]
                                                .courts!
                                                .isNotEmpty) {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (_) =>
                                                  CreateChallengeSelectCourt(
                                                    name: facility.name??"",
                                                    // name: viewModel
                                                    //     .createFacilitiesData[
                                                    // index]
                                                    //     .name ??
                                                    //     "",
                                                    facilityId: facility.id??"",
                                                    // viewModel
                                                    //     .createFacilitiesData[
                                                    // index]
                                                    //     .id ??
                                                    //     "",
                                                    courts: facility.courts??[],
                                                    // courts: viewModel
                                                    //     .createFacilitiesData[index]
                                                    //     .courts!,
                                                  ),
                                            ),
                                          );
                                        } else {
                                          ScaffoldMessenger.of(context)
                                              .showSnackBar(
                                            SnackBar(
                                                content: Text(
                                                    l10n.of(context).noCourtsAvailable)),
                                          );
                                          Navigator.pop(context);
                                        }

                                        // // context.read<BookingProvider>().setownerid(facility.id ?? "");
                                        // // print("${context.read<BookingProvider>().ownerid}");
                                        //
                                        // context.read<BookingProvider>().setownerid(facility.courts?[0].facilityOwnerId??"");
                                        // print(
                                        //     "Court ownerid is ${facility.courts?[0].facilityOwnerId??""}");
                                        // // if (viewModel
                                        // //             .createFacilitiesData[index]
                                        // //             .courts !=
                                        // //         null &&
                                        // //     viewModel
                                        // //         .createFacilitiesData[index]
                                        // //         .courts!
                                        // //         .isNotEmpty)
                                        //   if (facility.courts !=
                                        //         null &&
                                        //       facility.courts!
                                        //         .isNotEmpty)
                                        //
                                        // {
                                        //   Navigator.push(
                                        //     context,
                                        //     MaterialPageRoute(
                                        //       builder: (_) =>
                                        //           CreateChallengeSelectCourt(
                                        //         name: viewModel
                                        //                 .createFacilitiesData[
                                        //                     index]
                                        //                 .name ??
                                        //             "",
                                        //         facilityId: viewModel
                                        //                 .createFacilitiesData[
                                        //                     index]
                                        //                 .id ??
                                        //             "",
                                        //         courts: facility.courts!,
                                        //       ),
                                        //     ),
                                        //   );
                                        // } else {
                                        //   ScaffoldMessenger.of(context)
                                        //       .showSnackBar(
                                        //     SnackBar(
                                        //         content: Text(
                                        //            S.of(context).noCourtsAvailable)),
                                        //   );
                                        //   Navigator.pop(context);
                                        // }
                                      },
                                      child: Card(
                                        color: Colors.white,
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(12),
                                        ),
                                        elevation: 0.1,
                                        margin: EdgeInsets.only(
                                            bottom: screenHeight * 0.015),
                                        child: Padding(
                                          padding: EdgeInsets.all(
                                              screenWidth * 0.03),
                                          child: Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(8),
                                                child: NetworkImageWidget(
                                                  height: screenWidth * 0.29,
                                                  width: screenWidth * 0.26,
                                                  fit: BoxFit.fill,
                                                  image: (facility.image ?? "")
                                                      .toString(),
                                                ),
                                              ),
                                              SizedBox(
                                                  width: screenWidth * 0.025),
                                              Expanded(
                                                child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Flexible(
                                                          child: Text(
                                                            (facility.name ??
                                                                   l10n.of(context).na)
                                                                .toString()
                                                                .capitalizeFirstLetter(),
                                                            maxLines: 2,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            style: TextStyle(
                                                              fontSize: 15,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                            ),
                                                          ),
                                                        ),
                                                        if (facility.courts !=
                                                            null)
                                                          Text(
                                                            "${facility.courts?.length.toString() ?? l10n.of(context).na} ${l10n.of(context).courtsnavailableoblic}",
                                                            style: TextStyle(
                                                              fontSize: 10,
                                                            ),
                                                          ),
                                                      ],
                                                    ),
                                                    Row(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Image.asset(
                                                          "assets/icons/location.png",
                                                          width: screenWidth *
                                                              0.04,
                                                          height: screenWidth *
                                                              0.04,
                                                        ),
                                                        SizedBox(
                                                            width: screenWidth *
                                                                0.012),
                                                        Expanded(
                                                          child: Text(
                                                            (facility.address ??
                                                                    l10n.of(context).na)
                                                                .toString(),
                                                            maxLines: 2,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            style: TextStyle(
                                                              fontSize:
                                                                  screenWidth *
                                                                      0.03,
                                                              color: Colors
                                                                  .grey[700],
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    Row(
                                                      children: [
                                                        Text(" Distance:-",style: TextStyle(
                                                          fontSize: screenWidth * 0.03,
                                                          color: Colors.grey[700],
                                                        ),),
                                                        Text(
                                                          facility.distance != null
                                                              ? facility.distance!.toStringAsFixed(2)
                                                              : l10n.of(context).na,
                                                          maxLines: 2,
                                                          overflow: TextOverflow.ellipsis,
                                                          style: TextStyle(
                                                            fontSize: screenWidth * 0.03,
                                                            color: Colors.grey[700],
                                                          ),
                                                        ),
                                                        Text("Km",style: TextStyle(
                                                          fontSize: screenWidth * 0.03,
                                                          color: Colors.grey[700],
                                                        ),),
                                                      ],
                                                    ),
                                                    SizedBox(
                                                        height: screenHeight *
                                                            0.005),
                                                    Row(
                                                      children: [
                                                        Image.asset(
                                                            "assets/icons/rate.png",
                                                            width: screenWidth *
                                                                0.04,
                                                            height:
                                                                screenWidth *
                                                                    0.04),
                                                        SizedBox(
                                                            width: screenWidth *
                                                                0.012),
                                                        if (facility.courts !=
                                                                null &&
                                                            facility.courts!
                                                                .isNotEmpty)
                                                          Text(
                                                            facility
                                                                    .courts!
                                                                    .first
                                                                    .averageRating
                                                                    ?.toString() ??
                                                                "0",
                                                            style: TextStyle(
                                                              fontSize:
                                                                  screenWidth *
                                                                      0.035,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              color: Colors
                                                                  .grey[700],
                                                            ),
                                                          )
                                                        else
                                                          Text(
                                                            "0",
                                                            style: TextStyle(
                                                              fontSize:
                                                                  screenWidth *
                                                                      0.035,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              color: Colors
                                                                  .grey[700],
                                                            ),
                                                          ),
                                                        SizedBox(
                                                            width: screenWidth *
                                                                0.012),
                                                        Container(
                                                            width: 1,
                                                            height:
                                                                screenHeight *
                                                                    0.03,
                                                            color: Colors.grey),
                                                        SizedBox(
                                                            width: screenWidth *
                                                                0.012),
                                                        if (facility
                                                                .totalBookingCount !=
                                                            null)
                                                          Expanded(
                                                            child: Text(
                                                              "${facility.totalBookingCount}+ ${l10n.of(context).bookings}",
                                                              style: TextStyle(
                                                                fontSize:
                                                                    screenWidth *
                                                                        0.035,
                                                                color: Colors
                                                                    .grey[700],
                                                              ),
                                                            ),
                                                          ),
                                                      ],
                                                    ),
                                                    SizedBox(
                                                        height: screenHeight *
                                                            0.01),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              )
                            ],
                          ),
                        ),
            );
          },
        );
      },
    );
  }
}
