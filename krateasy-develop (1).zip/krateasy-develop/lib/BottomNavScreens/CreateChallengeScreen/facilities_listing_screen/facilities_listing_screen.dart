// import 'package:dropdown_button2/dropdown_button2.dart';
// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
// import 'package:kratEasyApp/GlobalUtils/app_colors.dart';
// import 'package:kratEasyApp/GlobalUtils/app_images.dart';
// import 'package:kratEasyApp/GlobalUtils/common_app_bar.dart';
// import 'package:kratEasyApp/ViewModel/BottomNavViewModels/ChallengeViewModel.dart';
// import 'package:kratEasyApp/ViewModel/BottomNavViewModels/FacilitiesViewModel.dart';
// import 'package:kratEasyApp/generated/l10n.dart';
// import 'package:provider/provider.dart';

// class FacilitiesListingScreen extends StatelessWidget {
//   const FacilitiesListingScreen({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final viewModel = Provider.of<FacilitiesViewModel>(context);
//     double screenWidth = MediaQuery.of(context).size.width;
//     double screenHeight = MediaQuery.of(context).size.height;
//     return Scaffold(
//       backgroundColor: AppColors.white,
//       appBar: CommonAppBar(
//         title:S.of(context).facilitiesListing,
//         action: [
//           InkWell(
//             onTap: () {
//               showFilterBottomSheet(context);
//             },
//             child: SizedBox(
//               height: 25,
//               width: 25,
//               child: Image.asset("assets/icons/filter.png", fit: BoxFit.fill),
//             ),
//           ),
//           SizedBox(width: 16),
//         ],
//       ),
//       body: SafeArea(
//         child: SingleChildScrollView(
//           child: Column(
//             children: [
//               SizedBox(height: 16),
//               ListView.builder(
//                 shrinkWrap: true,
//                 physics: NeverScrollableScrollPhysics(),
//                 padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.04),
//                 itemCount: viewModel.facilities.length,
//                 itemBuilder: (context, index) {
//                   final opening = viewModel.facilities[index];

//                   return Stack(
//                     children: [
//                       Card(
//                         color: Colors.white,
//                         shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(12),
//                         ),
//                         elevation: 0.1,
//                         margin: EdgeInsets.only(bottom: screenHeight * 0.015),
//                         child: Padding(
//                           padding: EdgeInsets.all(screenWidth * 0.03),
//                           child: Column(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               Row(
//                                 crossAxisAlignment: CrossAxisAlignment.start,
//                                 children: [
//                                   ClipRRect(
//                                     borderRadius: BorderRadius.circular(8),
//                                     child: Image.asset(
//                                       opening['image'],
//                                       width: screenWidth * 0.26,
//                                       height: screenWidth * 0.29,
//                                       fit: BoxFit.cover,
//                                     ),
//                                   ),
//                                   SizedBox(width: screenWidth * 0.025),
//                                   Expanded(
//                                     child: Column(
//                                       crossAxisAlignment:
//                                           CrossAxisAlignment.start,
//                                       children: [
//                                         Text(
//                                           opening['club'],
//                                           style: TextStyle(
//                                             fontSize: screenWidth * 0.035,
//                                             fontWeight: FontWeight.bold,
//                                           ),
//                                         ),
//                                         SizedBox(height: screenHeight * 0.005),
//                                         Row(
//                                           children: [
//                                             Image.asset(
//                                               "assets/icons/location.png",
//                                               width: screenWidth * 0.04,
//                                               height: screenWidth * 0.04,
//                                               fit: BoxFit.cover,
//                                             ),
//                                             SizedBox(
//                                               width: screenWidth * 0.012,
//                                             ),
//                                             Expanded(
//                                               child: Text(
//                                                 "Edgbaston, Birmingham",
//                                                 style: TextStyle(
//                                                   fontSize: screenWidth * 0.03,
//                                                   color: Colors.grey[700],
//                                                 ),
//                                               ),
//                                             ),
//                                           ],
//                                         ),
//                                         SizedBox(height: screenHeight * 0.005),
//                                         Row(
//                                           children: [
//                                             Image.asset(
//                                               "assets/icons/rate.png",
//                                               width: screenWidth * 0.04,
//                                               height: screenWidth * 0.04,
//                                               fit: BoxFit.cover,
//                                             ),
//                                             SizedBox(
//                                               width: screenWidth * 0.012,
//                                             ),
//                                             Text(
//                                               "4.7",
//                                               style: TextStyle(
//                                                 fontSize: screenWidth * 0.035,
//                                                 fontWeight: FontWeight.bold,
//                                                 color: Colors.grey[700],
//                                               ),
//                                             ),
//                                             SizedBox(
//                                               width: screenWidth * 0.012,
//                                             ),
//                                             Container(
//                                               width: 1,
//                                               height: screenHeight * 0.03,
//                                               color: Colors.grey,
//                                             ),
//                                             SizedBox(
//                                               width: screenWidth * 0.012,
//                                             ),
//                                             Expanded(
//                                               child: Text(
//                                                 "500+ Bookings",
//                                                 style: TextStyle(
//                                                   fontSize: screenWidth * 0.035,
//                                                   color: Colors.grey[700],
//                                                 ),
//                                               ),
//                                             ),
//                                           ],
//                                         ),
//                                         SizedBox(height: screenHeight * 0.005),
//                                         Row(
//                                           children: viewModel.iconPaths
//                                               .map(
//                                                 (icon) => Container(
//                                                   width: screenWidth * 0.07,
//                                                   height: screenWidth * 0.09,
//                                                   decoration: BoxDecoration(
//                                                     shape: BoxShape.circle,
//                                                     border: Border.all(
//                                                       color: const Color(
//                                                         0xFF8DC63F,
//                                                       ),
//                                                       width:
//                                                           1.5, // Slightly thicker border
//                                                     ),
//                                                   ),
//                                                   child: Center(
//                                                     child: Image.asset(
//                                                       icon,
//                                                       width: screenWidth * 0.04,
//                                                       height:
//                                                           screenWidth * 0.04,
//                                                       fit: BoxFit.contain,
//                                                     ),
//                                                   ),
//                                                 ),
//                                               )
//                                               .expand(
//                                                 (widget) => [
//                                                   widget,
//                                                   SizedBox(
//                                                     width: screenWidth * 0.015,
//                                                   ),
//                                                 ],
//                                               )
//                                               .toList()
//                                             ..removeLast(),
//                                         ),
//                                       ],
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ],
//                           ),
//                         ),
//                       ),
//                       // Label at the top-right corner (formatted text in separate lines)
//                       Positioned(
//                         top: screenHeight * 0.01,
//                         right: screenWidth * 0.02,
//                         child: Column(
//                           crossAxisAlignment: CrossAxisAlignment.end,
//                           children: [
//                             Text(
//                               "4 Courts",
//                               style: TextStyle(
//                                 fontSize: screenWidth * 0.035,
//                                 fontWeight: FontWeight.bold,
//                                 color: Colors.black,
//                               ),
//                             ),
//                             Text(
//                               "Available",
//                               style: TextStyle(
//                                 fontSize: screenWidth * 0.032,
//                                 fontWeight: FontWeight.normal,
//                                 color: Colors.black,
//                               ),
//                             ),
//                           ],
//                         ),
//                       ),
//                     ],
//                   );
//                 },
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }

// void showFilterBottomSheet(BuildContext context) {
//   showModalBottomSheet(
//     backgroundColor: AppColors.white,
//     context: context,
//     isScrollControlled: true,
//     shape: RoundedRectangleBorder(
//       borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
//     ),
//     builder: (context) {
//       return Padding(
//         padding: EdgeInsets.only(
//           bottom: MediaQuery.of(context).viewInsets.bottom,
//         ),
//         child: Padding(
//           padding: const EdgeInsets.all(16.0),
//           child: SingleChildScrollView(
//             child: Consumer<ChallengeViewModel>(
//               builder: (context, viewModel, child) {
//                 return Column(
//                   mainAxisSize: MainAxisSize.min,
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                       children: [
//                         Text(
//                           'Filter',
//                           style: TextStyle(
//                             fontSize: 20,
//                             fontWeight: FontWeight.w700,
//                             color: AppColors.black555,
//                           ),
//                         ),
//                         SizedBox(
//                           width: 40,
//                           height: 40,
//                           child: IconButton(
//                             icon: Image.asset(
//                               "assets/icons/cross.png",
//                               fit: BoxFit.fill,
//                             ),
//                             onPressed: () => Navigator.pop(context),
//                           ),
//                         ),
//                       ],
//                     ),
//                     Divider(),
//                     SizedBox(height: 15),
//                     Container(
//                       padding: EdgeInsets.only(right: 16),
//                       decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(10),
//                         color: AppColors.lightPrimaryColorFFE5,
//                       ),
//                       child: DropdownButtonHideUnderline(
//                         child: DropdownButton2<String>(
//                           style: TextStyle(
//                             fontSize: 16,
//                             fontWeight: FontWeight.normal,
//                             color: AppColors.grey769,
//                           ),
//                           value: viewModel.challenge,
//                           iconStyleData: IconStyleData(
//                             icon: SizedBox(
//                               height: 24,
//                               width: 24,
//                               child: Image.asset(
//                                 "assets/icons/sort.png",
//                                 fit: BoxFit.fill,
//                               ),
//                             ),
//                           ),
//                           hint: Align(
//                             alignment: Alignment.centerLeft,
//                             child: Text(
//                               "Sort",
//                               style: TextStyle(
//                                 fontSize: 15,
//                                 fontWeight: FontWeight.normal,
//                                 color: AppColors.grey8A8,
//                               ),
//                             ),
//                           ),
//                           isExpanded: true,
//                           items: viewModel.sort.map((String item) {
//                             return DropdownMenuItem<String>(
//                               value: item,
//                               child: Text(item),
//                             );
//                           }).toList(),
//                           onChanged: (val) {
//                             viewModel.changeChallenge(val!);
//                           },
//                           dropdownStyleData: DropdownStyleData(
//                             maxHeight: 300,
//                             decoration: BoxDecoration(
//                               borderRadius: BorderRadius.circular(10),
//                               color: Colors.white,
//                             ),
//                           ),
//                           menuItemStyleData: MenuItemStyleData(
//                             padding: EdgeInsets.symmetric(horizontal: 16),
//                           ),
//                           alignment: Alignment.center,
//                         ),
//                       ),
//                     ),
//                     viewModel.storeChallenges.isEmpty
//                         ? SizedBox()
//                         : SizedBox(height: 10),
//                     viewModel.storeChallenges.isEmpty
//                         ? SizedBox()
//                         : Wrap(
//                             children: List.generate(
//                               viewModel.storeChallenges.length,
//                               (index) {
//                                 return Container(
//                                   height: 30,
//                                   margin:
//                                       EdgeInsets.only(bottom: 10, right: 10),
//                                   padding: EdgeInsets.only(left: 5, right: 10),
//                                   decoration: BoxDecoration(
//                                     borderRadius: BorderRadius.circular(5),
//                                     color: AppColors.dark747D,
//                                   ),
//                                   child: Row(
//                                     mainAxisSize: MainAxisSize.min,
//                                     children: [
//                                       Text(
//                                         viewModel.storeChallenges[index],
//                                         style: TextStyle(
//                                           fontWeight: FontWeight.normal,
//                                           fontSize: 14,
//                                           color: AppColors.white,
//                                         ),
//                                       ),
//                                       SizedBox(width: 15),
//                                       InkWell(
//                                         onTap: () {
//                                           viewModel.deleteChallenges(index);
//                                         },
//                                         child: SizedBox(
//                                           width: 19,
//                                           height: 19,
//                                           child: Image.asset(
//                                             "assets/icons/crossgreen.png",
//                                             fit: BoxFit.fill,
//                                           ),
//                                         ),
//                                       ),
//                                     ],
//                                   ),
//                                 );
//                               },
//                             ),
//                           ),
//                     SizedBox(height: 15),
//                     Container(
//                       padding: EdgeInsets.only(right: 16),
//                       decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(10),
//                         color: AppColors.lightPrimaryColorFFE5,
//                       ),
//                       child: DropdownButtonHideUnderline(
//                         child: DropdownButton2<String>(
//                           style: TextStyle(
//                             fontSize: 16,
//                             fontWeight: FontWeight.normal,
//                             color: AppColors.grey769,
//                           ),
//                           value: viewModel.courtSize1,
//                           iconStyleData: IconStyleData(
//                             icon: Icon(Icons.keyboard_arrow_down_outlined),
//                           ),
//                           hint: Align(
//                             alignment: Alignment.centerLeft,
//                             child: Text(
//                               "Court Size",
//                               style: TextStyle(
//                                 fontSize: 15,
//                                 fontWeight: FontWeight.normal,
//                                 color: AppColors.grey8A8,
//                               ),
//                             ),
//                           ),
//                           isExpanded: true,
//                           items: viewModel.courtList1.map((String item) {
//                             return DropdownMenuItem<String>(
//                               value: item,
//                               child: Text(item),
//                             );
//                           }).toList(),
//                           onChanged: (val) {
//                             viewModel.changeCourtSize1(val!);
//                           },
//                           dropdownStyleData: DropdownStyleData(
//                             maxHeight: 300,
//                             decoration: BoxDecoration(
//                               borderRadius: BorderRadius.circular(10),
//                               color: Colors.white,
//                             ),
//                           ),
//                           menuItemStyleData: MenuItemStyleData(
//                             padding: EdgeInsets.symmetric(horizontal: 16),
//                           ),
//                           alignment: Alignment.center,
//                         ),
//                       ),
//                     ),
//                     SizedBox(height: 15),
//                     Container(
//                       padding: EdgeInsets.only(right: 16),
//                       decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(10),
//                         color: AppColors.lightPrimaryColorFFE5,
//                       ),
//                       child: DropdownButtonHideUnderline(
//                         child: DropdownButton2<String>(
//                           style: TextStyle(
//                             fontSize: 16,
//                             fontWeight: FontWeight.normal,
//                             color: AppColors.grey769,
//                           ),
//                           value: viewModel.sportsName1,
//                           iconStyleData: IconStyleData(
//                             icon: Icon(Icons.keyboard_arrow_down_outlined),
//                           ),
//                           hint: Align(
//                             alignment: Alignment.centerLeft,
//                             child: Text(
//                               "Select Sports",
//                               style: TextStyle(
//                                 fontSize: 15,
//                                 fontWeight: FontWeight.normal,
//                                 color: AppColors.grey8A8,
//                               ),
//                             ),
//                           ),
//                           isExpanded: true,
//                           items: viewModel.sportsList1.map((String item) {
//                             return DropdownMenuItem<String>(
//                               value: item,
//                               child: Text(item),
//                             );
//                           }).toList(),
//                           onChanged: (val) {
//                             viewModel.changeSports1(val!);
//                           },
//                           dropdownStyleData: DropdownStyleData(
//                             maxHeight: 300,
//                             decoration: BoxDecoration(
//                               borderRadius: BorderRadius.circular(10),
//                               color: Colors.white,
//                             ),
//                           ),
//                           menuItemStyleData: MenuItemStyleData(
//                             padding: EdgeInsets.symmetric(horizontal: 16),
//                           ),
//                           alignment: Alignment.center,
//                         ),
//                       ),
//                     ),
//                     SizedBox(height: 15),
//                     InkWell(
//                       onTap: () async {
//                         DateTime? pickedDate = await showDatePicker(
//                           builder: (BuildContext context, Widget? child) {
//                             return Theme(
//                               data: Theme.of(context).copyWith(
//                                 colorScheme: const ColorScheme.light(
//                                   primary: AppColors.primaryColor,
//                                   onPrimary: AppColors.white,
//                                   onSurface: AppColors.grey8A8,
//                                 ),
//                                 textButtonTheme: TextButtonThemeData(
//                                   style: TextButton.styleFrom(
//                                     foregroundColor: AppColors.grey8A8,
//                                   ),
//                                 ),
//                               ),
//                               child: child!,
//                             );
//                           },
//                           context: context,
//                           initialDate: DateTime.now(),
//                           firstDate: DateTime(2000),
//                           lastDate: DateTime(2100),
//                         );
//                         if (pickedDate != null) {
//                           viewModel.selectedDate(pickedDate);
//                         }
//                       },
//                       child: Container(
//                         height: 52,
//                         padding: EdgeInsets.symmetric(horizontal: 16),
//                         decoration: BoxDecoration(
//                           borderRadius: BorderRadius.circular(10),
//                           color: AppColors.lightPrimaryColorFFE5,
//                         ),
//                         child: Row(
//                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                           children: [
//                             Text(
//                               viewModel.formattedDate ??
//                                   DateFormat(
//                                     "MMM d yyyy",
//                                   ).format(DateTime.now()).toString(),
//                               style: TextStyle(
//                                 fontSize: 16,
//                                 fontWeight: FontWeight.normal,
//                                 color: AppColors.grey769,
//                               ),
//                             ),
//                             SizedBox(
//                               height: 29,
//                               width: 29,
//                               child: Image.asset(
//                                 "assets/icons/calender.png",
//                                 fit: BoxFit.fill,
//                               ),
//                             ),
//                           ],
//                         ),
//                       ),
//                     ),
//                     SizedBox(height: 15),
//                     Container(
//                       padding: EdgeInsets.only(right: 16),
//                       decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(10),
//                         color: AppColors.lightPrimaryColorFFE5,
//                       ),
//                       child: DropdownButtonHideUnderline(
//                         child: DropdownButton2<String>(
//                           style: TextStyle(
//                             fontSize: 16,
//                             fontWeight: FontWeight.normal,
//                             color: AppColors.grey769,
//                           ),
//                           value: viewModel.amenities,
//                           iconStyleData: IconStyleData(
//                             icon: Icon(Icons.keyboard_arrow_down_outlined),
//                           ),
//                           hint: Align(
//                             alignment: Alignment.centerLeft,
//                             child: Text(
//                               "Amenities",
//                               style: TextStyle(
//                                 fontSize: 15,
//                                 fontWeight: FontWeight.normal,
//                                 color: AppColors.grey8A8,
//                               ),
//                             ),
//                           ),
//                           isExpanded: true,
//                           items: viewModel.amenitiesList.map((String item) {
//                             return DropdownMenuItem<String>(
//                               value: item,
//                               child: Text(item),
//                             );
//                           }).toList(),
//                           onChanged: (val) {
//                             viewModel.changeAmenities(val!);
//                           },
//                           dropdownStyleData: DropdownStyleData(
//                             maxHeight: 300,
//                             decoration: BoxDecoration(
//                               borderRadius: BorderRadius.circular(10),
//                               color: Colors.white,
//                             ),
//                           ),
//                           menuItemStyleData: MenuItemStyleData(
//                             padding: EdgeInsets.symmetric(horizontal: 16),
//                           ),
//                           alignment: Alignment.center,
//                         ),
//                       ),
//                     ),
//                     viewModel.storeAmenities.isEmpty
//                         ? SizedBox()
//                         : SizedBox(height: 10),
//                     viewModel.storeAmenities.isEmpty
//                         ? SizedBox()
//                         : Wrap(
//                             children: List.generate(
//                               viewModel.storeAmenities.length,
//                               (index) {
//                                 return Container(
//                                   height: 30,
//                                   margin:
//                                       EdgeInsets.only(bottom: 10, right: 10),
//                                   padding: EdgeInsets.only(left: 5, right: 10),
//                                   decoration: BoxDecoration(
//                                     borderRadius: BorderRadius.circular(5),
//                                     color: AppColors.dark747D,
//                                   ),
//                                   child: Row(
//                                     mainAxisSize: MainAxisSize.min,
//                                     children: [
//                                       Text(
//                                         viewModel.storeAmenities[index],
//                                         style: TextStyle(
//                                           fontWeight: FontWeight.normal,
//                                           fontSize: 14,
//                                           color: AppColors.white,
//                                         ),
//                                       ),
//                                       SizedBox(width: 15),
//                                       InkWell(
//                                         onTap: () {
//                                           viewModel.deleteAmenities(index);
//                                         },
//                                         child: SizedBox(
//                                           width: 19,
//                                           height: 19,
//                                           child: Image.asset(
//                                             "assets/icons/crossgreen.png",
//                                             fit: BoxFit.fill,
//                                           ),
//                                         ),
//                                       ),
//                                     ],
//                                   ),
//                                 );
//                               },
//                             ),
//                           ),
//                     SizedBox(height: 15),

//                     /// distance
//                     Row(
//                       children: [
//                         SizedBox(
//                           height: 26,
//                           width: 26,
//                           child: Image.asset(
//                             "assets/icons/radius.png",
//                             fit: BoxFit.fill,
//                           ),
//                         ),
//                         SizedBox(width: 5),
//                         Text(
//                           'Radius (distance)',
//                           style: TextStyle(
//                             fontWeight: FontWeight.w700,
//                             fontSize: 15,
//                             color: AppColors.black555,
//                           ),
//                         ),
//                       ],
//                     ),
//                     SizedBox(height: 15),
//                     RangeSlider(
//                       min: 0,
//                       max: 100,
//                       divisions: 100,
//                       labels: RangeLabels(
//                         "${viewModel.rangeDistance.start.toStringAsFixed(0)}miles",
//                         "${viewModel.rangeDistance.end.toStringAsFixed(0)}miles",
//                       ),
//                       activeColor: AppColors.primaryColor,
//                       inactiveColor: AppColors.dark747D,
//                       values: viewModel.rangeDistance,
//                       onChanged: (RangeValues value) {
//                         viewModel.changeRangeDistance(value.start, value.end);
//                       },
//                     ),
//                     SizedBox(height: 15),

//                     /// rate
//                     Row(
//                       children: [
//                         SizedBox(
//                           height: 26,
//                           width: 26,
//                           child: Image.asset(
//                             AppImages.pngRate,
//                             fit: BoxFit.fill,
//                           ),
//                         ),
//                         SizedBox(width: 5),
//                         Text(
//                           'Rating',
//                           style: TextStyle(
//                             fontWeight: FontWeight.w700,
//                             fontSize: 15,
//                             color: AppColors.black555,
//                           ),
//                         ),
//                       ],
//                     ),
//                     SizedBox(height: 15),
//                     RangeSlider(
//                       min: 0,
//                       max: 10,
//                       divisions: 100,
//                       labels: RangeLabels(
//                         "0${viewModel.rangeRate.start.toStringAsFixed(0)}",
//                         "0${viewModel.rangeRate.end.toStringAsFixed(0)}",
//                       ),
//                       activeColor: AppColors.primaryColor,
//                       inactiveColor: AppColors.dark747D,
//                       values: viewModel.rangeRate,
//                       onChanged: (RangeValues value) {
//                         viewModel.changeRangeRate(value.start, value.end);
//                       },
//                     ),
//                     SizedBox(height: 15),
//                     InkWell(
//                       onTap: () {
//                         Navigator.pop(context);
//                       },
//                       child: Stack(
//                         children: [
//                           Container(
//                             height: 52,
//                             width: double.infinity,
//                             decoration: BoxDecoration(
//                               color: AppColors.green033,
//                               borderRadius: BorderRadius.circular(10),
//                             ),
//                           ),
//                           Container(
//                             height: 47,
//                             width: double.infinity,
//                             decoration: BoxDecoration(
//                               color: AppColors.primaryColor,
//                               borderRadius: BorderRadius.circular(10),
//                             ),
//                             child: Center(
//                               child: Text(
//                                 "Filter Apply",
//                                 style: TextStyle(
//                                   fontSize: 16,
//                                   fontWeight: FontWeight.w500,
//                                   color: AppColors.black,
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                   ],
//                 );
//               },
//             ),
//           ),
//         ),
//       );
//     },
//   );
// }
