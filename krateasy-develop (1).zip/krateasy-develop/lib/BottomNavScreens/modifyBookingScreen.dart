import 'dart:developer';
import 'package:easy_date_timeline/easy_date_timeline.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:kratEasyApp/GlobalUtils/common.dart';
import 'package:kratEasyApp/Models/SlotsResponseModel.dart';
import 'package:kratEasyApp/ViewModel/BottomNavViewModels/FacilitiesViewModel.dart';
import 'package:kratEasyApp/GlobalUtils/app_button.dart';
import 'package:kratEasyApp/GlobalUtils/app_colors.dart';
import 'package:kratEasyApp/GlobalUtils/common_app_bar.dart';
import 'package:kratEasyApp/ViewModel/modifyBookingModel.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:provider/provider.dart';

import '../GlobalUtils/app_constants.dart';
import '../GlobalUtils/app_snackbbar.dart';
import '../utils/widgets/common_widgets.dart';

class ModifyBookingScreen extends StatefulWidget {
  final String bookingId;

  const ModifyBookingScreen({
    super.key,
    required this.bookingId,
  });

  @override
  State<ModifyBookingScreen> createState() => _ModifyBookingScreenState();
}

class _ModifyBookingScreenState extends State<ModifyBookingScreen> {
  String finaldate = "";
  DateTime? focusedDateTime; // New variable for DateTime

  @override
  void initState() {
    super.initState();
    final modifybookingmodel = context.read<ModifybookingModel>();

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await modifybookingmodel.getModifyBookingDetails(
          context: context, bookingId: widget.bookingId);

      // Parse date string from API
      final dateString =
          modifybookingmodel.modifyBookingDetailResponse.data?.date;

      finaldate = DateFormat("dd-MM-yyyy").format(parseToLocalDate(
          modifybookingmodel.modifyBookingDetailResponse.data?.date ??
              DateTime.now().toString()));
      // Create a new DateTime object for widget use
      focusedDateTime =
          parseToLocalDate(dateString ?? DateTime.now().toString());
      // Update UI after async load
      if (mounted) {
        setState(() {
          focusedDateTime =
              parseToLocalDate(dateString ?? DateTime.now().toString());
        });
      }
      log("finaldat e   $finaldate");
      log("Initial new : $focusedDateTime");
      modifybookingmodel
          .getSlotsModified111(
              formatedDate: finaldate,
              courtId: modifybookingmodel
                      .modifyBookingDetailResponse.data?.courtId?.id ??
                  "",
              facilityId: modifybookingmodel
                      .modifyBookingDetailResponse.data?.facilityId?.id ??
                  "",
              context: context)
          .then((List<AvailableSlots> slots) {
        var listOfID = modifybookingmodel
                .modifyBookingDetailResponse.data?.slotId
                ?.map((slot) => slot.id?.toString() ?? '')
                .where((id) => id.isNotEmpty)
                .toList() ??
            [];

        modifybookingmodel.setAvailableSlots1(
          slots: slots,
          preSelectedIds: modifybookingmodel
                      .modifyBookingDetailResponse.data?.slotId?.isNotEmpty ??
                  false
              ? listOfID
              : null,
        );
        // Optionalonally select the first slot if none are pre-selected
        if ((listOfID.isEmpty ?? true) && slots.isNotEmpty) {
          print("truee...... ");
          modifybookingmodel.updateSelectedSlot1(slots.first, context,modifybookingmodel.modifyBookingDetailResponse.data?.slotId?.length??1);
        }
        // modifybookingmodel.calculatePrice();
      }).catchError((error) {
        log("Error fetching slots: $error");
        // ScaffoldMessenger.of(context).showSnackBar(
        //   SnackBar(content: Text(S.of(context).failedToLoadSlots)),
        // );
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ModifybookingModel>(
      builder: (context, viewModel, _) {
        double price = viewModel.slotPrice;
        double displayPrice = 0.0;
        if (viewModel.modifyBookingDetailResponse.data?.friends?.isNotEmpty ??
            false) {
          final friendsCount =
              viewModel.modifyBookingDetailResponse.data!.friends!.length;
          displayPrice =
              (viewModel.modifyBookingDetailResponse.data?.price ?? 0) /
                  friendsCount;
        } else {
          displayPrice =
              (viewModel.modifyBookingDetailResponse.data?.price ?? 0)
                  .toDouble();
        }

        return WillPopScope(
          onWillPop: () async {
            context.read<ModifybookingModel>().clearSelectedSlot();
            return true; // allow back navigation
          },
          child: Scaffold(
            bottomNavigationBar: SafeArea(
              child: Padding(
                padding: const EdgeInsets.only(bottom: 30, right: 16, left: 16),
                child: AppButton(

                  isLoading: viewModel.isModifyBookingLoading,
                  label: l10n.of(context).modify,
                  onPressed: () async {
                    // ✅ Minimum slot count validation
                    if (viewModel.selectedSlotIds.length !=
                        viewModel.originalSlotCount) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                            content: Text(
                                "Please select exactly ${viewModel.originalSlotCount} slots to proceed.")),
                      );
                      return;

                    }
                    viewModel. getModifyBookingApi(formatedDate: finaldate, slotIds: viewModel.selectedSlotIds, context: context, id: widget.bookingId);
                  },
                  textColor: AppColors.black,
                  bgColor: AppColors.primaryColor,
                ),
              ),
            ),
            backgroundColor: Colors.white,
            appBar: CommonAppBar(title: l10n.of(context).modifyBooking),
            resizeToAvoidBottomInset: false,
            body: viewModel.isBookingDetailLoading ||
                    viewModel.isLoadingSlotsNew ||
                    focusedDateTime == null
                ? Center(
                    child: CircularProgressIndicator(
                      color: AppColors.primaryColor,
                    ),
                  )
                : Stack(
                    children: [
                      SingleChildScrollView(
                        child: Padding(
                          padding:
                              EdgeInsets.only(right: 16, left: 16, bottom: 150),
                          child: Consumer<ModifybookingModel>(
                            builder: (BuildContext context, viewModel,
                                Widget? child) {
                              return Column(
                                children: [
                                  Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        child: Text(
                                            viewModel
                                                    .modifyBookingDetailResponse
                                                    .data
                                                    ?.courtId
                                                    ?.name ??
                                                "",
                                            style: TextStyle(
                                                color: AppColors.black,
                                                fontSize: 20,
                                                fontWeight: FontWeight.w600)),
                                      ),
                                      Text(
                                        displayPrice.toString(),
                                        style: TextStyle(
                                            fontSize: 20,
                                            color: AppColors.black,
                                            fontWeight: FontWeight.w600),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 10),
                                  Row(
                                    children: [
                                      Image.asset('assets/icons/clock.png',
                                          width: 18, height: 18),
                                      const SizedBox(width: 5),
                                      Text(l10n.of(context).minTimeToBook,
                                          style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.normal,
                                              color: AppColors.black555)),
                                      Text(viewModel.minHours ?? "",
                                          style: TextStyle(
                                              fontSize: 16,
                                              color: AppColors.black555,
                                              fontWeight: FontWeight.w700)),
                                    ],
                                  ),
                                  const SizedBox(height: 10),
                                  Divider(),
                                  const SizedBox(height: 10),
                                  Align(
                                    alignment: Alignment.topRight,
                                    child: Text(l10n.of(context).selectDate,
                                        style: TextStyle(
                                            decoration:
                                                TextDecoration.underline,
                                            fontSize: 14,
                                            color: AppColors.black,
                                            fontWeight: FontWeight.w600)),
                                  ),
                                  const SizedBox(height: 10),
                                  EasyDateTimeLinePicker.itemBuilder(
                                    firstDate: DateTime.now(),
                                    lastDate:
                                        DateTime.now().add(Duration(days: 30)),
                                    headerOptions: HeaderOptions(
                                        headerType: HeaderType.none),
                                    focusedDate: focusedDateTime,
                                    itemExtent: 56.0,
                                    itemBuilder: (context, date, isSelected,
                                        isDisabled, isToday, onTap) {
                                      bool isSelectedDate = (dateOnly(date) ==
                                          dateOnly(viewModel.selectedDate));
                                      final bookingVM =
                                          context.read<ModifybookingModel>();

                                      return InkResponse(
                                        onTap: () async {
                                          viewModel.clearSelectedSlot();
                                          await viewModel
                                              .updateSelectedDate2(date)
                                              .then((v) {
                                            finaldate = DateFormat("dd-MM-yyyy")
                                                .format(date);
                                            log("final date $finaldate ");
                                            viewModel
                                                .getSlotsNormal(
                                              context: context,
                                              courtId: viewModel
                                                      .modifyBookingDetailResponse
                                                      .data
                                                      ?.courtId
                                                      ?.id ??
                                                  "",
                                              formatedDate: finaldate,
                                              facilityId: viewModel
                                                      .modifyBookingDetailResponse
                                                      .data
                                                      ?.facilityId
                                                      ?.id ??
                                                  "",
                                            )
                                                .then(
                                              (List<AvailableSlots> slots) {
                                                bookingVM.setAvailableSlots1(
                                                    slots: slots);
                                              },
                                            );
                                          });
                                        },
                                        child: Container(
                                          height: 80,
                                          width: 50,
                                          padding: EdgeInsets.all(10),
                                          decoration: BoxDecoration(
                                            border: Border.all(
                                              width: 2,
                                              color: isSelectedDate
                                                  ? AppColors.primaryColor
                                                  : Colors
                                                      .transparent, // Border only on selected date
                                            ),
                                            borderRadius: BorderRadius.vertical(
                                                top: Radius.circular(60),
                                                bottom: Radius.circular(60)),
                                          ),
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(date.day.toString(),
                                                  style: TextStyle(
                                                      fontSize: 25,
                                                      fontWeight:
                                                          FontWeight.normal,
                                                      color: AppColors.black)),
                                              Text(
                                                DateFormat('E').format(date),
                                                // Format: Sun 25 Feb
                                                style: TextStyle(
                                                    fontSize: 15,
                                                    fontWeight:
                                                        FontWeight.normal,
                                                    color: AppColors.black555),
                                              ),
                                              Container(
                                                height: 9,
                                                width: 9,
                                                decoration: BoxDecoration(
                                                  color: isSelectedDate
                                                      ? AppColors.primaryColor
                                                      : Colors.transparent,
                                                  // Highlight dot on selected date
                                                  shape: BoxShape.circle,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    },
                                    onDateChange: (date) {
                                      setState(() {
                                        finaldate = DateFormat("dd-MM-yyyy")
                                            .format(date);
                                        // Ensure selected date updates
                                      });
                                    },
                                  ),
                                  const SizedBox(height: 10),
                                  Align(
                                    alignment: Alignment.topCenter,
                                    child: Text(
                                        DateFormat('E d MMM')
                                            .format(viewModel.selectedDate),
                                        style: TextStyle(
                                            fontSize: 18,
                                            color: AppColors.black,
                                            fontWeight: FontWeight.w700)),
                                  ),
                                  const SizedBox(height: 10),
                                  const Divider(),
                                  viewModel.isLoadingSlotsNew ||
                                          viewModel.isLoadingSlotsNew1
                                      ? Center(
                                          child: CircularProgressIndicator(
                                          color: AppColors.primaryColor,
                                        ))
                                      : (viewModel.slotsResponseModel.data
                                                  ?.availableSlots?.isEmpty ??
                                              true)
                                          ? noDataWidget(
                                              text: l10n.of(context).slots)
                                          :
                                  SizedBox(
                                              height: (viewModel
                                                              .slotsResponseModel
                                                              .data
                                                              ?.availableSlots
                                                              ?.length ??
                                                          0) >
                                                      6
                                                  ? 220
                                                  : null,
                                              child: GridView.builder(
                                                shrinkWrap: true,
                                                itemCount: viewModel
                                                        .availableSlots
                                                        .length ??
                                                    0,
                                                physics: (viewModel
                                                                .slotsResponseModel
                                                                .data
                                                                ?.availableSlots
                                                                ?.length ??
                                                            0) >
                                                        6
                                                    ? BouncingScrollPhysics()
                                                    : NeverScrollableScrollPhysics(),
                                                gridDelegate:
                                                    SliverGridDelegateWithFixedCrossAxisCount(
                                                  crossAxisCount: 2,
                                                  mainAxisSpacing: 12,
                                                  crossAxisSpacing: 10,
                                                  mainAxisExtent: 45,
                                                  childAspectRatio: 2.0,
                                                ),
                                                itemBuilder: (context1, index) {
                                                  final availableSlot =
                                                      viewModel.availableSlots[
                                                          index];
                                                  final isSelected = viewModel
                                                      .selectedSlotIds
                                                      .contains(
                                                          availableSlot.sId ??
                                                              "");

                                                  final startTime =
                                                      availableSlot.startTime ??
                                                          "";
                                                  final endTime =
                                                      availableSlot.endTime ??
                                                          "";

                                                  return GestureDetector(
                                                    onTap: () {
                                                      // Pass the required exact count (e.g., originalSlotCount)
                                                      viewModel.updateSelectedSlot1(availableSlot, context, viewModel.originalSlotCount);

                                                      // viewModel
                                                      //     .updateSelectedSlot1(
                                                      //         availableSlot,
                                                      //         context1,2);
                                                    },
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        color: isSelected
                                                            ? AppColors
                                                                .primaryColor
                                                            : AppColors
                                                                .lightPrimaryColor9EC,
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5),
                                                      ),
                                                      child: Center(
                                                        child: Text(
                                                          "$startTime - $endTime",
                                                          style: TextStyle(
                                                            fontSize: 14,
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            color: isSelected
                                                                ? AppColors
                                                                    .white
                                                                : AppColors
                                                                    .black555,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  );
                                                },
                                              ),
                                            ),
                                  const Divider(),

                                  viewModel.modifyBookingDetailResponse.data
                                              ?.friends?.isNotEmpty ??
                                          false
                                      ? ListView.builder(
                                          itemCount: viewModel
                                                  .modifyBookingDetailResponse
                                                  .data
                                                  ?.friends
                                                  ?.length ??
                                              0,
                                          shrinkWrap: true,
                                          padding: EdgeInsets.zero,
                                          physics:
                                              NeverScrollableScrollPhysics(),
                                          itemBuilder: (context, index) {
                                            final friend = viewModel
                                                .modifyBookingDetailResponse
                                                .data
                                                ?.friends?[index];
                                            return ListTile(
                                              contentPadding: EdgeInsets.zero,
                                              leading: CircleAvatar(
                                                backgroundColor:
                                                    AppColors.primaryColor,
                                                child: Center(
                                                  child: Text(
                                                    _getFirstLetter(
                                                        friend?.name ?? ''),
                                                    style: TextStyle(
                                                      fontSize: 16,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      color: AppColors.black,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              title: Text(
                                                friend?.name ?? '',
                                                style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w700,
                                                  color: AppColors.black,
                                                ),
                                                overflow: TextOverflow.ellipsis,
                                                maxLines: 1,
                                              ),
                                              subtitle: Text(
                                                friend?.mobileNumber ?? '---',
                                                style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w500,
                                                  color: AppColors.black555,
                                                ),
                                                overflow: TextOverflow.ellipsis,
                                                maxLines: 1,
                                              ),
                                              trailing: Row(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  Text(
                                                    l10n.of(context).payAmount,
                                                    style: TextStyle(
                                                      fontSize: 10,
                                                      fontWeight:
                                                          FontWeight.w400,
                                                      color: AppColors.black555,
                                                    ),
                                                  ),
                                                  SizedBox(width: 3),
                                                  Container(
                                                    width: 1,
                                                    height: 10,
                                                    color: AppColors.black555,
                                                  ),
                                                  SizedBox(width: 3),
                                                  Container(
                                                    height: 30,
                                                    decoration: BoxDecoration(
                                                      color: AppColors
                                                          .primaryColor,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              2),
                                                    ),
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            horizontal: 8,
                                                            vertical: 3),
                                                    child: Center(
                                                      child: Text(
                                                        '${AppConstants.appCurrency}${friend?.splitAmount?.toStringAsFixed(2) ?? '0.00'}',
                                                        style: TextStyle(
                                                          fontSize: 12,
                                                          fontWeight:
                                                              FontWeight.w700,
                                                          color: AppColors
                                                              .black555,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            );
                                          },
                                        )
                                      : SizedBox()
                                ],
                              );
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
          ),
        );
      },
    );
  }
}

String _getFirstLetter(String name) {
  if (name.isEmpty) return '';
  List<String> words = name.split(' ');
  if (words.isEmpty || words[0].isEmpty) return '';
  return words[0][0].toUpperCase();
}

// Helper function to compare dates without time
DateTime dateOnly(DateTime date) {
  return DateTime(date.year, date.month, date.day);
}
