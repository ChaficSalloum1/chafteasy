
// import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
// import 'package:kratEasyApp/generated/l10n.dart';

// class CompletedChallengesTab extends StatelessWidget {
//   const CompletedChallengesTab({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final viewModel = Provider.of<CompletedChallengeViewModel>(context);
//     double screenWidth = MediaQuery.of(context).size.width;
//     double screenHeight = MediaQuery.of(context).size.height;
//     return Scaffold(
//       backgroundColor: Colors.white,
//       body: SafeArea(
//         child: SingleChildScrollView(
//           child: Padding(
//             padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.04),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 SizedBox(height: 20),
//                 Text(S.of(context).completedChallenges,
//                     style: TextStyle(
//                         fontSize: 18,
//                         fontWeight: FontWeight.w600,
//                         color: AppColors.black)),
//                 SizedBox(height: 10),

//                 /// List of challenges
//                 ListView.builder(
//                   shrinkWrap: true,
//                   physics: NeverScrollableScrollPhysics(),
//                   itemCount: viewModel.openings.length,
//                   itemBuilder: (context, index) {
//                     final opening = viewModel.openings[index];
//                     return Card(
//                       color: Colors.white,
//                       shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(12)),
//                       elevation: 0.1,
//                       margin: EdgeInsets.only(
//                         bottom: index == viewModel.openings.length - 1
//                             ? 0 // No margin for the last card
//                             : screenHeight * 0.015,
//                       ),
//                       child: Padding(
//                         padding: EdgeInsets.all(screenWidth * 0.03),
//                         child: Column(
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           children: [
//                             // Content of the card
//                             Row(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 ClipRRect(
//                                     borderRadius: BorderRadius.circular(8),
//                                     child: Image.asset(opening['image'],
//                                         width: screenWidth * 0.20,
//                                         height: screenWidth * 0.20,
//                                         fit: BoxFit.fill)),
//                                 SizedBox(width: screenWidth * 0.025),
//                                 Expanded(
//                                   child: Column(
//                                     crossAxisAlignment:
//                                         CrossAxisAlignment.start,
//                                     children: [
//                                       Text("# KE01842785",
//                                           style: TextStyle(
//                                               fontSize: screenWidth * 0.035,
//                                               fontWeight: FontWeight.normal,
//                                               color: AppColors.black555)),
//                                       Text("Edgbaston Priory",
//                                           style: TextStyle(
//                                               fontSize: screenWidth * 0.038,
//                                               fontWeight: FontWeight.w600,
//                                               color: AppColors.black)),
//                                       Text(opening['court'],
//                                           style: TextStyle(
//                                               fontSize: screenWidth * 0.033,
//                                               fontWeight: FontWeight.w600,
//                                               color: AppColors.greyGreen47D)),
//                                       SizedBox(height: screenHeight * 0.005),
//                                       Row(
//                                         children: [
//                                           Image.asset(
//                                               "assets/png/public_icon.png",
//                                               width: screenWidth * 0.03,
//                                               height: screenWidth * 0.03,
//                                               fit: BoxFit.cover),
//                                           SizedBox(width: screenWidth * 0.009),
//                                           Text("Public",
//                                               style: TextStyle(
//                                                   fontSize: screenWidth * 0.035,
//                                                   fontWeight: FontWeight.normal,
//                                                   color: AppColors.black555)),
//                                         ],
//                                       ),
//                                     ],
//                                   ),
//                                 ),
//                                 Container(
//                                   padding: EdgeInsets.all(10),
//                                   decoration: BoxDecoration(
//                                       shape: BoxShape.circle,
//                                       border: Border.all(
//                                           width: 1,
//                                           color: AppColors.primaryColor)),
//                                   child: RotatedBox(
//                                       quarterTurns: 45,
//                                       child: Image.asset(
//                                           "assets/icons/tennis.png",
//                                           width: screenWidth * 0.06,
//                                           height: screenWidth * 0.06)),
//                                 ),
//                               ],
//                             ),
//                             SizedBox(height: screenHeight * 0.005),
//                             Row(
//                               children: [
//                                 Image.asset("assets/png/calender.png",
//                                     width: screenWidth * 0.033,
//                                     height: screenWidth * 0.033,
//                                     fit: BoxFit.cover),
//                                 SizedBox(width: screenWidth * 0.002),
//                                 Text(" 09 Feb, 2025 ",
//                                     style: TextStyle(
//                                         fontSize: screenWidth * 0.026,
//                                         color: Color(0xFF555555))),
//                                 SizedBox(width: screenWidth * 0.007),
//                                 Container(
//                                     width: 1,
//                                     height: screenHeight * 0.03,
//                                     color: Color(0xFFDD9D9D9)),
//                                 SizedBox(width: screenWidth * 0.007),
//                                 Text(" 09:00AM - 11:00AM",
//                                     style: TextStyle(
//                                         fontSize: screenWidth * 0.026,
//                                         color: Color(0xFF555555))),
//                                 SizedBox(width: screenWidth * 0.03),
//                                 Image.asset('assets/icons/location.png',
//                                     width: screenWidth * 0.033,
//                                     height: screenWidth * 0.033),
//                                 SizedBox(width: screenWidth * 0.002),
//                                 Expanded(
//                                     child: Text("Edgbaston, Birmingham",
//                                         style: TextStyle(
//                                             fontSize: screenWidth * 0.026,
//                                             color: Color(0xFF555555)))),
//                               ],
//                             ),
//                             Divider(),
//                             SizedBox(height: 5),
//                             Stack(
//                               children: [
//                                 Container(
//                                     height: 6,
//                                     width: screenWidth,
//                                     decoration: BoxDecoration(
//                                         borderRadius: BorderRadius.circular(3),
//                                         color: AppColors.grey1E1)),
//                                 Container(
//                                     height: 6,
//                                     width: (9 / 12) * screenWidth,
//                                     decoration: BoxDecoration(
//                                         borderRadius: BorderRadius.circular(3),
//                                         color: AppColors.greyGreen47D)),
//                               ],
//                             ),
//                             SizedBox(height: 5),
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Expanded(
//                                   child: Row(
//                                     mainAxisAlignment:
//                                         MainAxisAlignment.spaceBetween,
//                                     crossAxisAlignment:
//                                         CrossAxisAlignment.start,
//                                     children: [
//                                       Column(
//                                         crossAxisAlignment:
//                                             CrossAxisAlignment.start,
//                                         children: [
//                                           Text("9 Player going",
//                                               style: TextStyle(
//                                                   fontSize: screenWidth * 0.040,
//                                                   fontWeight: FontWeight.normal,
//                                                   color: AppColors.blackA2A)),
//                                           Center(
//                                               child: CircularImageStack(
//                                                   imageUrls:
//                                                       viewModel.imageUrls,
//                                                   maxImages: 4)),
//                                         ],
//                                       ),
//                                       Column(
//                                         crossAxisAlignment:
//                                             CrossAxisAlignment.end,
//                                         children: [
//                                           Text("Out of 12",
//                                               style: TextStyle(
//                                                   fontSize: screenWidth * 0.040,
//                                                   fontWeight: FontWeight.normal,
//                                                   color: AppColors.blackA2A)),
//                                           SizedBox(height: 8),
//                                           Row(
//                                             children: [
//                                               AppButtonCommon(
//                                                 onPressed: () {
//                                                   viewModel
//                                                       .navigateToViewChallengeScreen(
//                                                           context);
//                                                 },
//                                                 label: "Quick Rebook",
//                                               ),
//                                             ],
//                                           ),
//                                         ],
//                                       ),
//                                     ],
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ],
//                         ),
//                       ),
//                     );
//                   },
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }