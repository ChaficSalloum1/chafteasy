import 'package:geolocator/geolocator.dart';
import 'package:kratEasyApp/GlobalUtils/CircularImageStack.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/Screens/all_challenges.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/utils/widgets/common_widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../Localization/locale_provider.dart';
// import '../../GlobalUtils/CircularImageStack.dart';

class ActiveChallengesTab extends StatefulWidget {
  const ActiveChallengesTab({super.key});

  @override
  State<ActiveChallengesTab> createState() => _ActiveChallengesTabState();
}

class _ActiveChallengesTabState extends State<ActiveChallengesTab> {
  late AvailableChallengeGuestViewModel availableChallengeGuestViewModel;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
          child: ActiveChallengesContent(
        isAvailable: false,
      )),
    );
  }
}

class ActiveChallengesContent extends StatefulWidget {
  final bool isAvailable;
  final bool? isNoTopShown;

  const ActiveChallengesContent({
    super.key,
    required this.isAvailable,
    this.isNoTopShown = false,
  });

  @override
  State<ActiveChallengesContent> createState() =>
      _ActiveChallengesContentState();
}

class _ActiveChallengesContentState extends State<ActiveChallengesContent> {
  double? lat, long;

  // String? savedValue;
  // Future<void> _loadSavedData() async {
  //   final prefs = await SharedPreferences.getInstance();
  //   setState(() {
  //     savedValue = prefs.getString('language_code'); // 👈 key used while saving
  //   });
  // }
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await getLocation();
      // await _loadSavedData();
    });
  }

  Future<void> getLocation() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      lat = prefs.getDouble("current_lat") ?? 0.0;
      long = prefs.getDouble("current_long") ?? 0.0;
    });
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;

    return Consumer<AvailableChallengeGuestViewModel>(
      builder: (context, viewModel, _) {
        if (lat == null || long == null) {
          return Center(child: CircularProgressIndicator());
        }

        // ✅ Clone and sort
        List sortedChallenges = viewModel.searchChallengeData.toList();

        sortedChallenges.sort((a, b) {
          double distanceA = Geolocator.distanceBetween(
            lat!,
            long!,
            a.slots?.court?.facility?.latitude ?? 0.0,
            a.slots?.court?.facility?.longtitude ?? 0.0,
          );

          double distanceB = Geolocator.distanceBetween(
            lat!,
            long!,
            b.slots?.court?.facility?.latitude ?? 0.0,
            b.slots?.court?.facility?.longtitude ?? 0.0,
          );

          return distanceA.compareTo(distanceB); // ✅ Ascending (nearest first)
        });

        return SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.04),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ... your title section
                if (widget.isAvailable && widget.isNoTopShown == false)
                  Column(
                    children: [
                      SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(l10n.of(context).availableChallenges,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600)),
                          ElevatedButton(
                            onPressed: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => AllChallenges()));
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Color(0xFF3B747D),
                              foregroundColor: Colors.white,
                              minimumSize: Size(56, 26),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(6)),
                              padding: EdgeInsets.zero,
                            ),
                            child: Text(l10n.of(context).viewAll,
                                style: TextStyle(
                                    fontSize: 12, fontWeight: FontWeight.w500)),
                          ),
                        ],
                      ),
                      SizedBox(height: 8),
                    ],
                  ),
                if (widget.isAvailable == false && widget.isNoTopShown == false)
                  Text(
                    l10n.of(context).activeChallenges,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: AppColors.black,
                    ),
                  ),
                SizedBox(height: 10),
                viewModel.searchChallengeData.isEmpty
                    ? SizedBox(
                        height: MediaQuery.of(context).size.height * .6,
                        child: Center(
                          child: Text(
                            l10n.of(context).challengesNotAvailableYet,
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: AppColors.black555),
                          ),
                        ),
                      )
                    : ListView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: sortedChallenges.length, // ✅ Use sorted list
                        itemBuilder: (context, index) {
                          var challenge = sortedChallenges[index];
                          double distanceInMeters = Geolocator.distanceBetween(
                            lat!,
                            long!,
                            challenge.slots?.court?.facility?.latitude ?? 0.0,
                            challenge.slots?.court?.facility?.longtitude ?? 0.0,
                          );

                          List<String>? imageUrls = challenge.whoJoined
                              ?.map((x) => x['image']?.toString())
                              .where((url) => url != null && url.isNotEmpty)
                              .cast<String>()
                              .toList();

                          // ✅ Your existing UI using challenge and distance
                          return GestureDetector(
                            onTap: () {
                              // Navigator.push(context, MaterialPageRoute(builder: (_)=>ViewCourtDetailsCompleteScreen(
                              //               ID: challenge.id ??" ",
                              //             )));
                              debugPrint(
                                  "Challenge Id:>>>>>>>>> ${challenge.id}");

                              if (viewModel.isLoad != true) {
                                viewModel.setLoadingChallengeIndex(index);
                                viewModel
                                    .getChallengesDetails(
                                        ispublic: true,
                                        cancelChallenge: false,
                                        challengesId:
                                            (challenge.id ?? "").toString(),
                                        context: context)
                                    .then((_) {
                                  viewModel.setLoadingChallengeIndex(null);
                                });
                              }
                            },
                            child: Container(
                              width: double.infinity,
                              padding: EdgeInsets.all(8),
                              margin: EdgeInsets.only(bottom: 12),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                      width: 1, color: Color(0xFFD0D0D0))),
                              child: Column(
                                children: [
                                  Row(
                                    children: [
                                      /// image
                                      ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(5),
                                          child: NetworkImageWidget(
                                              image: (challenge.slots?.court
                                                          ?.image ??
                                                      "")
                                                  .toString(),
                                              height: 100,
                                              width: 95)),
                                      SizedBox(width: 8.0),

                                      /// text and sub text data
                                      Expanded(
                                        child: Column(
                                          children: [
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                      Row(
                                                        children: [
                                                          Text(
                                                            context
                                                                        .read<
                                                                            LocaleProvider>()
                                                                        .locale
                                                                        .languageCode ==
                                                                    "el"
                                                                ? (challenge
                                                                            .slots
                                                                            ?.court
                                                                            ?.sport
                                                                            ?.grname ??
                                                                        "${(challenge.slots?.court?.sport?.name ?? "").toString()}")
                                                                    .toString()
                                                                : (challenge
                                                                            .slots
                                                                            ?.court
                                                                            ?.sport
                                                                            ?.name ??
                                                                        "")
                                                                    .toString(),
                                                            style: TextStyle(
                                                                fontSize: 14,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w600,
                                                                color: Color(
                                                                    0XFF3B747D)),
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            maxLines: 1,
                                                          ),
                                                          // Text(distanceInMeters.toString()??""),
                                                          Text(
                                                              '(~ ${(distanceInMeters / 1000).toStringAsFixed(2)} km)'),
                                                        ],
                                                      ),
                                                      Text(
                                                          context
                                                                      .read<
                                                                          LocaleProvider>()
                                                                      .locale
                                                                      .languageCode ==
                                                                  "el"
                                                              ? (challenge.slots?.court?.grname ??
                                                                      "")
                                                                  .toString()
                                                              : (challenge
                                                                          .slots
                                                                          ?.court
                                                                          ?.name ??
                                                                      "")
                                                                  .toString(),
                                                          style: TextStyle(
                                                              fontSize: 14,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600),
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          maxLines: 2),
                                                      SizedBox(height: 3),
                                                    ],
                                                  ),
                                                ),
                                                Transform.translate(
                                                  offset: Offset(0, -10),
                                                  child: Container(
                                                    height: 35,
                                                    width: 35,
                                                    decoration: BoxDecoration(
                                                        shape: BoxShape.circle,
                                                        border: Border.all(
                                                            color: Colors.green,
                                                            width: 1)),
                                                    child: Center(
                                                      child: ClipRRect(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(25),
                                                          child: NetworkImageWidget(
                                                              image: (challenge
                                                                          .slots
                                                                          ?.court
                                                                          ?.sport
                                                                          ?.image ??
                                                                      "")
                                                                  .toString(),
                                                              fit: BoxFit.cover,
                                                              height: 25,
                                                              width: 25)),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            SizedBox(height: 3),
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Image.asset(
                                                    'assets/icons/calender.png',
                                                    width: 15,
                                                    height: 12),
                                                SizedBox(width: 3),
                                                Text(
                                                  formatDateToDayMonthYear(challenge
                                                      .date!), // formatBookingDate(
                                                  //     challenge.date!),
                                                  style: TextStyle(
                                                      fontSize: 10,
                                                      color: Colors.black54),
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                ),
                                                Container(
                                                    margin:
                                                        EdgeInsets.symmetric(
                                                            horizontal: 4),
                                                    height: 12,
                                                    width: 2,
                                                    color: AppColors.greyD0D0),
                                                Expanded(
                                                  child: Text(
                                                    '${challenge.slots?.startTime} - ${challenge.slots?.endTime}',
                                                    style: TextStyle(
                                                        fontSize: 10,
                                                        color: Colors.black54),
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            SizedBox(height: 3),
                                            Row(
                                              children: [
                                                Image.asset(
                                                    'assets/icons/location.png',
                                                    width: 15,
                                                    height: 12),
                                                SizedBox(width: 3),
                                                Expanded(
                                                  child: Text(
                                                    (challenge
                                                                .slots
                                                                ?.court
                                                                ?.facility
                                                                ?.address ??
                                                            l10n.of(context).na)
                                                        .toString(),
                                                    style: TextStyle(
                                                        fontSize: 10,
                                                        color: Colors.black54),
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                  Divider(),
                                  SizedBox(height: 3),
                                  Stack(
                                    children: [
                                      Container(
                                          height: 5,
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width -
                                              32,
                                          decoration: BoxDecoration(
                                              color: AppColors.greyD0D0,
                                              borderRadius:
                                                  BorderRadius.circular(5))),
                                      Container(
                                        height: 5,
                                        width: (challenge.maxPlayer != null &&
                                                challenge.maxPlayer != 0)
                                            ? (((challenge.whoJoined
                                                                ?.isNotEmpty ??
                                                            false
                                                        ? challenge
                                                            .whoJoined!.length
                                                        : 1) *
                                                    screenWidth) /
                                                challenge.maxPlayer!)
                                            : 1,
                                        decoration: BoxDecoration(
                                            color: AppColors.teal747D,
                                            borderRadius:
                                                BorderRadius.circular(5)),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 3),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                          "${(challenge.whoJoined?.isNotEmpty ?? false) ? challenge.whoJoined!.length : 1} ${l10n.of(context).players}",
                                          //       ,
                                          // "${challenge.whoJoined?.length ?? 1} Player going",
                                          // "${challenge.whoJoined?.length ?? 0} Player going",
                                          style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.normal,
                                              color: AppColors.blackA2A)),
                                      Text(
                                          "${l10n.of(context).outOf} ${challenge.maxPlayer.toInt().toString()}",
                                          style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.normal,
                                              color: AppColors.blackA2A)),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Center(
                                          child: CircularImageStackOld(
                                              imageUrls: imageUrls!,
                                              maxImages: 3 ?? 0)),
                                      Consumer<
                                          AvailableChallengeGuestViewModel>(
                                        builder: (BuildContext context,
                                            viewModel1, Widget? child) {
                                          return Transform.translate(
                                            offset: Offset(8, 8),
                                            child: Container(
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 7, vertical: 3),
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.only(
                                                    topLeft: Radius.circular(5),
                                                    bottomLeft:
                                                        Radius.circular(5),
                                                    bottomRight:
                                                        Radius.circular(12)),
                                                color: AppColors.black,
                                              ),
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  viewModel.loadingChallengeIndex ==
                                                          index
                                                      ? viewModel.isLoad
                                                          ? Center(
                                                              child: SizedBox(
                                                                height: 16,
                                                                width: 16,
                                                                child:
                                                                    CircularProgressIndicator(
                                                                  strokeWidth:
                                                                      1,
                                                                  color:
                                                                      AppColors
                                                                          .white,
                                                                ),
                                                              ),
                                                            )
                                                          : Text(
                                                              "${AppConstants.appCurrency}${(challenge.slots?.price ?? 0).toString()}",
                                                              style: TextStyle(
                                                                fontSize: 16,
                                                                color: AppColors
                                                                    .white,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .normal,
                                                              ),
                                                            )
                                                      : challenge.slots
                                                                  ?.price ==
                                                              0.0
                                                          ? Container()
                                                          : Text(
                                                              "${AppConstants.appCurrency}${(challenge.slots?.price ?? 0).toString()}",
                                                              style: TextStyle(
                                                                fontSize: 16,
                                                                color: AppColors
                                                                    .white,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .normal,
                                                              ),
                                                            ),
                                                  challenge.slots?.price == 0.0
                                                      ? Container()
                                                      : Container(
                                                          height: 15,
                                                          width: 2,
                                                          color:
                                                              AppColors.white,
                                                          margin: EdgeInsets
                                                              .symmetric(
                                                            horizontal: 8,
                                                          ),
                                                        ),
                                                  Text(
                                                    l10n.of(context).joinUs,
                                                    style: TextStyle(
                                                      fontSize: 14,
                                                      color: AppColors.white,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          );
                                        },
                                      )
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                          // buildChallengeCard(challenge, distanceInMeters, index, screenWidth, viewModel);
                        },
                      ),
              ],
            ),
          ),
        );
      },
    );
  }
}
