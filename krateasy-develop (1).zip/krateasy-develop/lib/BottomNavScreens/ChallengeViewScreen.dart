import 'dart:developer';

import 'package:dropdown_button2/dropdown_button2.dart';

import 'package:flutter/cupertino.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/utils.dart';
import 'package:kratEasyApp/utils/widgets/common_widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../API_CALLS/GlobalAPIUtils.dart';
import '../GlobalUtils/SideDrawerScreen.dart';
// import '../ViewModel/DashboardViewModel.dart';
import '../plugin/editedd_date_picker.dart';
import '../services/local/local_keys.dart';
import 'ChallengeTab/ActiveChallengeTab.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class ChallengeViewScreen extends StatefulWidget {
  const ChallengeViewScreen({super.key});

  @override
  State<ChallengeViewScreen> createState() => _ChallengeViewScreenState();
}

class _ChallengeViewScreenState extends State<ChallengeViewScreen> {
  late AvailableChallengeGuestViewModel availableChallengeGuestViewModel;
  @override
  void initState() {
    availableChallengeGuestViewModel =
        context.read<AvailableChallengeGuestViewModel>();
    Provider.of<ChooseSportsViewModel>(context, listen: false).fetchSports();

    availableChallengeGuestViewModel.searchController.clear();
    getSavedLocation();

    super.initState();
  }
  String address = "";
  var lat,long;
  Future<String?> getSavedLocation() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    address = await prefs.getString('saved_location') ?? "";
     lat = await prefs.getDouble("current_lat");
     long = await prefs.getDouble("current_long");
  }

  InputDecoration _inputDecoration(String hintText) {
    return InputDecoration(
      hintText: hintText,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.transparent), // Transparent border
      ),
      enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: Colors.transparent)),
      focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: Colors.transparent)),
      filled: true,
      fillColor: Colors.white,
      // Background color
      contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 14),
    );
  }
  final ValueNotifier<RangeValues> rangeValuesNotifier = ValueNotifier(
    const RangeValues(1, 3),
  );


  void showWhatToPlayDialog(BuildContext context) async {
    final _formKey = GlobalKey<FormState>();

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      isScrollControlled: true,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (BuildContext context) {
        return Consumer<HomeViewModel>(builder: (context, value, child) {
          return SafeArea(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header row
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(l10n.of(context).whatDoYouWantToPlay,
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                color: Color(0xFF555555))),
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Image.asset('assets/icons/cross.png',
                              width: 24, height: 24),
                        ),
                      ],
                    ),
                    SizedBox(height: 18),
                    // Dropdown for sport selection

                    DropdownButtonFormField<String>(
                      value: value.selectedSport, // ID
                      hint: Text(l10n.of(context).selectSports,
                          style: TextStyle(fontSize: 14)),
                      icon: Image.asset("assets/icons/lowarrow.png",
                          height: 14, width: 12),
                      items: value.sportsListModel.map((sport) {
                        return DropdownMenuItem<String>(
                          value: sport.id,
                          child: Text(sport.name ?? "",
                              style:
                              TextStyle(fontSize: 14, color: Colors.black)),
                        );
                      }).toList(),
                      onChanged: value.setSelectedSport, // Will update and save
                      style: TextStyle(fontSize: 14),
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Color(0xFFF4F9EC),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(color: Colors.transparent),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(color: Colors.transparent),
                        ),
                        contentPadding:
                        EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        hintStyle: TextStyle(fontSize: 14),
                      ),
                      validator: (value) =>
                      value == null ? l10n.of(context).pleaseSelectASport : null,
                    ),

                    SizedBox(height: 16),
                    // FutureBuilder for location (keeping it as is)

                    Consumer<MyLocationViewModel>(
                      builder: (context, myLocationViewModel, _) {
                        return TextFormField(
                          controller:
                          myLocationViewModel.locationController,
                          readOnly: true,
                          onTap: () {
                            if (!myLocationViewModel.isLoadingManually) {
                              myLocationViewModel.getAndNavigateToMapScreen(
                                  context, true);
                            }
                          },
                          style: TextStyle(fontSize: 12),
                          decoration: _inputDecoration(address).copyWith(
                            filled: true,
                            fillColor: Color(0xFFF4F9EC),
                            suffixIcon: Padding(
                                padding: EdgeInsets.all(15),
                                child: SizedBox(
                                  height: 10,
                                  width: 10,
                                  child:
                                  myLocationViewModel.isLoadingManually
                                      ? CircularProgressIndicator(
                                      color: AppColors.primaryColor,
                                      strokeWidth: 0.8)
                                      : Image.asset(
                                    fit: BoxFit.cover,
                                    'assets/icons/location.png',
                                  ),
                                )),
                            hintStyle: TextStyle(fontSize: 12),
                          ),
                        );
                      },
                    ),
                    // FutureBuilder<String?>(
                    //   future: getSavedLocation(),
                    //   builder: (context, snapshot) {
                    //     String location = snapshot.data ??
                    //         "${LocalService.instance.getData(LocalKeys.instance.currentLocation)}";
                    //     return TextFormField(
                    //       readOnly: true,
                    //       style: TextStyle(fontSize: 14),
                    //       decoration: _inputDecoration(location).copyWith(
                    //         filled: true,
                    //         fillColor: Color(0xFFF4F9EC),
                    //         suffixIcon: Padding(
                    //           padding: EdgeInsets.all(10),
                    //           child: Image.asset('assets/icons/location.png',
                    //               width: 10, height: 10),
                    //         ),
                    //         hintStyle: TextStyle(fontSize: 14),
                    //       ),
                    //     );
                    //   },
                    // ),
                    SizedBox(height: 16),
                    // Dropdown for time selection
                    DropdownButtonFormField<String>(
                      decoration: InputDecoration(
                        hintText: l10n.of(context).whichTime,
                        hintStyle: TextStyle(fontSize: 14),
                        filled: true,
                        fillColor: Color(0xFFF4F9EC),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: BorderSide.none),
                      ),
                      style: TextStyle(fontSize: 14, color: Colors.black),
                      items: [
                        "12:00 AM",
                        "01:00 AM",
                        "02:00 AM",
                        "03:00 AM",
                        "04:00 AM",
                        "05:00 AM",
                        "06:00 AM",
                        "07:00 AM",
                        "08:00 AM",
                        "09:00 AM",
                        "10:00 AM",
                        "11:00 AM",
                        "12:00 PM",
                        "01:00 PM",
                        "02:00 PM",
                        "03:00 PM",
                        "04:00 PM",
                        "05:00 PM",
                        "06:00 PM",
                        "07:00 PM",
                        "08:00 PM",
                        "09:00 PM",
                        "10:00 PM",
                        "11:00 PM"
                      ]
                          .map((time) => DropdownMenuItem(
                          value: time,
                          child: Text(time, style: TextStyle(fontSize: 14))))
                          .toList(),
                      onChanged: (v) {
                        print('Selected time: $v');
                        value.setSelectedTimeSlot(
                            v); // Make sure this updates the time slot value
                      },
                      validator: (value) =>
                      value == null ? l10n.of(context).pleaseSelectATime : null,
                    ),

                    SizedBox(height: 16),

                    DropdownButtonFormField<String>(
                      decoration: InputDecoration(
                        filled: true,
                        hintText: l10n.of(context).skillLevel,
                        fillColor: Color(0xFFF4F9EC),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: BorderSide.none),
                      ),
                      style: TextStyle(fontSize: 14),
                      items: ['Beginner', 'Intermediate', 'Advanced']
                          .map((skill) => DropdownMenuItem(
                          value: skill,
                          child: Text(skill,
                              style: TextStyle(
                                  fontSize: 14, color: Colors.black))))
                          .toList(),
                      onChanged: (v) {
                        print('Selected skill: $v');
                        value.setSelectedSkillLevel(
                            v); // Make sure this updates the skill level
                      },
                      validator: (value) => value == null
                          ? l10n.of(context).pleaseSelectSkillLevel
                          : null,
                    ),
                    SizedBox(height: 16),
                    // Radius slider
                    ValueListenableBuilder<RangeValues>(
                      valueListenable: rangeValuesNotifier,
                      builder: (context, rangeValues, child) {
                        // Round the values to the nearest integer between 1 and 6
                        int startHour = rangeValues.start.round().clamp(1, 6);
                        int endHour = rangeValues.end.round().clamp(1, 6);

                        return Text('$startHour hr - $endHour hr',
                            style: const TextStyle(
                                fontSize: 14, color: Colors.black));
                      },
                    ),
                    ValueListenableBuilder<RangeValues>(
                      valueListenable: rangeValuesNotifier,
                      builder: (context, rangeValues, child) {
                        return RangeSlider(
                          values: rangeValues,
                          min: 1,
                          max: 6,
                          activeColor: Color(0XFF8DC63F),
                          inactiveColor: Color(0XFF3B747D),
                          labels: RangeLabels(
                            '${rangeValues.start.round()}hr',
                            '${rangeValues.end.round()}hr',
                          ),
                          onChanged: (values) {
                            rangeValuesNotifier.value = RangeValues(
                              rangeValues.start,
                              values.end < rangeValues.start
                                  ? rangeValues.start
                                  : values.end,
                            );
                          },
                        );
                      },
                    ),
                    SizedBox(height: 16),
                    // Apply button
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: Stack(
                        children: [
                          Container(
                            height: 52,
                            width: double.infinity,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: Color(0xFF72A033)),
                          ),
                          GestureDetector(
                            onTap: () async {
                              SharedPreferences prefs = await SharedPreferences.getInstance();
                              if (_formKey.currentState!.validate()) {
                                // Collect the form data
                                String sportId = value.selectedSport ?? '';
                                String skillLevel =
                                    value.selectedSkillLevel ?? '';
                                String timeSlot =
                                    value.selectedTimeSlot ?? '';
                                RangeValues timeRadius =
                                    rangeValuesNotifier.value;

                                log(".sportIds.....$sportId");
                                log(".location.....${context.read<MyLocationViewModel>().locationController.text}");
                                log(".latitudew.....${await prefs.getDouble("current_lat")}");
                                log(".latitudew.....${await prefs.getDouble("current_long")}");
                                log("....skillLevels..$skillLevel");
                                log(".timeSlots.....$timeSlot");
                                log("....timeRadius..$timeRadius");
                                // Calculate the midpoint of the selected range
                                double midpoint =
                                    (timeRadius.start + timeRadius.end) / 2;

                                // Round the midpoint to the nearest whole number
                                int roundedTimeRadius = midpoint.round();

                                // Ensure the value is between 1 and 6
                                roundedTimeRadius =
                                    roundedTimeRadius.clamp(1, 6).toInt();

                                // Convert values to lists
                                // List<String> sportIds = [sportId];
                                // List<String> skillLevels = [skillLevel];
                                // List<String> timeSlots = [timeSlot];
                                //
                                // log(".sportIds.....$sportIds");
                                // log("....skillLevels..$skillLevels");
                                // log(".timeSlots.....$timeSlots");
                                // log("....timeRadius..$roundedTimeRadius");

                                // Submit to API
                                callPlayPreferencesApi(sportId,skillLevel,timeSlot);
                                // await value.setUserPreferences(
                                //   context: context,
                                //   sportIds: sportIds,
                                //   skillLevel: skillLevels,
                                //   timeSlot: timeSlots,
                                //   timeRadius: roundedTimeRadius
                                //       .toString(), // Send the number as string
                                // );
                                // setState(() {
                                //   shouldShow = false;
                                // });
                              }
                            },
                            child: Container(
                              height: 47,
                              width: double.infinity,
                              decoration: BoxDecoration(
                                  color: Color(0xFF8DC63F),
                                  borderRadius: BorderRadius.circular(10)),
                              child: Center(
                                child: value.isUserPreferencesLoading
                                    ? CircularProgressIndicator(
                                  color: Colors.white,
                                )
                                    : Text(l10n.of(context).apply,
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600)),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        });
      },
    );
  }



  Future<void> callPlayPreferencesApi(String sportid, String skilllevel, String timeslot) async {
    final url = Uri.parse('https://backend.krateasy.gr/api/app/preference/play-preferences');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? authToken = await GlobalAPIUtils.getAuthToken();




    final response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $authToken'

      },
      body: jsonEncode({
        "sport_id": sportid,
        "latitude":  await prefs.getDouble("current_lat"),
        "longitude":  await prefs.getDouble("current_long"),
        "skill_level": skilllevel,
        "preferred_duration_minutes": "",
        "timeSlot":timeslot,
      }),
    );

    if (response.statusCode == 200) {
      print('Success: ${response.body}');  Navigator.pop(context);
      Utils.flushbarSuccessMessage("You Will Notify if anyone creatted public challenge", NavigationService.navigatorKey.currentState!.context);

    } else {
      print('Failed with status: ${response.statusCode}');
      print('Response: ${response.body}');
    }
  }


  @override
  Widget build(BuildContext context) {
    // final viewModel = Provider.of<ChallengeViewModel>(context);

    double screenWidth = MediaQuery.of(context).size.width;
    // double screenHeight = MediaQuery.of(context).size.height;
    // final username = Provider.of<DashboardViewModel>(context).userName;

    return Consumer<AvailableChallengeGuestViewModel>(
        builder: (context, viewModel, _) {
      return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 1,
          leading: Builder(
            builder: (context) => IconButton(
              icon: Image.asset('assets/icons/drawer.png',
                  width: screenWidth * 0.08, height: screenWidth * 0.08),
              onPressed: () {
                Scaffold.of(context).openDrawer();
              },
            ),
          ),
          title: viewModel.isSearch
              ? TextFormField(
                  controller: viewModel.searchController,
            focusNode: viewModel.searchFocusNode,
                  onChanged: (value) {
                    viewModel.searchChallenges(value);
                  },
                  decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: l10n.of(context).searchChallenges),
                )
              : Text(
                  l10n.of(context).challenges,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: screenWidth * 0.05, // Responsive text size
                    fontWeight: FontWeight.bold,
                  ),
                ),
          actions: [
            InkWell(
              onTap: () {
                showWhatToPlayDialog(context);
              },
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image.asset(
                    'assets/icons/ring.png',
                    width: 20,
                    height: 20,
                  ),
                  Text(
                    l10n.of(context).getAlert,
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w400,
                      color: AppColors.black,
                    ),
                  ),
                ],
              ),
            ),
            IconButton(
                onPressed: () {
                  viewModel.statusUpdate();
                  viewModel.isSearch ? viewModel.clearChallengeList() : null;
                },
                icon: viewModel.isSearch
                    ? Icon(Icons.clear)
                    : Image.asset('assets/icons/search.png',
                        width: screenWidth * 0.08, height: screenWidth * 0.08)),
            IconButton(
              icon: Image.asset('assets/icons/filter.png',
                  width: screenWidth * 0.07, height: screenWidth * 0.07),
              onPressed: () {
                showDialog(
                  barrierDismissible: false,
                  context: context,
                  builder: (context) {
                    final viewModel = Provider.of<FacilitiesViewModel>(context,
                        listen: false);
                    final sortItems = viewModel.sortItems;
                    List<String> selectedSports = [];
                    bool amenitiesError = false;
                    bool allSelected=false;
                    bool isfill = false;

                    viewModel.clearSortValues();
                    timeController.clear();
                    viewModel.clearSelectedDate();
                    viewModel.clearSortValues();
                    viewModel.selectedFacilityList.clear();
                    viewModel.selectedAmenitie.clear();
                    selectedSports.clear();
                    viewModel.clearSelectedSports();

                    return Dialog(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      insetPadding: EdgeInsets.all(16),
                      child: DraggableScrollableSheet(
                        initialChildSize: 0.9,
                        maxChildSize: 0.95,
                        minChildSize: 0.5,
                        expand: false,
                        builder: (context, scrollController) {
                          return StatefulBuilder(
                            builder: (context, setStateModal) {
                              return LayoutBuilder(
                                builder: (context, constraints) {
                                  double paddingSize =
                                      constraints.maxWidth * 0.05;
                                  double fontSize = constraints.maxWidth * 0.05;
                                  return Container(
                                    padding: EdgeInsets.all(paddingSize),
                                    child: SingleChildScrollView(
                                      child: Consumer<
                                          AvailableChallengeGuestViewModel>(
                                        builder: (BuildContext context,
                                            facilityViewModel, Widget? child) {
                                          return Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Text(
                                                    "Filter",
                                                    style: TextStyle(
                                                      fontSize: fontSize,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                  GestureDetector(
                                                    onTap: () =>
                                                        Navigator.pop(context),
                                                    child: Container(
                                                      padding:
                                                          EdgeInsets.all(2),
                                                      decoration: BoxDecoration(
                                                        shape: BoxShape.circle,
                                                        border: Border.all(
                                                            width: 1.5,
                                                            color: AppColors
                                                                .black),
                                                      ),
                                                      child: Icon(Icons.close,
                                                          size: fontSize * 1.2),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              Divider(),
                                              // Sort Dropdown
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  DropdownButtonFormField<
                                                      String>(
                                                    decoration: InputDecoration(
                                                      filled: true,
                                                      fillColor:
                                                          Color(0xFFF4F9EC),
                                                      border:
                                                          OutlineInputBorder(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(8.0),
                                                        borderSide:
                                                            BorderSide.none,
                                                      ),
                                                      contentPadding:
                                                          EdgeInsets.symmetric(
                                                              horizontal:
                                                                  paddingSize),

                                                    ),
                                                    icon: SizedBox(
                                                      height: 24,
                                                      width: 24,
                                                      child: Image.asset(
                                                          'assets/icons/sort.png'),
                                                    ),
                                                    hint: Text(
                                                        l10n.of(context).sort),
                                                    value:
                                                        viewModel.selectedSort,
                                                    isExpanded: true,
                                                    onChanged: (value) {
                                                      if (value != null) {
                                                        final selected = sortItems
                                                            .firstWhere((item) =>
                                                                item['sort'] ==
                                                                value);
                                                        setStateModal(() {
                                                          viewModel
                                                                  .selectedSort =
                                                              value;
                                                          viewModel
                                                                  .selectedSortName =
                                                              selected['name'];
                                                          viewModel
                                                                  .selectedSortOrder =
                                                              selected[
                                                                  'sortOrder'];
                                                        });
                                                        print(viewModel.selectedSort);


                                                        setState(() {
                                                          isfill =true;
                                                        });

                                                      }
                                                    },
                                                    items:
                                                        sortItems.map((item) {
                                                      return DropdownMenuItem<
                                                          String>(
                                                        value: item['sort'],
                                                        child:
                                                            Text(item['name']),
                                                      );
                                                    }).toList(),
                                                  ),
                                                ],
                                              ),

                                              SizedBox(height: 10),
                                              // Sports Dropdown
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  GestureDetector(
                                                    onTap: () async {
                                                      final selected = await showModalBottomSheet<List<SportList>>(
                                                        context: context,
                                                        isScrollControlled: true,
                                                        builder: (_) => MultiSelectModal(
                                                          allItems: viewModel.facilityList,
                                                          selectedItems: viewModel.selectedFacilityList,
                                                        ),
                                                      );

                                                      if (selected != null) {
                                                        setStateModal(() {
                                                          viewModel.selectedFacilityList = selected;
                                                          viewModel.setSportsIdsList(selected.map((e) => e.id).toList());
                                                        });

                                                        setState(() {
                                                          isfill = true;
                                                        });
                                                      }
                                                    },
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        color: Color(0xFFF4F9EC),
                                                        borderRadius: BorderRadius.circular(8.0),
                                                      ),
                                                      padding: EdgeInsets.symmetric(horizontal: 12.0, vertical: 16),
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                        children: [
                                                          Expanded(
                                                            child: Text(
                                                              viewModel.selectedFacilityList.isNotEmpty
                                                                  ? viewModel.selectedFacilityList.map((e) => e.name).join(', ')
                                                                  : l10n.of(context).selectSports,
                                                              overflow: TextOverflow.ellipsis,
                                                            ),
                                                          ),
                                                          Image.asset('assets/icons/lowarrow.png', width: 16, height: 16),
                                                        ],
                                                      ),
                                                    ),
                                                  ),

                                                  // Container(
                                                  //   decoration: BoxDecoration(
                                                  //     color: Color(0xFFF4F9EC),
                                                  //     borderRadius:
                                                  //         BorderRadius.circular(
                                                  //             8.0),
                                                  //   ),
                                                  //   padding:
                                                  //       EdgeInsets.symmetric(
                                                  //           horizontal: 12.0),
                                                  //   child:
                                                  //       DropdownButtonHideUnderline(
                                                  //     child: DropdownButton<
                                                  //         SportList>(
                                                  //       icon: SizedBox(
                                                  //         height: 16,
                                                  //         width: 16,
                                                  //         child: Image.asset(
                                                  //             'assets/icons/lowarrow.png'),
                                                  //       ),
                                                  //       hint: Text(
                                                  //         selectedSports.isNotEmpty
                                                  //             ? selectedSports
                                                  //                 .last
                                                  //             : S
                                                  //                 .of(context)
                                                  //                 .selectSports,
                                                  //         overflow: TextOverflow
                                                  //             .ellipsis,
                                                  //       ),
                                                  //       isExpanded: true,
                                                  //       onChanged: (value) {
                                                  //         if (value != null) {
                                                  //           setStateModal(() {
                                                  //             viewModel.selectFaciliity(value, true);
                                                  //             List<String> facilityIdList = viewModel.selectedFacilityList
                                                  //                 .map((facility) => facility.id)
                                                  //                 .toList();
                                                  //             viewModel.setSportsIdsList(facilityIdList);
                                                  //           });
                                                  //           setState(() {
                                                  //             isfill =true;
                                                  //           });
                                                  //
                                                  //         }
                                                  //       },
                                                  //
                                                  //       items: viewModel
                                                  //           .facilityList
                                                  //           .map((sport) {
                                                  //         return DropdownMenuItem<
                                                  //             SportList>(
                                                  //           value: sport,
                                                  //           child: Text(
                                                  //               sport.name),
                                                  //         );
                                                  //       }).toList(),
                                                  //     ),
                                                  //   ),
                                                  // ),
                                                  Wrap(
                                                    spacing: 8.0,
                                                    children: viewModel
                                                        .selectedFacilityList
                                                        .map((filter) {
                                                      return GestureDetector(
                                                        onTap: () {
                                                          setStateModal(() {
                                                            viewModel
                                                                .selectFaciliity(
                                                                    filter,
                                                                    false);
                                                            // sportsError = viewModel
                                                            //     .selectedFacilityList
                                                            //     .isEmpty;
                                                          });
                                                        },
                                                        child: Chip(
                                                          label: Row(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .min,
                                                            children: [
                                                              Text(
                                                                filter.name,
                                                                style:
                                                                    TextStyle(
                                                                  color: Colors
                                                                      .white,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400,
                                                                  fontSize: 14,
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                  width: 4),
                                                              // Image.asset(
                                                              //   'assets/icons/crosscircle.png',
                                                              //   width: 19,
                                                              //   height: 19,
                                                              // ),
                                                            ],
                                                          ),
                                                          backgroundColor:
                                                              Color(0xFF3B747D),
                                                        ),
                                                      );
                                                    }).toList(),
                                                  ),
                                                ],
                                              ),
                                              SizedBox(height: 10),


                                              TextFormField(
                                                onTap: () async {
                                                  DateTime? picked =
                                                      await myshowDatePicker(
                                                    context: context,
                                                    initialDate: DateTime.now(),
                                                    firstDate: DateTime.now(),
                                                    lastDate: DateTime(2100),
                                                        fieldHintText: 'dd/mm/yyyy',
                                                    builder: (context, child) {
                                                      return Theme(
                                                        data: Theme.of(context)
                                                            .copyWith(
                                                          colorScheme:
                                                              ColorScheme.light(
                                                            primary: AppColors
                                                                .primaryColor,
                                                            onPrimary:
                                                                Colors.white,
                                                            onSurface:
                                                                Colors.black,
                                                          ),
                                                          textButtonTheme:
                                                              TextButtonThemeData(
                                                            style: TextButton
                                                                .styleFrom(
                                                              foregroundColor:
                                                                  AppColors
                                                                      .primaryColor,
                                                            ),
                                                          ),
                                                        ),
                                                        child: child!,
                                                      );
                                                    },
                                                  );
                                                  if (picked != null) {
                                                    setStateModal(() {
                                                      // viewModel.selectedDate =
                                                      //     "${picked.year}-${picked.month.toString().padLeft(2, '0')}-${picked.day.toString().padLeft(2, '0')}";
                                                      var pickedDate =  DateFormat("dd/MM/yyyy").format(picked);
                                                      viewModel.selectedDate= pickedDate;
                                                      // dateError =
                                                      //     false; // Reset error on selection
                                                    });
                                                    setState(() {
                                                      isfill =true;
                                                    });

                                                  }
                                                  log(
                                                      "viewModel.selectedDate is ${picked}");
                                                  log(
                                                      "viewModel.selectedDate is ${viewModel.selectedDate}");
                                                },
                                                controller:
                                                    TextEditingController(
                                                        text: viewModel
                                                            .selectedDate),
                                                readOnly: true,
                                                style: TextStyle(
                                                    fontSize: 16,
                                                    color: AppColors.black555),
                                                decoration: inputDecoration(
                                                  hintText: l10n.of(context).date,
                                                ).copyWith(
                                                  filled: true,
                                                  fillColor: Color(0xFFF4F9EC),
                                                  suffixIcon: Padding(
                                                    padding: EdgeInsets.all(14),
                                                    child: Icon(
                                                        Icons
                                                            .calendar_month_outlined,
                                                        size: 22),
                                                  ),
                                                ),
                                                validator: (val) =>
                                                    val == null || val.isEmpty
                                                        ? "Select a date"
                                                        : null,
                                              ),
                                              SizedBox(height: 10),
                                              // Time Dropdown
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  TextFormField(
                                                    readOnly: true,
                                                    controller: timeController,
                                                    decoration: InputDecoration(
                                                      hintText:
                                                          l10n.of(context).time,
                                                      hintStyle: TextStyle(
                                                          fontSize: 12),
                                                      filled: true,
                                                      fillColor:
                                                          Color(0xFFF4F9EC),
                                                      suffixIcon: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .symmetric(
                                                                horizontal: 18),
                                                        child: Image.asset(
                                                            "assets/icons/lowarrow.png",
                                                            height: 16,
                                                            width: 14),
                                                      ),
                                                      border:
                                                          OutlineInputBorder(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(8),
                                                        borderSide:
                                                            BorderSide.none,
                                                      ),
                                                    ),
                                                    style: TextStyle(
                                                        fontSize: 14,
                                                        color: Colors.black),
                                                    onTap: () => showDialog(
                                                      context: context,
                                                      builder: (_) =>
                                                          HourPickerDialog(
                                                        onTimeSelected:
                                                            (value) {
                                                          timeController.text =
                                                              value;
                                                          viewModel.changeTimeSlot(
                                                              value); // use your ViewModel
                                                              print(timeController.text);
                                                          setState(() {
                                                            isfill =true;
                                                          });

                                                            },
                                                      ),
                                                    ),
                                                  ),


                                                ],
                                              ),
                                              SizedBox(height: 10),
                                              // Amenities Dropdown
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  DropdownButtonFormField<
                                                      String>(
                                                    value: viewModel
                                                            .selectedAmenitie
                                                            .isEmpty
                                                        ? null
                                                        : viewModel
                                                            .selectedAmenitie
                                                            .last,
                                                    hint: Text(l10n
                                                        .of(context)
                                                        .amenities),
                                                    icon: Image.asset(
                                                        "assets/icons/lowarrow.png",
                                                        height: 16,
                                                        width: 14),
                                                    items: viewModel
                                                        .amenititesList
                                                        .map((sport) {
                                                      return DropdownMenuItem<
                                                          String>(
                                                        value: sport.id,
                                                        child: Text(sport.name),
                                                      );
                                                    }).toList(),
                                                    onChanged: (value) {
                                                      if (value != null &&
                                                          !viewModel
                                                              .selectedAmenitie
                                                              .contains(
                                                                  value)) {
                                                        setStateModal(() {
                                                          viewModel
                                                              .selectedAmenitie
                                                              .add(value);

                                                        });
                                                      }
                                                      print(viewModel
                                                          .selectedAmenitie);
                                                      setState(() {
                                                        isfill =true;
                                                      });

                                                    },
                                                    decoration: InputDecoration(
                                                      filled: true,
                                                      fillColor:
                                                          Color(0xFFF4F9EC),
                                                      enabledBorder:
                                                          OutlineInputBorder(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(10),
                                                        borderSide: BorderSide(
                                                            color: Colors
                                                                .transparent),
                                                      ),
                                                      focusedBorder:
                                                          OutlineInputBorder(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(10),
                                                        borderSide: BorderSide(
                                                            color: Colors
                                                                .transparent),
                                                      ),
                                                      contentPadding:
                                                          EdgeInsets.symmetric(
                                                              horizontal: 12,
                                                              vertical: 10),
                                                    ),
                                                  ),

                                                  SizedBox(height: 16),
                                                  Wrap(
                                                    spacing: 8.0,
                                                    children: viewModel
                                                        .selectedAmenitie
                                                        .map((id) {
                                                      final amenity = viewModel
                                                          .amenititesList
                                                          .firstWhere((a) =>
                                                              a.id == id);
                                                      return Chip(
                                                        label: Text(
                                                          amenity.name,
                                                          style: TextStyle(
                                                            color: Colors.white,
                                                            fontSize: 14,
                                                            fontWeight:
                                                                FontWeight.w400,
                                                          ),
                                                        ),
                                                        backgroundColor:
                                                            Color(0xFF3B747D),
                                                        deleteIcon: Image.asset(
                                                            'assets/icons/crosscircle.png'),
                                                        onDeleted: () {
                                                          setStateModal(() {
                                                            viewModel
                                                                .selectedAmenitie
                                                                .remove(id);
                                                            amenitiesError =
                                                                viewModel
                                                                    .selectedAmenitie
                                                                    .isEmpty;
                                                          });
                                                        },
                                                      );
                                                    }).toList(),
                                                  ),
                                                ],
                                              ),
                                              SizedBox(height: 15),

                                              SizedBox(height: 15),
                                              Row(
                                                children: [
                                                  SizedBox(
                                                      height: 26,
                                                      width: 26,
                                                      child: Image.asset(
                                                          "assets/icons/coins.png",
                                                          fit: BoxFit.fill)),
                                                  SizedBox(width: 5),
                                                  Text(
                                                      l10n.of(context).priceMinMax,
                                                      style: TextStyle(
                                                          fontWeight:
                                                              FontWeight.w700,
                                                          fontSize: 15,
                                                          color: AppColors
                                                              .black555)),
                                                ],
                                              ),
                                              SizedBox(height: 15),
                                              Text(
                                                  "${AppConstants.appCurrency}${viewModel.rangeValues.start.toStringAsFixed(0)} - £${viewModel.rangeValues.end.toStringAsFixed(0)}",
                                                  style: TextStyle(
                                                      fontSize: 14,
                                                      color:
                                                          AppColors.black555)),
                                              Consumer<FacilitiesViewModel>(
                                                builder: (context, provider, child) {
                                                  return GestureDetector(
                                                    onTapDown: (TapDownDetails details) {
                                                      RenderBox box = context.findRenderObject() as RenderBox;
                                                      double dx = details.localPosition.dx;
                                                      double width = box.size.width;

                                                      double tappedValue = (dx / width) * 1000; // Updated
                                                      RangeValues current = provider.rangeValues;

                                                      if ((tappedValue - current.start).abs() < (tappedValue - current.end).abs()) {
                                                        provider.changeRangeValues(
                                                          tappedValue.clamp(0, current.end),
                                                          current.end,
                                                        );
                                                      } else {
                                                        provider.changeRangeValues(
                                                          current.start,
                                                          tappedValue.clamp(current.start, 1000),
                                                        );
                                                      }
                                                    },
                                                    child: RangeSlider(
                                                      min: 0,
                                                      max: 1000,
                                                      divisions: 1000,
                                                      labels: RangeLabels(
                                                        "${AppConstants.appCurrency}${provider.rangeValues.start.toStringAsFixed(0)}",
                                                        "${AppConstants.appCurrency}${provider.rangeValues.end.toStringAsFixed(0)}",
                                                      ),
                                                      activeColor: AppColors.primaryColor,
                                                      inactiveColor: AppColors.dark747D,
                                                      values: provider.rangeValues,
                                                      onChanged: (RangeValues value) {
                                                        provider.changeRangeValues(value.start, value.end);
                                                      },
                                                    ),
                                                  );
                                                },
                                              ),

                                              SizedBox(height: 20),
                                              // Filter Apply Button with Validation
                                              Row(
                                                children: [
                                                  Expanded(
                                                    child: InkWell(
                                                      onTap: isfill? ()async {
                                                        String? selectedDate;
                                                        final selectedDateRaw = viewModel.selectedDate;

                                                        if (selectedDateRaw != null && selectedDateRaw
                                                            .trim()
                                                            .isNotEmpty) {
                                                          final parsedDate = DateFormat('dd/MM/yyyy').parse(
                                                              selectedDateRaw);
                                                          selectedDate = DateFormat('yyyy-MM-dd').format(parsedDate);
                                                        }

                                                        Provider.of<AvailableChallengeGuestViewModel>(
                                                          NavigationService.context,
                                                          listen: false,
                                                        ).fetchChallenges(
                                                          minPrice: double.parse(
                                                              viewModel.rangeValues.start.toStringAsFixed(0)),
                                                          maxPrice: double.parse(
                                                              viewModel.rangeValues.end.toStringAsFixed(0)),
                                                          sort: viewModel.selectedSort,
                                                          date: selectedDate,
                                                          // ✅ will be null if not selected
                                                          startTime: timeController.text,
                                                          amenities: viewModel.selectedAmenitie,
                                                          sportId: viewModel.selectedSportsList,
                                                        );

                                                        Navigator.of(context).pop();
                                                      }
                                          // {
                                                      //
                                                      //
                                                      //
                                                      //
                                                      //   final parsedDate = DateFormat('dd/MM/yyyy').parse(viewModel.selectedDate??"");
                                                      //
                                                      //   final selectedDate =  DateFormat('yyyy-MM-dd').format(parsedDate);
                                                      //
                                                      //   Provider.of<AvailableChallengeGuestViewModel>(
                                                      //       NavigationService.context,
                                                      //       listen: false)
                                                      //       .fetchChallenges(
                                                      //     minPrice:double.parse(viewModel.rangeValues.start.toStringAsFixed(0)),
                                                      //     maxPrice:double.parse(viewModel.rangeValues.end.toStringAsFixed(0)),
                                                      //     sort: viewModel.selectedSort,
                                                      //     date: selectedDate,
                                                      //     startTime: timeController.text,
                                                      //     amenities: viewModel.selectedAmenitie,
                                                      //     sportId: viewModel.selectedSportsList
                                                      //
                                                      //   );
                                                      //   Navigator.of(context)
                                                      //         .pop();
                                                      // }
                                                      :(){},
                                                      child: Stack(
                                                        children: [
                                                          Container(
                                                            height: 52,
                                                            width:
                                                            double.infinity,
                                                            decoration:
                                                            BoxDecoration(
                                                              color: isfill? AppColors
                                                                  .green033:Colors.grey,
                                                              borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                  10),
                                                            ),
                                                          ),
                                                          Container(
                                                            height: 47,
                                                            width:
                                                            double.infinity,
                                                            decoration:
                                                            BoxDecoration(
                                                              color: isfill? AppColors
                                                                  .primaryColor : Colors.grey,
                                                              borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                  10),
                                                            ),
                                                            child: Center(
                                                              child: Text(
                                                               l10n.of(context).filterApply,
                                                                style:
                                                                TextStyle(
                                                                  fontSize: 16,
                                                                  fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                                  color:
                                                                  AppColors
                                                                      .black,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),

                                                    ),
                                                  ),
                                                  SizedBox(width: 10,),
                                                  Expanded(
                                                    child: InkWell(
                                                      onTap: isfill? ()async {


                                                        Provider.of<AvailableChallengeGuestViewModel>(
                                                            NavigationService.context,
                                                            listen: false)
                                                            .fetchChallenges(
                                                            minPrice:double.parse(viewModel.rangeValues.start.toStringAsFixed(0)),
                                                            maxPrice:double.parse(viewModel.rangeValues.end.toStringAsFixed(0)),
                                                            sort: viewModel.selectedSort,
                                                            date: viewModel.selectedDate,
                                                            startTime: timeController.text,
                                                            amenities: viewModel.selectedAmenitie,
                                                            sportId: viewModel.selectedSportsList

                                                        );
                                                        Navigator.of(context)
                                                            .pop();
                                                      }:(){},
                                                      child: Stack(
                                                        children: [
                                                          Container(
                                                            height: 52,
                                                            width:
                                                            double.infinity,
                                                            decoration:
                                                            BoxDecoration(
                                                              color:isfill? AppColors
                                                                  .green033:Colors.grey,
                                                              borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                  10),
                                                            ),
                                                          ),
                                                          Container(
                                                            height: 47,
                                                            width:
                                                            double.infinity,
                                                            decoration:
                                                            BoxDecoration(
                                                              color:isfill? AppColors
                                                                  .primaryColor:Colors.grey,
                                                              borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                  10),
                                                            ),
                                                            child: Center(
                                                              child: Text(
                                                                "Reset Filter",
                                                                style:
                                                                TextStyle(
                                                                  fontSize: 16,
                                                                  fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                                  color:
                                                                  AppColors
                                                                      .black,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),

                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          );
                                        },
                                      ),
                                    ),
                                  );
                                },
                              );
                            },
                          );
                        },
                      ),
                    );
                  },
                ); // showDialog(
              },
            ),
          ],
        ),
        drawer: SideDrawerScreen(),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
        floatingActionButton: Padding(
          padding: const EdgeInsets.only(bottom: 20),
          child: Stack(
            children: [
              Container(
                  height: 50,
                  width: 250,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: AppColors.green033)),
              GestureDetector(
                onTap: () {
                  viewModel.addChallenge(context);
                },
                child: Container(
                  height: 46,
                  width: 250,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    gradient: LinearGradient(
                        colors: AppColors.dark348Green62ELg,
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight),
                  ),
                  child: Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image.asset("assets/icons/add.png",
                            width: 20, height: 20),
                        SizedBox(width: 5),
                        Text(l10n.of(context).createChallengeBt,
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        body: viewModel.isLoadingData
            ? loaderWidget()
            : SafeArea(
                child: Stack(
                  children: [
                    Column(
                      children: [
                        const Divider(
                            height: 1, thickness: 1, color: Color(0xFF8DC63F)),
                        const SizedBox(height: 20),
                        Expanded(child: ActiveChallengesTab()),
                      ],
                    ),
                  ],
                ),
              ),
      );
    });
  }

  void showFilterBottomSheet(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          insetPadding: EdgeInsets.all(16),
          child: Padding(
            padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: SingleChildScrollView(
                child: Consumer<ChallengeViewModel>(
                  builder: (context, viewModel, child) {
                    return Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(l10n.of(context).filter,
                                style: TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.black555)),
                            SizedBox(
                                width: 40,
                                height: 40,
                                child: IconButton(
                                    icon: Image.asset("assets/icons/cross.png",
                                        fit: BoxFit.fill),
                                    onPressed: () => Navigator.pop(context))),
                          ],
                        ),
                        Divider(),
                        SizedBox(height: 15),
                        Container(
                          padding: EdgeInsets.only(right: 16),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: AppColors.lightPrimaryColorFFE5),
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton2<String>(
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.normal,
                                  color: AppColors.grey769),
                              value: viewModel.challenge,
                              iconStyleData: IconStyleData(
                                  icon: SizedBox(
                                      height: 24,
                                      width: 24,
                                      child: Image.asset(
                                          "assets/icons/sort.png",
                                          fit: BoxFit.fill))),
                              hint: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Text(l10n.of(context).sort,
                                      style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.normal,
                                          color: AppColors.grey8A8))),
                              isExpanded: true,
                              items: viewModel.sort.map((String item) {
                                return DropdownMenuItem<String>(
                                    value: item, child: Text(item));
                              }).toList(),
                              onChanged: (val) {
                                viewModel.changeChallenge(val!);
                              },
                              dropdownStyleData: DropdownStyleData(
                                  maxHeight: 300,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: Colors.white)),
                              menuItemStyleData: MenuItemStyleData(
                                  padding:
                                      EdgeInsets.symmetric(horizontal: 16)),
                              alignment: Alignment.center,
                            ),
                          ),
                        ),
                        viewModel.storeChallenges.isEmpty
                            ? SizedBox()
                            : SizedBox(height: 15),

                        Container(
                          padding: EdgeInsets.only(right: 16),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: AppColors.lightPrimaryColorFFE5),
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton2<String>(
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.normal,
                                  color: AppColors.grey769),
                              value: viewModel.courtSize,
                              iconStyleData: IconStyleData(
                                  icon:
                                      Icon(Icons.keyboard_arrow_down_outlined)),
                              hint: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Text(l10n.of(context).courtSize,
                                      style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.normal,
                                          color: AppColors.grey8A8))),
                              isExpanded: true,
                              items: viewModel.courtList.map((String item) {
                                return DropdownMenuItem<String>(
                                    value: item, child: Text(item));
                              }).toList(),
                              onChanged: (val) {
                                viewModel.changeCourtSize(val!);
                              },
                              dropdownStyleData: DropdownStyleData(
                                  maxHeight: 300,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: Colors.white)),
                              menuItemStyleData: MenuItemStyleData(
                                  padding:
                                      EdgeInsets.symmetric(horizontal: 16)),
                              alignment: Alignment.center,
                            ),
                          ),
                        ),
                        SizedBox(height: 15),

                        viewModel.storeChallenges.isEmpty
                            ? SizedBox()
                            : Wrap(
                                children: List.generate(
                                    viewModel.storeChallenges.length, (index) {
                                  return Container(
                                    height: 30,
                                    margin:
                                        EdgeInsets.only(bottom: 10, right: 10),
                                    padding:
                                        EdgeInsets.only(left: 5, right: 10),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(5),
                                        color: AppColors.dark747D),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(viewModel.storeChallenges[index],
                                            style: TextStyle(
                                                fontWeight: FontWeight.normal,
                                                fontSize: 14,
                                                color: AppColors.white)),
                                        SizedBox(width: 15),
                                        InkWell(
                                          onTap: () {
                                            viewModel.deleteChallenges(index);
                                          },
                                          child: SizedBox(
                                              width: 19,
                                              height: 19,
                                              child: Image.asset(
                                                  "assets/icons/crossgreen.png",
                                                  fit: BoxFit.fill)),
                                        ),
                                      ],
                                    ),
                                  );
                                }),
                              ),
                        SizedBox(height: 15),
                        // Container(
                        //   padding: EdgeInsets.only(right: 16),
                        //   decoration: BoxDecoration(
                        //       borderRadius: BorderRadius.circular(10),
                        //       color: AppColors.lightPrimaryColorFFE5),
                        //   child: DropdownButtonHideUnderline(
                        //     child: DropdownButton2<String>(
                        //       style: TextStyle(
                        //           fontSize: 16,
                        //           fontWeight: FontWeight.normal,
                        //           color: AppColors.grey769),
                        //       value: viewModel.courtSize,
                        //       iconStyleData: IconStyleData(
                        //           icon:
                        //               Icon(Icons.keyboard_arrow_down_outlined)),
                        //       hint: Align(
                        //           alignment: Alignment.centerLeft,
                        //           child: Text("Court Size",
                        //               style: TextStyle(
                        //                   fontSize: 15,
                        //                   fontWeight: FontWeight.normal,
                        //                   color: AppColors.grey8A8))),
                        //       isExpanded: true,
                        //       items: viewModel.courtList.map((String item) {
                        //         return DropdownMenuItem<String>(
                        //             value: item, child: Text(item));
                        //       }).toList(),
                        //       onChanged: (val) {
                        //         viewModel.changeCourtSize(val!);
                        //       },
                        //       dropdownStyleData: DropdownStyleData(
                        //           maxHeight: 300,
                        //           decoration: BoxDecoration(
                        //               borderRadius: BorderRadius.circular(10),
                        //               color: Colors.white)),
                        //       menuItemStyleData: MenuItemStyleData(
                        //           padding:
                        //               EdgeInsets.symmetric(horizontal: 16)),
                        //       alignment: Alignment.center,
                        //     ),
                        //   ),
                        // ),
                        // SizedBox(height: 15),
                        Container(
                          padding: EdgeInsets.only(right: 16),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: AppColors.lightPrimaryColorFFE5),
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton2<String>(
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.normal,
                                  color: AppColors.grey769),
                              value: viewModel.sportsName,
                              iconStyleData: IconStyleData(
                                  icon:
                                      Icon(Icons.keyboard_arrow_down_outlined)),
                              hint: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Text(l10n.of(context).selectSports,
                                      style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.normal,
                                          color: AppColors.grey8A8))),
                              isExpanded: true,
                              items: viewModel.sportsList.map((String item) {
                                return DropdownMenuItem<String>(
                                    value: item, child: Text(item));
                              }).toList(),
                              onChanged: (val) {
                                viewModel.changeSports(val!);
                              },
                              dropdownStyleData: DropdownStyleData(
                                  maxHeight: 300,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: Colors.white)),
                              menuItemStyleData: MenuItemStyleData(
                                  padding:
                                      EdgeInsets.symmetric(horizontal: 16)),
                              alignment: Alignment.center,
                            ),
                          ),
                        ),
                        SizedBox(height: 15),
                        AppTextField(
                          borderColor: AppColors.lightPrimaryColorFFE5,
                          hintText:
                              l10n.of(context).searchByFacilityNameOrCourtName,
                          fillColor: AppColors.lightPrimaryColorFFE5,
                          suffix: Icon(CupertinoIcons.search),
                        ),
                        SizedBox(height: 15),
                        Container(
                          padding: EdgeInsets.only(right: 16),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: AppColors.lightPrimaryColorFFE5),
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton2<String>(
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.normal,
                                  color: AppColors.grey769),
                              value: viewModel.player,
                              iconStyleData: IconStyleData(
                                  icon:
                                      Icon(Icons.keyboard_arrow_down_outlined)),
                              hint: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Text(l10n.of(context).numberOfPlayer,
                                      style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.normal,
                                          color: AppColors.grey8A8))),
                              isExpanded: true,
                              items: viewModel.playerList.map((String item) {
                                return DropdownMenuItem<String>(
                                    value: item, child: Text(item));
                              }).toList(),
                              onChanged: (val) {
                                viewModel.changePlayer(val!);
                              },
                              dropdownStyleData: DropdownStyleData(
                                  maxHeight: 300,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: Colors.white)),
                              menuItemStyleData: MenuItemStyleData(
                                  padding:
                                      EdgeInsets.symmetric(horizontal: 16)),
                              alignment: Alignment.center,
                            ),
                          ),
                        ),

                        SizedBox(height: 15),
                        InkWell(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: Stack(
                            children: [
                              Container(
                                  height: 52,
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                      color: AppColors.green033,
                                      borderRadius: BorderRadius.circular(10))),
                              Container(
                                height: 47,
                                width: double.infinity,
                                decoration: BoxDecoration(
                                    color: AppColors.primaryColor,
                                    borderRadius: BorderRadius.circular(10)),
                                child: Center(
                                    child: Text(l10n.of(context).filterApply,
                                        style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                            color: AppColors.black))),
                              ),
                            ],
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  final timeController = TextEditingController();
}

class HourPickerDialog extends StatefulWidget {
  final Function(String) onTimeSelected;

  const HourPickerDialog({required this.onTimeSelected});

  @override
  State<HourPickerDialog> createState() => _HourPickerDialogState();
}

class _HourPickerDialogState extends State<HourPickerDialog> {
  final List<String> hours = List.generate(
    24,
    (index) => DateFormat.jm().format(DateTime(0, 0, 0, index)),
  );

  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      backgroundColor: Colors.white,
      contentPadding: EdgeInsets.all(16),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            "Select Time",
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
          ),
          SizedBox(height: 8),
          SizedBox(
            height: 100,
            child: ListWheelScrollView.useDelegate(
              itemExtent: 39,
              perspective: 0.004,
              diameterRatio: 1.5,
              physics: FixedExtentScrollPhysics(),
              onSelectedItemChanged: (index) {
                setState(() {
                  selectedIndex = index;
                });
              },
              childDelegate: ListWheelChildBuilderDelegate(
                builder: (context, index) {
                  if (index < 0 || index >= hours.length) return null;
                  return Center(
                    child: Text(
                      hours[index],
                      style: TextStyle(
                        fontSize: 16,
                        color:
                            index == selectedIndex ? Colors.black : Colors.grey,
                        fontWeight: index == selectedIndex
                            ? FontWeight.w500
                            : FontWeight.normal,
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          SizedBox(height: 25),
          ElevatedButton(
            onPressed: () {
              widget.onTimeSelected(hours[selectedIndex]);
              Navigator.of(context).pop();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryColor,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              padding: EdgeInsets.symmetric(horizontal: 30, vertical: 2),
            ),
            child: Text("Select", style: TextStyle(color: Colors.white)),
          )
        ],
      ),
    );
  }
}

class MultiSelectModal extends StatefulWidget {
  final List<SportList> allItems;
  final List<SportList> selectedItems;

  const MultiSelectModal({
    required this.allItems,
    required this.selectedItems,
  });

  @override
  _MultiSelectModalState createState() => _MultiSelectModalState();
}

class _MultiSelectModalState extends State<MultiSelectModal> {
  late List<SportList> _tempSelected;

  @override
  void initState() {
    super.initState();
    _tempSelected = List.from(widget.selectedItems);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: MediaQuery.of(context).viewInsets,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ...widget.allItems.map((item) {
              final isSelected = _tempSelected.contains(item);
              return CheckboxListTile(
                value: isSelected,
                title: Text(item.name),
                onChanged: (bool? selected) {
                  setState(() {
                    if (selected == true) {
                      _tempSelected.add(item);
                    } else {
                      _tempSelected.remove(item);
                    }
                  });
                },
              );
            }),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, _tempSelected),
              child: Text('Done'),
            ),
          ],
        ),
      ),
    );
  }
}
