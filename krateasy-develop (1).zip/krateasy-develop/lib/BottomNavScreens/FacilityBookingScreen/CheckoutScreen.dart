// import 'package:flutter/material.dart';
// import 'package:kratEasyApp/GlobalUtils/app_button.dart';
// import 'package:kratEasyApp/GlobalUtils/app_colors.dart';
// import 'package:kratEasyApp/generated/l10n.dart';
// import 'package:provider/provider.dart';
// import '../../GlobalUtils/common_app_bar.dart';
// import '../../ViewModel/FacilityBookViewModel/CheckoutViewModel.dart';
// import 'PaymentOption.dart';

// class CheckoutScreen extends StatelessWidget {
//   const CheckoutScreen({super.key});

//   @override
//   Widget build(BuildContext context) {
//     double screenWidth = MediaQuery.of(context).size.width;
//     double screenHeight = MediaQuery.of(context).size.height;
//     final ValueNotifier<String?> selectedOption = ValueNotifier<String?>(null);

//     return Scaffold(
//       backgroundColor: Colors.white,
//       appBar: CommonAppBar(title: S.of(context).choosePaymentMethod, backIconColor: Colors.white, backgroundColor: Colors.white),
//       body: Padding(
//         padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05, vertical: screenHeight * 0.02),
//         child: Consumer<CheckoutViewModel>(
//           builder: (context, viewModel, child) {
//             return Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Padding(padding: EdgeInsets.only(bottom: screenHeight * 0.015), child: Text( S.of(context).wallet, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: AppColors.black))),
//                 Container(
//                   padding: EdgeInsets.symmetric(horizontal: 13, vertical: 10),
//                   decoration: BoxDecoration(borderRadius: BorderRadius.circular(5), color: AppColors.greyE9EA.withOpacity(.6)),
//                   child: Row(
//                     children: [
//                       Image.asset('assets/icons/wallet.png', width: screenWidth * 0.08, height: screenHeight * 0.04,color: AppColors.black),
//                       SizedBox(width: screenWidth * 0.03),
//                       Text("£ 2,200", style: TextStyle(fontSize: screenWidth * 0.045, fontWeight: FontWeight.bold, color: Colors.black)),
//                       Spacer(),
//                       SizedBox(
//                         width: screenWidth * 0.07,
//                         height: screenHeight * 0.04,
//                         child: Radio(
//                           value: true,
//                           groupValue: viewModel.isWalletSelected,
//                           onChanged: (value) {
//                             viewModel.setWalletSelected(value as bool);
//                           },
//                           activeColor: Colors.black,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//                 SizedBox(height: 10),
//                 Padding(
//                   padding: EdgeInsets.only(bottom: screenHeight * 0.015),
//                   child: Text(S.of(context).creditDebitCard, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: AppColors.black)),
//                 ),

//                 Container(
//                   padding: EdgeInsets.symmetric(horizontal: 13,vertical: 10),
//                   decoration: BoxDecoration(
//                     borderRadius: BorderRadius.circular(5),
//                     color: AppColors.greyE9EA.withOpacity(.6)
//                   ),
//                   child: Row(
//                     children: [
//                       Image.asset('assets/icons/card.png', width: screenWidth * 0.08, height: screenHeight * 0.04),
//                       SizedBox(width: screenWidth * 0.03),
//                       Text(S.of(context).addCard, style: TextStyle(fontSize: screenWidth * 0.045, fontWeight: FontWeight.normal, color: Colors.black)),
//                       Spacer(),
//                       Image.asset(
//                         'assets/icons/sidearrow.png', // Replace with your actual asset path
//                         width: 16,
//                         height: 16,
//                       ),
//                     ],
//                   ),
//                 ),
//                 SizedBox(height: 10),
//                 Padding(
//                   padding: EdgeInsets.only(bottom: screenHeight * 0.015),
//                   child: Text(S.of(context).morePaymentsOptions, style: TextStyle(fontSize:18, fontWeight: FontWeight.w600, color: AppColors.black)),
//                 ),
//                 Container(
//                   padding: EdgeInsets.symmetric(vertical: 10),
//                   decoration: BoxDecoration(
//                     borderRadius: BorderRadius.circular(5),
//                     color: AppColors.greyE9EA.withOpacity(.6)
//                   ),
//                   child: Column(
//                     children: [
//                       PaymentOption(selectedOption: selectedOption, paymentMethod: S.of(context).applePay, imagePath: "assets/icons/apple.png"),
//                       Container(width: double.infinity, height: 1, color: AppColors.greyE6E6),
//                       PaymentOption(selectedOption: selectedOption, paymentMethod: "Google Pay", imagePath: "assets/icons/google.png"),
//                     ],
//                   ),
//                 ),
//                 Spacer(),
//                 AppButtonCommon(
//                   onPressed: (){
//                     viewModel.confirmPayment(context);
//                   },
//                   label: "Confirm Payment",
//                 ),
//                 SizedBox(height: 30)
//               ],
//             );
//           },
//         ),
//       ),
//     );
//   }
// } //now after the row add the
