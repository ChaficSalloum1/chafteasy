// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';

// import '../../ViewModel/FacilityBookViewModel/BookingDetailsViewModel.dart';

// class BookingDetailsScreen extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     double commonWidth = MediaQuery.of(context).size.width * 0.9; // Increased width
//     double commonHeight = 55; // Standardized height
//     return ChangeNotifierProvider(
//       create: (_) => BookingDetailsViewModel(),
//       child: Consumer<BookingDetailsViewModel>(
//         builder: (context, model, child) {
//           return Scaffold(
//             body: SingleChildScrollView(
//               child: Padding(
//                 padding: const EdgeInsets.all(16.0),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   children: [
//                     SizedBox(height: 50),

//                     /// Share Payment Link
//                     Container(
//                       padding: EdgeInsets.all(12),
//                       decoration: BoxDecoration(
//                         color: Color(0xFF8DC63F),
//                         borderRadius: BorderRadius.circular(20),
//                       ),
//                       child: Column(
//                         children: [
//                           Text(
//                             "Share payment link",
//                             style: TextStyle(
//                               fontSize: 20,
//                               fontWeight: FontWeight.w700,
//                             ),
//                           ),
//                           SizedBox(height: 8),
//                           Text(
//                             "All players will use this link to make their split payment",
//                             style: TextStyle(
//                               fontSize: 15,
//                               fontWeight: FontWeight.w400,
//                             ),
//                           ),
//                           SizedBox(height: 8),
//                           Container(
//                             padding: EdgeInsets.symmetric(
//                               horizontal: 12,
//                               vertical: 8,
//                             ),
//                             decoration: BoxDecoration(
//                               color: Colors.white,
//                               borderRadius: BorderRadius.circular(20),
//                             ),
//                             child: Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Expanded(
//                                   child: Text(
//                                     model.paymentLink,
//                                     overflow: TextOverflow.ellipsis,
//                                     style: TextStyle(color: Colors.black),
//                                   ),
//                                 ),
//                                 IconButton(
//                                   onPressed: () => model.shareFacility(
//                                     context,
//                                     "Facility Details",
//                                     "Demo Data will be shown for now..!",
//                                   ),
//                                   icon: SizedBox(
//                                     width: 20, // Adjust the width to make the icon smaller
//                                     height: 20, // Adjust the height to make the icon smaller
//                                     child: Image.asset(
//                                       'assets/icons/bookshare.png',
//                                     ),
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),

//                     SizedBox(height: 20),

//                     /// Players Count & Time Left
//                     Text(
//                       "${model.totalPlayers} Players",
//                       style: TextStyle(
//                         fontSize: 16,
//                         fontWeight: FontWeight.w600,
//                         color: Color(0xFF555555),
//                       ),
//                     ),
//                     SizedBox(height: 4),
//                     Text(
//                       model.timeLeft,
//                       style: TextStyle(
//                         fontSize: 20,
//                         fontWeight: FontWeight.w600,
//                         color: Colors.black,
//                       ),
//                     ),

//                     SizedBox(height: 20),

//                     /// Circular Payment Status
//                     Stack(
//                       alignment: Alignment.center,
//                       children: [
//                         SizedBox(
//                           height: 220,
//                           width: 220,
//                           child: Image.asset("assets/icons/eclipse.png"),
//                         ),
//                         Column(
//                           mainAxisSize: MainAxisSize.min,
//                           children: [
//                             Text(
//                               "Paid",
//                               style: TextStyle(
//                                 color: Color(0xFF555555),
//                                 fontSize: 16,
//                                 fontWeight: FontWeight.w500,
//                               ),
//                             ),
//                             SizedBox(height: 8),
//                             Text(
//                               "£${model.totalPaid}",
//                               style: TextStyle(
//                                 color: Color(0xFF3D767B),
//                                 fontSize: 25,
//                                 fontWeight: FontWeight.w700,
//                               ),
//                             ),
//                             SizedBox(height: 15),
//                             Text(
//                               "£${model.totalLeft}",
//                               style: TextStyle(
//                                 fontSize: 25,
//                                 fontWeight: FontWeight.w700,
//                               ),
//                             ),
//                             SizedBox(height: 8),
//                             Text(
//                               "Left",
//                               style: TextStyle(
//                                 fontSize: 16,
//                                 fontWeight: FontWeight.w500,
//                               ),
//                             ),
//                           ],
//                         ),
//                       ],
//                     ),

//                     SizedBox(height: 20),

//                     SingleChildScrollView(
//                       scrollDirection: Axis.horizontal,
//                       child: Row(
//                         mainAxisAlignment: MainAxisAlignment.center,
//                         children: model.players.map((player) {
//                           return Padding(
//                             padding: const EdgeInsets.symmetric(
//                               horizontal: 5.0,
//                             ),
//                             child: Column(
//                               children: [
//                                 Stack(
//                                   alignment: Alignment.topRight,
//                                   children: [
//                                     CircleAvatar(
//                                       radius: 30, // Increased size for better UI
//                                       backgroundImage: AssetImage(
//                                         player.imageUrl,
//                                       ),
//                                     ),
//                                     Positioned(
//                                       top: 0,
//                                       right: 0,
//                                       child: CircleAvatar(
//                                         radius: 12, // Small green check circle
//                                         backgroundColor: Color(0xFF8DC63F),
//                                         child: Image.asset(
//                                           "assets/icons/tick2.png",
//                                           height: 12,
//                                           width: 16,
//                                         ),
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                                 SizedBox(height: 8),
//                                 Text(
//                                   player.name,
//                                   textAlign: TextAlign.center,
//                                   style: TextStyle(
//                                     fontSize: 13,
//                                     fontWeight: FontWeight.w500,
//                                     color: Color(0xFF555555),
//                                   ),
//                                 ),
//                                 SizedBox(height: 15),
//                                 Text(
//                                   "£${player.amountPaid}",
//                                   style: TextStyle(
//                                     fontSize: 20,
//                                     fontWeight: FontWeight.w500,
//                                     color: Colors.black,
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           );
//                         }).toList(),
//                       ),
//                     ),
//                     SizedBox(height: 30),
//                     SizedBox(
//                       width: commonWidth,
//                       height: commonHeight,
//                       child: ElevatedButton(
//                         onPressed: () {
//                           model.gotoHome(context);
//                         },
//                         style: ElevatedButton.styleFrom(
//                           backgroundColor: const Color(0xFF8DC63F),
//                           shape: RoundedRectangleBorder(
//                             borderRadius: BorderRadius.circular(10),
//                           ),
//                         ),
//                         child: Text(
//                           "Go to Home",
//                           style: TextStyle(
//                             fontSize: 18,
//                             color: Colors.black,
//                             fontWeight: FontWeight.w600,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           );
//         },
//       ),
//     );
//   }
// }
