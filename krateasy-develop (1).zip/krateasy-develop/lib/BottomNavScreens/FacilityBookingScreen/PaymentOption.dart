import 'package:flutter/material.dart';

class PaymentOption extends StatelessWidget {
  final ValueNotifier<String?> selectedOption;
  final String paymentMethod;
  final String imagePath;
  final String type;
  PaymentOption(
      {Key? key,
      required this.selectedOption,
      required this.paymentMethod,
      required this.imagePath,
      required this.type})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;

    return InkWell(
      onTap: () {
        selectedOption.value = selectedOption.value == type ? null : type;
      },
      child: ValueListenableBuilder<String?>(
        valueListenable: selectedOption,
        builder: (context, value, child) {
          return Padding(
            padding: EdgeInsets.only(left: 14, right: 8),
            child: Row(
              children: [
                Image.asset(imagePath, width: 26, height: 26),
                SizedBox(width: screenWidth * 0.03),
                Text(
                  paymentMethod,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: Colors.black,
                  ),
                ),
                Spacer(),
                Radio<String>(
                  value: type.toLowerCase().replaceAll(" ", "_"),
                  groupValue: value, // If value is null, both remain unchecked
                  onChanged: null,
                  //  (newValue) {
                  //   selectedOption.value = newValue;
                  // },
                  activeColor: Colors.black,
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
