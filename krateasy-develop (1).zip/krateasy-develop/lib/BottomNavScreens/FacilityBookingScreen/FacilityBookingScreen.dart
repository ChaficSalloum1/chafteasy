// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
// import '../../GlobalUtils/common_app_bar.dart';
// import '../../ViewModel/FacilityBookViewModel/FacilityBookingViewModel.dart';

// class FacilityBookingScreen extends StatefulWidget {
//   const FacilityBookingScreen({super.key});

//   @override
//   _FacilityBookingScreenState createState() => _FacilityBookingScreenState();
// }

// class _FacilityBookingScreenState extends State<FacilityBookingScreen> {
//   final FacilityBookingViewModel viewModel = FacilityBookingViewModel();
//   DateTime selectedDate = DateTime.now();

//   List<DateTime> generateDates() {
//     List<DateTime> dates = [];
//     DateTime currentDate = DateTime.now();
//     DateTime firstDayOfCurrentMonth = DateTime(
//       currentDate.year,
//       currentDate.month,
//       1,
//     );
//     int daysInMonth = DateTime(currentDate.year, currentDate.month + 1, 0).day;
//     int daysInNextMonth =
//         DateTime(currentDate.year, currentDate.month + 2, 0).day;

//     // Add remaining days of the current month
//     for (int i = currentDate.day; i <= daysInMonth; i++) {
//       dates.add(DateTime(currentDate.year, currentDate.month, i));
//     }

//     // Add the next month's dates until reaching a total of 30 days
//     for (int i = 1; dates.length < 30; i++) {
//       dates.add(DateTime(currentDate.year, currentDate.month + 1, i));
//     }

//     return dates;
//   }

//   @override
//   Widget build(BuildContext context) {
//     final double screenWidth = MediaQuery.of(context).size.width;
//     final double screenHeight = MediaQuery.of(context).size.height;

//     return Scaffold(
//       appBar: CommonAppBar(
//         title: "Booking",
//         backIconColor: Colors.white,
//         backgroundColor: Colors.white,
//       ),
//       backgroundColor: Colors.white,
//       body: SingleChildScrollView(
//         // <-- Wrap the entire content with a scroll view
//         child: Padding(
//           padding: EdgeInsets.symmetric(
//             horizontal: screenWidth * 0.05,
//             vertical: screenHeight * 0.02,
//           ),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Row(
//                 children: [
//                   Expanded(
//                     child: Text(
//                       "Court Name",
//                       style: TextStyle(
//                         fontSize: 20,
//                         fontWeight: FontWeight.bold,
//                         color: Colors.black,
//                       ),
//                     ),
//                   ),
//                   Text(
//                     "£ 20/hr",
//                     style: TextStyle(
//                       fontSize: 22,
//                       fontWeight: FontWeight.bold,
//                       color: Colors.black,
//                     ),
//                   ),
//                 ],
//               ),
//               SizedBox(height: screenHeight * 0.02),
//               Row(
//                 children: [
//                   Image.asset('assets/icons/clock.png', height: 21, width: 21),
//                   SizedBox(width: screenWidth * 0.02),
//                   Text.rich(
//                     TextSpan(
//                       children: [
//                         TextSpan(
//                           text: "Min. Time to Book: ",
//                           style: TextStyle(
//                             fontSize: 16,
//                             color: Color(0xFF555555),
//                           ),
//                         ),
//                         TextSpan(
//                           text: "1 Hour",
//                           style: TextStyle(
//                             fontSize: 16,
//                             fontWeight: FontWeight.bold,
//                             color: Color(0xFF555555),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//               SizedBox(height: screenHeight * 0.02),

//               /// "Select Date" aligned to the right
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.end,
//                 children: [
//                   Text(
//                     "Select Date",
//                     style: TextStyle(
//                       fontSize: 16,
//                       fontWeight: FontWeight.bold,
//                       decoration: TextDecoration.underline,
//                     ),
//                   ),
//                 ],
//               ),
//               SizedBox(height: screenHeight * 0.02),

//               /// Horizontal Scroll for Dates
//               SingleChildScrollView(
//                 scrollDirection: Axis.horizontal,
//                 child: Row(
//                   children:
//                       generateDates().map((date) {
//                         bool isSelected =
//                             selectedDate.day == date.day &&
//                             selectedDate.month == date.month;
//                         return GestureDetector(
//                           onTap: () {
//                             setState(() {
//                               selectedDate = date;
//                             });
//                           },
//                           child: Container(
//                             margin: EdgeInsets.symmetric(horizontal: 5),
//                             padding: EdgeInsets.symmetric(
//                               vertical: 10,
//                               horizontal: 15,
//                             ),
//                             decoration:
//                                 isSelected
//                                     ? BoxDecoration(
//                                       border: Border.all(
//                                         color: Color(0xFF8DC63F),
//                                         width: 2,
//                                       ),
//                                       borderRadius: BorderRadius.circular(50),
//                                     )
//                                     : null,
//                             child: Column(
//                               children: [
//                                 Text(
//                                   date.day.toString(),
//                                   style: TextStyle(
//                                     fontSize: 25,
//                                     fontWeight: FontWeight.bold,
//                                     color:
//                                         isSelected
//                                             ? Color(0xFF8DC63F)
//                                             : Colors.black,
//                                   ),
//                                 ),
//                                 Text(
//                                   DateFormat.E().format(date),
//                                   style: TextStyle(
//                                     fontSize: 15,
//                                     color:
//                                         isSelected
//                                             ? Color(0xFF8DC63F)
//                                             : Colors.black,
//                                   ),
//                                 ),
//                                 if (isSelected)
//                                   Container(
//                                     width: 9,
//                                     height: 9,
//                                     margin: EdgeInsets.only(top: 4),
//                                     decoration: BoxDecoration(
//                                       color: Color(0xFF8DC63F),
//                                       shape: BoxShape.circle,
//                                     ),
//                                   ),
//                               ],
//                             ),
//                           ),
//                         );
//                       }).toList(),
//                 ),
//               ),
//               SizedBox(height: screenHeight * 0.02),

//               /// Selected Date Text
//               Center(
//                 child: Text(
//                   '${DateFormat('E d').format(selectedDate)}${getDaySuffix(selectedDate.day)} ${DateFormat('MMM').format(selectedDate)}',
//                   style: TextStyle(
//                     fontSize: 20,
//                     fontWeight: FontWeight.bold,
//                     color: Colors.black,
//                   ),
//                 ),
//               ),

//               Divider(),
//               SizedBox(height: screenHeight * 0.02),

//               /// Time Slots in a Responsive Wrap
//               LayoutBuilder(
//                 builder: (context, constraints) {
//                   double itemWidth =
//                       (constraints.maxWidth - (2 * screenWidth * 0.04)) / 3;
//                   return Wrap(
//                     spacing: screenWidth * 0.04,
//                     runSpacing: screenHeight * 0.02,
//                     children:
//                         viewModel.availableTimes.map((time) {
//                           bool isSelected = viewModel.selectedTime == time;
//                           return GestureDetector(
//                             onTap:
//                                 () => setState(
//                                   () => viewModel.selectedTime = time,
//                                 ),
//                             child: Container(
//                               width: itemWidth,
//                               padding: EdgeInsets.symmetric(
//                                 vertical: screenHeight * 0.018,
//                                 horizontal: screenWidth * 0.02,
//                               ),
//                               decoration: BoxDecoration(
//                                 color:
//                                     isSelected
//                                         ? Color(0xFF8DC63F)
//                                         : Colors.white,
//                                 border: Border.all(color: Colors.grey.shade400),
//                                 borderRadius: BorderRadius.circular(8),
//                               ),
//                               alignment: Alignment.center,
//                               child: Text(
//                                 time,
//                                 style: TextStyle(
//                                   color:
//                                       isSelected ? Colors.white : Colors.black,
//                                   fontSize: screenWidth * 0.035,
//                                 ),
//                               ),
//                             ),
//                           );
//                         }).toList(),
//                   );
//                 },
//               ),

//               SizedBox(height: screenHeight * 0.02),

//               /// Add Friends Button
//               SizedBox(
//                 width: double.infinity,
//                 child: ElevatedButton.icon(
//                   onPressed: () {
//                     // Add your button action here
//                     _showAddFriendsBottomSheet(context);
//                   },
//                   icon: Image.asset(
//                     'assets/icons/plus.png', // Replace with your actual asset path
//                     width: 24,
//                     height: 24,
//                   ),
//                   label: Text(
//                     "Add Friends",
//                     style: TextStyle(
//                       fontSize: 20,
//                       fontWeight: FontWeight.w600,
//                       color: Colors.white,
//                     ),
//                   ),
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor: Colors.black,
//                     minimumSize: const Size(
//                       double.infinity,
//                       50,
//                     ), // Set height to 50px
//                     padding: EdgeInsets.symmetric(
//                       vertical: screenHeight * 0.016,
//                     ),
//                     shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(8),
//                     ),
//                   ),
//                 ),
//               ),

//               SizedBox(height: screenHeight * 0.02),

//               /// Add Friends & Split the Cost Label
//               Center(
//                 child: TextButton(
//                   onPressed: () {
//                     // Add action for this label button
//                   },
//                   child: Text(
//                     "Add Friends & Split the Cost! ⚽🏀",
//                     textAlign: TextAlign.center,
//                     style: TextStyle(
//                       fontSize: screenWidth * 0.045,
//                       fontWeight: FontWeight.w600,
//                       color: Colors.black,
//                     ),
//                   ),
//                 ),
//               ),

//               SizedBox(height: screenHeight * 0.04),

//               /// Pricing & Checkout Button
//               Row(
//                 children: [
//                   SizedBox(
//                     width: screenWidth * 0.3,
//                     child: Container(
//                       padding: EdgeInsets.symmetric(
//                         vertical: screenHeight * 0.02,
//                       ),
//                       alignment: Alignment.center,
//                       decoration: BoxDecoration(
//                         border: Border.all(color: Colors.grey.shade400),
//                         borderRadius: BorderRadius.circular(6),
//                       ),
//                       child: Text(
//                         "£ 20/hr",
//                         style: TextStyle(
//                           fontSize: screenWidth * 0.04,
//                           fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                     ),
//                   ),
//                   SizedBox(width: screenWidth * 0.02),
//                   Divider(),
//                   SizedBox(width: screenWidth * 0.02),
//                   Expanded(
//                     child: ElevatedButton(
//                       style: ElevatedButton.styleFrom(
//                         shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(4),
//                         ),
//                         backgroundColor: Color(0xFF8DC63F),
//                         padding: EdgeInsets.symmetric(
//                           vertical: screenHeight * 0.02,
//                         ),
//                       ),
//                       onPressed: () {
//                         viewModel.checkOut(context);
//                       },
//                       child: Text(
//                         "Checkout",
//                         style: TextStyle(
//                           fontSize: screenWidth * 0.04,
//                           color: Colors.white,
//                         ),
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   void _showAddFriendsBottomSheet(BuildContext context) {
//     showModalBottomSheet(
//       context: context,
//       isScrollControlled: true,
//       backgroundColor: Colors.transparent,
//       builder: (context) {
//         return DraggableScrollableSheet(
//           initialChildSize: 0.6, // Adjust the initial height
//           minChildSize: 0.4,
//           maxChildSize: 0.9,
//           builder: (_, scrollController) {
//             return Container(
//               padding: EdgeInsets.all(16),
//               decoration: BoxDecoration(
//                 color: Color(0xFFF4F9EC), // Light greenish background
//                 borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
//               ),
//               child: Column(
//                 children: [
//                   /// **Header Title**
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                     children: [
//                       Text(
//                         "Add Friends",
//                         style: TextStyle(
//                           fontSize: 12,
//                           fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                     ],
//                   ),
//                   SizedBox(height: 10),

//                   /// **Search Bar**
//                   TextField(
//                     decoration: InputDecoration(
//                       hintText: "Search Contact",
//                       filled: true,
//                       fillColor: Colors.transparent,
//                       contentPadding: EdgeInsets.symmetric(
//                         vertical: 12,
//                         horizontal: 16,
//                       ),
//                       border: OutlineInputBorder(
//                         borderRadius: BorderRadius.circular(8),
//                         borderSide: BorderSide.none,
//                       ),
//                       suffixIcon: Padding(
//                         padding: EdgeInsets.all(10),
//                         child: Image.asset(
//                           'assets/icons/search.png', // Replace with your actual asset path
//                           width: 24,
//                           height: 24,
//                         ),
//                       ),
//                     ),
//                   ),

//                   SizedBox(height: 10),

//                   /// **Scrollable Contact List**
//                   Expanded(
//                     child: ListView.builder(
//                       controller: scrollController,
//                       itemCount: 8, // Example count
//                       itemBuilder: (context, index) {
//                         return ListTile(
//                           leading: CircleAvatar(
//                             backgroundImage: AssetImage(
//                               'assets/icons/emoji.png',
//                             ), // Replace with actual image
//                           ),
//                           title: Text(
//                             "Alexander Hipp",
//                             style: TextStyle(
//                               fontSize: 12,
//                               fontWeight: FontWeight.bold,
//                             ),
//                           ),
//                           subtitle: Text(
//                             "+966 565389",
//                             style: TextStyle(
//                               fontSize: 12,
//                               color: Color(0xFF555555),
//                               fontWeight: FontWeight.bold,
//                             ),
//                           ),
//                           trailing: TextButton.icon(
//                             onPressed: () {
//                               // Handle add friend action
//                             },
//                             icon: Icon(
//                               Icons.add_circle_outline,
//                               color: Color(0xFF4CAF50),
//                             ),
//                             label: Text(
//                               "Add",
//                               style: TextStyle(
//                                 fontSize: 12,
//                                 color: Color(0xFF4CAF50),
//                                 fontWeight: FontWeight.bold,
//                               ),
//                             ),
//                           ),
//                         );
//                       },
//                     ),
//                   ),
//                   SizedBox(height: 10),

//                   /// **Bottom "Add" Button**
//                   SizedBox(
//                     width: double.infinity,
//                     height: 48, // Adjust height as needed
//                     child: ElevatedButton(
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: Color(
//                           0xFF8DC63F,
//                         ), // Green button color
//                         shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(10),
//                         ),
//                         padding: EdgeInsets.symmetric(
//                           vertical: 12,
//                         ), // Extra padding for height
//                       ),
//                       onPressed: () {
//                         viewModel.addFriends(context);
//                       },
//                       child: Text(
//                         "Add",
//                         style: TextStyle(
//                           fontSize: 18,
//                           color: Colors.black,
//                           fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             );
//           },
//         );
//       },
//     );
//   }

//   String getDaySuffix(int day) {
//     if (day >= 11 && day <= 13) {
//       return 'th';
//     }
//     switch (day % 10) {
//       case 1:
//         return 'st';
//       case 2:
//         return 'nd';
//       case 3:
//         return 'rd';
//       default:
//         return 'th';
//     }
//   }
// }
