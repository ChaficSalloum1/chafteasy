// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import '../../GlobalUtils/common_app_bar.dart';
// import '../../ViewModel/FacilityBookViewModel/FacilityAddFriendsViewModel.dart';

// class FacilityAddFriendsScreen extends StatelessWidget {
//   const FacilityAddFriendsScreen({super.key});

//   @override
//   Widget build(BuildContext context) {
//     double screenWidth = MediaQuery.of(context).size.width;
//     double screenHeight = MediaQuery.of(context).size.height;

//     return Scaffold(
//       backgroundColor: Colors.white,
//       appBar: CommonAppBar(
//         title: "Added Friends",
//         backIconColor: Colors.white,
//         backgroundColor: Colors.white,
//       ),
//       body: Padding(
//         padding: EdgeInsets.symmetric(
//           horizontal: screenWidth * 0.05,
//           vertical: screenHeight * 0.02,
//         ),
//         child: Consumer<FacilityAddFriendsViewModel>(
//           builder: (context, viewModel, child) {
//             return Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 // "Add Friends" Section
//                 Container(
//                   padding: const EdgeInsets.all(12),
//                   decoration: BoxDecoration(
//                     color: Colors.transparent,
//                     borderRadius: BorderRadius.circular(12),
//                   ),
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       const Text(
//                         "Add Friends",
//                         style: TextStyle(
//                           fontSize: 12,
//                           fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                       const SizedBox(height: 10),
//                       GestureDetector(
//                         onTap: () {
//                           // Add Friend Action
//                         },
//                         child: Container(
//                           width: double.infinity,
//                           height: 50, // Set height to 50px
//                           padding: const EdgeInsets.symmetric(
//                             horizontal: 12,
//                           ), // Adjusted padding
//                           decoration: BoxDecoration(
//                             color: Color(0xFF8DC63F),
//                             borderRadius: BorderRadius.circular(8),
//                           ),
//                           alignment: Alignment
//                               .centerLeft, // Ensures text is aligned left
//                           child: const Text(
//                             "Add another Recipient",
//                             style: TextStyle(
//                               color: Colors.black,
//                               fontSize: 14,
//                               fontWeight: FontWeight.w400,
//                             ),
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//                 const SizedBox(height: 10),

//                 // Friends List
//                 Expanded(
//                   child: ListView.builder(
//                     itemCount: viewModel.friendsList.length,
//                     itemBuilder: (context, index) {
//                       final friend = viewModel.friendsList[index];
//                       return Padding(
//                         padding: const EdgeInsets.symmetric(vertical: 6),
//                         child: Row(
//                           children: [
//                             // Profile Picture
//                             CircleAvatar(
//                               radius: 20,
//                               backgroundImage: AssetImage(friend.imagePath),
//                             ),
//                             const SizedBox(width: 10),

//                             // Friend Name & Phone
//                             Column(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 Text(
//                                   friend.name,
//                                   style: const TextStyle(
//                                     fontSize: 14,
//                                     fontWeight: FontWeight.bold,
//                                   ),
//                                 ),
//                                 Text(
//                                   friend.phone,
//                                   style: const TextStyle(
//                                     fontSize: 12,
//                                     color: Colors.grey,
//                                   ),
//                                 ),
//                               ],
//                             ),
//                             const Spacer(),

//                             // Remove Button
//                             GestureDetector(
//                               onTap: () {
//                                 viewModel.removeFriend(index);
//                               },
//                               child: Row(
//                                 children: [
//                                   Image.asset(
//                                     'assets/icons/delete.png', // Replace with your actual asset path
//                                     width: 20, // Adjust size as needed
//                                     height: 20, // Adjust size as needed
//                                   ),
//                                   const SizedBox(width: 5),
//                                   const Text(
//                                     "Remove",
//                                     style: TextStyle(
//                                       color: Color(0xFFDD2323),
//                                       fontWeight: FontWeight.bold,
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           ],
//                         ),
//                       );
//                     },
//                   ),
//                 ),

//                 // Continue Button
//                 GestureDetector(
//                   onTap: () {
//                     // Continue Action
//                     Navigator.pop(context);
//                     Navigator.pop(context);
//                   },
//                   child: Container(
//                     width: double.infinity,
//                     height: 58, // Set height to 58px
//                     padding: const EdgeInsets.all(12),
//                     decoration: BoxDecoration(
//                       color: Color(0xff8DC63F),
//                       borderRadius: BorderRadius.circular(8),
//                     ),
//                     alignment:
//                         Alignment.center, // Ensures text is centered vertically
//                     child: const Text(
//                       "Continue",
//                       textAlign: TextAlign.center,
//                       style: TextStyle(
//                         color: Colors.black,
//                         fontSize: 18,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),
//                   ),
//                 ),
//               ],
//             );
//           },
//         ),
//       ),
//     );
//   }
// }
