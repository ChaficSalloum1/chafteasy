// import 'package:flutter/material.dart';
// import 'package:kratEasyApp/GlobalUtils/app_colors.dart';
// import 'package:provider/provider.dart';
// import '../../GlobalUtils/common_app_bar.dart';
// import '../../ViewModel/FacilityBookViewModel/SuccessPaymentViewModel.dart';

// class SuccessPaymentScreen extends StatelessWidget {
//   const SuccessPaymentScreen({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return ChangeNotifierProvider(
//       create: (context) => SuccessPaymentViewModel(),
//       child: Consumer<SuccessPaymentViewModel>(
//         builder: (context, viewModel, child) {
//           return Scaffold(
//             backgroundColor: Colors.white,
//             appBar: CommonAppBar(
//                 title: "Back",
//                 backIconColor: Colors.white,
//                 backgroundColor: Colors.white),
//             body: Stack(
//               children: [
//                 Column(
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Spacer(flex: 2),
//                     Center(
//                       child: Column(
//                         children: [
//                           SizedBox(
//                               width: 175,
//                               height: 168,
//                               child: Image.asset(viewModel.logoPath,
//                                   fit: BoxFit.fill)),
//                           SizedBox(height: 5),
//                           Text(viewModel.headText,
//                               style: TextStyle(
//                                   fontSize: 34,
//                                   fontWeight: FontWeight.w600,
//                                   color: AppColors.black)),
//                           SizedBox(height: 5),
//                           Text(viewModel.midText,
//                               style: TextStyle(
//                                   fontSize: 16,
//                                   fontWeight: FontWeight.w500,
//                                   color: AppColors.black555)),
//                           Text(viewModel.lowText,
//                               style: TextStyle(
//                                   fontSize: 16,
//                                   fontWeight: FontWeight.w500,
//                                   color: AppColors.black555)),
//                           SizedBox(height: 5),
//                           RichText(
//                             text: TextSpan(
//                               text: "Booking ID: ",
//                               style: TextStyle(
//                                   fontSize: 16,
//                                   fontWeight: FontWeight.w500,
//                                   color: AppColors.black555),
//                               children: [
//                                 TextSpan(
//                                     text: "#",
//                                     style: TextStyle(
//                                         fontSize: 16,
//                                         fontWeight: FontWeight.w500,
//                                         color: AppColors.black)),
//                                 TextSpan(
//                                     text: viewModel.lowText_2,
//                                     style: TextStyle(
//                                         fontSize: 16,
//                                         fontWeight: FontWeight.w500,
//                                         color: AppColors.black)),
//                               ],
//                             ),
//                           ),
//                           SizedBox(height: 20),
//                           Stack(
//                             children: [
//                               SizedBox(
//                                   height: 110,
//                                   width: 110,
//                                   child: Image.asset("assets/png/qr_code.png",
//                                       fit: BoxFit.fill)),
//                               Positioned(
//                                 left: 0,
//                                 top: 0,
//                                 bottom: 0,
//                                 right: 0,
//                                 child: Center(
//                                   child: Container(
//                                     height: 41,
//                                     width: 41,
//                                     color: AppColors.white,
//                                     child: Center(
//                                         child: SizedBox(
//                                             height: 21,
//                                             width: 33,
//                                             child: Image.asset(
//                                                 "assets/logo.png",
//                                                 fit: BoxFit.fill))),
//                                   ),
//                                 ),
//                               ),
//                             ],
//                           ),
//                           SizedBox(height: 20),
//                           Padding(
//                             padding: EdgeInsets.symmetric(horizontal: 16),
//                             child: Text(
//                               "We have successfully send the QR code to your email.Use it for your entry",
//                               textAlign: TextAlign.center,
//                               style: TextStyle(
//                                   fontSize: 14,
//                                   fontWeight: FontWeight.w500,
//                                   color: AppColors.black),
//                             ),
//                           ),
//                           SizedBox(height: 20),
//                           Padding(
//                             padding: EdgeInsets.symmetric(
//                                 horizontal:
//                                     20), // Proper padding from left & right
//                             child: Stack(
//                               children: [
//                                 Container(
//                                   height: 52,
//                                   width: double
//                                       .infinity, // Full width for responsiveness
//                                   decoration: BoxDecoration(
//                                       borderRadius: BorderRadius.circular(10),
//                                       color: Color(0xFF72A033)),
//                                 ),
//                                 GestureDetector(
//                                   onTap: () {
//                                     viewModel.bookingDetails(context);
//                                   },
//                                   child: Container(
//                                     height: 47,
//                                     width: double
//                                         .infinity, // Full width for responsiveness
//                                     decoration: BoxDecoration(
//                                         color: Color(0xFF8DC63F),
//                                         borderRadius:
//                                             BorderRadius.circular(10)),
//                                     child: Center(
//                                       child: Row(
//                                         mainAxisAlignment:
//                                             MainAxisAlignment.center,
//                                         children: [
//                                           SizedBox(width: 5),
//                                           Text("View Booking Details",
//                                               style: TextStyle(
//                                                   color: Colors.black,
//                                                   fontSize: 16,
//                                                   fontWeight: FontWeight.w600))
//                                         ],
//                                       ),
//                                     ),
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                     Spacer(flex: 5),
//                   ],
//                 ),
//               ],
//             ),
//           );
//         },
//       ),
//     );
//   }
// }
