import 'package:flutter/material.dart';
import 'package:kratEasyApp/GlobalUtils/app_colors.dart';
import 'package:kratEasyApp/GlobalUtils/app_text_field.dart';
import 'package:kratEasyApp/GlobalUtils/common.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';
import '../GlobalUtils/SideDrawerScreen.dart';
import '../ViewModel/NavBarViewModels/MyBookingsViewModel.dart';
import '../NavBarScreens/MyBookingTabs/CompletedBookingsTab.dart';
import '../NavBarScreens/MyBookingTabs/UpComingBookingsTab.dart';

class MyBookingScreen extends StatefulWidget {
  const MyBookingScreen({super.key});

  @override
  State<MyBookingScreen> createState() => _MyBookingScreenState();
}

class _MyBookingScreenState extends State<MyBookingScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final viewModel = context.read<MyBookingsViewModel>();
      viewModel.getMyBookingData(context: context, type: "upcoming");
      viewModel.getMyChallengeData(context: context, challengeType: "upcoming");
    });
  }

  @override
  Widget build(BuildContext context) {
    // final username = Provider.of<DashboardViewModel>(context).userName;
    double screenWidth = MediaQuery.of(context).size.width;
    // double screenHeight = MediaQuery.of(context).size.height;

    return DefaultTabController(
      length: 2,
      child: Consumer<MyBookingsViewModel>(builder: (context, viewModel, _) {
        final myBookings = viewModel.myBookingModel.data?.docs
            ?.where((item) => item.status?.toLowerCase() != "completed");
        printLog("upcoming booking length :${myBookings?.length}");

        final myCompletedBookings = viewModel.myBookingModel.data?.docs?.where(
          (item) => item.status?.toLowerCase() == "completed",
        );
        printLog("completed booking length :${myCompletedBookings?.length}");
        return Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            titleSpacing: 0,
            backgroundColor: Colors.white,
            elevation: 1,
            leading: Builder(
              builder: (context) {
                return IconButton(
                    icon: Image.asset('assets/icons/drawer.png',
                        width: 30, height: 30),
                    onPressed: () => Scaffold.of(context).openDrawer());
              },
            ),
            title: Text(l10n.of(context).myBooking,
                style: TextStyle(
                    color: Colors.black,
                    fontSize: screenWidth * 0.05,
                    fontWeight: FontWeight.bold)),
          ),
          drawer: SideDrawerScreen(),
          body: SafeArea(
            child: Stack(
              children: [
                Column(
                  children: [
                    const Divider(
                        height: 1, thickness: 1, color: Color(0xFF8DC63F)),
                    const SizedBox(height: 60),
                    Expanded(
                      child: TabBarView(
                        children: [
                          UpComingBookingsTab(),
                          ((myCompletedBookings ?? []).isEmpty)
                              ? Center(
                                  child: Lottie.asset(
                                    'assets/lottie/no-data.json',
                                    width: 300,
                                    height: 300,
                                    fit: BoxFit.fill,
                                    animate: true,
                                    repeat: true,
                                  ),
                                )
                              : viewModel.isLoading
                                  ? loaderWidget()
                                  : CompletedBookingsTab()
                        ],
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: EdgeInsets.only(left: 16, right: 16, top: 10),
                  child: Container(
                    height: 50,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: AppColors.white,
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.black.withOpacity(.1),
                          blurRadius: 5,
                          spreadRadius: 0,
                          offset: Offset(0, 5),
                        )
                      ],
                    ),
                    width: screenWidth,
                    child: Theme(
                      data: ThemeData(
                        tabBarTheme: TabBarThemeData(
                          labelColor: Colors.black,
                          dividerColor: AppColors.white,
                          unselectedLabelColor: AppColors.black555,
                          indicator: BoxDecoration(
                            color: Color(0xFF8DC63F),
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: TabBar(
                          indicatorSize: TabBarIndicatorSize.tab,
                          onTap: (index) async {
                            await viewModel.getMyBookingData(
                                context: context,
                                type: index == 0 ? "upcoming" : "completed");
                            await viewModel.getMyChallengeData(
                                context: context,
                                challengeType:
                                    index == 0 ? "upcoming" : "completed");
                          },
                          tabs: [
                            Tab(
                              child: Text(
                                l10n.of(context).upcoming,
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                            Tab(
                              child: Text(
                                l10n.of(context).completed,
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }),
    );
  }
}
