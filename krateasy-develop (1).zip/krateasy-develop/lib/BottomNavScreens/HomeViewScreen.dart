import 'dart:async';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:kratEasyApp/API_CALLS/API/AmenitiesListAPI.dart';
import 'package:kratEasyApp/BottomNavScreens/ChallengeTab/ActiveChallengeTab.dart';
import 'package:kratEasyApp/BottomNavScreens/CreateChallengeScreen/CreateChallengeScreen.dart';
import 'package:kratEasyApp/BottomNavScreens/HomeTabs/AvailableNearbyCourtsTab.dart';
import 'package:kratEasyApp/BottomNavScreens/modifyBookingScreen.dart';
import 'package:kratEasyApp/EntranceScreens/guest_booking.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/utils/extension.dart';
import 'package:kratEasyApp/utils/widgets/common_widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shimmer/shimmer.dart';
import 'package:url_launcher/url_launcher.dart';
import '../GlobalUtils/common_share.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tzData;
import 'package:skeletonizer/skeletonizer.dart';

class HomeViewScreen extends StatefulWidget {
  const HomeViewScreen({super.key});

  @override
  _HomeViewScreenState createState() => _HomeViewScreenState();
}

class _HomeViewScreenState extends State<HomeViewScreen> {
  //6 june code
  final PageController _controller = PageController();
  final ScrollController _scrollController = ScrollController();
  final ValueNotifier<RangeValues> rangeValuesNotifier =
      ValueNotifier(const RangeValues(1, 3));
  int currentIndex = 0;
  int _currentPage = 0;
  Timer? _timer;
  String? sportID;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // final notificationviewModel = Provider.of<NotificationsViewModel>(context,listen: false);
      // notificationviewModel.getNotificationListData(context: context);
      _initializeData();
    });
  }

  Future<void> _initializeData() async {
    final prefs = await SharedPreferences.getInstance();
    sportID = prefs.getString("sportID");

    final homeProvider = context.read<HomeViewModel>();
    final courtProvider = context.read<NearbyCourtsViewModel>();

    /// set [isLoading] as true
    homeProvider.setLoader(true);

    await AmenitiesListApi().fetchAndSaveAmenities();

    await homeProvider.getSportsDataApi(context: context);

    if (!mounted) return;

    // homeProvider.checkAndShowPopup(
    //   showPopupCallback: () => showWhatToPlayDialog(context),
    // );

    if (!mounted) return;
    await courtProvider.newSearchCourtApiForHome(context);

    if (!mounted) return;
    await homeProvider.getHomeData();

    /// set [isLoading] as false
    homeProvider.setLoader(false);

    if (!mounted) return;
    _startAutoScroll();
  }

  void _startAutoScroll() {
    _timer = Timer.periodic(const Duration(seconds: 8), (_) {
      final viewModel = context.read<HomeViewModel>();
      final totalBanners =
          1 + (viewModel.homeResponseModel.data?.banners?.length ?? 0);

      if (totalBanners == 0 || !_controller.hasClients) return;

      currentIndex = (currentIndex + 1) % totalBanners;

      _controller.animateToPage(
        currentIndex,
        duration: const Duration(milliseconds: 600),
        curve: Curves.easeInOut,
      );

      setState(() {
        _currentPage = currentIndex;
      });
    });
  }

  Future<void> launchBannerURL(String url) async {
    if (url.isEmpty) return;
    final uri = Uri.parse(url);

    try {
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else {
        debugPrint('Cannot launch $url');
      }
    } catch (e) {
      debugPrint("Launch error: $e");
    }
  }

  Future<String?> _getSavedLocation() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('saved_location') ??
        l10n.of(context).fetchingCurrentLocation;
  }

  @override
  void dispose() {
    _timer?.cancel(); // only cancel if it's initialized
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;

    return SafeArea(
      child: DefaultTabController(
        length: 2,
        child: Consumer3<HomeViewModel, AvailableChallengeGuestViewModel,
            NearbyCourtsViewModel>(
          builder: (context, viewModel, availableChallengeGuestViewModel,
              nearbyProvider, _) {
            return Scaffold(
              // floatingActionButton: FloatingActionButton(onPressed: (){
              //   showWhatToPlayDialog(context);
              // }),
              backgroundColor: Colors.white,
              body: Skeletonizer(
                enabled: viewModel.isLoading,
                child: RefreshIndicator(
                  onRefresh: () async {
                    final viewModel1 = context.read<NearbyCourtsViewModel>();

                    final homeProvider =
                        Provider.of<HomeViewModel>(context, listen: false);

                    await homeProvider.getHomeData();
                    await viewModel1.newSearchCourtApiForHome(context);
                    await AmenitiesListApi().fetchAndSaveAmenities();

                    await homeProvider.getSportsDataApi(context: context);
                  },
                  color: AppColors.primaryColor,
                  child: ListView(
                    physics: BouncingScrollPhysics(),
                    children: [
                      // if (viewModel.isLoadingHomeData ||
                      //     viewModel.isLoadingSports) ...[
                      //   Center(
                      //     child: HomeShimmer(),
                      //   )
                      // ] else ...

                      SizedBox(height: 20),

                      if (viewModel.homeResponseModel.data != null &&
                          viewModel.homeResponseModel.data?.banners !=
                              null) ...[
                        SizedBox(
                          height: 120,
                          width: double.infinity,
                          child: PageView.builder(
                            controller: _controller,
                            itemCount: 1 +
                                (viewModel.homeResponseModel.data?.banners
                                        ?.length ??
                                    0),
                            onPageChanged: (index) {
                              setState(() {
                                _currentPage = index;
                              });
                            },
                            itemBuilder: (context, index) {
                              if (index == 0) {
                                return Padding(
                                  padding: const EdgeInsets.only(
                                      left: 14, right: 14),
                                  child: Stack(
                                    children: [
                                      Image.asset(
                                        "assets/png/bannerImg.png",
                                        fit: BoxFit.fill,
                                        width: double.infinity,
                                        height: 120,
                                      ),
                                      Positioned(
                                        left: 10,
                                        top: 8,
                                        child: SizedBox(
                                          width: 300,
                                          child: Column(
                                            children: [
                                              Text(
                                                l10n
                                                    .of(context)
                                                    .joinPrivateChallengeByInvitingFriends,
                                                style: TextStyle(
                                                    color: AppColors.white,
                                                    fontSize: 14,
                                                    fontWeight:
                                                        FontWeight.w600),
                                              ),
                                              Text(
                                                overflow: TextOverflow.ellipsis,
                                                l10n
                                                    .of(context)
                                                    .challengeYourFriendsCompeteTogetherAndnenjoyExclusiveMatches,
                                                style: TextStyle(
                                                    color: AppColors.white,
                                                    fontSize: 10,
                                                    fontWeight:
                                                        FontWeight.w400),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        left: 10,
                                        bottom: 10,
                                        child: InkWell(
                                          onTap: () {
                                            debugPrint("Tapped API banner!");
                                            _showChallengeBottomSheet(context);
                                          },
                                          child: Skeleton.ignore(
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Colors.black,
                                                borderRadius:
                                                    BorderRadius.circular(6),
                                              ),
                                              // height: 26,
                                              // width: 66,
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 6, vertical: 4),
                                              child: Center(
                                                child: Text(
                                                  l10n.of(context).joinNow,
                                                  style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 12,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              } else {
                                // API banners
                                final banner = viewModel.homeResponseModel.data!
                                    .banners![index - 1];
                                return Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 14.0),
                                  child: Stack(
                                    children: [
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(16),
                                        child: Image.network(
                                          banner.image ?? '',
                                          fit: BoxFit.cover,
                                          width: double.infinity,
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              }
                            },
                          ),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: List.generate(
                            1 +
                                (viewModel.homeResponseModel.data?.banners
                                        ?.length ??
                                    0),
                            (index) => Container(
                              margin: const EdgeInsets.symmetric(horizontal: 4),
                              width: 10,
                              height: 4,
                              decoration: BoxDecoration(
                                color: _currentPage == index
                                    ? const Color(0xFF8DC63F)
                                    : const Color(0xFFE4F4D2),
                                borderRadius: BorderRadius.circular(4),
                              ),
                            ),
                          ),
                        ),
                      ],
                      //PLAY AGAIN
                      ...(viewModel.homeResponseModel.data?.completedBookings
                                  ?.isNotEmpty ??
                              false)
                          ? [
                              SizedBox(height: 20),
                              Padding(
                                padding: EdgeInsets.only(left: 14.0),
                                child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Text(l10n.of(context).playAgain,
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 18,
                                            fontWeight: FontWeight.w600))),
                              ),
                              SizedBox(height: 10),
                              Padding(
                                padding: EdgeInsets.symmetric(horizontal: 14.0),
                                child: SizedBox(
                                  height: 180,
                                  child: ListView.builder(
                                    shrinkWrap: true,
                                    physics: ScrollPhysics(),
                                    scrollDirection: Axis.horizontal,
                                    itemCount: viewModel.homeResponseModel.data
                                            ?.completedBookings?.length ??
                                        0,
                                    itemBuilder: (context, index) {
                                      var playAgainData = viewModel
                                          .homeResponseModel
                                          .data
                                          ?.completedBookings![(viewModel
                                              .homeResponseModel
                                              .data
                                              ?.completedBookings
                                              ?.length)! -
                                          1 -
                                          index]; // 👈 reverse index

                                      // var playAgainData = viewModel
                                      //     .homeResponseModel
                                      //     .data
                                      //     ?.completedBookings?[index];

                                      return InkWell(
                                        onTap: () {
                                          viewModel.setRebookTextUpdate(true);

                                          if (playAgainData.type ==
                                              "Challenge") {
                                            // debugPrint(
                                            //     "Challenge Id:>>>>>>>>> ${challenge.id}");
                                            print(
                                                "playAgainData.bookingId  ${playAgainData.id}");
                                            if (availableChallengeGuestViewModel
                                                        .loadingChallengeIndexCompleted !=
                                                    index &&
                                                !availableChallengeGuestViewModel
                                                    .isLoadCompleted) {
                                              availableChallengeGuestViewModel
                                                  .setLoadingChallengeIndexCompleted(
                                                      index);
                                              availableChallengeGuestViewModel
                                                  .getChallengesDetailsForCompleted(
                                                      ispublic: true,
                                                      cancelChallenge: false,
                                                      challengesId: playAgainData
                                                              .challengeId ??
                                                          "",
                                                      // (challenge.id ?? "")
                                                      //     .toString(),
                                                      context: context)
                                                  .then((_) {
                                                availableChallengeGuestViewModel
                                                    .setLoadingChallengeIndexCompleted(
                                                        null);
                                              });
                                            }
                                            // Navigator.push(
                                            //   context,
                                            //   MaterialPageRoute(
                                            //     builder: (context) =>
                                            //         ViewCourtDetailsCompleteScreen(
                                            //       ID: playAgainData.courtId ??
                                            //           "",
                                            //       isChallenge: true,
                                            //     ),
                                            //   ),
                                            // );
                                          } else {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) =>
                                                    ViewCourtDetailsCompleteScreen(
                                                  ID: playAgainData.courtId ??
                                                      "",
                                                  isChallenge:
                                                      playAgainData.type ==
                                                          "Challenge",
                                                  isRebook: true,
                                                ),
                                              ),
                                            );
                                          }
                                        },
                                        child: Container(
                                          width: 330,
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              border: Border.all(
                                                color: Color(0xffD0D0D0),
                                              ),
                                              borderRadius:
                                                  BorderRadius.circular(5)),
                                          margin: EdgeInsets.only(right: 04),
                                          child: Padding(
                                            padding: EdgeInsets.only(
                                                left: 6, right: 6, top: 4),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    ClipRRect(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              2.41),
                                                      child: NetworkImageWidget(
                                                          image: (playAgainData
                                                                      ?.courtImage ??
                                                                  l10n
                                                                      .of(context)
                                                                      .na)
                                                              .toString(),
                                                          width: 80,
                                                          height: 80),
                                                    ),
                                                    SizedBox(
                                                        width: screenWidth *
                                                            0.024),
                                                    Expanded(
                                                      child: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Text(
                                                              maxLines: 1,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              '${playAgainData?.bookingId ?? l10n.of(context).na}',
                                                              style: TextStyle(
                                                                  fontSize: 10,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400,
                                                                  color: Color(
                                                                      0xFF555555))),
                                                          SizedBox(height: 2),
                                                          Text(
                                                              maxLines: 1,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              (playAgainData?.courtName ??
                                                                      l10n
                                                                          .of(
                                                                              context)
                                                                          .na)
                                                                  .toString(),
                                                              style: TextStyle(
                                                                  fontSize: 10,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w600,
                                                                  color: Colors
                                                                      .black)),
                                                          SizedBox(
                                                              height:
                                                                  screenHeight *
                                                                      0.007),
                                                          Row(
                                                            children: [
                                                              Image.asset(
                                                                  "assets/icons/rate.png",
                                                                  width: 13,
                                                                  height: 13),
                                                              SizedBox(
                                                                  width:
                                                                      screenWidth *
                                                                          0.012),
                                                              playAgainData!.rating !=
                                                                          null &&
                                                                      playAgainData
                                                                              .rating !=
                                                                          ""
                                                                  ? Text(
                                                                      playAgainData
                                                                          .rating
                                                                          .toString(),
                                                                      style: TextStyle(
                                                                          fontSize:
                                                                              10,
                                                                          fontWeight: FontWeight
                                                                              .w700,
                                                                          color: Color(
                                                                              0xFF555555)))
                                                                  : Text(
                                                                      "0.0"
                                                                          .toString(),
                                                                      style: TextStyle(
                                                                          fontSize:
                                                                              10,
                                                                          fontWeight: FontWeight
                                                                              .w700,
                                                                          color:
                                                                              Color(0xFF555555))),
                                                              SizedBox(
                                                                  width:
                                                                      screenWidth *
                                                                          0.012),
                                                              Expanded(
                                                                child: Text(
                                                                  maxLines: 1,
                                                                  (playAgainData
                                                                              .facilityName ??
                                                                          l10n
                                                                              .of(context)
                                                                              .na)
                                                                      .toString(),
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          10,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w400,
                                                                      color: Color(
                                                                          0xFF555555)),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                          SizedBox(
                                                              height:
                                                                  screenHeight *
                                                                      0.007),
                                                          Row(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Image.asset(
                                                                  'assets/icons/location.png',
                                                                  width: 13,
                                                                  height: 13),
                                                              Expanded(
                                                                child: Text(
                                                                  (playAgainData
                                                                              .facilityAddress ??
                                                                          l10n
                                                                              .of(context)
                                                                              .na)
                                                                      .toString(),
                                                                  maxLines: 1,
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          10,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w400,
                                                                      color: Color(
                                                                          0xFF555555)),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Column(
                                                      children: [
                                                        Text(
                                                            (playAgainData
                                                                        .startTime ??
                                                                    l10n
                                                                        .of(
                                                                            context)
                                                                        .na)
                                                                .toString(),
                                                            style: TextStyle(
                                                                fontSize: 10,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w700,
                                                                color: Color(
                                                                    0xFF000000))),
                                                        SizedBox(height: 8),
                                                        Container(
                                                          padding: EdgeInsets
                                                              .symmetric(
                                                                  vertical: 2,
                                                                  horizontal:
                                                                      3),
                                                          decoration:
                                                              BoxDecoration(
                                                            color: Color(
                                                                    0xFF8DC63F)
                                                                .withOpacity(
                                                                    0.2), // 20% opacity
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        5),
                                                          ),
                                                          child: Column(
                                                            children: [
                                                              Row(
                                                                children: [
                                                                  Icon(
                                                                      Icons
                                                                          .calendar_month_outlined,
                                                                      color: AppColors
                                                                          .teal747D
                                                                          .withValues(
                                                                              alpha: 0.9),
                                                                      size: 12),
                                                                  SizedBox(
                                                                      width: 3),
                                                                  // Text(
                                                                  //     bookingDay,
                                                                  //     style: TextStyle(
                                                                  //         fontSize: 14,
                                                                  //         fontWeight: FontWeight.w600,
                                                                  //         color: Color(0xFF8DC63F))),
                                                                  // SizedBox(
                                                                  //     height:
                                                                  //         14,
                                                                  //     width:
                                                                  //         13,
                                                                  //     child:
                                                                  //         Image.asset("assets/icons/calender.png")),
                                                                  SizedBox(
                                                                      width: 3),
                                                                  Text(
                                                                    DateFormat(
                                                                            "dd")
                                                                        .format(
                                                                            parseToLocalDate(playAgainData.date))
                                                                        .toString(),
                                                                    // getDayFromStartTime(
                                                                    //     playAgainData.date),
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            14,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .w600,
                                                                        color: Color(
                                                                            0xFF8DC63F)),
                                                                  ),
                                                                ],
                                                              ),
                                                              Text(
                                                                DateFormat(
                                                                        "MMM, yyyy")
                                                                    .format(parseToLocalDate(
                                                                        playAgainData
                                                                            .date))
                                                                    .toString(),
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        10,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w400,
                                                                    color: Color(
                                                                        0xFF555555)),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                                SizedBox(height: 8),
                                                Divider(
                                                  thickness: 0.93,
                                                  color: Color(0xFFE3E3E3),
                                                ),
                                                SizedBox(height: 2),
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Text.rich(
                                                      TextSpan(
                                                        text: l10n
                                                            .of(context)
                                                            .typeOfBooking,
                                                        style: TextStyle(
                                                          fontSize: 10,
                                                          fontWeight:
                                                              FontWeight.w400,
                                                          color:
                                                              Color(0xFF555555),
                                                        ),
                                                        children: [
                                                          TextSpan(
                                                              text: (playAgainData
                                                                              .isSplit ==
                                                                          true
                                                                      ? l10n
                                                                          .of(
                                                                              context)
                                                                          .split
                                                                      : l10n
                                                                          .of(
                                                                              context)
                                                                          .wholeCourtBooking)
                                                                  .toString(),
                                                              style: TextStyle(
                                                                  fontSize: 10,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w700))
                                                        ],
                                                      ),
                                                    ),
                                                    Row(
                                                      children: [
                                                        Image.asset(
                                                            'assets/icons/amount.png',
                                                            width: 15,
                                                            height: 15),
                                                        SizedBox(
                                                            width: screenWidth *
                                                                0.012),
                                                        Text(
                                                          "${AppConstants.appCurrency} ${(playAgainData.price ?? 0).toString()}",
                                                          style: TextStyle(
                                                              fontSize: 10,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w700,
                                                              color:
                                                                  Colors.black),
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                                Spacer(),
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Row(
                                                      children: [
                                                        playAgainData
                                                                    .sportsIcon ==
                                                                null
                                                            ? ClipOval(
                                                                child:
                                                                    Image.asset(
                                                                  "assets/icons/sportsicon.png",
                                                                  width: 20,
                                                                  height: 20,
                                                                  fit: BoxFit
                                                                      .fill,
                                                                ),
                                                              )
                                                            : ClipOval(
                                                                child: Image
                                                                    .network(
                                                                  playAgainData
                                                                      .sportsIcon!,
                                                                  width: 20,
                                                                  height: 20,
                                                                  fit: BoxFit
                                                                      .fill,
                                                                ),
                                                              ),
                                                        SizedBox(
                                                            width: screenWidth *
                                                                0.012),
                                                        Text(
                                                            (playAgainData
                                                                        .sportName ??
                                                                    l10n
                                                                        .of(
                                                                            context)
                                                                        .na)
                                                                .toString(),
                                                            style: TextStyle(
                                                                fontSize: 12,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w600,
                                                                color: Color(
                                                                    0xFF3B747B))),
                                                      ],
                                                    ),
                                                    SizedBox(
                                                        width:
                                                            screenWidth * 0.05),
                                                    ...(availableChallengeGuestViewModel
                                                                    .loadingChallengeIndexCompleted ==
                                                                index &&
                                                            availableChallengeGuestViewModel
                                                                .isLoadCompleted
                                                        ? [
                                                            Container(
                                                              width: 140,
                                                              height: 25,
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: const Color(
                                                                    0xFF8DC63F),
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            4),
                                                              ),
                                                              child: Center(
                                                                child: Shimmer
                                                                    .fromColors(
                                                                  baseColor: Colors
                                                                      .grey
                                                                      .shade400,
                                                                  highlightColor:
                                                                      Colors
                                                                          .white,
                                                                  child:
                                                                      Container(
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                    child: Text(
                                                                      l10n
                                                                          .of(context)
                                                                          .viewBookings,
                                                                      style:
                                                                          const TextStyle(
                                                                        fontSize:
                                                                            10,
                                                                        fontWeight:
                                                                            FontWeight.w700,
                                                                        color: Colors
                                                                            .white, // Color must be present for shimmer to reflect
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            )
                                                          ]
                                                        : [
                                                            Skeleton.ignore(
                                                              child: Container(
                                                                width: 140,
                                                                height: 25,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  color: const Color(
                                                                      0xFF8DC63F),
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              4),
                                                                ),
                                                                child: Center(
                                                                  child: Text(
                                                                    playAgainData.type ==
                                                                            "Challenge"
                                                                        ? l10n
                                                                            .of(
                                                                                context)
                                                                            .rebook
                                                                        : l10n
                                                                            .of(context)
                                                                            .rebook,
                                                                    style:
                                                                        const TextStyle(
                                                                      color: Colors
                                                                          .white,
                                                                      fontSize:
                                                                          15,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w700,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            )
                                                          ]),
                                                  ],
                                                ),
                                                Spacer(),
                                              ],
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                            ]
                          : [],

                      // UPCOMING BOOKINGS
                      ...(viewModel.homeResponseModel.data?.upcomingBookings
                                  ?.isNotEmpty ??
                              false)
                          ? [
                              SizedBox(height: 20),
                              Padding(
                                padding: EdgeInsets.only(left: 14.0, right: 14),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(l10n.of(context).upcomingBookings,
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 18,
                                            fontWeight: FontWeight.w600)),
                                    ElevatedButton(
                                      onPressed: () {
                                        final viewModel =
                                            Provider.of<DashboardViewModel>(
                                                context,
                                                listen: false);
                                        viewModel.currentIndex == 1;
                                        viewModel.changeIndex(
                                          1,
                                        );
                                      },
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Color(0xFF3B747D),
                                        foregroundColor: Colors.white,
                                        minimumSize: Size(56, 26),
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(6)),
                                        padding: EdgeInsets.zero,
                                      ),
                                      child: Text(l10n.of(context).seeAll,
                                          style: TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.w500)),
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(left: 7.0, right: 7),
                                child: SizedBox(
                                  height: 220,
                                  child: ListView.builder(
                                    shrinkWrap: true,
                                    scrollDirection: Axis.horizontal,
                                    itemCount: viewModel.homeResponseModel.data
                                            ?.upcomingBookings?.length ??
                                        0,
                                    itemBuilder: (context, index) {
                                      // final opening = viewModel
                                      //     .homeResponseModel
                                      //     .data!
                                      //     .upcomingBookings![index];
                                      var opening = viewModel.homeResponseModel
                                          .data!.upcomingBookings![(viewModel
                                              .homeResponseModel
                                              .data
                                              ?.upcomingBookings
                                              ?.length)! -
                                          1 -
                                          index]; // 👈 reverse index

                                      final bookingDay = opening.date != null
                                          ? "${DateTime.parse(opening.date!).day}"
                                          : "${DateTime.now().day}";
                                      final bookingMonthYear =
                                          opening.date != null
                                              ? DateFormat('MMM yyyy').format(
                                                  DateTime.parse(opening.date!))
                                              : DateFormat('MMM yyyy')
                                                  .format(DateTime.now());

                                      return InkWell(
                                        onTap: viewModel.isLoading
                                            ? null
                                            : () {
                                                if (opening.type == "Court") {
                                                  Provider.of<HomeViewModel>(
                                                          context,
                                                          listen: false)
                                                      .getBookingDetails(
                                                          context: context,
                                                          bookingId:
                                                              opening.id ?? '',
                                                          courtId:
                                                              opening.courtId ??
                                                                  "");
                                                } else {
                                                  // if (viewModel.isLoad !=
                                                  //     true)
                                                  //     {
                                                  print("jgjgj");
                                                  availableChallengeGuestViewModel
                                                      .setLoadingChallengeIndex(
                                                          index);
                                                  availableChallengeGuestViewModel
                                                      .getChallengesDetails(
                                                          ispublic: true,
                                                          cancelChallenge:
                                                              false,
                                                          challengesId: opening
                                                                  .challengeId ??
                                                              "",
                                                          context: context,
                                                          isbuttonshow: false)
                                                      .then((_) {
                                                    availableChallengeGuestViewModel
                                                        .setLoadingChallengeIndex(
                                                            null);
                                                  });
                                                }
                                                // }
                                                // // Navigator.push(context, MaterialPageRoute(builder: (context) => BookingDetails()));
                                              },
                                        child: Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.95,
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              border: Border.all(
                                                color: Color(0xffD0D0D0),
                                              ),
                                              borderRadius:
                                                  BorderRadius.circular(5)),
                                          margin: EdgeInsets.only(right: 04),
                                          child: Padding(
                                            padding: EdgeInsets.only(
                                                right: 6, left: 6, top: 6),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    ClipRRect(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              8),
                                                      child: NetworkImageWidget(
                                                        image: opening
                                                                .courtImage ??
                                                            l10n.of(context).na,
                                                        width: 90,
                                                        height: 110,
                                                        fit: BoxFit.fill,
                                                      ),
                                                    ),
                                                    SizedBox(
                                                        width: MediaQuery.of(
                                                                    context)
                                                                .size
                                                                .width *
                                                            0.025),
                                                    Expanded(
                                                      child: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Text(
                                                              opening.bookingId ??
                                                                  "",
                                                              style: TextStyle(
                                                                  fontSize: 13,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400,
                                                                  color: Color(
                                                                      0xFF555555))),
                                                          SizedBox(
                                                            height: 2,
                                                          ),
                                                          Text(
                                                              opening.courtName
                                                                      ?.capitalizeFirstLetter() ??
                                                                  l10n
                                                                      .of(
                                                                          context)
                                                                      .na,
                                                              maxLines: 1,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              style: TextStyle(
                                                                  fontSize: 15,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w600,
                                                                  color: Colors
                                                                      .black)),
                                                          SizedBox(
                                                            height: 5,
                                                          ),
                                                          RichText(
                                                            text: TextSpan(
                                                              style: TextStyle(
                                                                  fontSize: 13,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400,
                                                                  color: Color(
                                                                      0xFF555555)),
                                                              text: l10n
                                                                  .of(context)
                                                                  .inviteCode,
                                                              children: [
                                                                TextSpan(
                                                                  text: opening
                                                                          .privatecode ??
                                                                      l10n
                                                                          .of(context)
                                                                          .na,
                                                                  style: TextStyle(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w600),
                                                                )
                                                              ],
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            height: 5,
                                                          ),
                                                          Row(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Image.asset(
                                                                  "assets/icons/rate.png",
                                                                  width: 15,
                                                                  height: 15),
                                                              SizedBox(
                                                                  width: MediaQuery.of(
                                                                              context)
                                                                          .size
                                                                          .width *
                                                                      0.012),
                                                              opening.rating !=
                                                                          null &&
                                                                      opening.rating !=
                                                                          ""
                                                                  ? Text(
                                                                      opening
                                                                          .rating
                                                                          .toString(),
                                                                      style: TextStyle(
                                                                          fontSize:
                                                                              13,
                                                                          fontWeight: FontWeight
                                                                              .w700,
                                                                          color: Color(
                                                                              0xFF555555)))
                                                                  : Text("0.0",
                                                                      style: TextStyle(
                                                                          fontSize:
                                                                              13,
                                                                          fontWeight: FontWeight
                                                                              .w700,
                                                                          color:
                                                                              Color(0xFF555555))),
                                                              SizedBox(
                                                                  width: MediaQuery.of(
                                                                              context)
                                                                          .size
                                                                          .width *
                                                                      0.012),
                                                              Text("|",
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          13,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w700,
                                                                      color: Color(
                                                                          0xFFD9D9D9))),
                                                              SizedBox(
                                                                  width: MediaQuery.of(
                                                                              context)
                                                                          .size
                                                                          .width *
                                                                      0.012),
                                                              Expanded(
                                                                child: Text(
                                                                    opening.facilityName ??
                                                                        l10n
                                                                            .of(
                                                                                context)
                                                                            .na,
                                                                    maxLines: 1,
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            11,
                                                                        color: Color(
                                                                            0xFF555555))),
                                                              ),
                                                            ],
                                                          ),
                                                          SizedBox(
                                                              height: MediaQuery.of(
                                                                          context)
                                                                      .size
                                                                      .height *
                                                                  0.005),
                                                          Row(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Image.asset(
                                                                  'assets/icons/location.png',
                                                                  width: 14,
                                                                  height: 14),
                                                              SizedBox(
                                                                  width: MediaQuery.of(
                                                                              context)
                                                                          .size
                                                                          .width *
                                                                      0.012),
                                                              Expanded(
                                                                child: Text(
                                                                    opening.facilityAddress ??
                                                                        l10n
                                                                            .of(
                                                                                context)
                                                                            .na,
                                                                    maxLines: 1,
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            12,
                                                                        color: Color(
                                                                            0xFF555555))),
                                                              ),
                                                              Text("~${((double.tryParse(opening.distance!) ?? 0) / 1000).toStringAsFixed(1)}km",
                                                                  maxLines: 1,
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          12,
                                                                      color: Color(
                                                                          0xFF555555))),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Column(
                                                      children: [
                                                        Text(
                                                            opening.startTime ??
                                                                l10n
                                                                    .of(context)
                                                                    .na,
                                                            style: TextStyle(
                                                                fontSize: 10,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w700,
                                                                color: Color(
                                                                    0xFF000000))),
                                                        SizedBox(height: 8),
                                                        Container(
                                                          padding: EdgeInsets
                                                              .symmetric(
                                                                  vertical: 2,
                                                                  horizontal:
                                                                      3),
                                                          decoration:
                                                              BoxDecoration(
                                                            color: AppColors
                                                                .greenCF3,
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        5),
                                                          ),
                                                          child: Column(
                                                            children: [
                                                              Row(
                                                                children: [
                                                                  Icon(
                                                                      Icons
                                                                          .calendar_month_outlined,
                                                                      color: AppColors
                                                                          .teal747D
                                                                          .withValues(
                                                                              alpha: 0.8),
                                                                      size: 12),
                                                                  SizedBox(
                                                                      width: 3),
                                                                  Text(
                                                                      bookingDay,
                                                                      style: TextStyle(
                                                                          fontSize:
                                                                              14,
                                                                          fontWeight: FontWeight
                                                                              .w600,
                                                                          color:
                                                                              Color(0xFF8DC63F))),
                                                                ],
                                                              ),
                                                              Text(
                                                                  bookingMonthYear,
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          10,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w600,
                                                                      color: Color(
                                                                          0xFF555555))),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                                // SizedBox(height: 8),

                                                Divider(
                                                    thickness: 0.93,
                                                    color: Color(0xFFE3E3E3)),
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Text.rich(
                                                      TextSpan(
                                                        text: l10n
                                                            .of(context)
                                                            .typeOfBooking,
                                                        style: TextStyle(
                                                            fontSize: 12,
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            color: Color(
                                                                0xFF555555)),
                                                        children: [
                                                          TextSpan(
                                                            text: opening
                                                                        .isSplit ==
                                                                    true
                                                                ? l10n
                                                                    .of(context)
                                                                    .split
                                                                : l10n
                                                                    .of(context)
                                                                    .wholeCourtBooking,
                                                            style: TextStyle(
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w700),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Row(
                                                      children: [
                                                        Image.asset(
                                                            'assets/icons/amount.png',
                                                            width: 15,
                                                            height: 15),
                                                        SizedBox(
                                                            width: MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .width *
                                                                0.010),
                                                        Text(
                                                          "${AppConstants.appCurrency} ${opening.price.toString()}",
                                                          style: TextStyle(
                                                              fontSize: 14,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w700),
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                                Divider(
                                                    thickness: 0.93,
                                                    color: Color(0xFFE3E3E3)),
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Flexible(
                                                      child: Row(children: [
                                                        opening.sportsIcon ==
                                                                null
                                                            ? ClipOval(
                                                                child:
                                                                    Image.asset(
                                                                  "assets/icons/sportsicon.png",
                                                                  width: 20,
                                                                  height: 20,
                                                                  fit: BoxFit
                                                                      .fill,
                                                                ),
                                                              )
                                                            : ClipRRect(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            25),
                                                                child: NetworkImageWidget(
                                                                    image: opening
                                                                            .sportsIcon ??
                                                                        "",
                                                                    width: 20,
                                                                    height: 20,
                                                                    fit: BoxFit
                                                                        .cover),
                                                              ),
                                                        SizedBox(width: 6),
                                                        Flexible(
                                                          child: Text(
                                                              opening.sportName ??
                                                                  l10n
                                                                      .of(
                                                                          context)
                                                                      .na,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              style: TextStyle(
                                                                  fontSize: 12,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w600,
                                                                  color: Color(
                                                                      0xFF3B747B))),
                                                        ),
                                                      ]),
                                                    ),
                                                    SizedBox(width: 6),
                                                    ValueListenableBuilder<
                                                        bool>(
                                                      valueListenable:
                                                          isSharingNotifier,
                                                      builder: (context,
                                                          isSharing, child) {
                                                        return Container(
                                                          width: 25,
                                                          height: 25,
                                                          decoration:
                                                              BoxDecoration(
                                                            color: Color(
                                                                0xFF8DC63F),
                                                            shape:
                                                                BoxShape.circle,
                                                          ),
                                                          child: isSharing
                                                              ? Padding(
                                                                  padding:
                                                                      const EdgeInsets
                                                                          .all(
                                                                          5),
                                                                  child:
                                                                      CircularProgressIndicator(
                                                                    strokeWidth:
                                                                        2,
                                                                    valueColor: AlwaysStoppedAnimation<
                                                                            Color>(
                                                                        Colors
                                                                            .white),
                                                                  ),
                                                                )
                                                              : IconButton(
                                                                  onPressed: () =>
                                                                      shareDataNew(
                                                                          'KratEasy.com/${opening.bookingId}',
                                                                          isSharingNotifier),
                                                                  icon: Image
                                                                      .asset(
                                                                    'assets/icons/share3.png',
                                                                    width: 15,
                                                                    height: 15,
                                                                  ),
                                                                  padding:
                                                                      EdgeInsets
                                                                          .zero,
                                                                ),
                                                        );
                                                      },
                                                    ),
                                                    SizedBox(width: 10),
                                                    opening.type == "Court"
                                                        ? Consumer<
                                                            MyBookingsViewModel>(
                                                            builder: (BuildContext
                                                                    context,
                                                                myBookingsViewModel,
                                                                Widget? child) {
                                                              return ElevatedButton(
                                                                onPressed:
                                                                    myBookingsViewModel
                                                                            .isCancelBookingLoading
                                                                        ? () {}
                                                                        : () {
                                                                            showDialog(
                                                                              context: context,
                                                                              builder: (BuildContext context) {
                                                                                return Dialog(
                                                                                  backgroundColor: AppColors.white,
                                                                                  child: ListView(
                                                                                    shrinkWrap: true,
                                                                                    physics: NeverScrollableScrollPhysics(),
                                                                                    children: [
                                                                                      Container(
                                                                                        width: double.infinity,
                                                                                        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 20),
                                                                                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(12)),
                                                                                        child: Column(
                                                                                          crossAxisAlignment: CrossAxisAlignment.center,
                                                                                          children: [
                                                                                            SizedBox(height: 100, width: 100, child: Image.asset(AppImages.pngDialogCancel, fit: BoxFit.fill)),
                                                                                            SizedBox(height: 10),
                                                                                            Text(l10n.of(context).areYouSure, style: TextStyle(color: AppColors.black, fontSize: 20, fontWeight: FontWeight.w600)),
                                                                                            SizedBox(height: 10),
                                                                                            Text(
                                                                                              l10n.of(context).areYouSureYouWantToCancelThisBookingIf,
                                                                                              textAlign: TextAlign.center,
                                                                                              style: TextStyle(color: AppColors.grey769, fontSize: 16, fontWeight: FontWeight.normal),
                                                                                            ),
                                                                                            SizedBox(height: 10),
                                                                                            Row(
                                                                                              children: [
                                                                                                Stack(
                                                                                                  children: [
                                                                                                    Container(height: 36, width: 130, decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.green033)),
                                                                                                    GestureDetector(
                                                                                                      onTap: () async {
                                                                                                        // Navigator.pop(context);
                                                                                                        debugPrint("fhjdj");
                                                                                                        final result = await context.read<MyBookingsViewModel>().cancelPayment(courtId: opening.courtId ?? "", bookingid: opening.bookingId ?? "");
                                                                                                        if (result)
                                                                                                          Navigator.pushNamed(
                                                                                                            context,
                                                                                                            '/dashboard',
                                                                                                          ).then((_) {
                                                                                                            // Navigator.pop(context);
                                                                                                          });
                                                                                                        else
                                                                                                          Navigator.pop(context);

                                                                                                        // myBookingsViewModel.cancelBooking(bookingId: opening.id ?? "", context: context, fromHome: true).then((_){
                                                                                                        //   setState(() {
                                                                                                        //     viewModel.homeResponseModel.data?.upcomingBookings?.remove(opening); // or bookings.removeWhere((b) => b.id == opening.id);
                                                                                                        //   });
                                                                                                        // });
                                                                                                        // HomeViewModel viewModel = HomeViewModel();
                                                                                                        // await viewModel.getHomeData();
                                                                                                      },
                                                                                                      child: Container(
                                                                                                        height: 32,
                                                                                                        width: 130,
                                                                                                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.primaryColor),
                                                                                                        child: Center(
                                                                                                          child: Text(l10n.of(context).yesConfirm, style: TextStyle(color: AppColors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                                                                                                        ),
                                                                                                      ),
                                                                                                    ),
                                                                                                  ],
                                                                                                ),
                                                                                                SizedBox(width: 6),
                                                                                                Expanded(
                                                                                                  child: AppButton(
                                                                                                    borderColor: AppColors.primaryColor,
                                                                                                    height: 30,
                                                                                                    label: l10n.of(context).cancel,
                                                                                                    bgColor: AppColors.white,
                                                                                                    textStyle: TextStyle(color: AppColors.primaryColor, fontSize: 12, fontWeight: FontWeight.w600),
                                                                                                    onPressed: () {
                                                                                                      Navigator.pop(context);
                                                                                                    },
                                                                                                  ),
                                                                                                ),
                                                                                              ],
                                                                                            ),
                                                                                          ],
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                );
                                                                              },
                                                                            );
                                                                          },
                                                                style: ElevatedButton
                                                                    .styleFrom(
                                                                  backgroundColor:
                                                                      Color(
                                                                          0xFFFFEAFA),
                                                                  foregroundColor:
                                                                      Color(
                                                                          0xFFFF0000),
                                                                  minimumSize:
                                                                      Size(50,
                                                                          25),
                                                                  shape: RoundedRectangleBorder(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              4)),
                                                                  padding:
                                                                      EdgeInsets
                                                                          .zero,
                                                                ),
                                                                child: myBookingsViewModel
                                                                        .isCancelBookingLoading
                                                                    ? CircularProgressIndicator(
                                                                        color: AppColors
                                                                            .primaryColor,
                                                                      )
                                                                    : Text(
                                                                        l10n
                                                                            .of(
                                                                                context)
                                                                            .cancel,
                                                                        style: TextStyle(
                                                                            fontSize:
                                                                                10,
                                                                            fontWeight:
                                                                                FontWeight.w700)),
                                                              );
                                                            },
                                                          )
                                                        : Consumer<
                                                            MyBookingsViewModel>(
                                                            builder: (BuildContext
                                                                    context,
                                                                myBookingsViewModel,
                                                                Widget? child) {
                                                              return ElevatedButton(
                                                                onPressed:
                                                                    myBookingsViewModel
                                                                            .isCancelBookingLoading
                                                                        ? () {}
                                                                        : () {
                                                                            showDialog(
                                                                              context: context,
                                                                              builder: (BuildContext context) {
                                                                                return Dialog(
                                                                                  backgroundColor: AppColors.white,
                                                                                  child: ListView(
                                                                                    shrinkWrap: true,
                                                                                    physics: NeverScrollableScrollPhysics(),
                                                                                    children: [
                                                                                      Container(
                                                                                        width: double.infinity,
                                                                                        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 20),
                                                                                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(12)),
                                                                                        child: Column(
                                                                                          crossAxisAlignment: CrossAxisAlignment.center,
                                                                                          children: [
                                                                                            SizedBox(height: 100, width: 100, child: Image.asset(AppImages.pngDialogCancel, fit: BoxFit.fill)),
                                                                                            SizedBox(height: 10),
                                                                                            Text(l10n.of(context).areYouSure, style: TextStyle(color: AppColors.black, fontSize: 20, fontWeight: FontWeight.w600)),
                                                                                            SizedBox(height: 10),
                                                                                            Text(
                                                                                              l10n.of(context).areYouSureYouWantToCancelThisChallengeIf,
                                                                                              textAlign: TextAlign.center,
                                                                                              style: TextStyle(color: AppColors.grey769, fontSize: 16, fontWeight: FontWeight.normal),
                                                                                            ),
                                                                                            SizedBox(height: 10),
                                                                                            Row(
                                                                                              children: [
                                                                                                Stack(
                                                                                                  children: [
                                                                                                    Container(height: 36, width: 130, decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.green033)),
                                                                                                    GestureDetector(
                                                                                                      onTap: () async {
                                                                                                        final result = await context.read<MyBookingsViewModel>().cancelPayment(courtId: opening.courtId ?? "", bookingid: opening.bookingId ?? "");
                                                                                                        if (result) {
                                                                                                          context.read<MyBookingsViewModel>().cancelChallenge(challengeID: opening?.challengeId ?? "", context: context).then((onValue) {
                                                                                                            Navigator.pushNamed(
                                                                                                              context,
                                                                                                              '/dashboard',
                                                                                                            );
                                                                                                          });
                                                                                                        } else
                                                                                                          Navigator.pop(context);

                                                                                                        //   debugPrint("dk");
                                                                                                        //   Navigator.pop(context);
                                                                                                        // await  myBookingsViewModel
                                                                                                        //       .cancelChallenge(
                                                                                                        //     challengeID: opening.challengeId ?? "",
                                                                                                        //     context: context,
                                                                                                        //   )
                                                                                                        //       .then((isSuccess) {
                                                                                                        //     if (isSuccess) {
                                                                                                        //       setState(() {
                                                                                                        //         viewModel.homeResponseModel.data?.upcomingBookings?.remove(opening);
                                                                                                        //       });
                                                                                                        //     }
                                                                                                        //   });
                                                                                                      },
                                                                                                      child: Container(
                                                                                                        height: 32,
                                                                                                        width: 130,
                                                                                                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.primaryColor),
                                                                                                        child: Center(
                                                                                                          child: Text(l10n.of(context).yesConfirm, style: TextStyle(color: AppColors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                                                                                                        ),
                                                                                                      ),
                                                                                                    ),
                                                                                                  ],
                                                                                                ),
                                                                                                SizedBox(width: 6),
                                                                                                Expanded(
                                                                                                  child: AppButton(
                                                                                                    borderColor: AppColors.primaryColor,
                                                                                                    height: 30,
                                                                                                    label: l10n.of(context).cancel,
                                                                                                    bgColor: AppColors.white,
                                                                                                    textStyle: TextStyle(color: AppColors.primaryColor, fontSize: 12, fontWeight: FontWeight.w600),
                                                                                                    onPressed: () {
                                                                                                      Navigator.pop(context);
                                                                                                    },
                                                                                                  ),
                                                                                                ),
                                                                                              ],
                                                                                            ),
                                                                                          ],
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                );
                                                                              },
                                                                            );
                                                                          },
                                                                style: ElevatedButton
                                                                    .styleFrom(
                                                                  backgroundColor:
                                                                      Color(
                                                                          0xFFFFEAFA),
                                                                  foregroundColor:
                                                                      Color(
                                                                          0xFFFF0000),
                                                                  minimumSize:
                                                                      Size(50,
                                                                          25),
                                                                  shape: RoundedRectangleBorder(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              4)),
                                                                  padding:
                                                                      EdgeInsets
                                                                          .zero,
                                                                ),
                                                                child: myBookingsViewModel
                                                                        .isCancelBookingLoading
                                                                    ? CircularProgressIndicator(
                                                                        color: AppColors
                                                                            .primaryColor,
                                                                      )
                                                                    : Text(
                                                                        l10n
                                                                            .of(
                                                                                context)
                                                                            .cancel,
                                                                        style: TextStyle(
                                                                            fontSize:
                                                                                10,
                                                                            fontWeight:
                                                                                FontWeight.w700)),
                                                              );
                                                            },
                                                          ),
                                                    SizedBox(width: 10),
                                                    if (opening.type == "Court")
                                                      ElevatedButton(
                                                        onPressed: () {
                                                          Navigator.push(
                                                              context,
                                                              MaterialPageRoute(
                                                                  builder:
                                                                      (context) =>
                                                                          ModifyBookingScreen(
                                                                            bookingId:
                                                                                opening.id ?? "",
                                                                            // courtId:
                                                                            //     opening.courtId,

                                                                            // date:
                                                                            //     DateFormat('dd-MM-yyyy').format(parseToLocalDate(opening.date)),
                                                                            // // facilityId: opening.,
                                                                            // selectedTimeSlots: [],
                                                                            // sportId: opening.sportID,
                                                                          )));
                                                        },
                                                        style: ElevatedButton
                                                            .styleFrom(
                                                          backgroundColor:
                                                              Color(0xFF3B747D),
                                                          foregroundColor:
                                                              Colors.white,
                                                          minimumSize:
                                                              Size(60, 25),
                                                          shape: RoundedRectangleBorder(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          4)),
                                                          padding:
                                                              EdgeInsets.zero,
                                                        ),
                                                        child: Text(
                                                            l10n
                                                                .of(context)
                                                                .modify,
                                                            style: TextStyle(
                                                                fontSize: 10,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w700)),
                                                      ),
                                                    SizedBox(width: 10),
                                                    viewModel.isLoading
                                                        ? Shimmer.fromColors(
                                                            baseColor:
                                                                Colors.grey,
                                                            highlightColor:
                                                                Colors.white,
                                                            child:
                                                                ElevatedButton(
                                                              onPressed: () {},
                                                              style:
                                                                  ElevatedButton
                                                                      .styleFrom(
                                                                backgroundColor:
                                                                    Color(
                                                                        0xFF555555),
                                                                foregroundColor:
                                                                    Colors
                                                                        .white,
                                                                minimumSize:
                                                                    Size(
                                                                        85, 25),
                                                                shape: RoundedRectangleBorder(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            4)),
                                                                padding:
                                                                    EdgeInsets
                                                                        .zero,
                                                              ),
                                                              child: opening
                                                                          .type ==
                                                                      "Court"
                                                                  ? Text(
                                                                      l10n
                                                                          .of(
                                                                              context)
                                                                          .viewBookings,
                                                                      style: TextStyle(
                                                                          fontSize:
                                                                              10,
                                                                          fontWeight: FontWeight
                                                                              .w700))
                                                                  : Text(
                                                                      l10n
                                                                          .of(
                                                                              context)
                                                                          .viewChallenge,
                                                                      style: TextStyle(
                                                                          fontSize:
                                                                              10,
                                                                          fontWeight:
                                                                              FontWeight.w700)),
                                                            ),
                                                          )
                                                        : Container(
                                                            padding: EdgeInsets
                                                                .symmetric(
                                                                    horizontal:
                                                                        6,
                                                                    vertical:
                                                                        6),
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          4),
                                                              color: Color(
                                                                  0xFF555555),
                                                            ),
                                                            child: Text(
                                                                opening.type ==
                                                                        "Court"
                                                                    ? l10n
                                                                        .of(
                                                                            context)
                                                                        .viewBookings
                                                                    : l10n
                                                                        .of(
                                                                            context)
                                                                        .viewChallenge,
                                                                style: TextStyle(
                                                                    color: Colors
                                                                        .white,
                                                                    fontSize:
                                                                        10,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w700)),
                                                          ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              )
                            ]
                          : [
                              // SizedBox(
                              //   height: 20,
                              // ),
                              // Center(child: Text("No Data Found")),
                              // SizedBox(
                              //   height: 20,
                              // )
                            ],

                      ///TABS BARS
                      SizedBox(height: 25),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: Container(
                          height: 50,
                          decoration: BoxDecoration(
                            color: AppColors.lightPrimaryColorFFE5,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Skeleton.ignore(
                            child: Row(
                              children: [
                                _buildTab(
                                  title: l10n.of(context).nearbyCourts,
                                  index: 0,
                                  selectedIndex: viewModel.selectedTabIndex,
                                  onTap: () => viewModel.setSelectedTabIndex(0),
                                ),
                                _buildTab(
                                  title: l10n.of(context).challenges,
                                  index: 1,
                                  selectedIndex: viewModel.selectedTabIndex,
                                  onTap: () {
                                    viewModel.setSelectedTabIndex(1);
                                    Provider.of<AvailableChallengeGuestViewModel>(
                                            NavigationService.context,
                                            listen: false)
                                        .fetchChallenges();
                                  },
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),

                      viewModel.selectedTabIndex == 0
                          ? Availablenearbycourtstab()
                          : ActiveChallengesContent(
                              isAvailable: true,
                            ),
                      // : Availablechallengestab(),
                      SizedBox(
                        height: 20,
                      ),

                      ///FOOTER
                      Center(
                        child: Image.asset(
                          'assets/logo.png', // Replace with your asset path
                          width: 72,
                          height: 43,
                          fit: BoxFit.cover,
                        ),
                      ),
                      SizedBox(height: 8), // Space between image and text
                      Text(l10n.of(context).yourSportsCommunityApp,
                          style: TextStyle(
                              color: Color(0xFF858585),
                              fontSize: 10,
                              fontWeight: FontWeight.w400),
                          textAlign: TextAlign.center),
                      SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Flexible(
                            child: TextButton(
                              onPressed: () {
                                Navigator.pushNamed(NavigationService.context,
                                    '/privacyPolicy');
                              },
                              child: Text(l10n.of(context).privacyPolicy,
                                  style: TextStyle(
                                      color: Color(0xFF8DC63F), fontSize: 12)),
                            ),
                          ),
                          Text("|",
                              style: TextStyle(
                                  color: Color(0XFFD9D9D9), fontSize: 16)),
                          TextButton(
                            onPressed: () {
                              Navigator.pushNamed(NavigationService.context,
                                  '/termsAndConditions');
                            },
                            child: Text(l10n.of(context).termsOfService,
                                style: TextStyle(
                                    color: Color(0xFF8DC63F), fontSize: 12)),
                          ),
                          Text("|",
                              style: TextStyle(
                                  color: Color(0XFFD9D9D9), fontSize: 16)),
                          TextButton(
                            onPressed: () {
                              Navigator.pushNamed(
                                  NavigationService.context, '/aboutUs');
                            },
                            child: Text(l10n.of(context).aboutUs,
                                style: TextStyle(
                                    color: Color(0xFF8DC63F), fontSize: 12)),
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      Text("V1.00.00",
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 10,
                              color: Colors.black),
                          textAlign: TextAlign.center),
                      SizedBox(height: 10),
                      Center(
                        child: Image.asset(
                          'assets/icons/footer.png',
                          // Replace with your asset path
                          width: 210,
                          height: 160,
                          fit: BoxFit.cover,
                        ),
                      ),
                      SizedBox(
                        height: 100,
                      )
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildTab({
    required String title,
    required int index,
    required int selectedIndex,
    required VoidCallback onTap,
  }) {
    bool isSelected = index == selectedIndex;
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: Duration(milliseconds: 200),
          decoration: BoxDecoration(
            color: isSelected ? Color(0xFF8DC63F) : Colors.transparent,
            borderRadius: BorderRadius.circular(10),
          ),
          alignment: Alignment.center,
          child: Text(
            title,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: isSelected ? Colors.black : AppColors.black555,
            ),
          ),
        ),
      ),
    );
  }

  void showWhatToPlayDialog(BuildContext context) async {
    final _formKey = GlobalKey<FormState>();
    final ValueNotifier<bool> isFormValid = ValueNotifier(false);
    void validateForm(HomeViewModel value) {
      final isValid = value.selectedSport != null &&
          value.selectedSkillLevel != null &&
          value.selectedTimeSlot != null;
      isFormValid.value = isValid;
    }

    bool isfill = false;
    showModalBottomSheet(
      context: context,
      useSafeArea: true,
      backgroundColor: Colors.white,
      isScrollControlled: true,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (BuildContext context) {
        return Consumer<HomeViewModel>(builder: (context, value, child) {
          return SingleChildScrollView(
            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header row
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(l10n.of(context).whatDoYouWantToPlay,
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: Color(0xFF555555))),
                      GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Image.asset('assets/icons/cross.png',
                            width: 24, height: 24),
                      ),
                    ],
                  ),
                  SizedBox(height: 18),
                  // Dropdown for sport selection

                  DropdownButtonFormField<String>(
                    value: value.selectedSport,
                    // ID
                    hint: Text(l10n.of(context).selectSports,
                        style: TextStyle(fontSize: 14)),
                    icon: Image.asset("assets/icons/lowarrow.png",
                        height: 14, width: 12),
                    items: value.sportsListModel.map((sport) {
                      return DropdownMenuItem<String>(
                        value: sport.id,
                        child: Text(sport.name ?? "",
                            style:
                                TextStyle(fontSize: 14, color: Colors.black)),
                      );
                    }).toList(),
                    onChanged: value.setSelectedSport,
                    // Will update and save
                    style: TextStyle(fontSize: 14),
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Color(0xFFF4F9EC),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: Colors.transparent),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: Colors.transparent),
                      ),
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                      hintStyle: TextStyle(fontSize: 14),
                    ),
                    validator: (value) => value == null
                        ? l10n.of(context).pleaseSelectASport
                        : null,
                  ),

                  SizedBox(height: 16),
                  // FutureBuilder for location (keeping it as is)
                  FutureBuilder<String?>(
                    future: _getSavedLocation(),
                    builder: (context, snapshot) {
                      String location = snapshot.data ??
                          l10n.of(context).locationNotFetchedPleaseTryAgain;
                      return TextFormField(
                        readOnly: true,
                        style: TextStyle(fontSize: 14),
                        decoration: _inputDecoration(location).copyWith(
                          filled: true,
                          fillColor: Color(0xFFF4F9EC),
                          suffixIcon: Padding(
                            padding: EdgeInsets.all(10),
                            child: Image.asset('assets/icons/location.png',
                                width: 10, height: 10),
                          ),
                          hintStyle: TextStyle(fontSize: 14),
                        ),
                      );
                    },
                  ),
                  SizedBox(height: 16),
                  // Dropdown for time selection
                  DropdownButtonFormField<String>(
                    decoration: InputDecoration(
                      hintText: l10n.of(context).whichTime,
                      hintStyle: TextStyle(fontSize: 14),
                      filled: true,
                      fillColor: Color(0xFFF4F9EC),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: BorderSide.none),
                    ),
                    style: TextStyle(fontSize: 14, color: Colors.black),
                    items: [
                      "12:00 AM",
                      "01:00 AM",
                      "02:00 AM",
                      "03:00 AM",
                      "04:00 AM",
                      "05:00 AM",
                      "06:00 AM",
                      "07:00 AM",
                      "08:00 AM",
                      "09:00 AM",
                      "10:00 AM",
                      "11:00 AM",
                      "12:00 PM",
                      "01:00 PM",
                      "02:00 PM",
                      "03:00 PM",
                      "04:00 PM",
                      "05:00 PM",
                      "06:00 PM",
                      "07:00 PM",
                      "08:00 PM",
                      "09:00 PM",
                      "10:00 PM",
                      "11:00 PM"
                    ]
                        .map((time) => DropdownMenuItem(
                            value: time,
                            child: Text(time, style: TextStyle(fontSize: 14))))
                        .toList(),
                    onChanged: (v) {
                      print('Selected time: $v');
                      value.setSelectedTimeSlot(
                          v); // Make sure this updates the time slot value
                    },
                    validator: (value) => value == null
                        ? l10n.of(context).pleaseSelectATime
                        : null,
                  ),

                  SizedBox(height: 16),

                  DropdownButtonFormField<String>(
                    decoration: InputDecoration(
                      filled: true,
                      hintText: l10n.of(context).skillLevel,
                      fillColor: Color(0xFFF4F9EC),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: BorderSide.none),
                    ),
                    style: TextStyle(fontSize: 14),
                    items: ['Beginner', 'Intermediate', 'Advanced']
                        .map((skill) => DropdownMenuItem(
                            value: skill,
                            child: Text(skill,
                                style: TextStyle(
                                    fontSize: 14, color: Colors.black))))
                        .toList(),
                    onChanged: (v) {
                      print('Selected skill: $v');
                      value.setSelectedSkillLevel(
                          v); // Make sure this updates the skill level
                    },
                    validator: (value) => value == null
                        ? l10n.of(context).pleaseSelectSkillLevel
                        : null,
                  ),
                  SizedBox(height: 16),
                  // Radius slider
                  ValueListenableBuilder<RangeValues>(
                    valueListenable: rangeValuesNotifier,
                    builder: (context, rangeValues, child) {
                      // Round the values to the nearest integer between 1 and 6
                      int startHour = rangeValues.start.round().clamp(1, 6);
                      int endHour = rangeValues.end.round().clamp(1, 6);

                      return Text('$startHour hr - $endHour hr',
                          style: const TextStyle(
                              fontSize: 14, color: Colors.black));
                    },
                  ),
                  ValueListenableBuilder<RangeValues>(
                    valueListenable: rangeValuesNotifier,
                    builder: (context, rangeValues, child) {
                      return RangeSlider(
                        values: rangeValues,
                        min: 1,
                        max: 6,
                        activeColor: Color(0XFF8DC63F),
                        inactiveColor: Color(0XFF3B747D),
                        labels: RangeLabels(
                          '${rangeValues.start.round()}hr',
                          '${rangeValues.end.round()}hr',
                        ),
                        onChanged: (values) {
                          rangeValuesNotifier.value = RangeValues(
                            rangeValues.start,
                            values.end < rangeValues.start
                                ? rangeValues.start
                                : values.end,
                          );
                        },
                      );
                    },
                  ),
                  SizedBox(height: 16),
                  // Apply button
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: Stack(
                      children: [
                        Container(
                          height: 52,
                          width: double.infinity,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Color(0xFF72A033)),
                        ),
                        GestureDetector(
                          onTap: value.isUserPreferencesLoading
                              ? () {}
                              : () async {
                                  if (_formKey.currentState?.validate() ??
                                      false) {
                                    // Collect the form data
                                    String sportId = value.selectedSport ?? '';
                                    String skillLevel =
                                        value.selectedSkillLevel ?? '';
                                    String timeSlot =
                                        value.selectedTimeSlot ?? '';
                                    RangeValues timeRadius =
                                        rangeValuesNotifier.value;

                                    // Calculate the midpoint of the selected range
                                    double midpoint =
                                        (timeRadius.start + timeRadius.end) / 2;

                                    // Round the midpoint to the nearest whole number
                                    int roundedTimeRadius = midpoint.round();

                                    // Ensure the value is between 1 and 6
                                    roundedTimeRadius =
                                        roundedTimeRadius.clamp(1, 6).toInt();

                                    // Convert values to lists
                                    List<String> sportIds = [sportId];
                                    List<String> skillLevels = [skillLevel];
                                    List<String> timeSlots = [timeSlot];

                                    print(".sportIds.....$sportIds");
                                    print("....skillLevels..$skillLevels");
                                    print(".timeSlots.....$timeSlots");
                                    print("....timeRadius..$roundedTimeRadius");

                                    // Submit to API
                                    await value.setUserPreferences(
                                      context: context,
                                      sportIds: sportIds,
                                      skillLevel: skillLevels,
                                      timeSlot: timeSlots,
                                      timeRadius: roundedTimeRadius
                                          .toString(), // Send the number as string
                                    );
                                  }
                                },
                          child: Container(
                            height: 47,
                            width: double.infinity,
                            decoration: BoxDecoration(
                                color: Color(0xFF8DC63F),
                                borderRadius: BorderRadius.circular(10)),
                            child: Center(
                              child: value.isUserPreferencesLoading
                                  ? CircularProgressIndicator(
                                      color: Colors.white,
                                    )
                                  : Text(l10n.of(context).apply,
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 14,
                                          fontWeight: FontWeight.w600)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 50),
                ],
              ),
            ),
          );
        });
      },
    );
  }

  String getDayFromStartTime(String? timeStr) {
    try {
      final parsedTime = DateFormat("hh:mm a").parse(timeStr ?? '');
      return DateFormat("dd").format(parsedTime);
    } catch (e) {
      print("elseeeeeee");
      return DateFormat("dd").format(DateTime.now());
    }
  }

  // Common Input Decoration for Fields
  InputDecoration _inputDecoration(String hintText) {
    return InputDecoration(
      hintText: hintText,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.transparent), // Transparent border
      ),
      enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: Colors.transparent)),
      focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: Colors.transparent)),
      filled: true,
      fillColor: Colors.white,
      // Background color
      contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 14),
    );
  }
}

Widget customFloatingActionButton(
    {required BuildContext context, required HomeViewModel viewModel}) {
  return Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: GestureDetector(
      onTap: () {
        viewModel.addChallenge(context);
      },
      child: Stack(
        children: [
          Container(
              height: 50,
              width: 250,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: AppColors.primaryColor)),
          Container(
            height: 47,
            width: 250,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              gradient: LinearGradient(
                  colors: [Color(0xFF044349), Color(0xFF61862E)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight),
            ),
            child: Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset("assets/icons/add.png", width: 20, height: 20),
                  SizedBox(width: 5),
                  Text(l10n.of(context).createChallengeBt,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

// final TextEditingController _codeController = TextEditingController();

void _showChallengeBottomSheet(BuildContext context) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.white,
    shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
    builder: (context) {
      return Stack(
        clipBehavior: Clip.none,
        children: [
          Consumer<HomeViewModel>(builder: (context, homeViewModel, child) {
            return Form(
              child: Padding(
                padding: EdgeInsets.only(
                    left: 16,
                    right: 16,
                    bottom: MediaQuery.of(context).viewInsets.bottom + 16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(height: 16),
                    Align(
                        alignment: Alignment.centerLeft,
                        child: Text(l10n.of(context).youreAlmostThere,
                            style: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.w400))),
                    SizedBox(height: 12),
                    Align(
                        alignment: Alignment.centerLeft,
                        child: Text(l10n.of(context).enterInviteChallengeCode,
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w400,
                                color: Color(0xFF555555)))),
                    SizedBox(height: 10),
                    TextFormField(
                      controller:
                          homeViewModel.challengeCodeTextEditingController,
                      style:
                          TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                      decoration: InputDecoration(
                        hintText: l10n.of(context).enterCode,
                        errorText: homeViewModel.challengeCodeErrorText,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: BorderSide(
                            color: Color.fromRGBO(59, 116, 125, 0.34),
                            width: 1.0,
                          ),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: BorderSide(
                            color: Color.fromRGBO(59, 116, 125, 0.34),
                            width: 1.0,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: BorderSide(
                            color: Color.fromRGBO(59, 116, 125, 0.34),
                            width: 2.0,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 30),
                    AppButtonCommon(
                      label: homeViewModel.isCheckCodeLoading
                          ? null
                          : l10n.of(context).joinChallenge,
                      isLoading: homeViewModel.isCheckCodeLoading,
                      isLoadingColor: AppColors.white,
                      onPressed: homeViewModel.isCheckCodeLoading
                          ? null
                          : () {
                              homeViewModel.checkChallengeCode(
                                code: homeViewModel
                                    .challengeCodeTextEditingController.text
                                    .trim(),
                                context: context,
                              );
                            },
                    ),
                    SizedBox(height: 80),
                  ],
                ),
              ),
            );
          }),
          Positioned(
            top: -55,
            right: 16,
            child: SizedBox(
              width: 30,
              height: 30,
              child: FloatingActionButton(
                backgroundColor: Colors.white,
                onPressed: () {
                  HomeViewModel(SearchCourtsApi()).clearCode();
                  Navigator.pop(context);
                },
                shape: CircleBorder(),
                child: Image.asset(
                  'assets/icons/close.png',
                  width: 17, // Adjust image size
                  height: 17,
                ),
              ),
            ),
          ),
        ],
      );
    },
  );
}
