import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/Screens/all_challenges.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:shimmer/shimmer.dart';
import '../../GlobalUtils/CircularImageStack.dart';
import '../../ViewModel/BottomNavViewModels/HomeTabsViewModel/AvailableChallengesViewModel.dart';

class Availablechallengestab extends StatefulWidget {
  const Availablechallengestab({super.key});

  @override
  State<Availablechallengestab> createState() => _AvailablechallengestabState();
}

class _AvailablechallengestabState extends State<Availablechallengestab> {
  final AvailableChallengesViewModel viewModel = AvailableChallengesViewModel();

  late AvailableChallengeGuestViewModel viewModel2;
  @override
  void initState() {
    super.initState();
    viewModel2 = context.read<AvailableChallengeGuestViewModel>();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      viewModel2.fetchChallenges();
    });
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Consumer<AvailableChallengeGuestViewModel>(
        builder: (BuildContext context, courts, Widget? child) {
          return viewModel2.isLoadingData
              ? Center(
                  child: CircularProgressIndicator(
                    color: AppColors.primaryColor,
                  ),
                )
              : courts.challengeData.isNotEmpty
                  ? Column(
                      children: [
                        SizedBox(height: 10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(l10n.of(context).availableChallenges,
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 18,
                                    fontWeight: FontWeight.w600)),
                            ElevatedButton(
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => AllChallenges()));
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Color(0xFF3B747D),
                                foregroundColor: Colors.white,
                                minimumSize: Size(56, 26),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(6)),
                                padding: EdgeInsets.zero,
                              ),
                              child: Text(l10n.of(context).viewAll,
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w500)),
                            ),
                          ],
                        ),
                        SizedBox(height: 8),
                        ListView.builder(
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemCount: courts.challengeData.length,
                          itemBuilder: (context, index) {
                            var courtData = courts.challengeData[index];
                            final imageUrls = (courtData.whoJoined ?? [])
                                .map((item) => item["image"] as String?)
                                .where((url) => url != null && url.isNotEmpty)
                                .cast<String>()
                                .toList();
                            final challengeDate = courts
                                        .challengeData[index].date !=
                                    null
                                ? DateFormat("dd MMM yyyy").format(courts
                                        .challengeData[index].date!
                                        .contains('-')
                                    ? DateFormat("dd-MM-yyyy").parse(
                                        courts.challengeData[index].date!)
                                    : DateFormat(
                                            "EEE MMM dd yyyy HH:mm:ss 'GMT'Z",
                                            'en_US')
                                        .parse(
                                            courts.challengeData[index].date!))
                                : "";
                            return Consumer<AvailableChallengeGuestViewModel>(
                                builder: (context,
                                    availableChallengeGuestViewModel, child) {
                              return GestureDetector(
                                onTap: availableChallengeGuestViewModel
                                            .loadingChallengeIndex ==
                                        index
                                    ? () {}
                                    : () {
                                        availableChallengeGuestViewModel
                                            .setLoadingChallengeIndex(index);
                                        availableChallengeGuestViewModel
                                            .getChallengesDetails(
                                                ispublic: true,
                                                cancelChallenge: false,
                                                challengesId:
                                                    courtData.id ?? "",
                                                context: context)
                                            .then((val) {
                                          availableChallengeGuestViewModel
                                              .setLoadingChallengeIndex(null);
                                        });
                                      },
                                child: Container(
                                  margin: EdgeInsets.only(
                                    bottom: 12,
                                  ),
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      border: Border.all(
                                        color: Color(0xffD0D0D0),
                                      ),
                                      borderRadius: BorderRadius.circular(5)),
                                  child: Padding(
                                    padding: EdgeInsets.all(screenWidth * 0.03),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(8),
                                              child: NetworkImageWidget(
                                                  image: (courtData.slots?.court
                                                              ?.image ??
                                                          "")
                                                      .toString(),
                                                  width: screenWidth * 0.20,
                                                  height: screenWidth * 0.25),
                                            ),
                                            SizedBox(
                                                width: screenWidth * 0.025),
                                            Expanded(
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    (courtData.slots?.court
                                                                ?.sport?.name ??
                                                            l10n.of(context).na)
                                                        .toString(),
                                                    style: TextStyle(
                                                        fontSize: 16,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        color: AppColors.black),
                                                  ),
                                                  SizedBox(height: 4),
                                                  Text(
                                                    (courtData.slots?.court
                                                                ?.name ??
                                                            l10n.of(context).na)
                                                        .toString(),
                                                    style: TextStyle(
                                                        fontSize: 14,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        color: AppColors
                                                            .greyGreen47D),
                                                  ),
                                                  SizedBox(
                                                    height: 4,
                                                  ),
                                                  Row(
                                                    children: [
                                                      Image.asset(
                                                          "assets/png/calender.png",
                                                          width: screenWidth *
                                                              0.033,
                                                          height: screenWidth *
                                                              0.033,
                                                          fit: BoxFit.cover),
                                                      SizedBox(width: 4),
                                                      Text(challengeDate,
                                                          style: TextStyle(
                                                              fontSize:
                                                                  screenWidth *
                                                                      0.026,
                                                              color: Color(
                                                                  0xFF555555))),
                                                      SizedBox(
                                                          width: screenWidth *
                                                              0.007),
                                                      Container(
                                                          width: 1,
                                                          height: screenHeight *
                                                              0.03,
                                                          color: Color(
                                                              0xffD9D9D9)),
                                                      SizedBox(
                                                          width: screenWidth *
                                                              0.007),
                                                      Text(
                                                        " ${courtData.slots?.startTime != null ? courtData.slots?.startTime.toString() : l10n.of(context).na} - ${courtData.slots?.endTime != null ? courtData.slots?.endTime.toString() : l10n.of(context).na}",
                                                        style: TextStyle(
                                                            fontSize:
                                                                screenWidth *
                                                                    0.026,
                                                            color: Color(
                                                                0xFF555555)),
                                                      ),
                                                    ],
                                                  ),
                                                  SizedBox(
                                                    height: 4,
                                                  ),
                                                  Row(
                                                    children: [
                                                      Image.asset(
                                                          "assets/png/location_grey.png",
                                                          width: screenWidth *
                                                              0.033,
                                                          height: screenWidth *
                                                              0.033,
                                                          fit: BoxFit.cover),
                                                      SizedBox(width: 4),
                                                      Flexible(
                                                        child: Text(
                                                            maxLines: 1,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            " ${courtData.slots?.court?.facility?.address ?? l10n.of(context).na} ",
                                                            style: TextStyle(
                                                                fontSize:
                                                                    screenWidth *
                                                                        0.026,
                                                                color: Color(
                                                                    0xFF555555))),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              padding: EdgeInsets.all(2),
                                              decoration: BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  border: Border.all(
                                                      width: 1,
                                                      color: AppColors
                                                          .primaryColor)),
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(50),
                                                child: NetworkImageWidget(
                                                    image: (courtData
                                                                .slots
                                                                ?.court
                                                                ?.sport
                                                                ?.image ??
                                                            "")
                                                        .toString(),
                                                    width: screenWidth * 0.07,
                                                    height: screenWidth * 0.07),
                                              ),
                                            ),
                                          ],
                                        ),
                                        Divider(),
                                        SizedBox(height: screenHeight * 0.005),
                                        Stack(
                                          children: [
                                            Container(
                                                height: 6,
                                                width: screenWidth,
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            3),
                                                    color: AppColors.grey1E1)),
                                            Container(
                                              height: 6,
                                              width: ((courtData
                                                          .whoJoined?.length)! /
                                                      (courtData.maxPlayer)) *
                                                  screenWidth,
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(3),
                                                  color:
                                                      AppColors.greyGreen47D),
                                            ),
                                          ],
                                        ),
                                        SizedBox(height: 5),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Expanded(
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Text(
                                                        "${imageUrls.length} ${l10n.of(context).players}${imageUrls.length > 1 ? l10n.of(context).s : ''} ${l10n.of(context).going}",
                                                        style: TextStyle(
                                                          fontSize:
                                                              screenWidth *
                                                                  0.040,
                                                          fontWeight:
                                                              FontWeight.normal,
                                                          color: AppColors
                                                              .blackA2A,
                                                        ),
                                                      ),
                                                      const SizedBox(height: 4),
                                                      if (imageUrls.isNotEmpty)
                                                        Center(
                                                          child:
                                                              CircularImageStackOld(
                                                            imageUrls:
                                                                imageUrls,
                                                            maxImages: 4,
                                                          ),
                                                        ),
                                                    ],
                                                  ),
                                                  Spacer(),
                                                  Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment.end,
                                                    children: [
                                                      Text(
                                                          "${l10n.of(context).outOf} ${courtData.maxPlayer.toString()}",
                                                          style: TextStyle(
                                                              fontSize:
                                                                  screenWidth *
                                                                      0.040,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .normal,
                                                              color: AppColors
                                                                  .blackA2A)),
                                                      SizedBox(height: 8),
                                                      Transform.translate(
                                                          offset: Offset(
                                                              screenWidth * .03,
                                                              screenWidth *
                                                                  .03),
                                                          child: availableChallengeGuestViewModel
                                                                      .loadingChallengeIndex ==
                                                                  index
                                                              ? Shimmer
                                                                  .fromColors(
                                                                  baseColor:
                                                                      Colors
                                                                          .grey,
                                                                  highlightColor:
                                                                      Colors
                                                                          .white,
                                                                  child:
                                                                      Container(
                                                                    padding: EdgeInsets.symmetric(
                                                                        horizontal:
                                                                            10,
                                                                        vertical:
                                                                            5),
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: AppColors
                                                                          .black,
                                                                      borderRadius: BorderRadius.only(
                                                                          topLeft: Radius.circular(
                                                                              3),
                                                                          bottomLeft: Radius.circular(
                                                                              5),
                                                                          bottomRight:
                                                                              Radius.circular(5)),
                                                                    ),
                                                                    child: Text(
                                                                      "${AppConstants.appCurrency} ${(courtData.slots?.price ?? 0).toString()} | ${l10n.of(context).joinUs}",
                                                                      style: TextStyle(
                                                                          fontSize:
                                                                              14,
                                                                          fontWeight: FontWeight
                                                                              .w900,
                                                                          color:
                                                                              Colors.white),
                                                                    ),
                                                                  ),
                                                                )
                                                              : Container(
                                                                  padding: EdgeInsets
                                                                      .symmetric(
                                                                          horizontal:
                                                                              10,
                                                                          vertical:
                                                                              5),
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    color: AppColors
                                                                        .black,
                                                                    borderRadius: BorderRadius.only(
                                                                        topLeft:
                                                                            Radius.circular(
                                                                                3),
                                                                        bottomLeft:
                                                                            Radius.circular(
                                                                                5),
                                                                        bottomRight:
                                                                            Radius.circular(5)),
                                                                  ),
                                                                  child: Text(
                                                                    "${AppConstants.appCurrency} ${(courtData.slots?.price ?? 0).toString()} | ${l10n.of(context).joinUs}",
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            14,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .w900,
                                                                        color: Colors
                                                                            .white),
                                                                  ),
                                                                )),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            });
                          },
                        ),
                      ],
                    )
                  : Center(
                      child: Padding(
                      padding: EdgeInsets.only(top: 15.0),
                      child: Text(l10n.of(context).noChallengesAvailable),
                    ));
        },
      ),
    );
  }
}
