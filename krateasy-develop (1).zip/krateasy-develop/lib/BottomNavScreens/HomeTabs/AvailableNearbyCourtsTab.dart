import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/Localization/locale_provider.dart';
import 'package:kratEasyApp/Models/search_Filter_Data_Model.dart';
import 'package:kratEasyApp/Screens/all_courts.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/utils/extension.dart';
import 'package:kratEasyApp/utils/throttle_debouncy.dart';
import 'package:kratEasyApp/utils/widgets/common_widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shimmer/shimmer.dart';

import '../../EntranceScreens/guest_booking.dart';
import 'dart:developer';

class Availablenearbycourtstab extends StatefulWidget {
  const Availablenearbycourtstab({super.key});

  @override
  State<Availablenearbycourtstab> createState() =>
      _AvailablenearbycourtstabState();
}

class _AvailablenearbycourtstabState extends State<Availablenearbycourtstab> {
  // final NearbyCourtsViewModel viewModel = NearbyCourtsViewModel();
  late NearbyCourtsViewModel viewModel1;
  // int setimeindex  =-1;

  // String? savedValue;
  // Future<void> _loadSavedData() async {
  //   final prefs = await SharedPreferences.getInstance();
  //   setState(() {
  //     savedValue = prefs.getString('language_code'); // 👈 key used while saving
  //   });
  // }
  @override
  void initState() {
    super.initState();
    viewModel1 = context.read<NearbyCourtsViewModel>();

    WidgetsBinding.instance.addPostFrameCallback((_) async {

      context.read<HomeViewModel>().setIsHomeFilter(false);
      final data = await viewModel1.newSearchCourtApiForHome(context);
      if (mounted && data != null) {
        setState(() {
          viewModel1.searchFilterDataModel = data;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final likeCourt = Provider.of<HomeViewModel>(context, listen: false);
    // double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      child: Consumer<NearbyCourtsViewModel>(
        builder: (BuildContext context, viewModel, Widget? child) {
          return (viewModel.searchFilterDataModel?.data?.isNotEmpty ?? false)
              ? Column(
                  children: [
                    SizedBox(height: 10),
                    Row(
                      crossAxisAlignment:
                          CrossAxisAlignment.center, // Center vertically
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(l10n.of(context).availableNearbyCourts,
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 18,
                                fontWeight: FontWeight.w600)),
                        InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => AllNearByCourts()));
                          },
                          child: Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 8, vertical: 5),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                color: AppColors.dark747D),
                            child: Center(
                              child: Text(l10n.of(context).viewAll,
                                  style: TextStyle(
                                      fontSize: 12,
                                      color: AppColors.white,
                                      fontWeight: FontWeight.w500)),
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 6),
                  Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: ListView.builder(
                        itemCount:
                            viewModel.searchFilterDataModel?.data?.length ?? 0,
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemBuilder: (context, index) {
                          // final isLoading =
                          //     homeViewModel.loadingIndex == index;

                          return  InkWell(
                            onTap: () async {
                              final courtId = viewModel
                                      .searchFilterDataModel?.data?[index].id ??
                                  "";

                              if (courtId == "") {
                                showSnackbar(
                                  context: context,
                                  message: l10n
                                      .of(context)
                                      .somethingWentWrongPleaseTryAgain,
                                );
                                return;
                              }
                               context.read<BookingProvider>().setownerid((viewModel
                                  .searchFilterDataModel?.data![index].facilityOwnerId.toString()??""));

                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (_) =>
                                          ViewCourtDetailsCompleteScreen(
                                            ID: courtId,isRebook: false,
                                            // starttime: setimeindex == -1
                                            //     ? ""
                                            //     : viewModel.searchFilterDataModel?.data?[index].slots?[setimeindex].startTime ?? "",
                                            //
                                            // endtime:   setimeindex == -1
                                            //     ? "":   viewModel
                                            //   .searchFilterDataModel
                                            //   ?.data?[index]
                                            //   .slots?[setimeindex].endTime??"" ,
                                          )));
                            },
                            child: Stack(
                              children: [
                                Container(
                                  padding: EdgeInsets.all(6),
                                  margin: EdgeInsets.only(
                                      bottom: screenHeight * 0.01),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5),
                                      border: Border.all(
                                          color: AppColors.greyD0D0)),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [

                                      Row(
                                        children: [
                                          SizedBox(
                                              height: 75,
                                              width: 90,
                                              child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          2.5),
                                                  child: NetworkImageWidget(
                                                      image: (viewModel
                                                                  .searchFilterDataModel
                                                                  ?.data?[index]
                                                                  .image ??
                                                              "")
                                                          .toString()))),
                                          SizedBox(width: 10),
                                          Expanded(
                                            child: Column(
                                              children: [
                                                Row(
                                                  children: [
                                                    Expanded(
                                                        child: Container(
                                                      margin: EdgeInsets.only(
                                                          right: 60),
                                                      child: Text(
                                                        context.read<LocaleProvider>().locale.languageCode =="el" ? (viewModel
                                                              .searchFilterDataModel
                                                              ?.data?[
                                                          index]
                                                              .grname ??
                                                              l10n
                                                                  .of(
                                                                  context)
                                                                  .na):   (viewModel
                                                                      .searchFilterDataModel
                                                                      ?.data?[
                                                                          index]
                                                                      .name ??
                                                                  l10n
                                                                      .of(
                                                                          context)
                                                                      .na)
                                                              .toString()
                                                              .capitalizeFirstLetter(),
                                                          maxLines: 1,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style: TextStyle(
                                                              fontSize: 16,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                              color: AppColors
                                                                  .black)),
                                                    )),
                                                  ],
                                                ),
                                                SizedBox(height: 4),
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Text(
                                                        context.read<LocaleProvider>().locale.languageCode =="el" ?  (viewModel
                                                            .searchFilterDataModel
                                                            ?.data?[
                                                        index]
                                                            .grsportname ??
                                                            l10n
                                                                .of(context)
                                                                .na):     (viewModel
                                                                    .searchFilterDataModel
                                                                    ?.data?[
                                                                        index]
                                                                    .sportname ??
                                                                l10n
                                                                    .of(context)
                                                                    .na)
                                                            .toString()
                                                            .capitalizeFirstLetter(),
                                                        maxLines: 1,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        style: TextStyle(
                                                            fontSize: 13,
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            color: AppColors
                                                                .black)),
                                                  ],
                                                ),
                                                SizedBox(height: 4),
                                                Row(
                                                  children: [
                                                    SizedBox(
                                                        width: 16,
                                                        height: 16,
                                                        child: Image.asset(
                                                            'assets/icons/rate.png',
                                                            fit: BoxFit.fill)),
                                                    SizedBox(width: 4),
                                                    Text(
                                                        (viewModel
                                                                    .searchFilterDataModel
                                                                    ?.data?[
                                                                        index]
                                                                    .averageRating ??
                                                                0)
                                                            .toString(),
                                                        style: TextStyle(
                                                            fontSize: 13,
                                                            fontWeight:
                                                                FontWeight.w700,
                                                            color: AppColors
                                                                .black555)),
                                                    Container(
                                                        margin: EdgeInsets
                                                            .symmetric(
                                                                horizontal: 3),
                                                        width: 1,
                                                        height: 15,
                                                        color:
                                                            AppColors.greyD9D9),
                                                    Text(
                                                        context.read<LocaleProvider>().locale.languageCode =="el" ? (viewModel
                                                            .searchFilterDataModel
                                                            ?.data?[
                                                        index]
                                                            .facility
                                                            ?.grname ??
                                                            l10n
                                                                .of(context)
                                                                .na)
                                                            .toString():   (viewModel
                                                                    .searchFilterDataModel
                                                                    ?.data?[
                                                                        index]
                                                                    .facility
                                                                    ?.name ??
                                                                l10n
                                                                    .of(context)
                                                                    .na)
                                                            .toString(),
                                                        style: TextStyle(
                                                            fontSize: 11,
                                                            fontWeight:
                                                                FontWeight
                                                                    .normal,
                                                            color: AppColors
                                                                .black555)),
                                                  ],
                                                ),
                                                SizedBox(height: 5),
                                                Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    SizedBox(
                                                        width: 16,
                                                        height: 16,
                                                        child: Image.asset(
                                                            AppImages
                                                                .pngLocationGrey,
                                                            fit: BoxFit.fill)),
                                                    SizedBox(width: 4),
                                                    Expanded(
                                                      child: Row(
                                                        children: [
                                                          Expanded(
                                                            child: Text(
                                                              (viewModel
                                                                          .searchFilterDataModel
                                                                          ?.data?[
                                                                              index]
                                                                          .facility
                                                                          ?.address ??
                                                                      l10n
                                                                          .of(context)
                                                                          .na)
                                                                  .toString(),
                                                              maxLines: 1,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              style: TextStyle(
                                                                  fontSize: 11,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400,
                                                                  color: AppColors
                                                                      .black555),
                                                            ),
                                                          ),
                                                          Text(
                                                            " (~${((viewModel.searchFilterDataModel?.data?[index].facility?.distance ?? 0) / 1000).toStringAsFixed(1)} kms)",
                                                            style: TextStyle(
                                                                fontSize: 11,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w400,
                                                                color: AppColors
                                                                    .black555),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    SizedBox(width: 4),
                                                    Text(
                                                      "${AppConstants.appCurrency} ${viewModel.searchFilterDataModel?.data?[index].slots?.firstOrNull?.price ?? 0}",
                                                      style: TextStyle(
                                                          fontSize: 13,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color:
                                                              AppColors.black),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(height: 10),
                                      Container(
                                          width: double.infinity,
                                          height: 1,
                                          color: AppColors.grey3E3),
                                      SizedBox(height: 10),
                                         Consumer<NearbyCourtsViewModel>(
                                        builder: (context, viewModel, _) {
                                          return SingleChildScrollView(
                                            scrollDirection: Axis.horizontal,
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              mainAxisSize: MainAxisSize.min,
                                              children: List.generate(
                                                  viewModel
                                                          .searchFilterDataModel
                                                          ?.data?[index]
                                                          .slots
                                                          ?.length ??
                                                      0, (timeIndex) {
                                                    // log("data ${context.read<BookingProvider>().selectedSlots}");
                                                    // bool isSelected = context.read<BookingProvider>().selectedSlotIds.contains( viewModel
                                                    //     .searchFilterDataModel
                                                    //     ?.data?[index]
                                                    //     .slots?[timeIndex].id);
                                                bool isSelected =
                                                    viewModel.getSelectedIndex(
                                                            index) ==
                                                        timeIndex;
                                                var slotData = viewModel
                                                    .searchFilterDataModel
                                                    ?.data?[index]
                                                    .slots?[timeIndex];

                                                return  Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          right: 10),
                                                  child:viewModel.isTapLoading?Shimmer.fromColors(
                                                    baseColor: Colors.grey[300]!,
                                                    highlightColor: Colors.grey[100]!,
                                                    child: Container(
                                                      width: 80,
                                                      height: 40,
                                                      decoration: BoxDecoration(
                                                        color: Colors.white,
                                                        borderRadius: BorderRadius.circular(9),
                                                      ),
                                                    ),
                                                  ):  GestureDetector(
                                                      onTap: () async {
                                                        viewModel.setLoading(true);
                                                        final bookingProvider = context.read<BookingProvider>();

                                                        bookingProvider.setownerid(
                                                          viewModel.searchFilterDataModel?.data![index].facilityOwnerId?.toString() ?? "",
                                                        );

                                                        viewModel.updateSelectedIndex(index, timeIndex);

                                                        // ✅ Wait for details to load
                                                        await likeCourt.getCourtDetails(
                                                          courtId: viewModel.searchFilterDataModel?.data?[index].id ?? "",
                                                          context: context,
                                                        );

                                                        final courtId = viewModel.searchFilterDataModel?.data?[index].id ?? "";
                                                        final facilityId = likeCourt.courtDetailsModel.data?.facilityId?.id ?? "";

                                                        Navigator.push(
                                                          context,
                                                          MaterialPageRoute(
                                                            builder: (_) => GuestBookingScreen(
                                                              courtId: courtId,
                                                              date: DateFormat('dd-MM-yyyy').format(DateTime.now()),
                                                              facilityId: facilityId,
                                                              selectedTimeSlots: [
                                                                viewModel.searchFilterDataModel?.data?[index].slots?[timeIndex].id ?? ""
                                                              ],
                                                            ),
                                                          ),
                                                        );
                                                        viewModel.setLoading(false);
                                                      },

//                                                     onTap: () async {
//                                                       // setState(() {
//                                                       //   setimeindex = timeIndex;
//                                                       // });
//                                                       context.read<BookingProvider>().setownerid((viewModel
//                                                           .searchFilterDataModel?.data![index].facilityOwnerId.toString()??""));
//                                                       viewModel
//                                                           .updateSelectedIndex(
//                                                               index, timeIndex);
//                                                       await likeCourt
//                                                           .getCourtDetails(
//                                                               courtId: viewModel
//                                                                       .searchFilterDataModel
//                                                                       ?.data?[
//                                                                           index]
//                                                                       .id ??
//                                                                   "",
//                                                               context: context)
//                                                           .then((_) async{
//                                                         Navigator.push(
//                                                           context,
//                                                           MaterialPageRoute(
//                                                             builder: (_) =>
//                                                                 GuestBookingScreen(
//                                                               // final likeCourt = Provider.of<HomeViewModel>(context, listen: false);
//                                                               courtId: viewModel
//                                                                       .searchFilterDataModel
//                                                                       ?.data?[
//                                                                           index]
//                                                                       .id ??
//                                                                   "",
//                                                               // likeCourt.courtDetailsModel.data?.id ?? "",
//                                                               date: DateFormat(
//                                                                       'dd-MM-yyyy')
//                                                                   .format(DateTime
//                                                                       .now()),
//                                                               // use the formatted date
//                                                               facilityId: likeCourt
//                                                                       .courtDetailsModel
//                                                                       .data
//                                                                       ?.facilityId
//                                                                       ?.id ??
//                                                                   "",
//                                                               selectedTimeSlots: [
//                                                                 viewModel
//                                                                     .searchFilterDataModel
//                                                                     ?.data?[index]
//                                                                     .slots?[timeIndex].id??""
//                                                               ],
//                                                             ),
//                                                           ),
//                                                         );
// //
//
//                                                       });
//                                                     },
                                                    child: Container(
                                                      padding: const EdgeInsets
                                                          .symmetric(
                                                          horizontal: 14,
                                                          vertical: 10),
                                                      decoration: BoxDecoration(
                                                          color: isSelected
                                                              ? Color(
                                                                  0xFF8DC63F)
                                                              : Color(
                                                                  0xFFF4F9EC),
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(9)),
                                                      child: Center(
                                                        child: Text(
                                                          (slotData?.startTime)
                                                              .toString(),
                                                          style: TextStyle(
                                                              fontSize: 13,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w700,
                                                              color: isSelected
                                                                  ? Colors.white
                                                                  : Color(
                                                                      0xFF858585)),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                );
                                              }),
                                            ),
                                          );
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                                // Positioned Circular Icon
                                Positioned(
                                  top: 5,
                                  right: 5,
                                  child: Column(
                                    children: [
                                      SizedBox(height: 2),
                                      Container(
                                        padding: EdgeInsets.symmetric(
                                            vertical: 2, horizontal: 3),
                                        decoration: BoxDecoration(
                                            color: AppColors.greenCF3,
                                            borderRadius:
                                                BorderRadius.circular(5)),
                                        child: Column(
                                          children: [
                                            Row(
                                              children: [
                                                Icon(
                                                    Icons
                                                        .calendar_month_outlined,
                                                    color: AppColors.teal747D
                                                        .withValues(alpha: 0.8),
                                                    size: 14),
                                                SizedBox(width: 3),
                                                Text(
                                                    DateFormat("d").format(
                                                        parseToLocalDate(viewModel
                                                            .searchFilterDataModel
                                                            ?.data?[index]
                                                            .date)),
                                                    style: TextStyle(
                                                        fontSize: 18,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        color: AppColors
                                                            .primaryColor)),
                                              ],
                                            ),
                                            Text(
                                                DateFormat("MMM yyyy").format(
                                                    parseToLocalDate(viewModel
                                                        .searchFilterDataModel
                                                        ?.data?[index]
                                                        .date)),
// ,
//                                                     DateFormat("MMM yyyy")
//                                                         .format(
//                                                       DateTime.tryParse(viewModel
//                                                                   .searchFilterDataModel
//                                                                   ?.data?[index]
//                                                                   .date ??
//                                                               '') ??
//                                                           DateTime.now(),
//                                                     ),
                                                style: TextStyle(
                                                    fontSize: 10,
                                                    fontWeight: FontWeight.w600,
                                                    color: AppColors.black555)),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                )
              : Center(
                  child: Padding(
                  padding: EdgeInsets.only(top: 15.0),
                  child: Text(l10n.of(context).noCourtsAvailable),
                ));
        },
      ),
    );
  }
}
