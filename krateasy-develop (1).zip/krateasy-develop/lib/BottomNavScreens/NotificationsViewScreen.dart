import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/GlobalUtils/date_time_formate.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/services/local/local_keys.dart';
import 'package:kratEasyApp/utils/widgets/common_widgets.dart';
import '../GlobalUtils/SideDrawerScreen.dart';

class NotificationsViewScreen extends StatefulWidget {
  const NotificationsViewScreen({super.key});

  @override
  State<NotificationsViewScreen> createState() => _NotificationsViewScreenState();
}

class _NotificationsViewScreenState extends State<NotificationsViewScreen> {
  late NotificationsViewModel viewModelNotification;

  @override
  void initState() {
    viewModelNotification = context.read<NotificationsViewModel>();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      viewModelNotification.getNotificationListData(context: context);
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = Provider.of<NotificationsViewModel>(context);
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Consumer<MyAccountViewModel>(
          builder: (BuildContext context, myAccountViewModel, Widget? child) {
            return Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text("${l10n.of(context).notifications}",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 16),),

                      SizedBox(height: 5),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
        leading: Builder(builder: (context) => IconButton(icon: Image.asset('assets/icons/drawer.png', width: 30, height: 30), onPressed: () => Scaffold.of(context).openDrawer())),
        actions: [
          Consumer<MyAccountViewModel>(
            builder: (BuildContext context, myAccountViewModel, Widget? child) {


              return GestureDetector(
                onTap: (){
                  Navigator.pushNamed(NavigationService.context, '/myAccount');

                },
                child: Builder(
                  builder: (context) {
                    String image = "";
                    bool isAvailable = false;
                    if (LocalService.instance.getData(LocalKeys.instance.userImage) != null && LocalService.instance.getData(LocalKeys.instance.userImage) != "") {
                      image = myAccountViewModel.image.toString() ?? "";
                      isAvailable = true;
                    } else {
                      image = 'assets/icons/user.png';
                    }
                    printLog("Image Drawer : $image");
                    return isAvailable
                        ? ClipRRect(borderRadius: BorderRadius.circular(37), child: NetworkImageWidget(width: 37, height: 37, image: myAccountViewModel.userImage.toString()))
                        : ClipRRect(
                            borderRadius: BorderRadius.circular(37),
                            child: Image.asset(image, height: 37, width: 37),
                          );
                  },
                ),
              );
            },
          ),
          SizedBox(width: 16)
        ],
      ),
      drawer: SideDrawerScreen(),
      body: Consumer<NotificationsViewModel>(builder: (context, viewModelNotification, _) {
        return SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Divider(height: 1, thickness: 1, color: Color(0xFF8DC63F)),
              SizedBox(
                height: 5,
              ),
              // Notification Section
              viewModel.searchNotificationModel.isEmpty
                  ? SizedBox()
                  : Padding(
                      padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.04, vertical: screenHeight * 0.012),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(l10n.of(context).notifications, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.black)),
                          GestureDetector(
                            onTap: () {
                              // Trigger popup menu
                              showMenu(
                                context: context,
                                position: RelativeRect.fromLTRB(
                                  screenWidth * 0.75, // X position
                                  screenHeight * 0.17, // Y position
                                  0.0, // width of the menu
                                  0.0, // height of the menu
                                ),
                                items: [
                                  PopupMenuItem(
                                    value: 'readAll',
                                    child: InkWell(
                                      onTap: () {
                                        viewModel.notificationModel.isEmpty ? normalSnackBar(context: context, msg: l10n.of(context).cantReadNotificationNotFound) :
                                        viewModelNotification.readNotification(context: context);
                                        Navigator.pop(context);
                                      },
                                      child: Row(
                                        children: [
                                          Image.asset('assets/icons/readall.png', height: 18, width: 18),
                                          SizedBox(width: 8),
                                          Text(l10n.of(context).readAllNew, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Colors.black)),
                                        ],
                                      ),
                                    ),
                                  ),
                                  PopupMenuItem(
                                    value: 'unreadAll',
                                    child: InkWell(
                                      onTap: () {
                                        viewModel.notificationModel.isEmpty ? normalSnackBar(context: context, msg: l10n.of(context).cantUnreadNotificationNotFound) : viewModelNotification.unreadNotification(context: context);
                                        Navigator.pop(context);
                                      },
                                      child: Row(
                                        children: [
                                          Image.asset('assets/icons/unreadall.png', height: 16, width: 16),
                                          SizedBox(width: 8),
                                          Text(l10n.of(context).unreadAll, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Colors.black)),
                                        ],
                                      ),
                                    ),
                                  ),
                                  PopupMenuItem(
                                    value: 'deleteAll',
                                    child: InkWell(
                                      onTap: () {
                                        viewModel.notificationModel.isEmpty ? normalSnackBar(context: context, msg: l10n.of(context).cantDeleteNotificationNotFound) : viewModelNotification.deleteNotification(context: context);
                                        Navigator.pop(context);
                                      },
                                      child: Row(
                                        children: [
                                          Image.asset('assets/icons/deleteall.png', height: 16, width: 16),
                                          SizedBox(width: 8),
                                          Text(l10n.of(context).deleteAll, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Colors.black)),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                                elevation: 8.0,
                                color: Colors.white,
                              ).then((value) {
                                if (value != null) {
                                  // Handle selection
                                  switch (value) {
                                    case 'readAll':
                                      // Implement "Read All" action
                                      break;
                                    case 'unreadAll':
                                      // Implement "Unread All" action
                                      break;
                                    case 'deleteAll':
                                      // Implement "Delete All" action
                                      break;
                                  }
                                }
                              });
                            },
                            child: Image.asset("assets/icons/notFrame.png", height: 18, width: 18),
                          ),
                        ],
                      ),
                    ),


              // Body: Loading Indicator or Notification List

              Expanded(
                child: viewModel.isLoadingData
                    ? Center(child: CircularProgressIndicator(color: AppColors.primaryColor))
                    : viewModel.searchNotificationModel.isEmpty
                        ? Center(child: Text(l10n.of(context).noNotificationsAvailable, style: TextStyle(fontSize: screenWidth * 0.04)))
                        : RefreshIndicator(
                            color: AppColors.primaryColor,
                            backgroundColor: AppColors.white,
                            onRefresh: () async {
                              await viewModel.getNotificationListData(context: context);
                            },
                            child: ListView.builder(
                              padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.04),
                              itemCount: viewModel.searchNotificationModel.length,
                              itemBuilder: (context, index) {
                                final notification = viewModel.searchNotificationModel[index];

                                return Dismissible(
                                  key: ValueKey(notification.id),
                                  direction: DismissDirection.endToStart,
                                  onDismissed: (direction) {
                                    // Remove notification from the list
                                    viewModel.deleteNotification(context: context, id: notification.id);
                                    viewModel.searchNotificationModel.removeWhere((item) => item.id == notification.id);
                                  },
                                  background: Container(
                                    margin: EdgeInsets.only(bottom: screenHeight * 0.015),
                                    alignment: Alignment.centerRight,
                                    padding: EdgeInsets.only(right: 20),
                                    color: Colors.red,
                                    child: SizedBox(height: 25, width: 25, child: Image.asset("assets/icons/delete2.png", color: AppColors.white, fit: BoxFit.fill)),
                                  ),
                                  child: InkWell(
                                    onTap: () {
                                      viewModel.notificationRedirection(notification);

                                      if (!(notification.isRead ?? true)) {
                                        viewModel.readNotification(context: context, id: notification.id);
                                      }
                                    },
                                    child: Card(
                                      color: Colors.white,
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5), side: BorderSide(color: Color(0XFFD0D0D0), width: 1.17)),
                                      elevation: 0,
                                      margin: EdgeInsets.only(bottom: screenHeight * 0.015),
                                      child: ListTile(
                                        leading: CircleAvatar(
                                          backgroundColor: Colors.transparent,
                                          child: Image.asset("assets/icons/notifier.png", width: screenWidth * 0.2, height: screenWidth * 0.2, fit: BoxFit.cover),
                                        ),
                                        title: Text(notification.title ?? "", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
                                        subtitle: Row(
                                          children: [
                                            Image.asset("assets/icons/calendarclock.png", width: 14, height: 14),
                                            SizedBox(width: screenWidth * 0.012),
                                            Text(formatDateToDayMonthYear(notification.createdAt ?? ""), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: Color(0xFF676769))),
                                          ],
                                        ),
                                        trailing: notification.isRead == true
                                            ? SizedBox()
                                            : Container(
                                                width: 10,
                                                height: 10,
                                                decoration: BoxDecoration(
                                                  color: Color(0xFF8DC63F),
                                                  shape: BoxShape.circle,
                                                ),
                                              ),
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
              ),
            ],
          ),
        );
      }),
    );
  }
}
