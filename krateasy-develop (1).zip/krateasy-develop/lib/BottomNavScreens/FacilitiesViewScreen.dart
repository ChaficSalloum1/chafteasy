import 'dart:convert';

import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/utils/extension.dart';
import 'package:kratEasyApp/utils/widgets/common_widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../GlobalUtils/SideDrawerScreen.dart';
import '../GlobalUtils/app_imports.dart';
import '../plugin/editedd_date_picker.dart';

class FacilitiesViewScreen extends StatefulWidget {
  final String? sportId;
  const FacilitiesViewScreen(
      {super.key, this.forSelection, this.onSelect, this.sportId});

  final bool? forSelection;
  final VoidCallback? onSelect;

  @override
  State<FacilitiesViewScreen> createState() => _FacilitiesViewScreenState();
}

class _FacilitiesViewScreenState extends State<FacilitiesViewScreen> {
  var lat;
  var long;

  final FocusNode searchFocusNode = FocusNode();
  ////
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      Provider.of<FacilitiesViewModel>(NavigationService.context, listen: false)
          .getFacilitiesData(context: context);
      Provider.of<ChooseSportsViewModel>(context, listen: false).fetchSports();
      SharedPreferences prefs = await SharedPreferences.getInstance();
      lat = await prefs.getDouble("current_lat");
      long = await prefs.getDouble("current_long");

      searchFocusNode.requestFocus();
    });
  }

  late FacilitiesViewModel facilitiesViewModel;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    facilitiesViewModel =
        Provider.of<FacilitiesViewModel>(context, listen: false);
  }

  double minPrice = 1;
  double maxPrice = 100;
  double radius = 50;

  double minRadius = 1;
  double maxRadius = 25;

  double minRating = 1;
  double maxRating = 5;
  @override
  Widget build(BuildContext context) {
    // final viewModel = Provider.of<FacilitiesViewModel>(context);

    // Fetch username from DashboardViewModel
    // final username = Provider.of<DashboardViewModel>(context).userName;
    return LayoutBuilder(
      builder: (context, constraints) {
        double screenWidth = constraints.maxWidth;
        double screenHeight = constraints.maxHeight;
        return Consumer<FacilitiesViewModel>(
          builder: (BuildContext context, viewModel, Widget? child) {
            return Scaffold(
              backgroundColor: Colors.white,
              appBar: widget.forSelection == true
                  ? CommonAppBar(
                      title: l10n.of(context).selectFacility,
                      backIconColor: Colors.white,
                      backgroundColor: Colors.white,
                    )
                  : AppBar(
                      backgroundColor: Colors.white,
                      elevation: 1,
                      leading: Builder(
                        builder: (context) {
                          return IconButton(
                              icon: Image.asset('assets/icons/drawer.png',
                                  width: 30, height: 30),
                              onPressed: () =>
                                  Scaffold.of(context).openDrawer());
                        },
                      ),
                      title: viewModel.isSearch
                          ? Builder(
                              builder: (context) {
                                // Delayed focus to allow widget to be fully built first
                                // WidgetsBinding.instance.addPostFrameCallback((_) {
                                //   FocusScope.of(context).requestFocus(viewModel.searchFocusNode);
                                // });

                                return TextFormField(
                                  controller: viewModel.searchController,
                                  focusNode: searchFocusNode,
                                  onChanged: (value) {
                                    viewModel.searchFacilityList(value);
                                  },
                                  decoration: InputDecoration(
                                    isDense: true,
                                    hintText: l10n.of(context).searchFacility,
                                    border: InputBorder.none,
                                  ),
                                );
                              },
                            )
                          : Text(
                              l10n.of(context).listOfFacilities,
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: screenWidth * 0.05,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                      actions: [
                        IconButton(
                            onPressed: () {
                              viewModel.searchStatus();
                              viewModel.isSearch
                                  ? searchFocusNode.requestFocus()
                                  : searchFocusNode.unfocus();
                            },
                            icon: viewModel.isSearch
                                ? Icon(Icons.clear)
                                : Image.asset('assets/icons/search.png',
                                    width: screenWidth * 0.08,
                                    height: screenWidth * 0.08)),
                        // Usage in your IconButton
                        IconButton(
                          icon: Image.asset('assets/icons/filter.png',
                              width: screenWidth * 0.07,
                              height: screenWidth * 0.07),
                          onPressed: () {
                            showDialog(
                              barrierDismissible: false,
                              context: context,
                              builder: (context) {
                                final viewModel =
                                    Provider.of<FacilitiesViewModel>(context,
                                        listen: false);
                                final sortItems = viewModel.sortItems;
                                final sportsItems = viewModel.sportsItems;
                                final courtItems = viewModel.courtItems;
                                final timeItems = viewModel.timeItems;
                                List<String> selectedSports = [];
                                List<String> selectedCourtType = [];
                                List<String> selectedTime = [];
                                // Validation error flags
                                bool sortError = false;
                                bool sportsError = false;
                                bool dateError = false;
                                bool timeError = false;
                                bool amenitiesError = false;

                                bool isclick = false;


                                return Dialog(
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12)),
                                  insetPadding: EdgeInsets.all(16),
                                  child: DraggableScrollableSheet(
                                    initialChildSize: 0.9,
                                    maxChildSize: 0.95,
                                    minChildSize: 0.5,
                                    expand: false,
                                    builder: (context, scrollController) {
                                      return StatefulBuilder(
                                        builder: (context, setStateModal) {
                                          return LayoutBuilder(
                                            builder: (context, constraints) {
                                              double paddingSize =
                                                  constraints.maxWidth * 0.05;
                                              double fontSize =
                                                  constraints.maxWidth * 0.05;
                                              return Container(
                                                padding:
                                                    EdgeInsets.all(paddingSize),
                                                child: SingleChildScrollView(
                                                  child: Consumer<
                                                      FacilitiesViewModel>(
                                                    builder:
                                                        (BuildContext context,
                                                            facilityViewModel,
                                                            Widget? child) {
                                                      return Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            children: [
                                                              Text(
                                                                l10n
                                                                    .of(context)
                                                                    .filter,
                                                                style:
                                                                    TextStyle(
                                                                  fontSize:
                                                                      fontSize,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                ),
                                                              ),
                                                              GestureDetector(
                                                                onTap: () =>
                                                                    Navigator.pop(
                                                                        context),
                                                                child:
                                                                    Container(
                                                                  padding:
                                                                      EdgeInsets
                                                                          .all(
                                                                              2),
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    shape: BoxShape
                                                                        .circle,
                                                                    border: Border.all(
                                                                        width:
                                                                            1.5,
                                                                        color: AppColors
                                                                            .black),
                                                                  ),
                                                                  child: Icon(
                                                                      Icons
                                                                          .close,
                                                                      size: fontSize *
                                                                          1.2),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                          Divider(),
                                                          // Sort Dropdown
                                                          Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              DropdownButtonFormField<
                                                                  String>(
                                                                decoration:
                                                                    InputDecoration(
                                                                  filled: true,
                                                                  fillColor: Color(
                                                                      0xFFF4F9EC),
                                                                  border:
                                                                      OutlineInputBorder(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            8.0),
                                                                    borderSide:
                                                                        BorderSide
                                                                            .none,
                                                                  ),
                                                                  contentPadding:
                                                                      EdgeInsets.symmetric(
                                                                          horizontal:
                                                                              paddingSize),
                                                                  errorText: sortError
                                                                      ? l10n
                                                                          .of(context)
                                                                          .pleaseSelectASortingOption
                                                                      : null,
                                                                ),
                                                                icon: SizedBox(
                                                                  height: 24,
                                                                  width: 24,
                                                                  child: Image
                                                                      .asset(
                                                                          'assets/icons/sort.png'),
                                                                ),
                                                                hint: Text(l10n
                                                                    .of(context)
                                                                    .sort),
                                                                value: viewModel
                                                                    .selectedSort,
                                                                isExpanded:
                                                                    true,
                                                                onChanged:
                                                                    (value) {
                                                                  if (value !=
                                                                      null) {
                                                                    final selected =
                                                                        sortItems.firstWhere((item) =>
                                                                            item['sort'] ==
                                                                            value);
                                                                    setStateModal(
                                                                        () {
                                                                      viewModel
                                                                              .selectedSort =
                                                                          value;
                                                                      viewModel
                                                                              .selectedSortName =
                                                                          selected[
                                                                              'name'];
                                                                      viewModel
                                                                              .selectedSortOrder =
                                                                          selected[
                                                                              'sortOrder'];
                                                                      sortError =
                                                                          false; // Reset error on selection
                                                                    });
                                                                    setState(
                                                                        () {
                                                                      isclick =
                                                                          true;
                                                                    });
                                                                  }
                                                                },
                                                                items: sortItems
                                                                    .map(
                                                                        (item) {
                                                                  return DropdownMenuItem<
                                                                      String>(
                                                                    value: item[
                                                                        'sort'],
                                                                    child: Text(
                                                                        item[
                                                                            'name']),
                                                                  );
                                                                }).toList(),
                                                              ),
                                                            ],
                                                          ),
                                                          SizedBox(height: 10),
                                                          // Sports Dropdown
                                                          Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              // Container(
                                                              //   decoration:
                                                              //       BoxDecoration(
                                                              //     color: Color(
                                                              //         0xFFF4F9EC),
                                                              //     borderRadius:
                                                              //         BorderRadius
                                                              //             .circular(
                                                              //                 8.0),
                                                              //   ),
                                                              //   padding: EdgeInsets
                                                              //       .symmetric(
                                                              //           horizontal:
                                                              //               12.0),
                                                              //   child:
                                                              //       DropdownButtonHideUnderline(
                                                              //     child: DropdownButton<
                                                              //         SportList>(
                                                              //       icon:
                                                              //           SizedBox(
                                                              //         height:
                                                              //             16,
                                                              //         width: 16,
                                                              //         child: Image
                                                              //             .asset(
                                                              //                 'assets/icons/lowarrow.png'),
                                                              //       ),
                                                              //       hint: Text(
                                                              //         selectedSports.isNotEmpty
                                                              //             ? selectedSports
                                                              //                 .last
                                                              //             : S
                                                              //                 .of(context)
                                                              //                 .selectSport,
                                                              //         overflow:
                                                              //             TextOverflow
                                                              //                 .ellipsis,
                                                              //       ),
                                                              //       isExpanded:
                                                              //           true,
                                                              //       onChanged:
                                                              //           (value) {
                                                              //         viewModel.selectFaciliity(
                                                              //             value!,
                                                              //             true);
                                                              //         setState(
                                                              //             () {
                                                              //           isclick =
                                                              //               true;
                                                              //         });
                                                              //         List<String> facilityIdList = viewModel
                                                              //             .selectedFacilityList
                                                              //             .map((facility) =>
                                                              //                 facility.id)
                                                              //             .toList();
                                                              //         viewModel
                                                              //             .setSportsIdsList(
                                                              //                 facilityIdList);
                                                              //         setStateModal(
                                                              //             () {
                                                              //           sportsError =
                                                              //               false; // Reset error on selection
                                                              //         });
                                                              //       },
                                                              //       items: viewModel
                                                              //           .facilityList
                                                              //           .map(
                                                              //               (sport) {
                                                              //         return DropdownMenuItem<
                                                              //             SportList>(
                                                              //           value:
                                                              //               sport,
                                                              //           child: Text(
                                                              //               sport.name),
                                                              //         );
                                                              //       }).toList(),
                                                              //     ),
                                                              //   ),
                                                              // ),
                                                              // This is the main widget inside your Column
                                                              Container(
                                                                decoration: BoxDecoration(
                                                                  color: Color(0xFFF4F9EC),
                                                                  borderRadius: BorderRadius.circular(8.0),
                                                                ),
                                                                padding: EdgeInsets.symmetric(horizontal: 12.0),
                                                                child: InkWell(
                                                                  onTap: () async {
                                                                    await showModalBottomSheet(
                                                                      context: context,
                                                                      isScrollControlled: true,
                                                                      builder: (_) => SportMultiSelectDialog(
                                                                        sports: viewModel.facilityList,
                                                                        selectedSports: viewModel.selectedFacilityList,
                                                                        onSelectionChanged: (List<SportList> selected) {
                                                                          viewModel.selectedFacilityList = selected;
                                                                          List<String> facilityIdList =
                                                                          selected.map((facility) => facility.id).toList();
                                                                          viewModel.setSportsIdsList(facilityIdList);
                                                                          setState(() {
                                                                            isclick = true;
                                                                            sportsError = selected.isEmpty;
                                                                          });
                                                                        },
                                                                      ),
                                                                    );
                                                                  },
                                                                  child: Padding(
                                                                    padding: const EdgeInsets.all(8.0),
                                                                    child: Row(
                                                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                      children: [
                                                                        Expanded(
                                                                          child: Text(
                                                                            viewModel.selectedFacilityList.isEmpty
                                                                                ? l10n.of(context).selectSport
                                                                                : viewModel.selectedFacilityList.map((e) => e.name).join(', '),
                                                                            overflow: TextOverflow.ellipsis,
                                                                          ),
                                                                        ),
                                                                        SizedBox(
                                                                          height: 16,
                                                                          width: 16,
                                                                          child: Image.asset('assets/icons/lowarrow.png'),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),

                                                              if (sportsError)
                                                                Padding(
                                                                  padding: EdgeInsets.only(
                                                                      left:
                                                                          12.0,
                                                                      top: 4.0),
                                                                  child: Text(
                                                                    l10n
                                                                        .of(context)
                                                                        .pleaseSelectASport,
                                                                    style: TextStyle(
                                                                        color: Colors
                                                                            .red,
                                                                        fontSize:
                                                                            12),
                                                                  ),
                                                                ),
                                                              // Selected sports chips

                                                              Wrap(
                                                                spacing: 8.0,
                                                                children: viewModel
                                                                    .selectedFacilityList
                                                                    .map(
                                                                        (filter) {
                                                                  return GestureDetector(
                                                                    onTap: () {
                                                                      setStateModal(
                                                                          () {
                                                                        viewModel.selectFaciliity(
                                                                            filter,
                                                                            false);
                                                                        sportsError = viewModel
                                                                            .selectedFacilityList
                                                                            .isEmpty;
                                                                      });

                                                                      setState(
                                                                          () {
                                                                        isclick =
                                                                            true;
                                                                      });
                                                                    },
                                                                    child: Chip(
                                                                      label:
                                                                          Row(
                                                                        mainAxisSize:
                                                                            MainAxisSize.min,
                                                                        children: [
                                                                          Text(
                                                                            filter.name,
                                                                            style:
                                                                                TextStyle(
                                                                              color: Colors.white,
                                                                              fontWeight: FontWeight.w400,
                                                                              fontSize: 14,
                                                                            ),
                                                                          ),
                                                                          // SizedBox(
                                                                          //     width: 4),
                                                                          // Image
                                                                          //     .asset(
                                                                          //   'assets/icons/crosscircle.png',
                                                                          //   width:
                                                                          //       19,
                                                                          //   height:
                                                                          //       19,
                                                                          // ),
                                                                        ],
                                                                      ),
                                                                      backgroundColor:
                                                                          Color(
                                                                              0xFF3B747D),
                                                                    ),
                                                                  );
                                                                }).toList(),
                                                              ),


                                                            ],
                                                          ),
                                                          SizedBox(height: 10),
                                                          // Date Picker

                                                          TextFormField(
                                                            onTap: () async {
                                                              DateTime? picked =
                                                                  await myshowDatePicker(
                                                                context:
                                                                    context,
                                                                initialDate:
                                                                    DateTime
                                                                        .now(),
                                                                firstDate:
                                                                    DateTime
                                                                        .now(),
                                                                lastDate:
                                                                    DateTime(
                                                                        2100),
                                                                fieldHintText: 'dd/mm/yyyy',
                                                                builder:
                                                                    (context,
                                                                        child) {
                                                                  return Theme(
                                                                    data: Theme.of(
                                                                            context)
                                                                        .copyWith(
                                                                      colorScheme:
                                                                          ColorScheme
                                                                              .light(
                                                                        primary:
                                                                            AppColors.primaryColor,
                                                                        onPrimary:
                                                                            Colors.white,
                                                                        onSurface:
                                                                            Colors.black,
                                                                      ),
                                                                      textButtonTheme:
                                                                          TextButtonThemeData(
                                                                        style: TextButton
                                                                            .styleFrom(
                                                                          foregroundColor:
                                                                              AppColors.primaryColor,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    child:
                                                                        child!,
                                                                  );
                                                                },
                                                              );
                                                              if (picked !=
                                                                  null) {
                                                                setStateModal(
                                                                    () {
                                                                      var pickedDate =  DateFormat("dd/MM/yyyy").format(picked);

                                                                      viewModel.selectedDate = pickedDate;
                                                                  // viewModel
                                                                  //         .selectedDate =
                                                                  //     "${picked.year}-${picked.month.toString().padLeft(2, '0')}-${picked.day.toString().padLeft(2, '0')}";
                                                                  dateError =
                                                                      false; // Reset error on selection
                                                                });
                                                                setState(() {
                                                                  isclick =
                                                                      true;
                                                                });
                                                              }
                                                            },
                                                            controller:
                                                                TextEditingController(
                                                                    text: viewModel
                                                                        .selectedDate),
                                                            readOnly: true,
                                                            style: TextStyle(
                                                                fontSize: 16,
                                                                color: AppColors
                                                                    .black555),
                                                            decoration:
                                                                inputDecoration(
                                                              hintText: l10n
                                                                  .of(context)
                                                                  .date,
                                                            ).copyWith(
                                                              filled: true,
                                                              fillColor: Color(
                                                                  0xFFF4F9EC),
                                                              suffixIcon:
                                                                  Padding(
                                                                padding:
                                                                    EdgeInsets
                                                                        .all(
                                                                            14),
                                                                child: Icon(
                                                                    Icons
                                                                        .calendar_month_outlined,
                                                                    size: 22),
                                                              ),
                                                            ),
                                                            validator: (val) => val ==
                                                                        null ||
                                                                    val.isEmpty
                                                                ? "Select a date"
                                                                : null,
                                                          ),

                                                          SizedBox(height: 10),
                                                          // Time Dropdown

                                                          TextFormField(
                                                            readOnly: true,
                                                            controller:
                                                                timeController,
                                                            decoration:
                                                                InputDecoration(
                                                              hintText: l10n
                                                                  .of(context)
                                                                  .time,
                                                              hintStyle:
                                                                  TextStyle(
                                                                      fontSize:
                                                                          12),
                                                              filled: true,
                                                              fillColor: Color(
                                                                  0xFFF4F9EC),
                                                              suffixIcon:
                                                                  Padding(
                                                                padding: const EdgeInsets
                                                                    .symmetric(
                                                                    horizontal:
                                                                        18),
                                                                child: Image.asset(
                                                                    "assets/icons/lowarrow.png",
                                                                    height: 16,
                                                                    width: 14),
                                                              ),
                                                              border:
                                                                  OutlineInputBorder(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            8),
                                                                borderSide:
                                                                    BorderSide
                                                                        .none,
                                                              ),
                                                            ),
                                                            style: TextStyle(
                                                                fontSize: 14,
                                                                color: Colors
                                                                    .black),
                                                            onTap: () =>
                                                                showDialog(
                                                              context: context,
                                                              builder: (_) =>
                                                                  HourPickerDialog(
                                                                onTimeSelected:
                                                                    (value) {
                                                                  timeController
                                                                          .text =
                                                                      value;
                                                                  viewModel
                                                                      .changeTimeSlot(
                                                                          value); // use your ViewModel

                                                                  setState(() {
                                                                    isclick =
                                                                        true;
                                                                  });
                                                                },
                                                              ),
                                                            ),
                                                          ),

                                                          SizedBox(height: 10),
                                                          // Amenities Dropdown
                                                          Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              DropdownButtonFormField<
                                                                  String>(
                                                                value: viewModel
                                                                        .selectedAmenitie
                                                                        .isEmpty
                                                                    ? null
                                                                    : viewModel
                                                                        .selectedAmenitie
                                                                        .last,
                                                                hint: Text(l10n
                                                                    .of(context)
                                                                    .amenities),
                                                                icon: Image.asset(
                                                                    "assets/icons/lowarrow.png",
                                                                    height: 16,
                                                                    width: 14),
                                                                items: viewModel
                                                                    .amenititesList
                                                                    .map(
                                                                        (sport) {
                                                                  return DropdownMenuItem<
                                                                      String>(
                                                                    value: sport
                                                                        .id,
                                                                    child: Text(
                                                                        sport
                                                                            .name),
                                                                  );
                                                                }).toList(),
                                                                onChanged:
                                                                    (value) {
                                                                  if (value !=
                                                                          null &&
                                                                      !viewModel
                                                                          .selectedAmenitie
                                                                          .contains(
                                                                              value)) {
                                                                    setStateModal(
                                                                        () {
                                                                      viewModel
                                                                          .selectedAmenitie
                                                                          .add(
                                                                              value);
                                                                      amenitiesError =
                                                                          false; // Reset error on selection
                                                                    });
                                                                    setState(
                                                                        () {
                                                                      isclick =
                                                                          true;
                                                                    });
                                                                  }
                                                                },
                                                                decoration:
                                                                    InputDecoration(
                                                                  filled: true,
                                                                  fillColor: Color(
                                                                      0xFFF4F9EC),
                                                                  enabledBorder:
                                                                      OutlineInputBorder(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10),
                                                                    borderSide:
                                                                        BorderSide(
                                                                            color:
                                                                                Colors.transparent),
                                                                  ),
                                                                  focusedBorder:
                                                                      OutlineInputBorder(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10),
                                                                    borderSide:
                                                                        BorderSide(
                                                                            color:
                                                                                Colors.transparent),
                                                                  ),
                                                                  contentPadding:
                                                                      EdgeInsets.symmetric(
                                                                          horizontal:
                                                                              12,
                                                                          vertical:
                                                                              10),
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                  height: 16),
                                                              Wrap(
                                                                spacing: 8.0,
                                                                children: viewModel
                                                                    .selectedAmenitie
                                                                    .map((id) {
                                                                  final amenity = viewModel
                                                                      .amenititesList
                                                                      .firstWhere((a) =>
                                                                          a.id ==
                                                                          id);
                                                                  return Chip(
                                                                    label: Text(
                                                                      amenity
                                                                          .name,
                                                                      style:
                                                                          TextStyle(
                                                                        color: Colors
                                                                            .white,
                                                                        fontSize:
                                                                            14,
                                                                        fontWeight:
                                                                            FontWeight.w400,
                                                                      ),
                                                                    ),
                                                                    backgroundColor:
                                                                        Color(
                                                                            0xFF3B747D),
                                                                    deleteIcon:
                                                                        Image.asset(
                                                                            'assets/icons/crosscircle.png'),
                                                                    onDeleted:
                                                                        () {
                                                                      setStateModal(
                                                                          () {
                                                                        viewModel
                                                                            .selectedAmenitie
                                                                            .remove(id);
                                                                        amenitiesError = viewModel
                                                                            .selectedAmenitie
                                                                            .isEmpty;
                                                                      });
                                                                    },
                                                                  );
                                                                }).toList(),
                                                              ),
                                                            ],
                                                          ),
                                                          SizedBox(height: 15),
                                                          Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Row(
                                                                children: [
                                                                  Image.asset(
                                                                      "assets/icons/radius.png",
                                                                      width: 24,
                                                                      height:
                                                                          24),
                                                                  SizedBox(
                                                                      width: 8),
                                                                  Text(
                                                                    l10n
                                                                        .of(context)
                                                                        .radiusDistance,
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            15,
                                                                        fontWeight:
                                                                            FontWeight.w700),
                                                                  ),
                                                                ],
                                                              ),
                                                              SizedBox(
                                                                  height: 5),
                                                              Text(
                                                                "${radius.round()} ${l10n.of(context).miles}",
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        14,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500),
                                                              ),
                                                              Slider(
                                                                value: radius,
                                                                min: 1,
                                                                max: 50,
                                                                divisions: 100,
                                                                label:
                                                                    "${radius.round()} ${l10n.of(context).miles}",
                                                                activeColor: Color(
                                                                    0xFF8DC63F),
                                                                inactiveColor:
                                                                    Color(
                                                                        0xFF3B747D),
                                                                onChanged:
                                                                    (double
                                                                        value) {
                                                                  setStateModal(
                                                                      () {
                                                                    radius =
                                                                        value;
                                                                    facilityViewModel
                                                                        .changeRadius(
                                                                            value);
                                                                  });
                                                                  setState(() {
                                                                    isclick =
                                                                        true;
                                                                  });
                                                                },
                                                              ),
                                                              SizedBox(
                                                                  height: 2),
                                                              // Row(
                                                              //   children: [
                                                              //     Image.asset(
                                                              //         "assets/icons/starfill.png",
                                                              //         width: 24,
                                                              //         height:
                                                              //             24),
                                                              //     SizedBox(
                                                              //         width: 8),
                                                              //     Text(
                                                              //       S
                                                              //           .of(context)
                                                              //           .rating,
                                                              //       style: TextStyle(
                                                              //           fontSize:
                                                              //               15,
                                                              //           fontWeight:
                                                              //               FontWeight.w700),
                                                              //     ),
                                                              //   ],
                                                              // ),
                                                              // Text(
                                                              //   "${minRating.round()} - ${maxRating.round()}",
                                                              //   style: TextStyle(
                                                              //       fontSize:
                                                              //           14,
                                                              //       fontWeight:
                                                              //           FontWeight
                                                              //               .w500),
                                                              // ),
                                                              // GestureDetector(
                                                              //   behavior:
                                                              //       HitTestBehavior
                                                              //           .translucent,
                                                              //   onTapDown:
                                                              //       (TapDownDetails
                                                              //           details) {
                                                              //     // Get box constraints
                                                              //     RenderBox
                                                              //         box =
                                                              //         context.findRenderObject()
                                                              //             as RenderBox;
                                                              //     final localPosition =
                                                              //         box.globalToLocal(
                                                              //             details
                                                              //                 .globalPosition);
                                                              //     final tapPercent =
                                                              //         localPosition
                                                              //                 .dx /
                                                              //             box.size
                                                              //                 .width;
                                                              //
                                                              //     // Calculate the value from tap position
                                                              //     final double
                                                              //         tappedValue =
                                                              //         1 +
                                                              //             (tapPercent *
                                                              //                 4); // 1 to 5 range
                                                              //
                                                              //     setStateModal(
                                                              //         () {
                                                              //       // Decide whether to update start or end based on distance
                                                              //       if ((tappedValue -
                                                              //                   minRating)
                                                              //               .abs() <
                                                              //           (tappedValue -
                                                              //                   maxRating)
                                                              //               .abs()) {
                                                              //         minRating =
                                                              //             tappedValue.clamp(
                                                              //                 1.0,
                                                              //                 maxRating);
                                                              //       } else {
                                                              //         maxRating = tappedValue.clamp(
                                                              //             minRating,
                                                              //             5.0);
                                                              //       }
                                                              //     });
                                                              //     setState(() {
                                                              //       isclick =
                                                              //           true;
                                                              //     });
                                                              //   },
                                                              //   child:
                                                              //       RangeSlider(
                                                              //     values: RangeValues(
                                                              //         minRating,
                                                              //         maxRating),
                                                              //     min: 1,
                                                              //     max: 5,
                                                              //     divisions:
                                                              //         100,
                                                              //     labels:
                                                              //         RangeLabels(
                                                              //       minRating
                                                              //           .round()
                                                              //           .toString(),
                                                              //       maxRating
                                                              //           .round()
                                                              //           .toString(),
                                                              //     ),
                                                              //     activeColor:
                                                              //         Color(
                                                              //             0xFF8DC63F),
                                                              //     inactiveColor:
                                                              //         Color(
                                                              //             0xFF3B747D),
                                                              //     onChanged:
                                                              //         (RangeValues
                                                              //             values) {
                                                              //       setStateModal(
                                                              //           () {
                                                              //         minRating =
                                                              //             values
                                                              //                 .start;
                                                              //         maxRating =
                                                              //             values
                                                              //                 .end;
                                                              //       });
                                                              //     },
                                                              //   ),
                                                              // ),
                                                            ],
                                                          ),
                                                          SizedBox(height: 20),
                                                          // Filter Apply Button with Validation
                                                          Row(
                                                            children: [
                                                              Expanded(
                                                                child: InkWell(
                                                                  onTap: isclick
                                                                      ? () {
                                                                          setStateModal(
                                                                              () {
                                                                            // your logic here
                                                                          });

                                                                          if (!sortError &&
                                                                              !sportsError &&
                                                                              !dateError &&
                                                                              !timeError &&
                                                                              !amenitiesError) {
                                                                            // final parsedDate = DateFormat('dd/MM/yyyy').parse(viewModel.selectedDate??"");
                                                                            //
                                                                            // final selectedDate =  DateFormat('yyyy-MM-dd').format(parsedDate);
                                                                            print("sportIdList=>${viewModel.selectedFacilityList.map((e) => e.id).toList()}");
                                                                            print("amenitiesList=>${viewModel.selectedAmenitie}");
                                                                            print("ddate=>${viewModel.selectedDate}");
                                                                            print("time=>${viewModel.selectTime}");

                                                                            facilityViewModel.getFilteredFacilitiesData(
                                                                              context: context,
                                                                              // sportIdList:viewModel.selectedFacilityList.map((e) => e.id).toList(),
                                                                              sportIdList: viewModel.selectedFacilityList.map((e) => e.id).join(','),

                                                                              amenitiesList: viewModel.selectedAmenitie,
                                                                              date: "",
                                                                              time: facilityViewModel.selectTime,
                                                                              sort: viewModel.selectedSort,
                                                                              orderStatus: viewModel.selectedSortOrder ?? '',
                                                                              minRating: minRating.round().toString(),
                                                                              maxRating: maxRating.round().toString(),
                                                                              // maxPrice: maxRating.round().toString(),
                                                                              radius: radius.round().toString(),
                                                                            ).then((_){
                                                                              Navigator.of(context).pop();
                                                                            });
                                                                          }
                                                                        }
                                                                      : null,
                                                                  child:
                                                                      Container(
                                                                    height: 52,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              10),
                                                                      color: isclick
                                                                          ? AppColors
                                                                              .green033
                                                                          : Colors
                                                                              .grey
                                                                              .shade400,
                                                                    ),
                                                                    child:
                                                                        Container(
                                                                      margin: EdgeInsets
                                                                          .all(
                                                                              2.5), // for slight border effect
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.circular(10),
                                                                        color: isclick
                                                                            ? AppColors.primaryColor
                                                                            : Colors.grey,
                                                                      ),
                                                                      child:
                                                                          Center(
                                                                        child:
                                                                            Text(
                                                                          l10n.of(context).filterApply,
                                                                          style:
                                                                              TextStyle(
                                                                            fontSize:
                                                                                16,
                                                                            fontWeight:
                                                                                FontWeight.bold,
                                                                            color:
                                                                                AppColors.black,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              SizedBox(width: 20,),
                                                              Expanded(
                                                                child: InkWell(
                                                                  onTap:  (){
                                                                timeController.clear();
                                                                viewModel.clearSelectedDate();
                                                                viewModel.clearSortValues();
                                                                viewModel.selectedFacilityList.clear();
                                                                viewModel.selectedAmenitie.clear();
                                                                selectedSports.clear();
                                                                viewModel.clearSelectedSports();
                                                                radius =50.0;

                                                                facilityViewModel
                                                                    .changeRadius(
                                                                    50.0);

                                                                 Provider.of<FacilitiesViewModel>(NavigationService.context, listen: false)
                                                                    .getFacilitiesData(context: context).then((_){
                                                                Navigator.of(context)
                                                                    .pop();
                                                                });


                                                                },
                                                                  child: Stack(
                                                                    children: [
                                                                      Container(
                                                                        height: 52,
                                                                        width:
                                                                        double.infinity,
                                                                        decoration:
                                                                        BoxDecoration(
                                                                          color: AppColors
                                                                              .green033,
                                                                          borderRadius:
                                                                          BorderRadius
                                                                              .circular(
                                                                              10),
                                                                        ),
                                                                      ),
                                                                      Container(
                                                                        height: 47,
                                                                        width:
                                                                        double.infinity,
                                                                        decoration:
                                                                        BoxDecoration(
                                                                          color: AppColors
                                                                              .primaryColor,
                                                                          borderRadius:
                                                                          BorderRadius
                                                                              .circular(
                                                                              10),
                                                                        ),
                                                                        child: Center(
                                                                          child: Text(
                                                                            "Reset Filter",
                                                                            style:
                                                                            TextStyle(
                                                                              fontSize: 16,
                                                                              fontWeight:
                                                                              FontWeight
                                                                                  .bold,
                                                                              color:
                                                                              AppColors
                                                                                  .black,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),

                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ],
                                                      );
                                                    },
                                                  ),
                                                ),
                                              );
                                            },
                                          );
                                        },
                                      );
                                    },
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ],
                    ),
              drawer: SideDrawerScreen(), // Pass username here
              body: viewModel.isLoading
                  ? Center(
                      child: CircularProgressIndicator(
                          color: AppColors.primaryColor))
                  : viewModel.searchFacilitiesData.isEmpty
                      ? Center(
                          child: Text(l10n.of(context).facilitiesNotAvailable,
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.black555)))
                      : SafeArea(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Divider(
                                  height: 1,
                                  thickness: 1,
                                  color: Color(0xFF8DC63F)),
                              SizedBox(height: 20),
                              widget.forSelection == true
                                  ? Builder(builder: (context) {
                                      final List<Map<String, dynamic>>
                                          courtFacilityList = [];
                                      for (var facility
                                          in viewModel.searchFacilitiesData) {
                                        for (var court
                                            in facility.courts ?? []) {
                                          courtFacilityList.add({
                                            'facility': facility,
                                            'court': court,
                                          });
                                        }
                                      }
                                      return Expanded(
                                        child: ListView.builder(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: screenWidth * 0.04),
                                          itemCount: courtFacilityList.length,
                                          itemBuilder: (context, index) {
                                            final facilityData =
                                                courtFacilityList[index]
                                                    ['facility'];
                                            final courtData =
                                                courtFacilityList[index]
                                                    ['court'];

                                            return Stack(
                                              children: [
                                                InkWell(
                                                  onTap: () {
                                                    context
                                                        .read<
                                                            CreateChallengeViewModel>()
                                                        .updateSelectedFacility(
                                                            id: facilityData
                                                                    ?.id ??
                                                                "",
                                                            name: facilityData
                                                                    ?.name ??
                                                                "",
                                                            courtId:
                                                                courtData?.id ??
                                                                    "");
                                                    widget.onSelect?.call();
                                                  },
                                                  child: Card(
                                                    color: Colors.white,
                                                    shape:
                                                        RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        12)),
                                                    elevation: 0.1,
                                                    margin: EdgeInsets.only(
                                                        bottom: screenHeight *
                                                            0.015),
                                                    child: Padding(
                                                      padding: EdgeInsets.all(
                                                          screenWidth * 0.03),
                                                      child: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Row(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              ClipRRect(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            8),
                                                                child:
                                                                    NetworkImageWidget(
                                                                  height:
                                                                      screenWidth *
                                                                          0.29,
                                                                  width:
                                                                      screenWidth *
                                                                          0.26,
                                                                  fit: BoxFit
                                                                      .fill,
                                                                  image: (facilityData
                                                                              .image ??
                                                                          "")
                                                                      .toString(),
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                  width:
                                                                      screenWidth *
                                                                          0.025),
                                                              Expanded(
                                                                child: Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Text(
                                                                        (facilityData.name ??
                                                                                "")
                                                                            .toString()
                                                                            .capitalizeFirstLetter(),
                                                                        style: TextStyle(
                                                                            fontSize: screenWidth *
                                                                                0.035,
                                                                            fontWeight:
                                                                                FontWeight.bold)),
                                                                    SizedBox(
                                                                        height: screenHeight *
                                                                            0.01),
                                                                    Row(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Image.asset(
                                                                            "assets/icons/location.png",
                                                                            width: screenWidth *
                                                                                0.04,
                                                                            height:
                                                                                screenWidth * 0.04),
                                                                        SizedBox(
                                                                            width:
                                                                                screenWidth * 0.012),
                                                                        Row(
                                                                          children: [
                                                                            Expanded(child: Text((facilityData.address ?? l10n.of(context).na).toString(), style: TextStyle(fontSize: screenWidth * 0.03, color: Colors.grey[700]))),
                                                                          ],
                                                                        ),
                                                                      ],
                                                                    ),
                                                                    SizedBox(
                                                                        height: screenHeight *
                                                                            0.005),
                                                                    Row(
                                                                      children: [
                                                                        Image.asset(
                                                                            "assets/icons/rate.png",
                                                                            width: screenWidth *
                                                                                0.04,
                                                                            height:
                                                                                screenWidth * 0.04),
                                                                        SizedBox(
                                                                            width:
                                                                                screenWidth * 0.012),
                                                                        Text(
                                                                            "4.7",
                                                                            style: TextStyle(
                                                                                fontSize: screenWidth * 0.035,
                                                                                fontWeight: FontWeight.bold,
                                                                                color: Colors.grey[700])),
                                                                        SizedBox(
                                                                            width:
                                                                                screenWidth * 0.012),
                                                                        Container(
                                                                            width:
                                                                                1,
                                                                            height: screenHeight *
                                                                                0.03,
                                                                            color:
                                                                                Colors.grey),
                                                                        SizedBox(
                                                                            width:
                                                                                screenWidth * 0.012),
                                                                        Expanded(
                                                                            child:
                                                                                Text("500+ ${l10n.of(context).bookings}", style: TextStyle(fontSize: screenWidth * 0.035, color: Colors.grey[700]))),
                                                                      ],
                                                                    ),
                                                                    SizedBox(
                                                                        height: screenHeight *
                                                                            0.01),
                                                                    Row(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Text(
                                                                            "${l10n.of(context).courts}: ",
                                                                            style:
                                                                                TextStyle(fontSize: screenWidth * 0.033, fontWeight: FontWeight.bold)),
                                                                        Expanded(
                                                                            child:
                                                                                Text((courtData.name ?? "${l10n.of(context).courts}"), style: TextStyle(fontSize: screenWidth * 0.033))),
                                                                      ],
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  top: screenHeight * 0.01,
                                                  right: screenWidth * 0.02,
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment.end,
                                                    children: [
                                                      Text(
                                                          l10n
                                                              .of(context)
                                                              .available,
                                                          style: TextStyle(
                                                              fontSize:
                                                                  screenWidth *
                                                                      0.032,
                                                              color: Colors
                                                                  .black)),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            );
                                          },
                                        ),
                                      );
                                    })
                                  : Expanded(
                                      child: ListView.builder(
                                        padding: EdgeInsets.symmetric(
                                            horizontal: screenWidth * 0.04),
                                        itemCount: viewModel
                                            .searchFacilitiesData.length,
                                        itemBuilder: (context, index) {
                                          final facilityData = viewModel.searchFacilitiesData[index];
                                          // double totalRating = 0.0;
                                          // double avgFacRating = 0.0;
                                          //
                                          // if (facilityData.courts != null && facilityData.courts!.isNotEmpty) {
                                          //   for (var court in facilityData.courts!) {
                                          //     totalRating += court.totalrating ?? 0.0; // Safely handle nulls
                                          //   }
                                          //   avgFacRating = totalRating / facilityData.courts!.length;
                                          // }
                                          //
                                          // print("totalRating => $totalRating");
                                          // print("avgFacRating => $avgFacRating");

                                          double totalRating = 0.0;
                                          double avgFacRating = 0.0;
                                          int ratedCourtCount = 0;

                                          if (facilityData.courts != null && facilityData.courts!.isNotEmpty) {
                                            for (var court in facilityData.courts!) {
                                              if (court.totalrating != null && court.totalrating! > 0) {
                                                totalRating += court.averageRating ?? 0.0;
                                                ratedCourtCount++;
                                              }
                                            }

                                            if (ratedCourtCount > 0) {
                                              avgFacRating = totalRating ;
                                            }
                                          }

                                          print("Total court rating sum => $totalRating");
                                          print("Average facility rating => $avgFacRating");


                                          return Stack(
                                            children: [
                                              InkWell(
                                                onTap: () {
                                                  if (widget.forSelection ==
                                                      true) {
                                                    context
                                                        .read<
                                                            CreateChallengeViewModel>()
                                                        .updateSelectedFacility(
                                                            id: facilityData
                                                                    .id ??
                                                                "",
                                                            name: facilityData
                                                                    .name ??
                                                                "",
                                                            courtId: facilityData
                                                                    .courts
                                                                    ?.firstOrNull
                                                                    ?.id ??
                                                                "");
                                                    // viewModel.updateSelectedFacility(facilityData?.id ?? "") ;
                                                    widget.onSelect?.call();
                                                  } else {
                                                    viewModel
                                                        .updateSelectedFacility(
                                                            facilityData);
                                                    viewModel
                                                        .navigateToFacility(
                                                            context);
                                                  }
                                                  // You can navigate to another screen or perform any action
                                                },
                                                child: Card(
                                                  color: Colors.white,
                                                  shape: RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              12)),
                                                  elevation: 0.1,
                                                  margin: EdgeInsets.only(
                                                      bottom:
                                                          screenHeight * 0.015),
                                                  child: Padding(
                                                    padding: EdgeInsets.all(
                                                        screenWidth * 0.02),
                                                    child: Row(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                      children: [
                                                        ClipRRect(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(8),
                                                          child: NetworkImageWidget(
                                                              height:
                                                                  screenWidth *
                                                                      0.29,
                                                              width:
                                                                  screenWidth *
                                                                      0.28,
                                                              fit: BoxFit.cover,
                                                              image: (facilityData
                                                                          .image ??
                                                                      "")
                                                                  .toString()),
                                                        ),
                                                        SizedBox(
                                                            width: screenWidth *
                                                                0.025),
                                                        Expanded(
                                                          child: Column(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .center,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Row(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .center,
                                                                children: [
                                                                  Expanded(
                                                                      child: Text(
                                                                          (facilityData.name ?? l10n.of(context).na)
                                                                              .toString()
                                                                              .capitalizeFirstLetter(),
                                                                          maxLines:
                                                                              1,
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          style: TextStyle(
                                                                              fontSize: 16,
                                                                              fontWeight: FontWeight.bold))),
                                                                  SizedBox(
                                                                      width: 4),
                                                                  Column(
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .end,
                                                                    children: [
                                                                      Text(
                                                                          facilityData.courts?.length != 1
                                                                              ? "${facilityData.courts?.length ?? 0} ${l10n.of(context).courts}"
                                                                              : "${facilityData.courts?.length ?? 0} ${l10n.of(context).courts}",
                                                                          style: TextStyle(
                                                                              fontSize: 10,
                                                                              fontWeight: FontWeight.bold,
                                                                              color: Colors.black)),
                                                                      Text(l10n.of(context).available,
                                                                          style: TextStyle(
                                                                              fontSize: 10,
                                                                              fontWeight: FontWeight.normal,
                                                                              color: Colors.black)),
                                                                    ],
                                                                  )
                                                                ],
                                                              ),
                                                              SizedBox(
                                                                  height:
                                                                      screenHeight *
                                                                          0.0001),
                                                              Row(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .center,
                                                                children: [
                                                                  Image.asset(
                                                                      "assets/icons/location.png",
                                                                      width: screenWidth *
                                                                          0.04,
                                                                      height:
                                                                          screenWidth *
                                                                              0.04,
                                                                      fit: BoxFit
                                                                          .cover),
                                                                  SizedBox(
                                                                      width: screenWidth *
                                                                          0.012),
                                                                  Expanded(
                                                                      child: Text(
                                                                          (facilityData.address ?? l10n.of(context).na)
                                                                              .toString()
                                                                              .capitalizeFirstLetter(),
                                                                          maxLines:
                                                                              1,
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          style: TextStyle(
                                                                              fontSize: screenWidth * 0.03,
                                                                              color: Color(0xFF555555)))),
                                                                  Text(
                                                                    " (~${(facilityData.distanceInKm)?.toStringAsFixed(2)} kms)",
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            11,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .w400,
                                                                        color: AppColors
                                                                            .black555),
                                                                  ),
                                                                  Text(
                                                                    facilityData.distance != null
                                                                        ? facilityData.distance! < 1
                                                                        ? ' (~${(facilityData.distance! * 1000).toStringAsFixed(0)} m)'
                                                                        : ' (~${facilityData.distance!.toStringAsFixed(2)} km)'
                                                                        : '',
                                                                    style: TextStyle(
                                                                      fontSize: 11,
                                                                      fontWeight: FontWeight.w400,
                                                                      color: AppColors.black555,
                                                                    ),
                                                                  ),

                                                                ],
                                                              ),
                                                              SizedBox(
                                                                  height:
                                                                      screenHeight *
                                                                          0.004),
                                                              Row(
                                                                children: [
                                                                  Image.asset(
                                                                      "assets/icons/rate.png",
                                                                      width: screenWidth *
                                                                          0.04,
                                                                      height:
                                                                          screenWidth *
                                                                              0.04,
                                                                      fit: BoxFit
                                                                          .cover),
                                                                  SizedBox(
                                                                      width: screenWidth *
                                                                          0.012),
                                                                  Text(
                                                                      (facilityData.rating ??
                                                                              "${avgFacRating.toStringAsFixed(2)}")
                                                                          .toString(),
                                                                      style: TextStyle(
                                                                          fontSize: screenWidth *
                                                                              0.035,
                                                                          fontWeight: FontWeight
                                                                              .bold,
                                                                          color:
                                                                              Colors.grey[700])),
                                                                  SizedBox(
                                                                      width: screenWidth *
                                                                          0.012),
                                                                  Container(
                                                                      width: 1,
                                                                      height:
                                                                          screenHeight *
                                                                              0.02,
                                                                      color: Colors
                                                                          .grey),
                                                                  SizedBox(
                                                                      width: screenWidth *
                                                                          0.012),
                                                                  Expanded(
                                                                      child: Text(
                                                                          "${(facilityData.totalBookingCount ?? "").toString()}+ ${l10n.of(context).bookings}",
                                                                          style: TextStyle(
                                                                              fontSize: screenWidth * 0.035,
                                                                              color: Colors.grey[700]))),
                                                                ],
                                                              ),
                                                              // SizedBox(height: screenHeight * 0.003),
                                                              SizedBox(
                                                                height: 45,
                                                                child: ListView
                                                                    .builder(
                                                                  scrollDirection:
                                                                      Axis.horizontal,
                                                                  itemCount: facilityData
                                                                          .courts
                                                                          ?.length ??
                                                                      0,
                                                                  itemBuilder:
                                                                      (context,
                                                                          index) {
                                                                    var courtData =
                                                                        facilityData
                                                                            .courts?[index];
                                                                    return Container(
                                                                      margin: EdgeInsets.only(
                                                                          right:
                                                                              5),
                                                                      width: 35,
                                                                      height:
                                                                          35,
                                                                      decoration: BoxDecoration(
                                                                          shape: BoxShape
                                                                              .circle,
                                                                          border: Border.all(
                                                                              color: const Color(0xFF8DC63F),
                                                                              width: 1.5)),
                                                                      child:
                                                                          Center(
                                                                        child:
                                                                            ClipRRect(
                                                                          borderRadius:
                                                                              BorderRadius.circular(100),
                                                                          child: NetworkImageWidget(
                                                                              height: 24,
                                                                              width: 24,
                                                                              image: (courtData?.image ?? "").toString()),
                                                                        ),
                                                                      ),
                                                                    );
                                                                  },
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          );
                                        },
                                      ),
                                    ),
                            ],
                          ),
                        ),
            );
          },
        );
      },
    );
  }

  final timeController = TextEditingController();
}

class HourPickerDialog extends StatefulWidget {
  final Function(String) onTimeSelected;

  const HourPickerDialog({required this.onTimeSelected});

  @override
  State<HourPickerDialog> createState() => _HourPickerDialogState();
}

class _HourPickerDialogState extends State<HourPickerDialog> {
  final List<String> hours = List.generate(
    24,
    (index) => DateFormat.jm().format(DateTime(0, 0, 0, index)),
  );

  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      backgroundColor: Colors.white,
      contentPadding: EdgeInsets.all(16),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            "Select Time",
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
          ),
          SizedBox(height: 8),
          SizedBox(
            height: 100,
            child: ListWheelScrollView.useDelegate(
              itemExtent: 39,
              perspective: 0.004,
              diameterRatio: 1.5,
              physics: FixedExtentScrollPhysics(),
              onSelectedItemChanged: (index) {
                setState(() {
                  selectedIndex = index;
                });
              },
              childDelegate: ListWheelChildBuilderDelegate(
                builder: (context, index) {
                  if (index < 0 || index >= hours.length) return null;
                  return Center(
                    child: Text(
                      hours[index],
                      style: TextStyle(
                        fontSize: 16,
                        color:
                            index == selectedIndex ? Colors.black : Colors.grey,
                        fontWeight: index == selectedIndex
                            ? FontWeight.w500
                            : FontWeight.normal,
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          SizedBox(height: 25),
          ElevatedButton(
            onPressed: () {
              widget.onTimeSelected(hours[selectedIndex]);
              Navigator.of(context).pop();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryColor,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              padding: EdgeInsets.symmetric(horizontal: 30, vertical: 2),
            ),
            child: Text(l10n.of(context).select,
                style: TextStyle(color: Colors.white)),
          )
        ],
      ),
    );
  }
}





///
class SportMultiSelectDialog extends StatefulWidget {
  final List<SportList> sports;
  final List<SportList> selectedSports;
  final Function(List<SportList>) onSelectionChanged;

  const SportMultiSelectDialog({
    required this.sports,
    required this.selectedSports,
    required this.onSelectionChanged,
  });

  @override
  _SportMultiSelectDialogState createState() => _SportMultiSelectDialogState();
}

class _SportMultiSelectDialogState extends State<SportMultiSelectDialog> {
  late List<SportList> tempSelected;

  @override
  void initState() {
    super.initState();
    tempSelected = List.from(widget.selectedSports);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        padding: EdgeInsets.all(16),
        height: MediaQuery.of(context).size.height * 0.6,
        child: Column(
          children: [
            Text("Select Sports", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Expanded(
              child: ListView.builder(
                itemCount: widget.sports.length,
                itemBuilder: (context, index) {
                  final sport = widget.sports[index];
                  final isSelected = tempSelected.contains(sport);
                  return ListTile(
                    onTap: () {
                      setState(() {
                        if (isSelected) {
                          tempSelected.remove(sport);
                        } else {
                          tempSelected.add(sport);
                        }
                      });
                    },
                    title: Text(sport.name),
                    trailing: Icon(
                      isSelected ? Icons.check_circle : Icons.circle_outlined,
                      color: isSelected ? Colors.green : Colors.grey,
                    ),
                  );
                },
              ),
            ),

            InkWell(
              onTap:(){
                widget.onSelectionChanged(tempSelected);
                Navigator.of(context).pop();
              },
              child:
              Container(
                height: 52,
                decoration:
                BoxDecoration(
                  borderRadius:
                  BorderRadius.circular(
                      10),
                  color:AppColors
                      .green033

                ),
                child:
                Container(
                  margin: EdgeInsets
                      .all(
                      2.5), // for slight border effect
                  decoration:
                  BoxDecoration(
                    borderRadius:
                    BorderRadius.circular(10),
                    color:AppColors.primaryColor

                  ),
                  child:
                  Center(
                    child:
                    Text(
                      l10n.of(context).filterApply,
                      style:
                      TextStyle(
                        fontSize:
                        16,
                        fontWeight:
                        FontWeight.bold,
                        color:
                        AppColors.black,
                      ),
                    ),
                  ),
                ),
              ),
            ),

          ],
        ),
      ),
    );
  }
}
