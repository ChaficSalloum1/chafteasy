import 'package:carousel_slider/carousel_slider.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:kratEasyApp/EntranceScreens/guest_booking.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/utils/extension.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../GlobalUtils/FacilityCard.dart';
import '../../GlobalUtils/RuleItem.dart';
import '../../Localization/locale_provider.dart';

class FeaturedFacilityScreen extends StatefulWidget {
  const FeaturedFacilityScreen({super.key});

  @override
  State<FeaturedFacilityScreen> createState() => _FeaturedFacilityScreenState();
}

class _FeaturedFacilityScreenState extends State<FeaturedFacilityScreen> {
  late GoogleMapController mapController;

  void _onMapCreated(GoogleMapController controller) {
    mapController = controller;
  }

  // Method to open Google Maps with directions
  Future<void> _openGoogleMaps(double latitude, double longitude) async {
    final String googleMapsUrl = "google.navigation:q=$latitude,$longitude";

    if (await canLaunch(googleMapsUrl)) {
      await launch(googleMapsUrl);
    } else {
      throw 'Could not open Google Maps.';
    }
  }

  // String? savedValue;
  // Future<void> _loadSavedData() async {
  //   final prefs = await SharedPreferences.getInstance();
  //   setState(() {
  //     savedValue = prefs.getString('language_code'); // 👈 key used while saving
  //   });
  // }

  // @override
  // void initState() {
  //
  //   WidgetsBinding.instance.addPostFrameCallback((_)async{
  //     await _loadSavedData();
  //   });
  //   super.initState();
  // }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final viewModel = Provider.of<FeaturedFacilityViewModel>(context);
    final isLargeScreen = screenWidth > 600;
    final screenHeight = MediaQuery.of(context).size.height;
    // print("Lat: $lat, Lng: $long"); // Ensure it's not 0.0, 0.0 or malformed

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CommonAppBar(
        centerTile: true,
        title: l10n.of(context).facilityDetails,
        backIconColor: Colors.white,
        bg: Colors.white,
        action: [

          TextButton.icon(
            // onPressed: null,
            onPressed: () async {
              final viewModel = Provider.of<FacilitiesViewModel>(context, listen: false);

              // viewModel.setShareLoading(true); // Show CircularProgressIndicator

              try {
                // Example share content: text or link
                final String contentToShare = 'Check out this Awesome App:';

                await Share.share(contentToShare);
              } catch (e) {
                print("Share failed: $e");
                // Optionally show a SnackBar or AlertDialog for errors
              } finally {
                // viewModel.setShareLoading(false); // Hide CircularProgressIndicator
              }
            },

            icon: Provider.of<FacilitiesViewModel>(context, listen: false).isShare
                    ?SizedBox(
                      height: 10,width: 10,
                      child: CircularProgressIndicator(color: AppColors.primaryColor,strokeWidth: 0.5,)):  SizedBox(
                width: 20,
                height: 20,
                child: Image.asset('assets/icons/share.png')),
            label:Text(l10n.of(context).share,
                style: TextStyle(color: Colors.black)),
          ),
        ],
      ),
      body: viewModel.isLoading
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              child: Consumer<FacilitiesViewModel>(
                builder: (BuildContext context, facilityModel, Widget? child) {
                  var facilityData = facilityModel.selectedFacility;
                  String? imageGalleryChangeUrl = facilityData.image;

                  final double facilityLat =
                      (facilityData.latitude ?? 0.0).toDouble();
                  final double facilityLng =
                      (facilityData.longitude ?? 0.0).toDouble();

                  print("faclat:$facilityLat");
                  print("faclong:$facilityLng");
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Stack(
                        children: [
                          NetworkImageWidget(
                              image:
                                  facilityModel.selectedGalleryImage.toString(),
                              width: screenWidth,
                              height: screenWidth * 0.6,
                              fit: BoxFit.cover),
                          Positioned(
                            bottom: 10,
                            left: 10,
                            right: 10,
                            child: SizedBox(
                              height: 50,
                              child: ListView.builder(
                                scrollDirection: Axis.horizontal,
                                itemCount: facilityData.gallery?.length ?? 0,
                                itemBuilder: (BuildContext context, int index) {
                                  final imagesUrl =
                                      facilityData.gallery?[index];

                                  return InkWell(
                                    onTap: () {
                                      showDialog(
                                        context: context,
                                        builder: (BuildContext context) {
                                          return Dialog(
                                            backgroundColor: Colors.transparent,
                                            insetPadding: EdgeInsets.all(10),
                                            child: CarouselSlider.builder(
                                              itemCount: facilityData.gallery?.length ?? 0,
                                              itemBuilder: (BuildContext context, int itemIndex, int pageViewIndex) {
                                                final imageUrl = facilityData.gallery?[itemIndex];
                                                return Container(
                                              width: w,
                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(20),
                                                    image: DecorationImage(image: NetworkImage(imageUrl!,),fit: BoxFit.cover  )
                                                  ),

                                                );
                                              },
                                              options: CarouselOptions(
                                                initialPage: index, // Show tapped image first
                                                enableInfiniteScroll: true,
                                                enlargeCenterPage: true,
                                                viewportFraction: 1.0,
                                                // height: MediaQuery.of(context).size.height * 0.6,
                                              ),
                                            ),
                                          );
                                        },
                                      );
                                    },


                                    child: Padding(
                                      padding:
                                          EdgeInsets.symmetric(horizontal: 4.0),
                                      child: Container(
                                        margin: EdgeInsets.only(right: 5),
                                        height: 47,
                                        width: 47,
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius:
                                              BorderRadius.circular(5),
                                          border: Border.all(
                                              color: Colors.white, width: 1.5),
                                        ),
                                        child: ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            child: NetworkImageWidget(
                                              width: 47,
                                              height: 47,
                                              fit: BoxFit.cover,
                                              image: imagesUrl,
                                            )),
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 12),
                      ListView.builder(
                        padding: EdgeInsets.symmetric(horizontal: 16),
                        physics: NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        itemCount: facilityData.courts?.length ?? 0,
                        itemBuilder: (context, index) {
                          final court = facilityData.courts?[index];

                          return court?.price == null
                              ? SizedBox()
                              : FacilityCard(
                                  name: context.read<LocaleProvider>().locale.languageCode=="el" ?court?.grname??"" :  court?.name ?? "",
                                  price:
                                      "${AppConstants.appCurrency} ${court?.price?.toString() ?? 0}",
                                  rating:
                                      court?.averageRating?.toString() ?? "",
                                  image: court?.image ?? "",
                                  reviewsRate:
                                      court?.totalrating?.toString() ?? "",
                                  onBookPressed: () {
                                    context
                                        .read<FacilitiesViewModel>()
                                        .updateSelectedCourt(court!);
                                    print("Court id is ${court.id}");

                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => GuestBookingScreen(
                                          courtId: court.id ?? "",
                                          date: DateFormat('dd-MM-yyyy').format(
                                              DateTime
                                                  .now()), // use the formatted date
                                          facilityId: court.facilityId ?? "",
                                          selectedTimeSlots: [],
                                        ),
                                      ),
                                    );
                                  },
                                );
                        },
                      ),
                      SizedBox(height: 16),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                                (facilityData.name ?? "")
                                    .toString()
                                    .capitalizeFirstLetter(),
                                style: TextStyle(
                                    fontSize: 22, fontWeight: FontWeight.bold)),
                            SizedBox(height: 8),
                            Row(
                              children: [
                                Row(
                                  children: [
                                    Image.asset(
                                      "assets/icons/rate.png",
                                      width: 20, // Adjust size as needed
                                      height: 20,
                                    ),
                                  ],
                                ),
                                SizedBox(width: 4),
                                Text((facilityData.rating ?? 0).toString(),
                                    style: TextStyle(
                                        color: Color(0xFF555555),
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold)),
                                SizedBox(width: 8),
                                Container(
                                    height: 15,
                                    width: 2,
                                    color: AppColors.greyD9D9),
                                SizedBox(width: 8),
                                Text(
                                  "${(facilityData.totalBookingCount ?? 0).toString()}+ ${l10n.of(context).bookings}",
                                  style: TextStyle(
                                      color: Color(0xFF555555),
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500),
                                ),
                              ],
                            ),
                            SizedBox(height: 12),
                            SizedBox(
                              height: 38,
                              child: ListView.builder(
                                scrollDirection: Axis.horizontal,
                                itemCount: facilityData.courts?.length,
                                itemBuilder: (BuildContext context, int index) {
                                  var images =
                                      facilityData.courts?[index].image;
                                  return Container(
                                    height: 35,
                                    width: 35,
                                    margin: EdgeInsets.only(right: 8),
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                          color: AppColors.primaryColor,
                                          width: 1),
                                    ),
                                    child: Center(
                                      child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(35),
                                          child: NetworkImageWidget(
                                              image: images ?? "",
                                              width: 25,
                                              height: 25)),
                                    ),
                                  );
                                },
                              ),
                            ),
                            SizedBox(height: 12),
                            Text.rich(
                              TextSpan(
                                children: [
                                  TextSpan(
                                      text: l10n.of(context).description,
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: Color(0xFF555555))),
                                  TextSpan(
                                      text: (facilityData.description ?? "")
                                          .toString()
                                          .capitalizeFirstLetter(),
                                      style:
                                          TextStyle(color: Color(0xFF555555))),
                                ],
                              ),
                            ),
                            SizedBox(height: 16),
                            Text(l10n.of(context).amenitiesclg,
                                style: TextStyle(
                                    color: Color(0xFF555555),
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold)),
                            SizedBox(height: 8),
                            SizedBox(
                              height: screenHeight * 0.12,
                              child: Consumer<FeaturedFacilityViewModel>(
                                builder: (context, viewModel, child) {
                                  return ListView.builder(
                                    scrollDirection: Axis.horizontal,
                                    itemCount: facilityData.amenities?.length,
                                    padding: EdgeInsets.symmetric(
                                        horizontal: isLargeScreen ? 20 : 10),
                                    itemBuilder: (context, index) {
                                      final amenities =
                                          facilityData.amenities?[index];
                                      return Container(
                                          margin: EdgeInsets.only(right: 10),
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              border: Border.all(
                                                  color: AppColors.greyD0D0)),
                                          child: _buildFeatureBox(
                                              (amenities?.image ?? "")
                                                  .toString(),
                                           context.read<LocaleProvider>().locale.languageCode =="el" ? (amenities?.grname ?? "")
                                                .toString():  (amenities?.name ?? "")
                                                  .toString(),
                                              isLargeScreen));
                                    },
                                  );
                                },
                              ),
                            ),
                            SizedBox(height: 10),
                            facilityData.bio !=null ?
                            Text(l10n.of(context).rules,
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xFF555555))):SizedBox(),
                            SizedBox(height: 8),
                            RuleList(text: (facilityData.bio ?? "").toString()),
                            SizedBox(height: 16),

                            GestureDetector(
                              onTap: ()async{

                                final double latitude =     facilityData.latitude ?? 28.6139;   // Example latitude
                                final double longitude =     facilityData.longitude ?? 77.2090; // Example longitude

                                final String googleMapsUrl = 'https://www.google.com/maps/search/?api=1&query=$latitude,$longitude';

                                if (await canLaunchUrl(Uri.parse(googleMapsUrl))) {
                                await launchUrl(Uri.parse(googleMapsUrl), mode: LaunchMode.externalApplication);
                                } else {
                                throw 'Could not launch $googleMapsUrl';
                                }
                              },
                              child: Stack(
                                children: [
                                  SizedBox(
                                    width: w*2,
                                    height:
                                        MediaQuery.of(context).size.width * 0.5,
                                    child: GoogleMap(
                                      onMapCreated: _onMapCreated,
                                      initialCameraPosition: CameraPosition(
                                        target: LatLng(
                                          facilityData.latitude ?? 0.0,
                                          facilityData.longitude ?? 0.0,
                                        ),
                                        zoom: 11.0,
                                      ),
                                      markers: {
                                        Marker(
                                          markerId: MarkerId('facilityMarker'),
                                          position: LatLng(
                                              facilityData.latitude ?? 28.6139,
                                              facilityData.longitude ?? 77.2090),
                                          infoWindow: InfoWindow(
                                              title: (facilityData.address ?? "")
                                                  .toString()),
                                        ),
                                      },
                                    ),
                                  ),
                                  Positioned(
                                    bottom: 10,
                                    left: 10,
                                    right: 10,
                                    child: Container(
                                      width: screenWidth * .7,
                                      padding: EdgeInsets.all(8),
                                      decoration: BoxDecoration(
                                          color: Colors.white.withOpacity(0.8),
                                          borderRadius: BorderRadius.circular(8)),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Image.asset(
                                                  "assets/icons/location.png",
                                                  width: 18,
                                                  height: 18),
                                              SizedBox(width: 5),
                                              SizedBox(
                                                width: screenWidth * .6,
                                                child: Text(
                                                  (facilityData.address ?? "")
                                                      .toString(),
                                                  maxLines: 4,
                                                  overflow: TextOverflow.ellipsis,
                                                  style: TextStyle(
                                                      color: Color(0xFF555555),
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                              ),
                                            ],
                                          ),
                                          InkWell(
                                              onTap: () {
                                                _openGoogleMaps(
                                                    facilityData.latitude ??
                                                        28.6139,
                                                    facilityData.longitude ??
                                                        77.2090);
                                              },
                                              child: Image.asset(
                                                  "assets/icons/loc.png",
                                                  width: 20,
                                                  height: 20)),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 30)
                    ],
                  );
                },
              ),
            ),
    );
  }

  Widget _buildFeatureBox(String imagePath, String label, bool isLargeScreen) {
    return Container(
      width: isLargeScreen ? 130 : 120,
      padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(10)),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: NetworkImageWidget(
                  image: imagePath,
                  width: isLargeScreen ? 50 : 35,
                  height: isLargeScreen ? 50 : 40),
            ),
            // Image.asset(imagePath, width: isLargeScreen ? 50 : 35, height: isLargeScreen ? 50 : 40),
            const SizedBox(height: 5),
            Text(label.capitalizeFirstLetter(),
                style: TextStyle(
                    fontSize: isLargeScreen ? 14 : 12,
                    fontWeight: FontWeight.w400,
                    color: Color(0xFF555555)),
                textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}
