// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import '../ViewModel/BottomNavViewModels/OpeningsViewModel.dart';

// class OpeningsViewScreen extends StatelessWidget {
//   const OpeningsViewScreen({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final viewModel = Provider.of<OpeningsViewModel>(context);
//     double screenWidth = MediaQuery.of(context).size.width;
//     double screenHeight = MediaQuery.of(context).size.height;

//     return Scaffold(
//       backgroundColor: Colors.white,
//       body: SafeArea(
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             // Header with filter icon
//             Padding(
//               padding: EdgeInsets.symmetric(
//                 horizontal: screenWidth * 0.04,
//                 vertical: screenHeight * 0.015,
//               ),
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   Expanded(
//                     child: Text(
//                       "Browse Openings",
//                       style: TextStyle(
//                         fontSize: screenWidth * 0.045, // Responsive font size
//                         fontWeight: FontWeight.bold,
//                         color: Colors.black,
//                       ),
//                       overflow: TextOverflow.ellipsis,
//                     ),
//                   ),
//                   GestureDetector(
//                     onTap: () {
//                       // Add filter logic here
//                     },
//                     child: Image.asset(
//                       "assets/icons/filter.png",
//                       width: screenWidth * 0.06,
//                       height: screenWidth * 0.06,
//                       fit: BoxFit.cover,
//                     ),
//                   ),
//                 ],
//               ),
//             ),

//             // List of openings
//             Expanded(
//               child: ListView.builder(
//                 padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.04),
//                 itemCount: viewModel.openings.length,
//                 itemBuilder: (context, index) {
//                   final opening = viewModel.openings[index];

//                   return Card(
//                     color: Colors.white,
//                     shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(12),
//                     ),
//                     elevation: 0.1,
//                     margin: EdgeInsets.only(bottom: screenHeight * 0.015),
//                     child: Padding(
//                       padding: EdgeInsets.all(screenWidth * 0.03),
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Row(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               ClipRRect(
//                                 borderRadius: BorderRadius.circular(8),
//                                 child: Image.asset(
//                                   opening['image'],
//                                   width: screenWidth * 0.20,
//                                   height: screenWidth * 0.20,
//                                   fit: BoxFit.fill,
//                                 ),
//                               ),
//                               SizedBox(width: screenWidth * 0.025),
//                               Expanded(
//                                 child: Column(
//                                   crossAxisAlignment: CrossAxisAlignment.start,
//                                   children: [
//                                     Text(
//                                       opening['club'],
//                                       style: TextStyle(
//                                         fontSize: screenWidth * 0.035,
//                                         fontWeight: FontWeight.bold,
//                                       ),
//                                     ),
//                                     Text(
//                                       opening['court'],
//                                       style: TextStyle(
//                                         fontSize: screenWidth * 0.032,
//                                         fontWeight: FontWeight.bold,
//                                         color: Color(0xFF3B747D),
//                                       ),
//                                     ),
//                                     SizedBox(height: screenHeight * 0.005),
//                                     Row(
//                                       children: [
//                                         Image.asset(
//                                           "assets/icons/calendarclock.png",
//                                           width: screenWidth * 0.04,
//                                           height: screenWidth * 0.04,
//                                         ),
//                                         SizedBox(width: screenWidth * 0.012),
//                                         Expanded(
//                                           child: Text(
//                                             "${opening['date']} - ${opening['time']}",
//                                             style: TextStyle(
//                                               fontSize: screenWidth * 0.03,
//                                               color: Colors.grey[700],
//                                             ),
//                                           ),
//                                         ),
//                                       ],
//                                     ),
//                                     SizedBox(height: screenHeight * 0.005),
//                                     // Location Row (Newly Added)
//                                     Row(
//                                       children: [
//                                         Icon(
//                                           Icons
//                                               .location_on, // Location Pin Icon
//                                           size: screenWidth * 0.04,
//                                           color: Colors.grey[700],
//                                         ),
//                                         SizedBox(width: screenWidth * 0.012),
//                                         Expanded(
//                                           child: Text(
//                                             "Edgbaston, Birmingham",
//                                             style: TextStyle(
//                                               fontSize: screenWidth * 0.03,
//                                               color: Colors.grey[700],
//                                             ),
//                                           ),
//                                         ),
//                                       ],
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                               Image.asset(
//                                 "assets/icons/game.png",
//                                 width: screenWidth * 0.06,
//                                 height: screenWidth * 0.06,
//                               ),
//                             ],
//                           ),
//                           SizedBox(height: screenHeight * 0.01),
//                           Text(
//                             "Available Player Slots",
//                             style: TextStyle(fontSize: screenWidth * 0.032),
//                           ),
//                           Divider(),
//                           Row(
//                             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                             children: [
//                               Expanded(
//                                 child: Row(
//                                   children: [
//                                     Image.asset(
//                                       "assets/icons/people.png",
//                                       width: screenWidth * 0.04,
//                                       height: screenWidth * 0.04,
//                                     ),
//                                     SizedBox(width: screenWidth * 0.012),
//                                     Text(
//                                       opening['slots'],
//                                       style: TextStyle(
//                                         fontWeight: FontWeight.bold,
//                                         fontSize: screenWidth * 0.035,
//                                       ),
//                                     ),
//                                     SizedBox(width: screenWidth * 0.012),
//                                     Container(
//                                       width: 1,
//                                       height: screenHeight * 0.03,
//                                       color: Colors.grey,
//                                     ),
//                                     SizedBox(width: screenWidth * 0.012),
//                                     Container(
//                                       padding: EdgeInsets.symmetric(
//                                         horizontal: screenWidth * 0.02,
//                                         vertical: screenHeight * 0.005,
//                                       ),
//                                       decoration: BoxDecoration(
//                                         color: Colors.teal,
//                                         borderRadius: BorderRadius.circular(20),
//                                       ),
//                                       child: Row(
//                                         children: [
//                                           Icon(
//                                             Icons.circle,
//                                             size: screenWidth * 0.02,
//                                             color: Colors.greenAccent,
//                                           ),
//                                           SizedBox(width: screenWidth * 0.012),
//                                           Text(
//                                             opening['type'],
//                                             style: TextStyle(
//                                               fontSize: screenWidth * 0.025,
//                                               color: Colors.white,
//                                               fontWeight: FontWeight.bold,
//                                             ),
//                                           ),
//                                         ],
//                                       ),
//                                     ),
//                                     SizedBox(width: screenWidth * 0.012),
//                                     Container(
//                                       width: 1,
//                                       height: screenHeight * 0.03,
//                                       color: Colors.grey,
//                                     ),
//                                     SizedBox(width: screenWidth * 0.012),
//                                     Image.asset(
//                                       "assets/icons/public.png",
//                                       width: screenWidth * 0.04,
//                                       height: screenWidth * 0.04,
//                                     ),
//                                     SizedBox(width: screenWidth * 0.012),
//                                     Text(
//                                       opening['privacy'],
//                                       style: TextStyle(
//                                         fontSize: screenWidth * 0.03,
//                                         color: Colors.grey,
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                               ElevatedButton.icon(
//                                 style: ElevatedButton.styleFrom(
//                                   backgroundColor: const Color(0xFF8DC63F),
//                                   shape: RoundedRectangleBorder(
//                                     borderRadius: BorderRadius.circular(8),
//                                   ),
//                                 ),
//                                 onPressed: () {
//                                   // Add Challenge logic here
//                                 },
//                                 // icon: Image.asset(
//                                 //   "assets/icons/add.png", // Custom add icon from assets
//                                 //   width: screenWidth * 0.05,
//                                 //   height: screenWidth * 0.05,
//                                 // ),
//                                 label: Text(
//                                   "Join Openings",
//                                   style: TextStyle(
//                                     color: Colors.white,
//                                     fontSize: screenWidth * 0.03,
//                                     fontWeight: FontWeight.bold,
//                                   ),
//                                 ),
//                               ),
//                             ],
//                           ),
//                         ],
//                       ),
//                     ),
//                   );
//                 },
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
