import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Initialization {
  static Future<void> setLocalTimeZone() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String timeZone;
    try {
      timeZone = await FlutterTimezone.getLocalTimezone();
      print("inside timezone ==>$timeZone");
    } catch (e) {
      timeZone = "Asia/Kolkata";
    }
    await prefs.setString("timeZone", timeZone);
    print("Time zone set: $timeZone");
  }
}
