

// models/payment_details.dart
class PaymentDetailsResponse {
  final String message;
  final bool status;
  final PaymentDetails? data;

  PaymentDetailsResponse({
    required this.message,
    required this.status,
    required this.data,
  });

  factory PaymentDetailsResponse.fromJson(Map<String, dynamic> json) {
    return PaymentDetailsResponse(
      message: json['message'] as String? ?? '',
      status: json['status'] as bool? ?? false,
      data: json['data'] != null
          ? PaymentDetails.fromJson(json['data'] as Map<String, dynamic>)
          : null,
    );
  }
}

class PaymentDetails {
  final bool isDeleted;
  final num amount; // keep num to accept int/double
  final String status; // e.g., "preauth"
  final int member;
  final List<String> slotId;
  final String bookingId;
  final String id; // maps from _id
  final String courtId;
  final String userId;
  final String checkoutSessionId;
  final String paymentIntentId;
  final DateTime? date;
  final String type; // e.g., "challenge"
  final DateTime? createdAt;
  final int v;

  PaymentDetails({
    required this.isDeleted,
    required this.amount,
    required this.status,
    required this.member,
    required this.slotId,
    required this.bookingId,
    required this.id,
    required this.courtId,
    required this.userId,
    required this.checkoutSessionId,
    required this.paymentIntentId,
    required this.date,
    required this.type,
    required this.createdAt,
    required this.v,
  });

  factory PaymentDetails.fromJson(Map<String, dynamic> json) {
    DateTime? _parseDT(String? s) =>
        (s == null || s.isEmpty) ? null : DateTime.tryParse(s);

    return PaymentDetails(
      isDeleted: json['isDeleted'] as bool? ?? false,
      amount: json['amount'] as num? ?? 0,
      status: json['status'] as String? ?? '',
      member: json['member'] is int ? json['member'] as int : int.tryParse('${json['member']}') ?? 0,
      slotId: (json['slotId'] as List?)?.map((e) => '$e').toList() ?? const [],
      bookingId: json['bookingId'] as String? ?? '',
      id: json['_id'] as String? ?? '',
      courtId: json['courtId'] as String? ?? '',
      userId: json['userId'] as String? ?? '',
      checkoutSessionId: json['checkoutSessionId'] as String? ?? '',
      paymentIntentId: json['paymentIntentId'] as String? ?? '',
      date: _parseDT(json['date'] as String?),
      type: json['type'] as String? ?? '',
      createdAt: _parseDT(json['createdAt'] as String?),
      v: json['__v'] is int ? json['__v'] as int : int.tryParse('${json['__v']}') ?? 0,
    );
  }
}
