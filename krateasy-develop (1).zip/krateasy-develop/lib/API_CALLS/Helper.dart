import '../Models/AmenitiesList.dart';
import '../Models/SportList.dart';

class Helper {
  static List<SportList> sports = [];
  static List<AmenitiesList> amenities = [];
  static Map<String, dynamic> fullResponse = {};
  // Mock data for testing purposes
  static List<SportList> mockSports = [
    SportList(
      name: "Swimming",
      image:
          "https://api-ap-south-mum-1.openstack.acecloudhosting.com:8080/invent-colab-obj-bucket/krat-easy/service/krat-easy_1742982463070.webp",
      id: "67e3cd419e8c690c574a2184",
    ),
  ];
}

class Sport {
  final String id;
  final String name;

  Sport({required this.id, required this.name});
}

