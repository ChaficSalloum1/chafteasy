import 'package:kratEasyApp/API_CALLS/API/AmenitiesListAPI.dart';
import 'package:shared_preferences/shared_preferences.dart';

class GlobalAPIUtils {
  // Private constructor to prevent instantiation
  GlobalAPIUtils._();

  static const String baseUrl = "https://backend.krateasy.gr/api/";
  static const String termsConditionsUrl = "common/content/terms-and-condition";
  static const String privacyPolicyUrl = "common/content/privacy-policy";
  static const String aboutUsUrl = "common/content/about-us";
  static const String addMoneyWalletUrl = "app/wallet/add-amount";
  static const String getTotalAmountUrl = "app/wallet-transaction/list";
  static const String getSportsListUrl = "common/sport-list";
  static const String getAmenitiesListUrl = "common/amenity-list";
  static const String getSearchCourtListUrl = "app/court/available-list";
  static const String getTransactionDetailsUrl = "app/wallet-transaction/list";
  static const String getBookGuestCourtUrl = "app/booking/book-court";
  static const String getChallengesGuestUrl =
      "app/challenges/available-public-challenges";
  static const String getPromoCodeURL = "app/booking/apply-discount";
  static const String getWalletDetail = "app/wallet";
  static const String socialLogin = "app/auth/social-login";

  // Getter method to access the URL
  static String getBaseUrl() {
    return baseUrl;
  }

  // Getter method to access the URL
  static String getTermsConditionsUrl() {
    return termsConditionsUrl;
  }

  static String getPrivacyPolicyUrl() {
    return privacyPolicyUrl;
  }

  static String getAboutUs() {
    return aboutUsUrl;
  }

  // Getter method to access the URL
  static String getAddMoneyWalletUrl() {
    return addMoneyWalletUrl;
  }

  // Getter method to access the URL
  static String getTotalWalletAmountUrl() {
    return getTotalAmountUrl;
  }

  // Getter method to access the URL
  static String getSportsURL() {
    return getSportsListUrl;
  }

  // Getter method to access the URL
  static String getAmenitiesURL() {
    return getAmenitiesListUrl;
  }

  // Getter method to access the URL
  static String getSearchCourtURL() {
    return getSearchCourtListUrl;
  }

  // Getter method to access the URL
  static String getTransactionsDetailsURL() {
    return getTransactionDetailsUrl;
  }

  // Getter method to access the URL
  static String getWalletDetailUrl() {
    return getWalletDetail;
  }

  // Getter method to access the URL
  static String getGuestBookingCourtURL() {
    return getBookGuestCourtUrl;
  }

  // Getter method to access the URL
  static String getChallangesBookingCourtURL() {
    return getChallengesGuestUrl;
  }

  static Future<String?> getAuthToken() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString("auth_token");
  }

  //getter method to access the Promo code url
  static String getPromoCodeURLFucntion() {
    return getPromoCodeURL;
  }
//get social login url
static String getSocialLoginUrl(){
  return socialLogin;
}

}
