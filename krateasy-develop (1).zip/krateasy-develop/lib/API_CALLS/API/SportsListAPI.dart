import 'dart:convert';

import 'package:http/http.dart' as http;

import '../../Models/SportList.dart';
import '../GlobalAPIUtils.dart';

class SportsListAPI {
  Future<List<SportList>> fetchSports() async {
    String? baseurl = GlobalAPIUtils.getBaseUrl();
    String? getSportListURL = GlobalAPIUtils.getSportsURL();

    var request = http.Request('GET', Uri.parse(baseurl + getSportListURL));
    try {
      http.StreamedResponse response = await request.send();
      if (response.statusCode == 200) {
        var responseData = await response.stream.bytesToString();
        var decodedData = jsonDecode(responseData);
        return (decodedData['data']['data'] as List)
            .map((item) => SportList.fromJson(item))
            .toList();
      } else {
        throw Exception(response.reasonPhrase);
      }
    } catch (e) {
      throw Exception('Error fetching sports: $e');
    }
  }
}
