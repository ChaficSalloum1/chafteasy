import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../Models/ChallengesGuestModel.dart';
import '../GlobalAPIUtils.dart';

class Challenegesguestapi {
  Future<List<ChallengesGuestModel>> fetchChallenges() async {
    String? baseurl = GlobalAPIUtils.getBaseUrl();
    String? getChallengesURL = GlobalAPIUtils.getChallangesBookingCourtURL();

    final url = Uri.parse(baseurl + getChallengesURL);
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final data = json.decode(response.body)['data'] as List;
      return data.map((json) => ChallengesGuestModel.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load challenges');
    }
  }
}
