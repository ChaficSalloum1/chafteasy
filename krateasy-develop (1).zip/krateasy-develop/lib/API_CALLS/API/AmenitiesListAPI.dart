import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../Models/AmenitiesList.dart';
import '../GlobalAPIUtils.dart';
import '../Helper.dart';

class AmenitiesListApi {
  Future<void> fetchAndSaveAmenities() async {
    String? baseurl = GlobalAPIUtils.getBaseUrl();
    String? getAmenitiesUrl = GlobalAPIUtils.getAmenitiesURL();

    var request = http.Request('GET', Uri.parse(baseurl + getAmenitiesUrl));
    try {
      http.StreamedResponse response = await request.send();
      if (response.statusCode == 200) {
        var responseData = await response.stream.bytesToString();
        var decodedData = jsonDecode(responseData);

        List<AmenitiesList> amenitiesList =
            (decodedData['data']['data'] as List)
                .map((item) => AmenitiesList.fromJson(item))
                .toList();

        // Save amenities to Helper class
        Helper.amenities = amenitiesList;
      } else {
        throw Exception(response.reasonPhrase);
      }
    } catch (e) {
      print('Error fetching amenities: $e');
    }
  }
}
