import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:kratEasyApp/Models/wallet_Detail_Model.dart';

import '../../Models/TransactionDetailsModel.dart';
import '../GlobalAPIUtils.dart';

class TransactionDetailsAPI {
  static Future<List<TransactionDetailsModel>> getWalletTransactions() async {
    try {
      String? authToken = await GlobalAPIUtils.getAuthToken();
      String? baseurl = GlobalAPIUtils.getBaseUrl();
      String? transactionDetailsUrl = GlobalAPIUtils.getTransactionsDetailsURL();

      final response = await http.get(
        Uri.parse(baseurl + transactionDetailsUrl),
        headers: {'Authorization': 'Bearer $authToken'},
      );

      print('Response Status Code: ${response.statusCode}');
      print('Response Body: ${response.body}');

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseBody = json.decode(response.body);
        final List<dynamic> docs = responseBody['data']['transactionData']['docs'];

        return docs
            .map((json) => TransactionDetailsModel.fromJson(json))
            .toList();
      } else {
        throw Exception('Failed to load transactions: ${response.reasonPhrase}');
      }
    } catch (e, stacktrace) {
      print("Exception occurred in getWalletTransactions: $e");
      print("Stacktrace: $stacktrace");
      return []; // Return empty list on error to match expected return type
    }
  }


  //get Wallet Detail.
  static Future<WalletDetailModel> getWalletDetail() async {
    try {
      String? authToken = await GlobalAPIUtils.getAuthToken();
      String? baseurl = GlobalAPIUtils.getBaseUrl();
      String? walletdetailUrl = GlobalAPIUtils.getWalletDetailUrl();

      final response = await http.get(
        Uri.parse(baseurl + walletdetailUrl),
        headers: {'Authorization': 'Bearer $authToken'},
      );

      print('Response walletdetailUrl Code: ${response.statusCode}');
      print('Response walletdetailUrl: ${response.body}');

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseBody = json.decode(response.body);
        return WalletDetailModel.fromJson(responseBody);
      } else {
        throw Exception(
            'Failed to load wallet details: ${response.reasonPhrase}');
      }
    } catch (e) {
      throw Exception('Error fetching wallet details: $e');
    }
  }
}
