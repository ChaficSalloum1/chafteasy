import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:kratEasyApp/API_CALLS/GlobalAPIUtils.dart';
import 'package:kratEasyApp/Models/checkChallengeCodeModel.dart';
import 'package:kratEasyApp/Models/search_Filter_Data_Model.dart';
import 'package:kratEasyApp/Models/serach_Court_Payload_Model.dart';

class SearchCourtsApi {
  final String? baseUrl = GlobalAPIUtils.baseUrl;
  String? getSearchCourtUrl = GlobalAPIUtils.getSearchCourtURL();

  // Future<void> searchCourtApi(SearchCourtModel bookingRequest, context) async {
  //   final Uri url = Uri.parse(baseUrl! + getSearchCourtUrl!);

  //   try {
  //     // Print the request body
  //     print('Request Body: ${json.encode(bookingRequest.toJson())}');

  //     final response = await http.post(
  //       url,
  //       headers: {'Content-Type': 'application/json'},
  //       body: json.encode(bookingRequest.toJson()),
  //     );
  //     final Map<String, dynamic> data = json.decode(response.body);

  //     if (response.statusCode == 200 && data["status"] == true) {
  //       print('Search Court Response: ${response.body}');
  //       Helper.fullResponse = data;
  //     } else {
  //       // return data[]
  //       ScaffoldMessenger.of(context).showSnackBar(
  //           SnackBar(content: Text("Error: ${data["message"].toString()}")));
  //       print('SearchCourt Failed with Status Code: ${response.statusCode}');
  //     }
  //   } catch (e) {
  //     print('Error during booking: $e');
  //   }
  // }

  // Future<bool> searchCourtApi(SearchCourtModel bookingRequest, context) async {
  //   final Uri url = Uri.parse(baseUrl! + getSearchCourtUrl!);

  //   try {
  //     print('Request Body: ${json.encode(bookingRequest.toJson())}');

  //     final response = await http.post(
  //       url,
  //       headers: {'Content-Type': 'application/json'},
  //       body: json.encode(bookingRequest.toJson()),
  //     );
  //     final Map<String, dynamic> data = json.decode(response.body);

  //     if (response.statusCode == 200 && data["status"] == true) {
  //       print('Search Court Response: ${response.body}');
  //       Helper.fullResponse = data;
  //       return true;
  //     } else {
  //       ScaffoldMessenger.of(context).showSnackBar(
  //         SnackBar(content: Text("${data["message"]}")),
  //       );
  //       print('SearchCourt Failed with Status Code: ${response.statusCode}');
  //       return false;
  //     }
  //   } catch (e) {
  //     print('Error during booking: $e');
  //     return false;
  //   }
  // }

  //new
// Future<SearchFilterDataModel?> newSearchCourtApi(
//     BookingRequest request, BuildContext context) async {
//   final Uri url = Uri.parse(baseUrl! + getSearchCourtUrl!);

//   try {
//     final response = await http.post(
//       url,
//       headers: {
//         'Content-Type': 'application/json',
//       },
//       body: jsonEncode(request.toJson()),
//     );

//     final jsonData = jsonDecode(response.body);
//     log("json body.....$jsonData");

//     if (response.statusCode == 200 && jsonData["data"] !=null) {
//       return SearchFilterDataModel.fromJson(jsonData); // always return the model
//     } else {
//       log('Server error: ${response.statusCode}');
//       return null;
//     }
//   } catch (e) {
//     log('API Error: $e');
//     return null;
//   }
// }

  Future<SearchFilterDataModel?> newSearchCourtApi(
      BookingRequest request, BuildContext context) async {
    final Uri url = Uri.parse(baseUrl! + getSearchCourtUrl!);

    try {
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode(request.toJson()),
      );

      final jsonData = jsonDecode(response.body);
      log("json body.....$jsonData");

      // If success = true but data is null or empty, treat it as no data
      if (jsonData["success"] == true &&
          (jsonData["data"] == null ||
              (jsonData["data"] is List && jsonData["data"].isEmpty))) {
        return null; // return null here to indicate no data
      }

      return SearchFilterDataModel.fromJson(jsonData);
    } catch (e) {
      log('API Error: $e');
      return null;
    }
  }

  // Future<SearchFilterDataModel?> newSearchCourtApi(
  //     BookingRequest request, BuildContext context) async {
  //   final Uri url = Uri.parse(baseUrl! + getSearchCourtUrl!);

  //   try {
  //     final response = await http.post(
  //       url,
  //       headers: {
  //         'Content-Type': 'application/json',
  //       },
  //       body: jsonEncode(request.toJson()),
  //     );

  //     final jsonData = jsonDecode(response.body);
  //     log("json body.....$jsonData");
  //     if (jsonData["success"] == true &&
  //         (jsonData["data"] == null ||
  //             (jsonData["data"] is List && jsonData["data"].isEmpty))) {
  //       return 1;
  //     } else {
  //       return SearchFilterDataModel.fromJson(jsonData);
  //     }
  //   } catch (e) {
  //     log('API Error: $e');
  //     return null;
  //   }
  // }

  //   Future<SearchFilterDataModel?> newSearchCourtApi(
  //       BookingRequest request, BuildContext context) async {
  //       final Uri url = Uri.parse(baseUrl! + getSearchCourtUrl!);

  //     try {
  //       final response = await http.post(
  //         url,
  //         headers: {
  //           'Content-Type': 'application/json',
  //         },
  //         body: jsonEncode(request.toJson()),
  //       );
  //         final jsonData = jsonDecode(response.body);
  // log("json body.....$jsonData");
  //       if (response.statusCode == 200 && jsonData["status"] == true) {
  //         return SearchFilterDataModel.fromJson(jsonData);
  //       } else {

  //         log('Server error: ${response.statusCode}');
  //         return null;
  //       }
  //     } catch (e) {
  //       log('API Error: $e');
  //       return null;
  //     }
  //   }

  // Future<bool> searchCourtApi(
  //     SearchCourtModel bookingRequest, BuildContext context) async {
  //   final Uri url = Uri.parse(baseUrl! + getSearchCourtUrl!);

  //   try {
  //     final jsonBody = bookingRequest.toJson();
  //     log('Request Body1111: ${json.encode(jsonBody)}');

  //     final response = await http.post(
  //       url,
  //       headers: {'Content-Type': 'application/json'},
  //       body: json.encode(jsonBody),
  //     );

  //     final Map<String, dynamic> data = json.decode(response.body);

  //     if (response.statusCode == 200 && data["status"] == true) {
  //       print('Search Court Response: ${response.body}');
  //       Helper.fullResponse = data;
  //       return true;
  //     } else {
  //       ScaffoldMessenger.of(context).showSnackBar(
  //         SnackBar(content: Text("${data["message"] ?? "Search failed"}")),
  //       );
  //       print('SearchCourt Failed with Status Code: ${response.statusCode}');
  //       return false;
  //     }
  //   } catch (e) {
  //     print('Error during search: $e');
  //     ScaffoldMessenger.of(context).showSnackBar(
  //       SnackBar(content: Text("Something went wrong. Please try again.")),
  //     );
  //     return false;
  //   }
  // }

  // Future<void> filterBookingData(SearchCourtModel bookingRequest) async {
  //   final Uri url = Uri.parse('${baseUrl!}$getSearchCourtUrl');

  //   try {
  //     final body = json.encode(bookingRequest.toJson());
  //     print('Request Body: $body');

  //     final response = await http.post(
  //       url,
  //       headers: {'Content-Type': 'application/json'},
  //       body: body,
  //     );

  //     if (response.statusCode == 200) {
  //       print('Search Court Response: ${response.body}');
  //       final Map<String, dynamic> data = json.decode(response.body);
  //       Helper.fullResponse = data;
  //     } else {
  //       print('SearchCourt Failed. Status Code: ${response.statusCode}');
  //       print('Response: ${response.body}');
  //     }
  //   } catch (e) {
  //     print('Exception in filterBookingData: $e');
  //   }
  // }

  //modify challenge

  // Future<SearchFilterDataModel?> modifyChallenge(
  //     BookingRequest request, BuildContext context) async {
  //   final Uri url = Uri.parse(baseUrl! + getSearchCourtUrl!);

  //   try {
  //     final response = await http.post(
  //       url,
  //       headers: {
  //         'Content-Type': 'application/json',
  //       },
  //       body: jsonEncode(request.toJson()),
  //     );

  //     final jsonData = jsonDecode(response.body);
  //     log("json body.....$jsonData");

  //     // If success = true but data is null or empty, treat it as no data
  //     if (jsonData["success"] == true &&
  //         (jsonData["data"] == null ||
  //             (jsonData["data"] is List && jsonData["data"].isEmpty))) {
  //       return null; // return null here to indicate no data
  //     }

  //     return SearchFilterDataModel.fromJson(jsonData);
  //   } catch (e) {
  //     log('API Error: $e');
  //     return null;
  //   }
  // }
//check private challenge code

  Future<CheckChallengeCodeModel> checkChallengeCodeApi(
      {required BuildContext context, required String code}) async {
    try {
      String? authToken = await GlobalAPIUtils.getAuthToken();
      String? baseurl = GlobalAPIUtils.getBaseUrl();
      // String? checkChallengeCodeUrl = GlobalAPIUtils.getChallangesBookingCourtURL();

      final response = await http.get(
        Uri.parse(baseurl + "app/challenges/check-challenge/$code"),
        headers: {'Authorization': 'Bearer $authToken'},
      );

      print('Response CheckChallengeCodeModel Code: ${response.statusCode}');
      print('Response CheckChallengeCodeModelUrl: ${response.body}');

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseBody = json.decode(response.body);
        return CheckChallengeCodeModel.fromJson(responseBody);
      } else {
        throw Exception(
            'Failed to load wallet details: ${response.reasonPhrase}');
      }
    } catch (e) {
      throw Exception('Error fetching wallet details: $e');
    }
  }






}
