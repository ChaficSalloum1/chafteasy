import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../Models/AddMoneyInWalletModel.dart';
import '../GlobalAPIUtils.dart';

class AddMoneyInWallet {
  Future<AddMoneyInWalletModel> addMoney(
    int amount,
    BuildContext context,
  ) async {
    try {
      String? authToken = await GlobalAPIUtils.getAuthToken();
      String? baseurl = GlobalAPIUtils.getBaseUrl();
      String? addmoneyurl = GlobalAPIUtils.getAddMoneyWalletUrl();

      if (authToken == null) {
        return AddMoneyInWalletModel(
          success: false,
          message: 'Token not found.',
        );
      }

      // API Call
      final response = await http.post(
        Uri.parse(baseurl + addmoneyurl),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $authToken',
        },
        body: jsonEncode({'amount': amount}),
      );

      if (response.statusCode == 200) {
        final result = AddMoneyInWalletModel.fromJson(
          jsonDecode(response.body),
        );

        return result;
      } else {
        return AddMoneyInWalletModel(
          success: false,
          message:
              response.body.isNotEmpty
                  ? jsonDecode(response.body)['message']
                  : 'Failed to add money. Status: ${response.statusCode}',
        );
      }
    } catch (e) {
      return AddMoneyInWalletModel(success: false, message: e.toString());
    }
  }
}
