class TapThrottle {
  static final Map<String, bool> _tapLocks = {};

  static Future<void> run(String key, Future<void> Function() action,
      {Duration duration = const Duration(seconds: 1)}) async {
    if (_tapLocks[key] == true) return; // Already running

    _tapLocks[key] = true;
    try {
      await action();
    } finally {
      Future.delayed(duration, () => _tapLocks[key] = false);
    }
  }
}
