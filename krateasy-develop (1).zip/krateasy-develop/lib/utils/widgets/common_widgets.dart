// Common Input Decoration for Fields
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:shimmer/shimmer.dart';

InputDecoration inputDecoration({required String hintText}) {
  return InputDecoration(
    hintText: hintText,
    hintStyle: TextStyle(fontSize: 12, color: Colors.grey[700]),

    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: BorderSide(color: Colors.transparent), // Transparent border
    ),
    enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.transparent)),
    focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.transparent)),
    filled: true,
    fillColor: Colors.white,
    // Background color
    contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 14),
  );
}

/// loading list  Shimmer

class LoadListShimmer extends StatelessWidget {
  const LoadListShimmer({super.key});

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: Colors.grey.shade300,
      highlightColor: Colors.grey.shade100,
      child: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: 8,
        physics: BouncingScrollPhysics(),
        itemBuilder: (context, index) {
          return Container(
            height: 100,
            margin: const EdgeInsets.symmetric(vertical: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.grey,
              borderRadius: BorderRadius.circular(10),
            ),
          );
        },
      ),
    );
  }
}

//deatil page shimmer

class DetailScreenShimmer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: Colors.grey[300]!,
      highlightColor: Colors.grey[100]!,
      child: SingleChildScrollView(
        child: Column(
          children: [
            // SizedBox(height: 50),
            Container(height: 200, color: Colors.grey[300]), // image
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  shimmerBox(height: 20, width: 150),
                  SizedBox(height: 8),
                  shimmerBox(height: 15, width: 100),
                  SizedBox(height: 16),
                  shimmerRow(icon: Icons.calendar_today, width: 120),
                  SizedBox(height: 16),
                  shimmerRow(icon: Icons.star, width: 80),
                  SizedBox(height: 16),
                  shimmerRow(icon: Icons.location_on, width: 180),
                  SizedBox(height: 16),
                  shimmerBox(height: 15, width: 120),
                  SizedBox(height: 16),
                  shimmerBox(height: 10, width: double.infinity),
                  SizedBox(height: 10),
                  // shimmerBox(height: 15, width: 100),
                  // SizedBox(height: 10),
                  // shimmerBox(height: 20, width: 150),
                  SizedBox(height: 8),
                  shimmerBox(height: 20, width: double.infinity),
                  SizedBox(height: 22),
                  Row(
                    children: [
                      Spacer(),
                      shimmerSquare(),
                      Spacer(),
                      shimmerSquare(),
                      Spacer(),
                      shimmerSquare(),
                      Spacer(),
                    ],
                  ),
                  SizedBox(height: 30),

                  shimmerBox(height: 60, width: double.infinity),
                ],
              ),
            ),
          ],
        ),
      ),
      // ),
    );
  }

  Widget shimmerBox({required double height, required double width}) {
    return Container(
      height: height,
      width: width,
      decoration: BoxDecoration(
        color: Colors.grey[300],
        borderRadius: BorderRadius.circular(6),
      ),
    );
  }

  Widget shimmerRow({required IconData icon, required double width}) {
    return Row(
      children: [
        Icon(icon, color: Colors.grey[400]),
        SizedBox(width: 8),
        shimmerBox(height: 15, width: width),
      ],
    );
  }

  Widget shimmerSquare() {
    return Container(
      height: 80,
      width: 80,
      decoration: BoxDecoration(
        color: Colors.grey[300],
        borderRadius: BorderRadius.circular(5),
      ),
    );
  }
}

//common date formate
String formatDateToDayMonthYear(String dateString) {
  try {
    // Parse the input date and convert to local time
    DateTime parsedDate = DateTime.parse(dateString).toLocal();

    // Format: dd MMMM yyyy -> 09 May 2025
    return DateFormat('dd MMMM yyyy').format(parsedDate);
  } catch (e) {
    return ''; // Return empty if parsing fails
  }
}

//get only date , common function

DateTime parseToLocalDate(String? rawDate) {
  if (rawDate == null || rawDate.isEmpty) return DateTime.now();

  final List<DateFormat> knownFormats = [
    DateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"), // ISO 8601 UTC
    DateFormat("yyyy-MM-dd HH:mm:ss"),
    DateFormat("dd/MM/yyyy"),
    DateFormat("d/M/yyyy"),
    DateFormat("dd-MM-yyyy"),
    DateFormat("d-M-yyyy"),
    DateFormat("yyyy-MM-dd"),
  ];

  for (var format in knownFormats) {
    try {
      return format.parse(rawDate, true).toLocal(); // true = assume UTC
    } catch (_) {
      continue;
    }
  }

  // If all parsing fails, use current time
  return DateTime.now();
}

class CommonRules extends StatelessWidget {
  final String text;
  const CommonRules({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 18,
          width: 18,
          child: Image.asset(AppImages.pngTick, color: AppColors.greyGreen47D),
        ),
        SizedBox(width: 7),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w400,
              color: AppColors.black555,
            ),
          ),
        ),
      ],
    );
  }
}

class CommonAmenities extends StatelessWidget {
  final String text;
  final String image;
  const CommonAmenities({super.key, required this.text, required this.image});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(right: 10),
      padding: EdgeInsets.symmetric(vertical: 15, horizontal: 15),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: AppColors.white,
        border: Border.all(color: AppColors.grey3E3, width: 1),
      ),
      child: Column(
        children: [
          SizedBox(
            height: 40,
            width: 40,
            child: NetworkImageWidget(image: image, fit: BoxFit.cover),
          ),
          SizedBox(height: 5),
          Text(
            text,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: AppColors.black555,
            ),
          ),
        ],
      ),
    );
  }
}

String convertToLocalFormattedTime(String backendTime) {
  try {
    DateTime parsedTime;

    // 1. Try ISO8601 parsing first (most common: "2025-05-29T08:00:00Z")
    if (backendTime.contains('T')) {
      parsedTime = DateTime.parse(backendTime);
    } else {
      // 2. Try fallback format: "2025-05-29 08:00:00"
      parsedTime = DateFormat("yyyy-MM-dd HH:mm:ss").parse(backendTime, true);
    }

    // 3. Convert to local time zone (device-based, e.g., Greece if device is set to Greek time)
    DateTime localTime = parsedTime.toLocal();

    // 4. Format to "10:00 AM" or "10:00 π.μ." if locale is Greek
    // You can set locale explicitly if needed: 'el_GR' (Greek), 'en_US', etc.
    String formatted = DateFormat.jm().format(localTime);
    return formatted;
  } catch (e) {
    print('Error converting time: $e');
    return 'Invalid time';
  }
}

// class CircularImageStack extends StatelessWidget {
//   final List<String> imageUrls;
//   final int maxImages;

//   const CircularImageStack(
//       {Key? key, required this.imageUrls, this.maxImages = 5})
//       : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     double overlap = 15;

//     List<Widget> imageWidgets = [];
//     int extraCount = imageUrls.length - maxImages;

//     for (int i = 0;
//         i < (imageUrls.length > maxImages ? maxImages : imageUrls.length);
//         i++) {
//       imageWidgets.add(
//         Positioned(
//             left: i * overlap.toDouble(),
//             child: ClipRRect(
//                 borderRadius: BorderRadius.circular(16),
//                 child: NetworkImageWidget(
//                     image: imageUrls[i],
//                     height: 30,
//                     width: 30,
//                     fit: BoxFit.contain))),
//       );
//     }

//     if (extraCount > 0) {
//       imageWidgets.add(
//         Positioned(
//           left: maxImages * overlap.toDouble(),
//           child: CircleAvatar(
//               radius: 16,
//               backgroundColor: Colors.black,
//               child: Text("+$extraCount",
//                   style: TextStyle(color: Colors.white, fontSize: 16))),
//         ),
//       );
//     }
//     return SizedBox(
//         height: 35,
//         width: ((maxImages + 1) * overlap + 20).toDouble(),
//         child: Stack(children: imageWidgets));
//   }
// }

//get local time zone
Future<String> getLocalIanaTimeZone() async {
  try {
    final String timeZone = await FlutterTimezone.getLocalTimezone();
    return timeZone; // e.g. "Asia/Kolkata"
  } catch (e) {
    print("Could not get timezone: $e");
    return "Unknown";
  }
}

class HomeShimmer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: Colors.grey[300]!,
      highlightColor: Colors.grey[100]!,
      child: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 20),

            // Banner Shimmer
            SizedBox(
              height: 120,
              width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14.0),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                3,
                (index) => Container(
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: 10,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
            ),

            // Play Again Section Shimmer
            SizedBox(height: 20),
            Padding(
              padding: EdgeInsets.only(left: 14.0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Container(
                  width: 100,
                  height: 20,
                  color: Colors.white,
                ),
              ),
            ),
            SizedBox(height: 10),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 14.0),
              child: SizedBox(
                height: 180,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: 2,
                  itemBuilder: (context, index) {
                    return Container(
                      width: 330,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(5),
                      ),
                      margin: EdgeInsets.only(right: 4),
                      child: Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: 80,
                                  height: 80,
                                  color: Colors.white,
                                ),
                                SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                          width: 100,
                                          height: 12,
                                          color: Colors.white),
                                      SizedBox(height: 8),
                                      Container(
                                          width: 150,
                                          height: 12,
                                          color: Colors.white),
                                      SizedBox(height: 8),
                                      Row(
                                        children: [
                                          Container(
                                              width: 12,
                                              height: 12,
                                              color: Colors.white),
                                          SizedBox(width: 4),
                                          Container(
                                              width: 30,
                                              height: 12,
                                              color: Colors.white),
                                        ],
                                      ),
                                      SizedBox(height: 8),
                                      Row(
                                        children: [
                                          Container(
                                              width: 12,
                                              height: 12,
                                              color: Colors.white),
                                          SizedBox(width: 4),
                                          Container(
                                              width: 200,
                                              height: 12,
                                              color: Colors.white),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                Column(
                                  children: [
                                    Container(
                                        width: 40,
                                        height: 12,
                                        color: Colors.white),
                                    SizedBox(height: 8),
                                    Container(
                                      width: 40,
                                      height: 40,
                                      color: Colors.white,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            SizedBox(height: 8),
                            Container(height: 1, color: Colors.white),
                            SizedBox(height: 8),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                    width: 100,
                                    height: 12,
                                    color: Colors.white),
                                Row(
                                  children: [
                                    Container(
                                        width: 15,
                                        height: 15,
                                        color: Colors.white),
                                    SizedBox(width: 4),
                                    Container(
                                        width: 50,
                                        height: 12,
                                        color: Colors.white),
                                  ],
                                ),
                              ],
                            ),
                            Spacer(),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                        width: 20,
                                        height: 20,
                                        color: Colors.white),
                                    SizedBox(width: 6),
                                    Container(
                                        width: 80,
                                        height: 12,
                                        color: Colors.white),
                                  ],
                                ),
                                Container(
                                    width: 100,
                                    height: 25,
                                    color: Colors.white),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),

            // Upcoming Bookings Shimmer
            SizedBox(height: 20),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 14.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(width: 150, height: 20, color: Colors.white),
                  Container(width: 60, height: 25, color: Colors.white),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 7.0),
              child: SizedBox(
                height: 220,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: 2,
                  itemBuilder: (context, index) {
                    return Container(
                      width: MediaQuery.of(context).size.width * 0.95,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(5),
                      ),
                      margin: EdgeInsets.only(right: 4),
                      child: Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: 90,
                                  height: 110,
                                  color: Colors.white,
                                ),
                                SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                          width: 100,
                                          height: 14,
                                          color: Colors.white),
                                      SizedBox(height: 4),
                                      Container(
                                          width: 150,
                                          height: 16,
                                          color: Colors.white),
                                      SizedBox(height: 8),
                                      Container(
                                          width: 120,
                                          height: 14,
                                          color: Colors.white),
                                      SizedBox(height: 8),
                                      Row(
                                        children: [
                                          Container(
                                              width: 15,
                                              height: 15,
                                              color: Colors.white),
                                          SizedBox(width: 4),
                                          Container(
                                              width: 30,
                                              height: 14,
                                              color: Colors.white),
                                          SizedBox(width: 4),
                                          Container(
                                              width: 1,
                                              height: 15,
                                              color: Colors.white),
                                          SizedBox(width: 4),
                                          Container(
                                              width: 80,
                                              height: 12,
                                              color: Colors.white),
                                        ],
                                      ),
                                      SizedBox(height: 8),
                                      Row(
                                        children: [
                                          Container(
                                              width: 14,
                                              height: 14,
                                              color: Colors.white),
                                          SizedBox(width: 4),
                                          Container(
                                              width: 150,
                                              height: 12,
                                              color: Colors.white),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                Column(
                                  children: [
                                    Container(
                                        width: 40,
                                        height: 12,
                                        color: Colors.white),
                                    SizedBox(height: 8),
                                    Container(
                                      width: 40,
                                      height: 40,
                                      color: Colors.white,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            SizedBox(height: 8),
                            Container(height: 1, color: Colors.white),
                            SizedBox(height: 8),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                    width: 120,
                                    height: 14,
                                    color: Colors.white),
                                Row(
                                  children: [
                                    Container(
                                        width: 15,
                                        height: 15,
                                        color: Colors.white),
                                    SizedBox(width: 4),
                                    Container(
                                        width: 60,
                                        height: 14,
                                        color: Colors.white),
                                  ],
                                ),
                              ],
                            ),
                            SizedBox(height: 8),
                            Container(height: 1, color: Colors.white),
                            SizedBox(height: 8),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                        width: 20,
                                        height: 20,
                                        color: Colors.white),
                                    SizedBox(width: 6),
                                    Container(
                                        width: 80,
                                        height: 14,
                                        color: Colors.white),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Container(
                                        width: 25,
                                        height: 25,
                                        color: Colors.white),
                                    SizedBox(width: 10),
                                    Container(
                                        width: 50,
                                        height: 25,
                                        color: Colors.white),
                                    SizedBox(width: 10),
                                    Container(
                                        width: 50,
                                        height: 25,
                                        color: Colors.white),
                                    SizedBox(width: 10),
                                    Container(
                                        width: 85,
                                        height: 25,
                                        color: Colors.white),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
