// class AppString {
//   static final String appName = "KratEasyBooking";
//   static final String helloMate = "Hey Mate !";
//   static final String getAlert = "Get Alert";
//   static final String joinNow = "Join Now";
//   static final String joinPrivateChallenge =
//       "Join Private Challenge by Inviting Friends";
//   static final String challengeYourFriend =
//       "Challenge your friends, compete together, and enjoy exclusive matches!";
//   static final String playAgain = "Play Again";
//   static final String upcomingBookings = "Upcoming Bookings";
// }
