// GENERATED CODE - DO NOT MODIFY BY HAND
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'intl/messages_all.dart';

// **************************************************************************
// Generator: Flutter Intl IDE plugin
// Made by Localizely
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, lines_longer_than_80_chars
// ignore_for_file: join_return_with_assignment, prefer_final_in_for_each
// ignore_for_file: avoid_redundant_argument_values, avoid_escaping_inner_quotes

class l10n {
  l10n();

  static l10n? _current;

  static l10n get current {
    assert(
      _current != null,
      'No instance of S was loaded. Try to initialize the S delegate before accessing S.current.',
    );
    return _current!;
  }

  static const AppLocalizationDelegate delegate = AppLocalizationDelegate();

  static Future<l10n> load(Locale locale) {
    final name =
        (locale.countryCode?.isEmpty ?? false)
            ? locale.languageCode
            : locale.toString();
    final localeName = Intl.canonicalizedLocale(name);
    return initializeMessages(localeName).then((_) {
      Intl.defaultLocale = localeName;
      final instance = l10n();
      l10n._current = instance;

      return instance;
    });
  }

  static l10n of(BuildContext context) {
    final instance = l10n.maybeOf(context);
    assert(
      instance != null,
      'No instance of S present in the widget tree. Did you add S.delegate in localizationsDelegates?',
    );
    return instance!;
  }

  static l10n? maybeOf(BuildContext context) {
    return Localizations.of<l10n>(context, l10n);
  }

  /// `Join Now`
  String get joinNow {
    return Intl.message('Join Now', name: 'joinNow', desc: '', args: []);
  }

  /// `Verification Code`
  String get verificationCode {
    return Intl.message(
      'Verification Code',
      name: 'verificationCode',
      desc: '',
      args: [],
    );
  }

  /// `Enter the 4-digit code sent to your phone`
  String get enterThe4digitCodeSentToYourPhone {
    return Intl.message(
      'Enter the 4-digit code sent to your phone',
      name: 'enterThe4digitCodeSentToYourPhone',
      desc: '',
      args: [],
    );
  }

  /// `Didn't receive a code? Resend`
  String get didntReceiveACodeResend {
    return Intl.message(
      'Didn\'t receive a code? Resend',
      name: 'didntReceiveACodeResend',
      desc: '',
      args: [],
    );
  }

  /// `Resend OTP in 50s`
  String get resendOtpIn50s {
    return Intl.message(
      'Resend OTP in 50s',
      name: 'resendOtpIn50s',
      desc: '',
      args: [],
    );
  }

  /// `Verification`
  String get verification {
    return Intl.message(
      'Verification',
      name: 'verification',
      desc: '',
      args: [],
    );
  }

  /// `Join Private Challenge by Inviting Friends`
  String get joinPrivateChallengeByInvitingFriends {
    return Intl.message(
      'Join Private Challenge by Inviting Friends',
      name: 'joinPrivateChallengeByInvitingFriends',
      desc: '',
      args: [],
    );
  }

  /// `Account Delete Successfully`
  String get accountDeleteSuccessfully {
    return Intl.message(
      'Account Delete Successfully',
      name: 'accountDeleteSuccessfully',
      desc: '',
      args: [],
    );
  }

  /// `Somethings went wrong(deleteAccount)`
  String get somethingsWentWrongdeleteaccount {
    return Intl.message(
      'Somethings went wrong(deleteAccount)',
      name: 'somethingsWentWrongdeleteaccount',
      desc: '',
      args: [],
    );
  }

  /// `Somethings went wrong(notificationToggle)`
  String get somethingsWentWrongnotificationtoggle {
    return Intl.message(
      'Somethings went wrong(notificationToggle)',
      name: 'somethingsWentWrongnotificationtoggle',
      desc: '',
      args: [],
    );
  }

  /// `Set Password`
  String get setPassword {
    return Intl.message(
      'Set Password',
      name: 'setPassword',
      desc: '',
      args: [],
    );
  }

  /// `Crete a strong password. It must contain`
  String get creteAStrongPasswordItMustContain {
    return Intl.message(
      'Crete a strong password. It must contain',
      name: 'creteAStrongPasswordItMustContain',
      desc: '',
      args: [],
    );
  }

  /// `at least 6 characters and 1 special symbol`
  String get atLeast6CharactersAnd1SpecialSymbol {
    return Intl.message(
      'at least 6 characters and 1 special symbol',
      name: 'atLeast6CharactersAnd1SpecialSymbol',
      desc: '',
      args: [],
    );
  }

  /// `Reset Password`
  String get resetPassword {
    return Intl.message(
      'Reset Password',
      name: 'resetPassword',
      desc: '',
      args: [],
    );
  }

  /// `At least 9 characters, with uppercase`
  String get atLeast9CharactersWithUppercase {
    return Intl.message(
      'At least 9 characters, with uppercase',
      name: 'atLeast9CharactersWithUppercase',
      desc: '',
      args: [],
    );
  }

  /// `and lowercase letters`
  String get andLowercaseLetters {
    return Intl.message(
      'and lowercase letters',
      name: 'andLowercaseLetters',
      desc: '',
      args: [],
    );
  }

  /// `Password`
  String get password {
    return Intl.message('Password', name: 'password', desc: '', args: []);
  }

  /// `Successfully Change`
  String get successfullyChange {
    return Intl.message(
      'Successfully Change',
      name: 'successfullyChange',
      desc: '',
      args: [],
    );
  }

  /// `Your new password is now active.`
  String get yourNewPasswordIsNowActive {
    return Intl.message(
      'Your new password is now active.',
      name: 'yourNewPasswordIsNowActive',
      desc: '',
      args: [],
    );
  }

  /// `Stay Secure!`
  String get staySecure {
    return Intl.message('Stay Secure!', name: 'staySecure', desc: '', args: []);
  }

  /// `Your Account`
  String get yourAccount {
    return Intl.message(
      'Your Account',
      name: 'yourAccount',
      desc: '',
      args: [],
    );
  }

  /// `Successfully Created`
  String get successfullyCreated {
    return Intl.message(
      'Successfully Created',
      name: 'successfullyCreated',
      desc: '',
      args: [],
    );
  }

  /// `Your account successfully created! Click`
  String get yourAccountSuccessfullyCreatedClick {
    return Intl.message(
      'Your account successfully created! Click',
      name: 'yourAccountSuccessfullyCreatedClick',
      desc: '',
      args: [],
    );
  }

  /// `Continue to go to the home screen`
  String get continueToGoToTheHomeScreen {
    return Intl.message(
      'Continue to go to the home screen',
      name: 'continueToGoToTheHomeScreen',
      desc: '',
      args: [],
    );
  }

  /// `Welcome & Easy📍Booking`
  String get welcomeEasybooking {
    return Intl.message(
      'Welcome & Easy📍Booking',
      name: 'welcomeEasybooking',
      desc: '',
      args: [],
    );
  }

  /// `Take on the Challenge! 💪🏆`
  String get takeOnTheChallenge {
    return Intl.message(
      'Take on the Challenge! 💪🏆',
      name: 'takeOnTheChallenge',
      desc: '',
      args: [],
    );
  }

  /// `Find & Book Your Game in Seconds!`
  String get findBookYourGameInSeconds {
    return Intl.message(
      'Find & Book Your Game in Seconds!',
      name: 'findBookYourGameInSeconds',
      desc: '',
      args: [],
    );
  }

  /// `👉Join a Challenge: Compete prove your skills. 👉Create a Challenge: Invite others. 👉Public or Private: Open to all or just your crew!`
  String get joinAChallengeCompeteProveYourSkillsCreateAChallenge {
    return Intl.message(
      '👉Join a Challenge: Compete prove your skills. 👉Create a Challenge: Invite others. 👉Public or Private: Open to all or just your crew!',
      name: 'joinAChallengeCompeteProveYourSkillsCreateAChallenge',
      desc: '',
      args: [],
    );
  }

  /// `👉 Select your sport, 👉 Choose a location, 👉 Pick a date & time 👉 Confirm & play!`
  String get selectYourSportChooseALocationPickADateTime {
    return Intl.message(
      '👉 Select your sport, 👉 Choose a location, 👉 Pick a date & time 👉 Confirm & play!',
      name: 'selectYourSportChooseALocationPickADateTime',
      desc: '',
      args: [],
    );
  }

  /// `assets/logo.png`
  String get assetslogopng {
    return Intl.message(
      'assets/logo.png',
      name: 'assetslogopng',
      desc: '',
      args: [],
    );
  }

  /// `Login`
  String get login {
    return Intl.message('Login', name: 'login', desc: '', args: []);
  }

  /// `Get ready to unlock a world of`
  String get getReadyToUnlockAWorldOf {
    return Intl.message(
      'Get ready to unlock a world of',
      name: 'getReadyToUnlockAWorldOf',
      desc: '',
      args: [],
    );
  }

  /// `possibilities-Sign into your account now`
  String get possibilitiessignIntoYourAccountNow {
    return Intl.message(
      'possibilities-Sign into your account now',
      name: 'possibilitiessignIntoYourAccountNow',
      desc: '',
      args: [],
    );
  }

  /// `Forget Password`
  String get forgetPassword {
    return Intl.message(
      'Forget Password',
      name: 'forgetPassword',
      desc: '',
      args: [],
    );
  }

  /// `Please Enter your registered number to`
  String get pleaseEnterYourRegisteredNumberTo {
    return Intl.message(
      'Please Enter your registered number to',
      name: 'pleaseEnterYourRegisteredNumberTo',
      desc: '',
      args: [],
    );
  }

  /// `receive a verification code`
  String get receiveAVerificationCode {
    return Intl.message(
      'receive a verification code',
      name: 'receiveAVerificationCode',
      desc: '',
      args: [],
    );
  }

  /// `Mate`
  String get mate {
    return Intl.message('Mate', name: 'mate', desc: '', args: []);
  }

  /// `Upcoming`
  String get upcoming {
    return Intl.message('Upcoming', name: 'upcoming', desc: '', args: []);
  }

  /// `Complete Profile`
  String get completeProfile {
    return Intl.message(
      'Complete Profile',
      name: 'completeProfile',
      desc: '',
      args: [],
    );
  }

  /// `Full Name`
  String get fullName {
    return Intl.message('Full Name', name: 'fullName', desc: '', args: []);
  }

  /// `Email Address`
  String get emailAddress {
    return Intl.message(
      'Email Address',
      name: 'emailAddress',
      desc: '',
      args: [],
    );
  }

  /// `Phone Number`
  String get phoneNumber {
    return Intl.message(
      'Phone Number',
      name: 'phoneNumber',
      desc: '',
      args: [],
    );
  }

  /// `Select Sports Name`
  String get selectSportsName {
    return Intl.message(
      'Select Sports Name',
      name: 'selectSportsName',
      desc: '',
      args: [],
    );
  }

  /// `Submit`
  String get submit {
    return Intl.message('Submit', name: 'submit', desc: '', args: []);
  }

  /// `Fill your information below or register`
  String get fillYourInformationBelowOrRegister {
    return Intl.message(
      'Fill your information below or register',
      name: 'fillYourInformationBelowOrRegister',
      desc: '',
      args: [],
    );
  }

  /// `with your account.`
  String get withYourAccount {
    return Intl.message(
      'with your account.',
      name: 'withYourAccount',
      desc: '',
      args: [],
    );
  }

  /// `Badminton`
  String get badminton {
    return Intl.message('Badminton', name: 'badminton', desc: '', args: []);
  }

  /// `Hockey`
  String get hockey {
    return Intl.message('Hockey', name: 'hockey', desc: '', args: []);
  }

  /// `Cricket`
  String get cricket {
    return Intl.message('Cricket', name: 'cricket', desc: '', args: []);
  }

  /// `Tennis`
  String get tennis {
    return Intl.message('Tennis', name: 'tennis', desc: '', args: []);
  }

  /// `Basketball`
  String get basketball {
    return Intl.message('Basketball', name: 'basketball', desc: '', args: []);
  }

  /// `Football`
  String get football {
    return Intl.message('Football', name: 'football', desc: '', args: []);
  }

  /// `Failed to load Terms & Conditions`
  String get failedToLoadTermsConditions {
    return Intl.message(
      'Failed to load Terms & Conditions',
      name: 'failedToLoadTermsConditions',
      desc: '',
      args: [],
    );
  }

  /// `Something went wrong. Please try again.`
  String get somethingWentWrongPleaseTryAgain {
    return Intl.message(
      'Something went wrong. Please try again.',
      name: 'somethingWentWrongPleaseTryAgain',
      desc: '',
      args: [],
    );
  }

  /// `Failed to load About us`
  String get failedToLoadAboutUs {
    return Intl.message(
      'Failed to load About us',
      name: 'failedToLoadAboutUs',
      desc: '',
      args: [],
    );
  }

  /// `Somethings went Wrong(getMyBookingData)`
  String get somethingsWentWronggetmybookingdata {
    return Intl.message(
      'Somethings went Wrong(getMyBookingData)',
      name: 'somethingsWentWronggetmybookingdata',
      desc: '',
      args: [],
    );
  }

  /// `Somethings went Wrong(getFavouriteListData)`
  String get somethingsWentWronggetfavouritelistdata {
    return Intl.message(
      'Somethings went Wrong(getFavouriteListData)',
      name: 'somethingsWentWronggetfavouritelistdata',
      desc: '',
      args: [],
    );
  }

  /// `Somethings went Wrong(getMyChallengeData)`
  String get somethingsWentWronggetmychallengedata {
    return Intl.message(
      'Somethings went Wrong(getMyChallengeData)',
      name: 'somethingsWentWronggetmychallengedata',
      desc: '',
      args: [],
    );
  }

  /// `Somethings went Wrong(Type Challenge)`
  String get somethingsWentWrongtypeChallenge {
    return Intl.message(
      'Somethings went Wrong(Type Challenge)',
      name: 'somethingsWentWrongtypeChallenge',
      desc: '',
      args: [],
    );
  }

  /// `Interested Sports`
  String get interestedSports {
    return Intl.message(
      'Interested Sports',
      name: 'interestedSports',
      desc: '',
      args: [],
    );
  }

  /// `Something went wrong (getProfileDataApi)`
  String get somethingWentWrongGetprofiledataapi {
    return Intl.message(
      'Something went wrong (getProfileDataApi)',
      name: 'somethingWentWrongGetprofiledataapi',
      desc: '',
      args: [],
    );
  }

  /// `Error: Please select sport`
  String get errorPleaseSelectSport {
    return Intl.message(
      'Error: Please select sport',
      name: 'errorPleaseSelectSport',
      desc: '',
      args: [],
    );
  }

  /// `Profile Update Successfully`
  String get profileUpdateSuccessfully {
    return Intl.message(
      'Profile Update Successfully',
      name: 'profileUpdateSuccessfully',
      desc: '',
      args: [],
    );
  }

  /// `Somethings went wrong(Edit My Account)`
  String get somethingsWentWrongeditMyAccount {
    return Intl.message(
      'Somethings went wrong(Edit My Account)',
      name: 'somethingsWentWrongeditMyAccount',
      desc: '',
      args: [],
    );
  }

  /// `Favorite Sport`
  String get favoriteSport {
    return Intl.message(
      'Favorite Sport',
      name: 'favoriteSport',
      desc: '',
      args: [],
    );
  }

  /// `Somethings went Wrong(getProfileDataApi)`
  String get somethingsWentWronggetprofiledataapi {
    return Intl.message(
      'Somethings went Wrong(getProfileDataApi)',
      name: 'somethingsWentWronggetprofiledataapi',
      desc: '',
      args: [],
    );
  }

  /// `Payment Successful`
  String get paymentSuccessful {
    return Intl.message(
      'Payment Successful',
      name: 'paymentSuccessful',
      desc: '',
      args: [],
    );
  }

  /// `Somethings went Wrong(fetchChallenges)`
  String get somethingsWentWrongfetchchallenges {
    return Intl.message(
      'Somethings went Wrong(fetchChallenges)',
      name: 'somethingsWentWrongfetchchallenges',
      desc: '',
      args: [],
    );
  }

  /// `Somethings went Wrong(getChallengesDetails)`
  String get somethingsWentWronggetchallengesdetails {
    return Intl.message(
      'Somethings went Wrong(getChallengesDetails)',
      name: 'somethingsWentWronggetchallengesdetails',
      desc: '',
      args: [],
    );
  }

  /// `Your transaction is complete.`
  String get yourTransactionIsComplete {
    return Intl.message(
      'Your transaction is complete.',
      name: 'yourTransactionIsComplete',
      desc: '',
      args: [],
    );
  }

  /// `Enjoy your booking! ✅`
  String get enjoyYourBooking {
    return Intl.message(
      'Enjoy your booking! ✅',
      name: 'enjoyYourBooking',
      desc: '',
      args: [],
    );
  }

  /// `You can only deselect the start or end slot.`
  String get youCanOnlyDeselectTheStartOrEndSlot {
    return Intl.message(
      'You can only deselect the start or end slot.',
      name: 'youCanOnlyDeselectTheStartOrEndSlot',
      desc: '',
      args: [],
    );
  }

  /// `Please select slots in sequence.`
  String get pleaseSelectSlotsInSequence {
    return Intl.message(
      'Please select slots in sequence.',
      name: 'pleaseSelectSlotsInSequence',
      desc: '',
      args: [],
    );
  }

  /// `Contacts permission is required!`
  String get contactsPermissionIsRequired {
    return Intl.message(
      'Contacts permission is required!',
      name: 'contactsPermissionIsRequired',
      desc: '',
      args: [],
    );
  }

  /// `Booking successful`
  String get bookingSuccessful {
    return Intl.message(
      'Booking successful',
      name: 'bookingSuccessful',
      desc: '',
      args: [],
    );
  }

  /// `Unexpected error occurred.`
  String get unexpectedErrorOccurred {
    return Intl.message(
      'Unexpected error occurred.',
      name: 'unexpectedErrorOccurred',
      desc: '',
      args: [],
    );
  }

  /// `Something went wrong (getSlots)`
  String get somethingWentWrongGetslots {
    return Intl.message(
      'Something went wrong (getSlots)',
      name: 'somethingWentWrongGetslots',
      desc: '',
      args: [],
    );
  }

  /// `Invalid OTP. Please try again.`
  String get invalidOtpPleaseTryAgain {
    return Intl.message(
      'Invalid OTP. Please try again.',
      name: 'invalidOtpPleaseTryAgain',
      desc: '',
      args: [],
    );
  }

  /// `Error verifying OTP. Please try again.`
  String get errorVerifyingOtpPleaseTryAgain {
    return Intl.message(
      'Error verifying OTP. Please try again.',
      name: 'errorVerifyingOtpPleaseTryAgain',
      desc: '',
      args: [],
    );
  }

  /// `An error occurred. Please try again.`
  String get anErrorOccurredPleaseTryAgain {
    return Intl.message(
      'An error occurred. Please try again.',
      name: 'anErrorOccurredPleaseTryAgain',
      desc: '',
      args: [],
    );
  }

  /// `Invalid promo data received from server.`
  String get invalidPromoDataReceivedFromServer {
    return Intl.message(
      'Invalid promo data received from server.',
      name: 'invalidPromoDataReceivedFromServer',
      desc: '',
      args: [],
    );
  }

  /// `An unexpected error occurred. Please try again.`
  String get anUnexpectedErrorOccurredPleaseTryAgain {
    return Intl.message(
      'An unexpected error occurred. Please try again.',
      name: 'anUnexpectedErrorOccurredPleaseTryAgain',
      desc: '',
      args: [],
    );
  }

  /// `Connection error. Please check your network.`
  String get connectionErrorPleaseCheckYourNetwork {
    return Intl.message(
      'Connection error. Please check your network.',
      name: 'connectionErrorPleaseCheckYourNetwork',
      desc: '',
      args: [],
    );
  }

  /// `Failed to book.`
  String get failedToBook {
    return Intl.message(
      'Failed to book.',
      name: 'failedToBook',
      desc: '',
      args: [],
    );
  }

  /// `Please enter the OTP.`
  String get pleaseEnterTheOtp {
    return Intl.message(
      'Please enter the OTP.',
      name: 'pleaseEnterTheOtp',
      desc: '',
      args: [],
    );
  }

  /// `Unexpected response format from server.`
  String get unexpectedResponseFormatFromServer {
    return Intl.message(
      'Unexpected response format from server.',
      name: 'unexpectedResponseFormatFromServer',
      desc: '',
      args: [],
    );
  }

  /// `Failed to apply promo code.`
  String get failedToApplyPromoCode {
    return Intl.message(
      'Failed to apply promo code.',
      name: 'failedToApplyPromoCode',
      desc: '',
      args: [],
    );
  }

  /// `Location services are disabled.`
  String get locationServicesAreDisabled {
    return Intl.message(
      'Location services are disabled.',
      name: 'locationServicesAreDisabled',
      desc: '',
      args: [],
    );
  }

  /// `Location permission denied.`
  String get locationPermissionDenied {
    return Intl.message(
      'Location permission denied.',
      name: 'locationPermissionDenied',
      desc: '',
      args: [],
    );
  }

  /// `Location permissions are permanently denied. Please enable them in settings.`
  String get locationPermissionsArePermanentlyDeniedPleaseEnableThemInSettings {
    return Intl.message(
      'Location permissions are permanently denied. Please enable them in settings.',
      name: 'locationPermissionsArePermanentlyDeniedPleaseEnableThemInSettings',
      desc: '',
      args: [],
    );
  }

  /// `No address found.`
  String get noAddressFound {
    return Intl.message(
      'No address found.',
      name: 'noAddressFound',
      desc: '',
      args: [],
    );
  }

  /// `Location permission permanently denied. Please enable it from settings.`
  String get locationPermissionPermanentlyDeniedPleaseEnableItFromSettings {
    return Intl.message(
      'Location permission permanently denied. Please enable it from settings.',
      name: 'locationPermissionPermanentlyDeniedPleaseEnableItFromSettings',
      desc: '',
      args: [],
    );
  }

  /// `No courts available.`
  String get noCourtsAvailable {
    return Intl.message(
      'No courts available.',
      name: 'noCourtsAvailable',
      desc: '',
      args: [],
    );
  }

  /// `No slots available at this time.`
  String get noSlotsAvailableAtThisTime {
    return Intl.message(
      'No slots available at this time.',
      name: 'noSlotsAvailableAtThisTime',
      desc: '',
      args: [],
    );
  }

  /// `Something went wrong.`
  String get somethingWentWrong {
    return Intl.message(
      'Something went wrong.',
      name: 'somethingWentWrong',
      desc: '',
      args: [],
    );
  }

  /// `Please select time slots in sequence.`
  String get pleaseSelectTimeSlotsInSequence {
    return Intl.message(
      'Please select time slots in sequence.',
      name: 'pleaseSelectTimeSlotsInSequence',
      desc: '',
      args: [],
    );
  }

  /// `Failed to fetch users`
  String get failedToFetchUsers {
    return Intl.message(
      'Failed to fetch users',
      name: 'failedToFetchUsers',
      desc: '',
      args: [],
    );
  }

  /// `Something went wrong while fetching notifications.`
  String get somethingWentWrongWhileFetchingNotifications {
    return Intl.message(
      'Something went wrong while fetching notifications.',
      name: 'somethingWentWrongWhileFetchingNotifications',
      desc: '',
      args: [],
    );
  }

  /// `Somethings went Wrong(unreadNotification)`
  String get somethingsWentWrongunreadnotification {
    return Intl.message(
      'Somethings went Wrong(unreadNotification)',
      name: 'somethingsWentWrongunreadnotification',
      desc: '',
      args: [],
    );
  }

  /// `Somethings went Wrong(deleteNotification)`
  String get somethingsWentWrongdeletenotification {
    return Intl.message(
      'Somethings went Wrong(deleteNotification)',
      name: 'somethingsWentWrongdeletenotification',
      desc: '',
      args: [],
    );
  }

  /// `No favorite player data found.`
  String get noFavoritePlayerDataFound {
    return Intl.message(
      'No favorite player data found.',
      name: 'noFavoritePlayerDataFound',
      desc: '',
      args: [],
    );
  }

  /// `Something went wrong (getFavouritePlayerData)`
  String get somethingWentWrongGetfavouriteplayerdata {
    return Intl.message(
      'Something went wrong (getFavouritePlayerData)',
      name: 'somethingWentWrongGetfavouriteplayerdata',
      desc: '',
      args: [],
    );
  }

  /// `Somethings went Wrong(getHomeData)`
  String get somethingsWentWronggethomedata {
    return Intl.message(
      'Somethings went Wrong(getHomeData)',
      name: 'somethingsWentWronggethomedata',
      desc: '',
      args: [],
    );
  }

  /// `Somethings went Wrong(getBookingDetails)`
  String get somethingsWentWronggetbookingdetails {
    return Intl.message(
      'Somethings went Wrong(getBookingDetails)',
      name: 'somethingsWentWronggetbookingdetails',
      desc: '',
      args: [],
    );
  }

  /// `Something went wrong (getBookingDetails)`
  String get somethingWentWrongGetbookingdetails {
    return Intl.message(
      'Something went wrong (getBookingDetails)',
      name: 'somethingWentWrongGetbookingdetails',
      desc: '',
      args: [],
    );
  }

  /// `Somethings went wrong. Please try again later!`
  String get somethingsWentWrongPleaseTryAgainLater {
    return Intl.message(
      'Somethings went wrong. Please try again later!',
      name: 'somethingsWentWrongPleaseTryAgainLater',
      desc: '',
      args: [],
    );
  }

  /// `Code cannot be empty`
  String get codeCannotBeEmpty {
    return Intl.message(
      'Code cannot be empty',
      name: 'codeCannotBeEmpty',
      desc: '',
      args: [],
    );
  }

  /// `Something went wrong (getFacilitiesData)`
  String get somethingWentWrongGetfacilitiesdata {
    return Intl.message(
      'Something went wrong (getFacilitiesData)',
      name: 'somethingWentWrongGetfacilitiesdata',
      desc: '',
      args: [],
    );
  }

  /// `Somethings went Wrong(getFacilitiesData)`
  String get somethingsWentWronggetfacilitiesdata {
    return Intl.message(
      'Somethings went Wrong(getFacilitiesData)',
      name: 'somethingsWentWronggetfacilitiesdata',
      desc: '',
      args: [],
    );
  }

  /// `An error occurred while fetching challenge facilities. Please try again later.`
  String get anErrorOccurredWhileFetchingChallengeFacilitiesPleaseTryAgain {
    return Intl.message(
      'An error occurred while fetching challenge facilities. Please try again later.',
      name: 'anErrorOccurredWhileFetchingChallengeFacilitiesPleaseTryAgain',
      desc: '',
      args: [],
    );
  }

  /// `Please select a sport first`
  String get pleaseSelectASportFirst {
    return Intl.message(
      'Please select a sport first',
      name: 'pleaseSelectASportFirst',
      desc: '',
      args: [],
    );
  }

  /// `Please select a Facility first`
  String get pleaseSelectAFacilityFirst {
    return Intl.message(
      'Please select a Facility first',
      name: 'pleaseSelectAFacilityFirst',
      desc: '',
      args: [],
    );
  }

  /// `Invalid Amount. Please try again later!`
  String get invalidAmountPleaseTryAgainLater {
    return Intl.message(
      'Invalid Amount. Please try again later!',
      name: 'invalidAmountPleaseTryAgainLater',
      desc: '',
      args: [],
    );
  }

  /// `Somethings went wrong(createChallenge)`
  String get somethingsWentWrongcreatechallenge {
    return Intl.message(
      'Somethings went wrong(createChallenge)',
      name: 'somethingsWentWrongcreatechallenge',
      desc: '',
      args: [],
    );
  }

  /// `Please select slots in order.`
  String get pleaseSelectSlotsInOrder {
    return Intl.message(
      'Please select slots in order.',
      name: 'pleaseSelectSlotsInOrder',
      desc: '',
      args: [],
    );
  }

  /// `You can only deselect the first or last slot.`
  String get youCanOnlyDeselectTheFirstOrLastSlot {
    return Intl.message(
      'You can only deselect the first or last slot.',
      name: 'youCanOnlyDeselectTheFirstOrLastSlot',
      desc: '',
      args: [],
    );
  }

  /// `Started`
  String get started {
    return Intl.message('Started', name: 'started', desc: '', args: []);
  }

  /// `Invalid time`
  String get invalidTime {
    return Intl.message(
      'Invalid time',
      name: 'invalidTime',
      desc: '',
      args: [],
    );
  }

  /// `Available Challenges`
  String get availableChallenges {
    return Intl.message(
      'Available Challenges',
      name: 'availableChallenges',
      desc: '',
      args: [],
    );
  }

  /// `Challenges not available yet`
  String get challengesNotAvailableYet {
    return Intl.message(
      'Challenges not available yet',
      name: 'challengesNotAvailableYet',
      desc: '',
      args: [],
    );
  }

  /// `Available Nearby Courts`
  String get availableNearbyCourts {
    return Intl.message(
      'Available Nearby Courts',
      name: 'availableNearbyCourts',
      desc: '',
      args: [],
    );
  }

  /// `Courts not available yet`
  String get courtsNotAvailableYet {
    return Intl.message(
      'Courts not available yet',
      name: 'courtsNotAvailableYet',
      desc: '',
      args: [],
    );
  }

  /// `Please try again later!`
  String get pleaseTryAgainLater {
    return Intl.message(
      'Please try again later!',
      name: 'pleaseTryAgainLater',
      desc: '',
      args: [],
    );
  }

  /// `Upcoming Bookings`
  String get upcomingBookings {
    return Intl.message(
      'Upcoming Bookings',
      name: 'upcomingBookings',
      desc: '',
      args: [],
    );
  }

  /// `Upcoming Bookings Not Found !!`
  String get upcomingBookingsNotFound {
    return Intl.message(
      'Upcoming Bookings Not Found !!',
      name: 'upcomingBookingsNotFound',
      desc: '',
      args: [],
    );
  }

  /// `Type of Booking: `
  String get typeOfBooking {
    return Intl.message(
      'Type of Booking: ',
      name: 'typeOfBooking',
      desc: '',
      args: [],
    );
  }

  /// `Whole Court Booking`
  String get wholeCourtBooking {
    return Intl.message(
      'Whole Court Booking',
      name: 'wholeCourtBooking',
      desc: '',
      args: [],
    );
  }

  /// `Are you sure ?`
  String get areYouSure {
    return Intl.message(
      'Are you sure ?',
      name: 'areYouSure',
      desc: '',
      args: [],
    );
  }

  /// `Are you sure you want to cancel this booking? If yes, please press the confirm button. We will deduct the platform fee, and the remaining amount will be transferred to your wallet. Thank you.`
  String get areYouSureYouWantToCancelThisBookingIf {
    return Intl.message(
      'Are you sure you want to cancel this booking? If yes, please press the confirm button. We will deduct the platform fee, and the remaining amount will be transferred to your wallet. Thank you.',
      name: 'areYouSureYouWantToCancelThisBookingIf',
      desc: '',
      args: [],
    );
  }

  /// `Yes, Confirm`
  String get yesConfirm {
    return Intl.message('Yes, Confirm', name: 'yesConfirm', desc: '', args: []);
  }

  /// `Cancel`
  String get cancel {
    return Intl.message('Cancel', name: 'cancel', desc: '', args: []);
  }

  /// `Modify`
  String get modify {
    return Intl.message('Modify', name: 'modify', desc: '', args: []);
  }

  /// `View Bookings`
  String get viewBookings {
    return Intl.message(
      'View Bookings',
      name: 'viewBookings',
      desc: '',
      args: [],
    );
  }

  /// `Hey `
  String get hey {
    return Intl.message('Hey ', name: 'hey', desc: '', args: []);
  }

  /// `Loading...`
  String get loading {
    return Intl.message('Loading...', name: 'loading', desc: '', args: []);
  }

  /// `N/A`
  String get na {
    return Intl.message('N/A', name: 'na', desc: '', args: []);
  }

  /// `Get Alert`
  String get getAlert {
    return Intl.message('Get Alert', name: 'getAlert', desc: '', args: []);
  }

  /// `Home`
  String get home {
    return Intl.message('Home', name: 'home', desc: '', args: []);
  }

  /// `My Booking`
  String get myBooking {
    return Intl.message('My Booking', name: 'myBooking', desc: '', args: []);
  }

  /// `Facilities`
  String get facilities {
    return Intl.message('Facilities', name: 'facilities', desc: '', args: []);
  }

  /// `Challenges`
  String get challenges {
    return Intl.message('Challenges', name: 'challenges', desc: '', args: []);
  }

  /// `Notifications`
  String get notifications {
    return Intl.message(
      'Notifications',
      name: 'notifications',
      desc: '',
      args: [],
    );
  }

  /// `Filter`
  String get filter {
    return Intl.message('Filter', name: 'filter', desc: '', args: []);
  }

  /// `Select Sport`
  String get selectSport {
    return Intl.message(
      'Select Sport',
      name: 'selectSport',
      desc: '',
      args: [],
    );
  }

  /// `Please select a sport`
  String get pleaseSelectASport {
    return Intl.message(
      'Please select a sport',
      name: 'pleaseSelectASport',
      desc: '',
      args: [],
    );
  }

  /// `Date`
  String get date {
    return Intl.message('Date', name: 'date', desc: '', args: []);
  }

  /// `Time`
  String get time {
    return Intl.message('Time', name: 'time', desc: '', args: []);
  }

  /// `Amenities`
  String get amenities {
    return Intl.message('Amenities', name: 'amenities', desc: '', args: []);
  }

  /// `Filter Apply`
  String get filterApply {
    return Intl.message(
      'Filter Apply',
      name: 'filterApply',
      desc: '',
      args: [],
    );
  }

  /// `What do you want to play?`
  String get whatDoYouWantToPlay {
    return Intl.message(
      'What do you want to play?',
      name: 'whatDoYouWantToPlay',
      desc: '',
      args: [],
    );
  }

  /// `Select Sports`
  String get selectSports {
    return Intl.message(
      'Select Sports',
      name: 'selectSports',
      desc: '',
      args: [],
    );
  }

  /// `Which Time`
  String get whichTime {
    return Intl.message('Which Time', name: 'whichTime', desc: '', args: []);
  }

  /// `Skill Level`
  String get skillLevel {
    return Intl.message('Skill Level', name: 'skillLevel', desc: '', args: []);
  }

  /// `Please select skill level`
  String get pleaseSelectSkillLevel {
    return Intl.message(
      'Please select skill level',
      name: 'pleaseSelectSkillLevel',
      desc: '',
      args: [],
    );
  }

  /// `Apply`
  String get apply {
    return Intl.message('Apply', name: 'apply', desc: '', args: []);
  }

  /// `Filter Result`
  String get filterResult {
    return Intl.message(
      'Filter Result',
      name: 'filterResult',
      desc: '',
      args: [],
    );
  }

  /// `Enter Mobile Number`
  String get enterMobileNumber {
    return Intl.message(
      'Enter Mobile Number',
      name: 'enterMobileNumber',
      desc: '',
      args: [],
    );
  }

  /// `Continue`
  String get continues {
    return Intl.message('Continue', name: 'continues', desc: '', args: []);
  }

  /// `Remember Me`
  String get rememberMe {
    return Intl.message('Remember Me', name: 'rememberMe', desc: '', args: []);
  }

  /// `Forgot Password?`
  String get forgotPassword {
    return Intl.message(
      'Forgot Password?',
      name: 'forgotPassword',
      desc: '',
      args: [],
    );
  }

  /// `Log in`
  String get logIn {
    return Intl.message('Log in', name: 'logIn', desc: '', args: []);
  }

  /// `Don't have an account? Sign Up`
  String get dontHaveAnAccountSignUp {
    return Intl.message(
      'Don\'t have an account? Sign Up',
      name: 'dontHaveAnAccountSignUp',
      desc: '',
      args: [],
    );
  }

  /// `Already have account?`
  String get alreadyHaveAccount {
    return Intl.message(
      'Already have account?',
      name: 'alreadyHaveAccount',
      desc: '',
      args: [],
    );
  }

  /// `👉 Join a Challenge: `
  String get joinAChallenge {
    return Intl.message(
      '👉 Join a Challenge: ',
      name: 'joinAChallenge',
      desc: '',
      args: [],
    );
  }

  /// `Compete prove your skills.`
  String get competeProveYourSkills {
    return Intl.message(
      'Compete prove your skills.',
      name: 'competeProveYourSkills',
      desc: '',
      args: [],
    );
  }

  /// `👉 Create a Challenge: `
  String get createAChallenge {
    return Intl.message(
      '👉 Create a Challenge: ',
      name: 'createAChallenge',
      desc: '',
      args: [],
    );
  }

  /// `Invite others. `
  String get inviteOthers {
    return Intl.message(
      'Invite others. ',
      name: 'inviteOthers',
      desc: '',
      args: [],
    );
  }

  /// `👉  Public or Private: `
  String get publicOrPrivate {
    return Intl.message(
      '👉  Public or Private: ',
      name: 'publicOrPrivate',
      desc: '',
      args: [],
    );
  }

  /// `Open to all or just your crew!`
  String get openToAllOrJustYourCrew {
    return Intl.message(
      'Open to all or just your crew!',
      name: 'openToAllOrJustYourCrew',
      desc: '',
      args: [],
    );
  }

  /// `Let’s get playing!`
  String get letsGetPlaying {
    return Intl.message(
      'Let’s get playing!',
      name: 'letsGetPlaying',
      desc: '',
      args: [],
    );
  }

  /// `Book a Court`
  String get bookACourt {
    return Intl.message('Book a Court', name: 'bookACourt', desc: '', args: []);
  }

  /// `You’re Almost There!`
  String get youreAlmostThere {
    return Intl.message(
      'You’re Almost There!',
      name: 'youreAlmostThere',
      desc: '',
      args: [],
    );
  }

  /// `Enter OTP`
  String get enterOtp {
    return Intl.message('Enter OTP', name: 'enterOtp', desc: '', args: []);
  }

  /// `Verify OTP`
  String get verifyOtp {
    return Intl.message('Verify OTP', name: 'verifyOtp', desc: '', args: []);
  }

  /// `Resend OTP`
  String get resendOtp {
    return Intl.message('Resend OTP', name: 'resendOtp', desc: '', args: []);
  }

  /// `Please enter your phone number`
  String get pleaseEnterYourPhoneNumber {
    return Intl.message(
      'Please enter your phone number',
      name: 'pleaseEnterYourPhoneNumber',
      desc: '',
      args: [],
    );
  }

  /// `Phone number must be 8-10 digits`
  String get phoneNumberMustBe810Digits {
    return Intl.message(
      'Phone number must be between 8-12 digits',
      name: 'phoneNumberMustBe810Digits',
      desc: '',
      args: [],
    );
  }

  /// `Enter 8-10 digit phone number`
  String get enter810DigitPhoneNumber {
    return Intl.message(
      'Enter 8-10 digit phone number',
      name: 'enter810DigitPhoneNumber',
      desc: '',
      args: [],
    );
  }

  /// `SEND OTP`
  String get sendOtp {
    return Intl.message('SEND OTP', name: 'sendOtp', desc: '', args: []);
  }

  /// `Failed to send OTP. Please try again.`
  String get failedToSendOtpPleaseTryAgain {
    return Intl.message(
      'Failed to send OTP. Please try again.',
      name: 'failedToSendOtpPleaseTryAgain',
      desc: '',
      args: [],
    );
  }

  /// `Agree with `
  String get agreeWith {
    return Intl.message('Agree with ', name: 'agreeWith', desc: '', args: []);
  }

  /// `Terms & Conditions`
  String get termsConditions {
    return Intl.message(
      'Terms & Conditions',
      name: 'termsConditions',
      desc: '',
      args: [],
    );
  }

  /// `Please accept the Terms & Conditions to continue.`
  String get pleaseAcceptTheTermsConditionsToContinue {
    return Intl.message(
      'Please accept the Terms & Conditions to continue.',
      name: 'pleaseAcceptTheTermsConditionsToContinue',
      desc: '',
      args: [],
    );
  }

  /// `OR`
  String get or {
    return Intl.message('OR', name: 'or', desc: '', args: []);
  }

  /// `Back to Login`
  String get backToLogin {
    return Intl.message(
      'Back to Login',
      name: 'backToLogin',
      desc: '',
      args: [],
    );
  }

  /// `Enter Password`
  String get enterPassword {
    return Intl.message(
      'Enter Password',
      name: 'enterPassword',
      desc: '',
      args: [],
    );
  }

  /// `Re-Enter Password`
  String get reenterPassword {
    return Intl.message(
      'Re-Enter Password',
      name: 'reenterPassword',
      desc: '',
      args: [],
    );
  }

  /// `Sign up`
  String get signUp {
    return Intl.message('Sign up', name: 'signUp', desc: '', args: []);
  }

  /// `Location permission not granted.`
  String get locationPermissionNotGranted {
    return Intl.message(
      'Location permission not granted.',
      name: 'locationPermissionNotGranted',
      desc: '',
      args: [],
    );
  }

  /// `Enable Location`
  String get enableLocation {
    return Intl.message(
      'Enable Location',
      name: 'enableLocation',
      desc: '',
      args: [],
    );
  }

  /// `Location services are disabled. Please turn on GPS to continue.`
  String get locationServicesAreDisabledPleaseTurnOnGpsToContinue {
    return Intl.message(
      'Location services are disabled. Please turn on GPS to continue.',
      name: 'locationServicesAreDisabledPleaseTurnOnGpsToContinue',
      desc: '',
      args: [],
    );
  }

  /// `Open Settings`
  String get openSettings {
    return Intl.message(
      'Open Settings',
      name: 'openSettings',
      desc: '',
      args: [],
    );
  }

  /// `Verify`
  String get verify {
    return Intl.message('Verify', name: 'verify', desc: '', args: []);
  }

  /// `Please select a time`
  String get pleaseSelectATime {
    return Intl.message(
      'Please select a time',
      name: 'pleaseSelectATime',
      desc: '',
      args: [],
    );
  }

  /// `Wallet`
  String get wallet {
    return Intl.message('Wallet', name: 'wallet', desc: '', args: []);
  }

  /// `Total Amount`
  String get totalAmount {
    return Intl.message(
      'Total Amount',
      name: 'totalAmount',
      desc: '',
      args: [],
    );
  }

  /// `Transactions`
  String get transactions {
    return Intl.message(
      'Transactions',
      name: 'transactions',
      desc: '',
      args: [],
    );
  }

  /// `View All`
  String get viewAll {
    return Intl.message('View All', name: 'viewAll', desc: '', args: []);
  }

  /// `No transactions found.`
  String get noTransactionsFound {
    return Intl.message(
      'No transactions found.',
      name: 'noTransactionsFound',
      desc: '',
      args: [],
    );
  }

  /// `Terms and Conditions`
  String get termsAndConditions {
    return Intl.message(
      'Terms and Conditions',
      name: 'termsAndConditions',
      desc: '',
      args: [],
    );
  }

  /// `Privacy Policy`
  String get privacyPolicy {
    return Intl.message(
      'Privacy Policy',
      name: 'privacyPolicy',
      desc: '',
      args: [],
    );
  }

  /// `No data available`
  String get noDataAvailable {
    return Intl.message(
      'No data available',
      name: 'noDataAvailable',
      desc: '',
      args: [],
    );
  }

  /// `My Favourite Players`
  String get myFavouritePlayers {
    return Intl.message(
      'My Favourite Players',
      name: 'myFavouritePlayers',
      desc: '',
      args: [],
    );
  }

  /// `No favourite players found!`
  String get noFavouritePlayersFound {
    return Intl.message(
      'No favourite players found!',
      name: 'noFavouritePlayersFound',
      desc: '',
      args: [],
    );
  }

  /// `My Account`
  String get myAccount {
    return Intl.message('My Account', name: 'myAccount', desc: '', args: []);
  }

  /// `Mobile Number`
  String get mobileNumber {
    return Intl.message(
      'Mobile Number',
      name: 'mobileNumber',
      desc: '',
      args: [],
    );
  }

  /// `Skill Set`
  String get skillSet {
    return Intl.message('Skill Set', name: 'skillSet', desc: '', args: []);
  }

  /// `Edit Profile`
  String get editProfile {
    return Intl.message(
      'Edit Profile',
      name: 'editProfile',
      desc: '',
      args: [],
    );
  }

  /// `Camera`
  String get camera {
    return Intl.message('Camera', name: 'camera', desc: '', args: []);
  }

  /// `Gallery`
  String get gallery {
    return Intl.message('Gallery', name: 'gallery', desc: '', args: []);
  }

  /// `Enter Your Name`
  String get enterYourName {
    return Intl.message(
      'Enter Your Name',
      name: 'enterYourName',
      desc: '',
      args: [],
    );
  }

  /// `Enter Your Email`
  String get enterYourEmail {
    return Intl.message(
      'Enter Your Email',
      name: 'enterYourEmail',
      desc: '',
      args: [],
    );
  }

  /// `Add More`
  String get addMore {
    return Intl.message('Add More', name: 'addMore', desc: '', args: []);
  }

  /// `Save Profile`
  String get saveProfile {
    return Intl.message(
      'Save Profile',
      name: 'saveProfile',
      desc: '',
      args: [],
    );
  }

  /// `Error: Please enter your name`
  String get errorPleaseEnterYourName {
    return Intl.message(
      'Error: Please enter your name',
      name: 'errorPleaseEnterYourName',
      desc: '',
      args: [],
    );
  }

  /// `Error: Please select skills`
  String get errorPleaseSelectSkills {
    return Intl.message(
      'Error: Please select skills',
      name: 'errorPleaseSelectSkills',
      desc: '',
      args: [],
    );
  }

  /// `Error: Please enter your email`
  String get errorPleaseEnterYourEmail {
    return Intl.message(
      'Error: Please enter your email',
      name: 'errorPleaseEnterYourEmail',
      desc: '',
      args: [],
    );
  }

  /// `About Us`
  String get aboutUs {
    return Intl.message('About Us', name: 'aboutUs', desc: '', args: []);
  }

  /// `Booking Not Available yet`
  String get bookingNotAvailableYet {
    return Intl.message(
      'Booking Not Available yet',
      name: 'bookingNotAvailableYet',
      desc: '',
      args: [],
    );
  }

  /// `Split`
  String get split {
    return Intl.message('Split', name: 'split', desc: '', args: []);
  }

  /// `Cancel Bookings`
  String get cancelBookings {
    return Intl.message(
      'Cancel Bookings',
      name: 'cancelBookings',
      desc: '',
      args: [],
    );
  }

  /// `Are you sure you want to cancel this challenge? If yes, please press the confirm button. We will deduct the platform fee, and the remaining amount will be transferred to your wallet. Thank you.`
  String get areYouSureYouWantToCancelThisChallengeIf {
    return Intl.message(
      'Are you sure you want to cancel this challenge? If yes, please press the confirm button. We will deduct the platform fee, and the remaining amount will be transferred to your wallet. Thank you.',
      name: 'areYouSureYouWantToCancelThisChallengeIf',
      desc: '',
      args: [],
    );
  }

  /// `Favorite Courts`
  String get favoriteCourts {
    return Intl.message(
      'Favorite Courts',
      name: 'favoriteCourts',
      desc: '',
      args: [],
    );
  }

  /// `Favorite Courts Not Available`
  String get favoriteCourtsNotAvailable {
    return Intl.message(
      'Favorite Courts Not Available',
      name: 'favoriteCourtsNotAvailable',
      desc: '',
      args: [],
    );
  }

  /// `Bookings`
  String get bookings {
    return Intl.message('Bookings', name: 'bookings', desc: '', args: []);
  }

  /// `Quick Rebook`
  String get quickRebook {
    return Intl.message(
      'Quick Rebook',
      name: 'quickRebook',
      desc: '',
      args: [],
    );
  }

  /// `Rate the Court`
  String get rateTheCourt {
    return Intl.message(
      'Rate the Court',
      name: 'rateTheCourt',
      desc: '',
      args: [],
    );
  }

  /// `Write the comment`
  String get writeTheComment {
    return Intl.message(
      'Write the comment',
      name: 'writeTheComment',
      desc: '',
      args: [],
    );
  }

  /// `Review`
  String get review {
    return Intl.message('Review', name: 'review', desc: '', args: []);
  }

  /// `Booking Details`
  String get bookingDetails {
    return Intl.message(
      'Booking Details',
      name: 'bookingDetails',
      desc: '',
      args: [],
    );
  }

  /// `Court Booking`
  String get courtBooking {
    return Intl.message(
      'Court Booking',
      name: 'courtBooking',
      desc: '',
      args: [],
    );
  }

  /// `Full Paid`
  String get fullPaid {
    return Intl.message('Full Paid', name: 'fullPaid', desc: '', args: []);
  }

  /// `Description : `
  String get description {
    return Intl.message(
      'Description : ',
      name: 'description',
      desc: '',
      args: [],
    );
  }

  /// `Rules : `
  String get rules {
    return Intl.message('Rules : ', name: 'rules', desc: '', args: []);
  }

  /// `Friend`
  String get friend {
    return Intl.message('Friend', name: 'friend', desc: '', args: []);
  }

  /// `View Court Details`
  String get viewCourtDetails {
    return Intl.message(
      'View Court Details',
      name: 'viewCourtDetails',
      desc: '',
      args: [],
    );
  }

  /// `Cancel Booking`
  String get cancelBooking {
    return Intl.message(
      'Cancel Booking',
      name: 'cancelBooking',
      desc: '',
      args: [],
    );
  }

  /// `Player going`
  String get playerGoing {
    return Intl.message(
      'Player going',
      name: 'playerGoing',
      desc: '',
      args: [],
    );
  }

  /// `Out of `
  String get outOf {
    return Intl.message('Out of ', name: 'outOf', desc: '', args: []);
  }

  /// `Book Now`
  String get bookNow {
    return Intl.message('Book Now', name: 'bookNow', desc: '', args: []);
  }

  /// `Added Amount`
  String get addedAmount {
    return Intl.message(
      'Added Amount',
      name: 'addedAmount',
      desc: '',
      args: [],
    );
  }

  /// `Paid Amount`
  String get paidAmount {
    return Intl.message('Paid Amount', name: 'paidAmount', desc: '', args: []);
  }

  /// `Refunded`
  String get refunded {
    return Intl.message('Refunded', name: 'refunded', desc: '', args: []);
  }

  /// `Transaction Details`
  String get transactionDetails {
    return Intl.message(
      'Transaction Details',
      name: 'transactionDetails',
      desc: '',
      args: [],
    );
  }

  /// `Transaction info: `
  String get transactionInfo {
    return Intl.message(
      'Transaction info: ',
      name: 'transactionInfo',
      desc: '',
      args: [],
    );
  }

  /// `Successful`
  String get successful {
    return Intl.message('Successful', name: 'successful', desc: '', args: []);
  }

  /// `From `
  String get from {
    return Intl.message('From ', name: 'from', desc: '', args: []);
  }

  /// `Transaction ID `
  String get transactionId {
    return Intl.message(
      'Transaction ID ',
      name: 'transactionId',
      desc: '',
      args: [],
    );
  }

  /// `Transaction`
  String get transaction {
    return Intl.message('Transaction', name: 'transaction', desc: '', args: []);
  }

  /// `Back`
  String get back {
    return Intl.message('Back', name: 'back', desc: '', args: []);
  }

  /// `Delete Account`
  String get deleteAccount {
    return Intl.message(
      'Delete Account',
      name: 'deleteAccount',
      desc: '',
      args: [],
    );
  }

  /// `Do you really want to delete this account?`
  String get doYouReallyWantToDeleteThisAccount {
    return Intl.message(
      'Do you really want to delete this account?',
      name: 'doYouReallyWantToDeleteThisAccount',
      desc: '',
      args: [],
    );
  }

  /// `Logout`
  String get logout {
    return Intl.message('Logout', name: 'logout', desc: '', args: []);
  }

  /// `Are you sure you want to logout your account?`
  String get areYouSureYouWantToLogoutYourAccount {
    return Intl.message(
      'Are you sure you want to logout your account?',
      name: 'areYouSureYouWantToLogoutYourAccount',
      desc: '',
      args: [],
    );
  }

  /// `App Version`
  String get appVersion {
    return Intl.message('App Version', name: 'appVersion', desc: '', args: []);
  }

  /// `Reviews`
  String get reviews {
    return Intl.message('Reviews', name: 'reviews', desc: '', args: []);
  }

  /// `Exit`
  String get exit {
    return Intl.message('Exit', name: 'exit', desc: '', args: []);
  }

  /// `Exit App`
  String get exitApp {
    return Intl.message('Exit App', name: 'exitApp', desc: '', args: []);
  }

  /// `Are you sure you want to exit?`
  String get areYouSureYouWantToExit {
    return Intl.message(
      'Are you sure you want to exit?',
      name: 'areYouSureYouWantToExit',
      desc: '',
      args: [],
    );
  }

  /// `Data`
  String get data {
    return Intl.message('Data', name: 'data', desc: '', args: []);
  }

  /// `No`
  String get no {
    return Intl.message('No', name: 'no', desc: '', args: []);
  }

  /// `Found`
  String get found {
    return Intl.message('Found', name: 'found', desc: '', args: []);
  }

  /// `Otp Required`
  String get otpRequired {
    return Intl.message(
      'Otp Required',
      name: 'otpRequired',
      desc: '',
      args: [],
    );
  }

  /// `Invalid Otp`
  String get invalidOtp {
    return Intl.message('Invalid Otp', name: 'invalidOtp', desc: '', args: []);
  }

  /// `Select`
  String get select {
    return Intl.message('Select', name: 'select', desc: '', args: []);
  }

  /// `Select Location`
  String get selectLocation {
    return Intl.message(
      'Select Location',
      name: 'selectLocation',
      desc: '',
      args: [],
    );
  }

  /// `Search place...`
  String get searchPlace {
    return Intl.message(
      'Search place...',
      name: 'searchPlace',
      desc: '',
      args: [],
    );
  }

  /// `Please select a valid location.`
  String get pleaseSelectAValidLocation {
    return Intl.message(
      'Please select a valid location.',
      name: 'pleaseSelectAValidLocation',
      desc: '',
      args: [],
    );
  }

  /// `Confirm`
  String get confirm {
    return Intl.message('Confirm', name: 'confirm', desc: '', args: []);
  }

  /// `Search Courts`
  String get searchCourts {
    return Intl.message(
      'Search Courts',
      name: 'searchCourts',
      desc: '',
      args: [],
    );
  }

  /// `Fetching Current Location...`
  String get fetchingCurrentLocation {
    return Intl.message(
      'Fetching Current Location...',
      name: 'fetchingCurrentLocation',
      desc: '',
      args: [],
    );
  }

  /// `Select Date`
  String get selectDate {
    return Intl.message('Select Date', name: 'selectDate', desc: '', args: []);
  }

  /// `Welcome to`
  String get welcomeTo {
    return Intl.message('Welcome to', name: 'welcomeTo', desc: '', args: []);
  }

  /// `Krat Easy`
  String get kratEasy {
    return Intl.message('Krat Easy', name: 'kratEasy', desc: '', args: []);
  }

  /// `Set your location to start exploring\n sports courts around you.`
  String get setYourLocationToStartExploringnSportsCourtsAroundYou {
    return Intl.message(
      'Set your location to start exploring sports courts around you.',
      name: 'setYourLocationToStartExploringnSportsCourtsAroundYou',
      desc: '',
      args: [],
    );
  }

  /// `Detect my location`
  String get detectMyLocation {
    return Intl.message(
      'Detect my location',
      name: 'detectMyLocation',
      desc: '',
      args: [],
    );
  }

  /// `Select Location Manually`
  String get selectLocationManually {
    return Intl.message(
      'Select Location Manually',
      name: 'selectLocationManually',
      desc: '',
      args: [],
    );
  }

  /// `Add Address`
  String get addAddress {
    return Intl.message('Add Address', name: 'addAddress', desc: '', args: []);
  }

  /// `Address`
  String get address {
    return Intl.message('Address', name: 'address', desc: '', args: []);
  }

  /// `City`
  String get city {
    return Intl.message('City', name: 'city', desc: '', args: []);
  }

  /// `Country`
  String get country {
    return Intl.message('Country', name: 'country', desc: '', args: []);
  }

  /// `Nearby Courts`
  String get nearbyCourts {
    return Intl.message(
      'Nearby Courts',
      name: 'nearbyCourts',
      desc: '',
      args: [],
    );
  }

  /// `Booking ID: `
  String get bookingId {
    return Intl.message('Booking ID: ', name: 'bookingId', desc: '', args: []);
  }

  /// `Unable to fetch booking id`
  String get unableToFetchBookingId {
    return Intl.message(
      'Unable to fetch booking id',
      name: 'unableToFetchBookingId',
      desc: '',
      args: [],
    );
  }

  /// `We have successfully send the QR code to your email.Use it for your entry`
  String get weHaveSuccessfullySendTheQrCodeToYourEmailuse {
    return Intl.message(
      'We have successfully send the QR code to your email.Use it for your entry',
      name: 'weHaveSuccessfullySendTheQrCodeToYourEmailuse',
      desc: '',
      args: [],
    );
  }

  /// `Share Payment Link`
  String get sharePaymentLink {
    return Intl.message(
      'Share Payment Link',
      name: 'sharePaymentLink',
      desc: '',
      args: [],
    );
  }

  /// `All players will use this link to make\ntheir split payment`
  String get allPlayersWillUseThisLinkToMakentheirSplitPayment {
    return Intl.message(
      'All players will use this link to make their split payment',
      name: 'allPlayersWillUseThisLinkToMakentheirSplitPayment',
      desc: '',
      args: [],
    );
  }

  /// `Go to Home`
  String get goToHome {
    return Intl.message('Go to Home', name: 'goToHome', desc: '', args: []);
  }

  /// `Left`
  String get left {
    return Intl.message('Left', name: 'left', desc: '', args: []);
  }

  /// `Paid`
  String get paid {
    return Intl.message('Paid', name: 'paid', desc: '', args: []);
  }

  /// `Players`
  String get players {
    return Intl.message('Players', name: 'players', desc: '', args: []);
  }

  /// `Credit & Debit Card`
  String get creditDebitCard {
    return Intl.message(
      'Credit & Debit Card',
      name: 'creditDebitCard',
      desc: '',
      args: [],
    );
  }

  /// `Add Card`
  String get addCard {
    return Intl.message('Add Card', name: 'addCard', desc: '', args: []);
  }

  /// `More Payments Options`
  String get morePaymentsOptions {
    return Intl.message(
      'More Payments Options',
      name: 'morePaymentsOptions',
      desc: '',
      args: [],
    );
  }

  /// `Apple Pay`
  String get applePay {
    return Intl.message('Apple Pay', name: 'applePay', desc: '', args: []);
  }

  /// `Google Pay`
  String get googlePay {
    return Intl.message('Google Pay', name: 'googlePay', desc: '', args: []);
  }

  /// `Please select a payment method`
  String get pleaseSelectAPaymentMethod {
    return Intl.message(
      'Please select a payment method',
      name: 'pleaseSelectAPaymentMethod',
      desc: '',
      args: [],
    );
  }

  /// `Confirm Payment`
  String get confirmPayment {
    return Intl.message(
      'Confirm Payment',
      name: 'confirmPayment',
      desc: '',
      args: [],
    );
  }

  /// `Resend in`
  String get resendIn {
    return Intl.message('Resend in', name: 'resendIn', desc: '', args: []);
  }

  /// `Cancel Challenge`
  String get cancelChallenge {
    return Intl.message(
      'Cancel Challenge',
      name: 'cancelChallenge',
      desc: '',
      args: [],
    );
  }

  /// `Join Challenge`
  String get joinChallenge {
    return Intl.message(
      'Join Challenge',
      name: 'joinChallenge',
      desc: '',
      args: [],
    );
  }

  /// `Feeds`
  String get feeds {
    return Intl.message('Feeds', name: 'feeds', desc: '', args: []);
  }

  /// `Public`
  String get public {
    return Intl.message('Public', name: 'public', desc: '', args: []);
  }

  /// `Private`
  String get private {
    return Intl.message('Private', name: 'private', desc: '', args: []);
  }

  /// `Created By`
  String get createdBy {
    return Intl.message('Created By', name: 'createdBy', desc: '', args: []);
  }

  /// `Amenities : `
  String get amenitiesclg {
    return Intl.message(
      'Amenities : ',
      name: 'amenitiesclg',
      desc: '',
      args: [],
    );
  }

  /// `Booking`
  String get booking {
    return Intl.message('Booking', name: 'booking', desc: '', args: []);
  }

  /// `Min. Time to Book: `
  String get minTimeToBook {
    return Intl.message(
      'Min. Time to Book: ',
      name: 'minTimeToBook',
      desc: '',
      args: [],
    );
  }

  /// `Slots`
  String get slots {
    return Intl.message('Slots', name: 'slots', desc: '', args: []);
  }

  /// `Do you want recorded or not ?`
  String get doYouWantRecordedOrNot {
    return Intl.message(
      'Do you want recorded or not ?',
      name: 'doYouWantRecordedOrNot',
      desc: '',
      args: [],
    );
  }

  /// `Split payment with friends`
  String get splitPaymentWithFriends {
    return Intl.message(
      'Split payment with friends',
      name: 'splitPaymentWithFriends',
      desc: '',
      args: [],
    );
  }

  /// `Add Friends`
  String get addFriends {
    return Intl.message('Add Friends', name: 'addFriends', desc: '', args: []);
  }

  /// `Add Friends & Split the Cost! ⚽🏀`
  String get addFriendsSplitTheCost {
    return Intl.message(
      'Add Friends & Split the Cost! ⚽🏀',
      name: 'addFriendsSplitTheCost',
      desc: '',
      args: [],
    );
  }

  /// `Remove`
  String get remove {
    return Intl.message('Remove', name: 'remove', desc: '', args: []);
  }

  /// `Pay Amount`
  String get payAmount {
    return Intl.message('Pay Amount', name: 'payAmount', desc: '', args: []);
  }

  /// `Promo Code`
  String get promoCode {
    return Intl.message('Promo Code', name: 'promoCode', desc: '', args: []);
  }

  /// `Applied`
  String get applied {
    return Intl.message('Applied', name: 'applied', desc: '', args: []);
  }

  /// `Please enter promo code`
  String get pleaseEnterPromoCode {
    return Intl.message(
      'Please enter promo code',
      name: 'pleaseEnterPromoCode',
      desc: '',
      args: [],
    );
  }

  /// `Checkout`
  String get checkout {
    return Intl.message('Checkout', name: 'checkout', desc: '', args: []);
  }

  /// `Please add friends to split the cost.`
  String get pleaseAddFriendsToSplitTheCost {
    return Intl.message(
      'Please add friends to split the cost.',
      name: 'pleaseAddFriendsToSplitTheCost',
      desc: '',
      args: [],
    );
  }

  /// `Slot not available.`
  String get slotNotAvailable {
    return Intl.message(
      'Slot not available.',
      name: 'slotNotAvailable',
      desc: '',
      args: [],
    );
  }

  /// `Please select a slot to continue.`
  String get pleaseSelectASlotToContinue {
    return Intl.message(
      'Please select a slot to continue.',
      name: 'pleaseSelectASlotToContinue',
      desc: '',
      args: [],
    );
  }

  /// `Search Contact`
  String get searchContact {
    return Intl.message(
      'Search Contact',
      name: 'searchContact',
      desc: '',
      args: [],
    );
  }

  /// `Contact List is empty !`
  String get contactListIsEmpty {
    return Intl.message(
      'Contact List is empty !',
      name: 'contactListIsEmpty',
      desc: '',
      args: [],
    );
  }

  /// `No Number`
  String get noNumber {
    return Intl.message('No Number', name: 'noNumber', desc: '', args: []);
  }

  /// `Added`
  String get added {
    return Intl.message('Added', name: 'added', desc: '', args: []);
  }

  /// `Add`
  String get add {
    return Intl.message('Add', name: 'add', desc: '', args: []);
  }

  /// `Select Language`
  String get selectLanguage {
    return Intl.message(
      'Select Language',
      name: 'selectLanguage',
      desc: '',
      args: [],
    );
  }

  /// `English`
  String get english {
    return Intl.message('English', name: 'english', desc: '', args: []);
  }

  /// `Greek`
  String get greek {
    return Intl.message('Greek', name: 'greek', desc: '', args: []);
  }

  /// `Location not fetched. Please try again.`
  String get locationNotFetchedPleaseTryAgain {
    return Intl.message(
      'Location not fetched. Please try again.',
      name: 'locationNotFetchedPleaseTryAgain',
      desc: '',
      args: [],
    );
  }

  /// `Please select at least one time slot`
  String get pleaseSelectAtLeastOneTimeSlot {
    return Intl.message(
      'Please select at least one time slot',
      name: 'pleaseSelectAtLeastOneTimeSlot',
      desc: '',
      args: [],
    );
  }

  /// `Invalid sport selection.`
  String get invalidSportSelection {
    return Intl.message(
      'Invalid sport selection.',
      name: 'invalidSportSelection',
      desc: '',
      args: [],
    );
  }

  /// `No data found.`
  String get noDataFound {
    return Intl.message(
      'No data found.',
      name: 'noDataFound',
      desc: '',
      args: [],
    );
  }

  /// `Error`
  String get error {
    return Intl.message('Error', name: 'error', desc: '', args: []);
  }

  /// `going`
  String get going {
    return Intl.message('going', name: 'going', desc: '', args: []);
  }

  /// `What sport do you want to play?`
  String get whatSportDoYouWantToPlay {
    return Intl.message(
      'What sport do you want to play?',
      name: 'whatSportDoYouWantToPlay',
      desc: '',
      args: [],
    );
  }

  /// `Please select at least one slot to continue.`
  String get pleaseSelectAtLeastOneSlotToContinue {
    return Intl.message(
      'Please select at least one slot to continue.',
      name: 'pleaseSelectAtLeastOneSlotToContinue',
      desc: '',
      args: [],
    );
  }

  /// `Courts`
  String get courts {
    return Intl.message('Courts', name: 'courts', desc: '', args: []);
  }

  /// `Please select a date`
  String get pleaseSelectADate {
    return Intl.message(
      'Please select a date',
      name: 'pleaseSelectADate',
      desc: '',
      args: [],
    );
  }

  /// `Location not available`
  String get locationNotAvailable {
    return Intl.message(
      'Location not available',
      name: 'locationNotAvailable',
      desc: '',
      args: [],
    );
  }

  /// `JOIN US`
  String get joinUs {
    return Intl.message('JOIN US', name: 'joinUs', desc: '', args: []);
  }

  /// `I agree to the Terms & Conditions`
  String get iAgreeToTheTermsConditions {
    return Intl.message(
      'I agree to the Terms & Conditions',
      name: 'iAgreeToTheTermsConditions',
      desc: '',
      args: [],
    );
  }

  /// `Add another Recipient`
  String get addAnotherRecipient {
    return Intl.message(
      'Add another Recipient',
      name: 'addAnotherRecipient',
      desc: '',
      args: [],
    );
  }

  /// `Friend List Is Empty!`
  String get friendListIsEmpty {
    return Intl.message(
      'Friend List Is Empty!',
      name: 'friendListIsEmpty',
      desc: '',
      args: [],
    );
  }

  /// `readAll`
  String get readall {
    return Intl.message('readAll', name: 'readall', desc: '', args: []);
  }

  /// `Can't read notification not found`
  String get cantReadNotificationNotFound {
    return Intl.message(
      'Can\'t read notification not found',
      name: 'cantReadNotificationNotFound',
      desc: '',
      args: [],
    );
  }

  /// `Read All`
  String get readAllNew {
    return Intl.message('Read All', name: 'readAllNew', desc: '', args: []);
  }

  /// `Unread All`
  String get unreadAll {
    return Intl.message('Unread All', name: 'unreadAll', desc: '', args: []);
  }

  /// `Can't unread notification not found`
  String get cantUnreadNotificationNotFound {
    return Intl.message(
      'Can\'t unread notification not found',
      name: 'cantUnreadNotificationNotFound',
      desc: '',
      args: [],
    );
  }

  /// `Can't delete notification not found`
  String get cantDeleteNotificationNotFound {
    return Intl.message(
      'Can\'t delete notification not found',
      name: 'cantDeleteNotificationNotFound',
      desc: '',
      args: [],
    );
  }

  /// `Delete All`
  String get deleteAll {
    return Intl.message('Delete All', name: 'deleteAll', desc: '', args: []);
  }

  /// `No notifications available`
  String get noNotificationsAvailable {
    return Intl.message(
      'No notifications available',
      name: 'noNotificationsAvailable',
      desc: '',
      args: [],
    );
  }

  /// `Completed`
  String get completed {
    return Intl.message('Completed', name: 'completed', desc: '', args: []);
  }

  /// `Challenge your friends, compete together, and\nenjoy exclusive matches!`
  String get challengeYourFriendsCompeteTogetherAndnenjoyExclusiveMatches {
    return Intl.message(
      'Challenge your friends, compete together, and\\nenjoy exclusive matches!',
      name: 'challengeYourFriendsCompeteTogetherAndnenjoyExclusiveMatches',
      desc: '',
      args: [],
    );
  }

  /// `Play Again`
  String get playAgain {
    return Intl.message('Play Again', name: 'playAgain', desc: '', args: []);
  }

  /// `View Detail`
  String get viewDetail {
    return Intl.message('View Detail', name: 'viewDetail', desc: '', args: []);
  }

  /// `Rebook`
  String get rebook {
    return Intl.message('Rebook', name: 'rebook', desc: '', args: []);
  }

  /// `See All`
  String get seeAll {
    return Intl.message('See All', name: 'seeAll', desc: '', args: []);
  }

  /// `INVITE CODE: `
  String get inviteCode {
    return Intl.message(
      'INVITE CODE: ',
      name: 'inviteCode',
      desc: '',
      args: [],
    );
  }

  /// `Your Sports Community App`
  String get yourSportsCommunityApp {
    return Intl.message(
      'Your Sports Community App',
      name: 'yourSportsCommunityApp',
      desc: '',
      args: [],
    );
  }

  /// `Terms of Service`
  String get termsOfService {
    return Intl.message(
      'Terms of Service',
      name: 'termsOfService',
      desc: '',
      args: [],
    );
  }

  /// `Enter Invite Challenge Code`
  String get enterInviteChallengeCode {
    return Intl.message(
      'Enter Invite Challenge Code',
      name: 'enterInviteChallengeCode',
      desc: '',
      args: [],
    );
  }

  /// `Enter Code`
  String get enterCode {
    return Intl.message('Enter Code', name: 'enterCode', desc: '', args: []);
  }

  /// `Create Challenge`
  String get createChallengeBt {
    return Intl.message(
      'Create Challenge',
      name: 'createChallengeBt',
      desc: '',
      args: [],
    );
  }

  /// `Select Facility`
  String get selectFacility {
    return Intl.message(
      'Select Facility',
      name: 'selectFacility',
      desc: '',
      args: [],
    );
  }

  /// `Search Facility`
  String get searchFacility {
    return Intl.message(
      'Search Facility',
      name: 'searchFacility',
      desc: '',
      args: [],
    );
  }

  /// `List of Facilities`
  String get listOfFacilities {
    return Intl.message(
      'List of Facilities',
      name: 'listOfFacilities',
      desc: '',
      args: [],
    );
  }

  /// `Please select a sorting option`
  String get pleaseSelectASortingOption {
    return Intl.message(
      'Please select a sorting option',
      name: 'pleaseSelectASortingOption',
      desc: '',
      args: [],
    );
  }

  /// `Sort`
  String get sort {
    return Intl.message('Sort', name: 'sort', desc: '', args: []);
  }

  /// `Please select at least one amenity`
  String get pleaseSelectAtLeastOneAmenity {
    return Intl.message(
      'Please select at least one amenity',
      name: 'pleaseSelectAtLeastOneAmenity',
      desc: '',
      args: [],
    );
  }

  /// `Radius (Distance)`
  String get radiusDistance {
    return Intl.message(
      'Radius (Distance)',
      name: 'radiusDistance',
      desc: '',
      args: [],
    );
  }

  /// `miles`
  String get miles {
    return Intl.message('miles', name: 'miles', desc: '', args: []);
  }

  /// `Rating`
  String get rating {
    return Intl.message('Rating', name: 'rating', desc: '', args: []);
  }

  /// `Facilities not available`
  String get facilitiesNotAvailable {
    return Intl.message(
      'Facilities not available',
      name: 'facilitiesNotAvailable',
      desc: '',
      args: [],
    );
  }

  /// `Available`
  String get available {
    return Intl.message('Available', name: 'available', desc: '', args: []);
  }

  /// `Search Challenges`
  String get searchChallenges {
    return Intl.message(
      'Search Challenges',
      name: 'searchChallenges',
      desc: '',
      args: [],
    );
  }

  /// `Price (Min & Max)`
  String get priceMinMax {
    return Intl.message(
      'Price (Min & Max)',
      name: 'priceMinMax',
      desc: '',
      args: [],
    );
  }

  /// `Court Size`
  String get courtSize {
    return Intl.message('Court Size', name: 'courtSize', desc: '', args: []);
  }

  /// `Search by Facility Name or Court Name`
  String get searchByFacilityNameOrCourtName {
    return Intl.message(
      'Search by Facility Name or Court Name',
      name: 'searchByFacilityNameOrCourtName',
      desc: '',
      args: [],
    );
  }

  /// `Number of Player`
  String get numberOfPlayer {
    return Intl.message(
      'Number of Player',
      name: 'numberOfPlayer',
      desc: '',
      args: [],
    );
  }

  /// `s`
  String get s {
    return Intl.message('s', name: 's', desc: '', args: []);
  }

  /// `No Challenges Available`
  String get noChallengesAvailable {
    return Intl.message(
      'No Challenges Available',
      name: 'noChallengesAvailable',
      desc: '',
      args: [],
    );
  }

  /// `Facility Details`
  String get facilityDetails {
    return Intl.message(
      'Facility Details',
      name: 'facilityDetails',
      desc: '',
      args: [],
    );
  }

  /// `Share`
  String get share {
    return Intl.message('Share', name: 'share', desc: '', args: []);
  }

  /// `Choose Payment Method`
  String get choosePaymentMethod {
    return Intl.message(
      'Choose Payment Method',
      name: 'choosePaymentMethod',
      desc: '',
      args: [],
    );
  }

  /// `Challenge Type`
  String get challengeType {
    return Intl.message(
      'Challenge Type',
      name: 'challengeType',
      desc: '',
      args: [],
    );
  }

  /// `Note: `
  String get noteHeader {
    return Intl.message('Note: ', name: 'noteHeader', desc: '', args: []);
  }

  /// `Open for anyone to join.`
  String get openForAnyoneToJoin {
    return Intl.message(
      'Open for anyone to join.',
      name: 'openForAnyoneToJoin',
      desc: '',
      args: [],
    );
  }

  /// `Select specific users to challenge.`
  String get selectSpecificUsersToChallenge {
    return Intl.message(
      'Select specific users to challenge.',
      name: 'selectSpecificUsersToChallenge',
      desc: '',
      args: [],
    );
  }

  /// `Refund minus a small convenience fee`
  String get refundMinusASmallConvenienceFee {
    return Intl.message(
      'Refund minus a small convenience fee',
      name: 'refundMinusASmallConvenienceFee',
      desc: '',
      args: [],
    );
  }

  /// `Level: `
  String get level {
    return Intl.message('Level: ', name: 'level', desc: '', args: []);
  }

  /// `Match Type: `
  String get matchType {
    return Intl.message('Match Type: ', name: 'matchType', desc: '', args: []);
  }

  /// `Active`
  String get active {
    return Intl.message('Active', name: 'active', desc: '', args: []);
  }

  /// `Inactive`
  String get inactive {
    return Intl.message('Inactive', name: 'inactive', desc: '', args: []);
  }

  /// `Courts Available`
  String get courtsnavailableoblic {
    return Intl.message(
      'Courts Available',
      name: 'courtsnavailableoblic',
      desc: '',
      args: [],
    );
  }

  /// `Facilities Listing`
  String get facilitiesListing {
    return Intl.message(
      'Facilities Listing',
      name: 'facilitiesListing',
      desc: '',
      args: [],
    );
  }

  /// `Completed Challenges`
  String get completedChallenges {
    return Intl.message(
      'Completed Challenges',
      name: 'completedChallenges',
      desc: '',
      args: [],
    );
  }

  /// `Active Challenges`
  String get activeChallenges {
    return Intl.message(
      'Active Challenges',
      name: 'activeChallenges',
      desc: '',
      args: [],
    );
  }

  /// `Added Friends`
  String get addedFriends {
    return Intl.message(
      'Added Friends',
      name: 'addedFriends',
      desc: '',
      args: [],
    );
  }

  /// `View Challenge`
  String get viewChallenge {
    return Intl.message(
      'View Challenge',
      name: 'viewChallenge',
      desc: '',
      args: [],
    );
  }

  /// `Register/ Login`
  String get alreadyHaveAccountS {
    return Intl.message(
      'Register/ Login',
      name: 'alreadyHaveAccountS',
      desc: '',
      args: [],
    );
  }

  /// `Modify Booking`
  String get modifyBooking {
    return Intl.message(
      'Modify Booking',
      name: 'modifyBooking',
      desc: '',
      args: [],
    );
  }

  /// `Please verify your mobile number using the OTP.`
  String get verifyYourPhoneNumberWithOtp {
    return Intl.message(
      'Please verify your mobile number using the OTP.',
      name: 'verifyYourPhoneNumberWithOtp',
      desc: '',
      args: [],
    );
  }

  /// `Challenge not found`
  String get challengeNotFound {
    return Intl.message(
      'Challenge not found',
      name: 'challengeNotFound',
      desc: '',
      args: [],
    );
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<l10n> {
  const AppLocalizationDelegate();

  List<Locale> get supportedLocales {
    return const <Locale>[
      Locale.fromSubtags(languageCode: 'en'),
      Locale.fromSubtags(languageCode: 'el'),
    ];
  }

  @override
  bool isSupported(Locale locale) => _isSupported(locale);
  @override
  Future<l10n> load(Locale locale) => l10n.load(locale);
  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  bool _isSupported(Locale locale) {
    for (var supportedLocale in supportedLocales) {
      if (supportedLocale.languageCode == locale.languageCode) {
        return true;
      }
    }
    return false;
  }
}
