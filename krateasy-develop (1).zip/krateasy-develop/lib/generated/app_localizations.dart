import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_el.dart';
import 'app_localizations_en.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'generated/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale) : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates = <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('el'),
    Locale('en')
  ];

  /// No description provided for @joinNow.
  ///
  /// In en, this message translates to:
  /// **'Join Now'**
  String get joinNow;

  /// No description provided for @verificationCode.
  ///
  /// In en, this message translates to:
  /// **'Verification Code'**
  String get verificationCode;

  /// No description provided for @enterThe4digitCodeSentToYourPhone.
  ///
  /// In en, this message translates to:
  /// **'Enter the 4-digit code sent to your phone'**
  String get enterThe4digitCodeSentToYourPhone;

  /// No description provided for @didntReceiveACodeResend.
  ///
  /// In en, this message translates to:
  /// **'Didn\'t receive a code? Resend'**
  String get didntReceiveACodeResend;

  /// No description provided for @resendOtpIn50s.
  ///
  /// In en, this message translates to:
  /// **'Resend OTP in 50s'**
  String get resendOtpIn50s;

  /// No description provided for @verification.
  ///
  /// In en, this message translates to:
  /// **'Verification'**
  String get verification;

  /// No description provided for @joinPrivateChallengeByInvitingFriends.
  ///
  /// In en, this message translates to:
  /// **'Join Private Challenge by Inviting Friends'**
  String get joinPrivateChallengeByInvitingFriends;

  /// No description provided for @accountDeleteSuccessfully.
  ///
  /// In en, this message translates to:
  /// **'Account Delete Successfully'**
  String get accountDeleteSuccessfully;

  /// No description provided for @somethingsWentWrongdeleteaccount.
  ///
  /// In en, this message translates to:
  /// **'Somethings went wrong(deleteAccount)'**
  String get somethingsWentWrongdeleteaccount;

  /// No description provided for @somethingsWentWrongnotificationtoggle.
  ///
  /// In en, this message translates to:
  /// **'Somethings went wrong(notificationToggle)'**
  String get somethingsWentWrongnotificationtoggle;

  /// No description provided for @setPassword.
  ///
  /// In en, this message translates to:
  /// **'Set Password'**
  String get setPassword;

  /// No description provided for @creteAStrongPasswordItMustContain.
  ///
  /// In en, this message translates to:
  /// **'Crete a strong password. It must contain'**
  String get creteAStrongPasswordItMustContain;

  /// No description provided for @atLeast6CharactersAnd1SpecialSymbol.
  ///
  /// In en, this message translates to:
  /// **'at least 6 characters and 1 special symbol'**
  String get atLeast6CharactersAnd1SpecialSymbol;

  /// No description provided for @resetPassword.
  ///
  /// In en, this message translates to:
  /// **'Reset Password'**
  String get resetPassword;

  /// No description provided for @atLeast9CharactersWithUppercase.
  ///
  /// In en, this message translates to:
  /// **'At least 9 characters, with uppercase'**
  String get atLeast9CharactersWithUppercase;

  /// No description provided for @andLowercaseLetters.
  ///
  /// In en, this message translates to:
  /// **'and lowercase letters'**
  String get andLowercaseLetters;

  /// No description provided for @password.
  ///
  /// In en, this message translates to:
  /// **'Password'**
  String get password;

  /// No description provided for @successfullyChange.
  ///
  /// In en, this message translates to:
  /// **'Successfully Change'**
  String get successfullyChange;

  /// No description provided for @yourNewPasswordIsNowActive.
  ///
  /// In en, this message translates to:
  /// **'Your new password is now active.'**
  String get yourNewPasswordIsNowActive;

  /// No description provided for @staySecure.
  ///
  /// In en, this message translates to:
  /// **'Stay Secure!'**
  String get staySecure;

  /// No description provided for @yourAccount.
  ///
  /// In en, this message translates to:
  /// **'Your Account'**
  String get yourAccount;

  /// No description provided for @successfullyCreated.
  ///
  /// In en, this message translates to:
  /// **'Successfully Created'**
  String get successfullyCreated;

  /// No description provided for @yourAccountSuccessfullyCreatedClick.
  ///
  /// In en, this message translates to:
  /// **'Your account successfully created! Click'**
  String get yourAccountSuccessfullyCreatedClick;

  /// No description provided for @continueToGoToTheHomeScreen.
  ///
  /// In en, this message translates to:
  /// **'Continue to go to the home screen'**
  String get continueToGoToTheHomeScreen;

  /// No description provided for @welcomeEasybooking.
  ///
  /// In en, this message translates to:
  /// **'Welcome & Easy📍Booking'**
  String get welcomeEasybooking;

  /// No description provided for @takeOnTheChallenge.
  ///
  /// In en, this message translates to:
  /// **'Take on the Challenge! 💪🏆'**
  String get takeOnTheChallenge;

  /// No description provided for @findBookYourGameInSeconds.
  ///
  /// In en, this message translates to:
  /// **'Find & Book Your Game in Seconds!'**
  String get findBookYourGameInSeconds;

  /// No description provided for @joinAChallengeCompeteProveYourSkillsCreateAChallenge.
  ///
  /// In en, this message translates to:
  /// **'👉Join a Challenge: Compete prove your skills. 👉Create a Challenge: Invite others. 👉Public or Private: Open to all or just your crew!'**
  String get joinAChallengeCompeteProveYourSkillsCreateAChallenge;

  /// No description provided for @selectYourSportChooseALocationPickADateTime.
  ///
  /// In en, this message translates to:
  /// **'👉 Select your sport, 👉 Choose a location, 👉 Pick a date & time 👉 Confirm & play!'**
  String get selectYourSportChooseALocationPickADateTime;

  /// No description provided for @assetslogopng.
  ///
  /// In en, this message translates to:
  /// **'assets/logo.png'**
  String get assetslogopng;

  /// No description provided for @login.
  ///
  /// In en, this message translates to:
  /// **'Login'**
  String get login;

  /// No description provided for @getReadyToUnlockAWorldOf.
  ///
  /// In en, this message translates to:
  /// **'Get ready to unlock a world of'**
  String get getReadyToUnlockAWorldOf;

  /// No description provided for @possibilitiessignIntoYourAccountNow.
  ///
  /// In en, this message translates to:
  /// **'possibilities-Sign into your account now'**
  String get possibilitiessignIntoYourAccountNow;

  /// No description provided for @forgetPassword.
  ///
  /// In en, this message translates to:
  /// **'Forget Password'**
  String get forgetPassword;

  /// No description provided for @pleaseEnterYourRegisteredNumberTo.
  ///
  /// In en, this message translates to:
  /// **'Please Enter your registered number to'**
  String get pleaseEnterYourRegisteredNumberTo;

  /// No description provided for @receiveAVerificationCode.
  ///
  /// In en, this message translates to:
  /// **'receive a verification code'**
  String get receiveAVerificationCode;

  /// No description provided for @mate.
  ///
  /// In en, this message translates to:
  /// **'Mate'**
  String get mate;

  /// No description provided for @upcoming.
  ///
  /// In en, this message translates to:
  /// **'upcoming'**
  String get upcoming;

  /// No description provided for @completeProfile.
  ///
  /// In en, this message translates to:
  /// **'Complete Profile'**
  String get completeProfile;

  /// No description provided for @fullName.
  ///
  /// In en, this message translates to:
  /// **'Full Name'**
  String get fullName;

  /// No description provided for @emailAddress.
  ///
  /// In en, this message translates to:
  /// **'Email Address'**
  String get emailAddress;

  /// No description provided for @phoneNumber.
  ///
  /// In en, this message translates to:
  /// **'Phone Number'**
  String get phoneNumber;

  /// No description provided for @selectSportsName.
  ///
  /// In en, this message translates to:
  /// **'Select Sports Name'**
  String get selectSportsName;

  /// No description provided for @submit.
  ///
  /// In en, this message translates to:
  /// **'Submit'**
  String get submit;

  /// No description provided for @fillYourInformationBelowOrRegister.
  ///
  /// In en, this message translates to:
  /// **'Fill your information below or register'**
  String get fillYourInformationBelowOrRegister;

  /// No description provided for @withYourAccount.
  ///
  /// In en, this message translates to:
  /// **'with your account.'**
  String get withYourAccount;

  /// No description provided for @badminton.
  ///
  /// In en, this message translates to:
  /// **'Badminton'**
  String get badminton;

  /// No description provided for @hockey.
  ///
  /// In en, this message translates to:
  /// **'Hockey'**
  String get hockey;

  /// No description provided for @cricket.
  ///
  /// In en, this message translates to:
  /// **'Cricket'**
  String get cricket;

  /// No description provided for @tennis.
  ///
  /// In en, this message translates to:
  /// **'Tennis'**
  String get tennis;

  /// No description provided for @basketball.
  ///
  /// In en, this message translates to:
  /// **'Basketball'**
  String get basketball;

  /// No description provided for @football.
  ///
  /// In en, this message translates to:
  /// **'Football'**
  String get football;

  /// No description provided for @failedToLoadTermsConditions.
  ///
  /// In en, this message translates to:
  /// **'Failed to load Terms & Conditions'**
  String get failedToLoadTermsConditions;

  /// No description provided for @somethingWentWrongPleaseTryAgain.
  ///
  /// In en, this message translates to:
  /// **'Something went wrong. Please try again.'**
  String get somethingWentWrongPleaseTryAgain;

  /// No description provided for @failedToLoadAboutUs.
  ///
  /// In en, this message translates to:
  /// **'Failed to load About us'**
  String get failedToLoadAboutUs;

  /// No description provided for @somethingsWentWronggetmybookingdata.
  ///
  /// In en, this message translates to:
  /// **'Somethings went Wrong(getMyBookingData)'**
  String get somethingsWentWronggetmybookingdata;

  /// No description provided for @somethingsWentWronggetfavouritelistdata.
  ///
  /// In en, this message translates to:
  /// **'Somethings went Wrong(getFavouriteListData)'**
  String get somethingsWentWronggetfavouritelistdata;

  /// No description provided for @somethingsWentWronggetmychallengedata.
  ///
  /// In en, this message translates to:
  /// **'Somethings went Wrong(getMyChallengeData)'**
  String get somethingsWentWronggetmychallengedata;

  /// No description provided for @somethingsWentWrongtypeChallenge.
  ///
  /// In en, this message translates to:
  /// **'Somethings went Wrong(Type Challenge)'**
  String get somethingsWentWrongtypeChallenge;

  /// No description provided for @interestedSports.
  ///
  /// In en, this message translates to:
  /// **'Interested Sports'**
  String get interestedSports;

  /// No description provided for @somethingWentWrongGetprofiledataapi.
  ///
  /// In en, this message translates to:
  /// **'Something went wrong (getProfileDataApi)'**
  String get somethingWentWrongGetprofiledataapi;

  /// No description provided for @errorPleaseSelectSport.
  ///
  /// In en, this message translates to:
  /// **'Error: Please select sport'**
  String get errorPleaseSelectSport;

  /// No description provided for @profileUpdateSuccessfully.
  ///
  /// In en, this message translates to:
  /// **'Profile Update Successfully'**
  String get profileUpdateSuccessfully;

  /// No description provided for @somethingsWentWrongeditMyAccount.
  ///
  /// In en, this message translates to:
  /// **'Somethings went wrong(Edit My Account)'**
  String get somethingsWentWrongeditMyAccount;

  /// No description provided for @favoriteSport.
  ///
  /// In en, this message translates to:
  /// **'Favorite Sport'**
  String get favoriteSport;

  /// No description provided for @somethingsWentWronggetprofiledataapi.
  ///
  /// In en, this message translates to:
  /// **'Somethings went Wrong(getProfileDataApi)'**
  String get somethingsWentWronggetprofiledataapi;

  /// No description provided for @paymentSuccessful.
  ///
  /// In en, this message translates to:
  /// **'Payment Successful'**
  String get paymentSuccessful;

  /// No description provided for @somethingsWentWrongfetchchallenges.
  ///
  /// In en, this message translates to:
  /// **'Somethings went Wrong(fetchChallenges)'**
  String get somethingsWentWrongfetchchallenges;

  /// No description provided for @somethingsWentWronggetchallengesdetails.
  ///
  /// In en, this message translates to:
  /// **'Somethings went Wrong(getChallengesDetails)'**
  String get somethingsWentWronggetchallengesdetails;

  /// No description provided for @yourTransactionIsComplete.
  ///
  /// In en, this message translates to:
  /// **'Your transaction is complete.'**
  String get yourTransactionIsComplete;

  /// No description provided for @enjoyYourBooking.
  ///
  /// In en, this message translates to:
  /// **'Enjoy your booking! ✅'**
  String get enjoyYourBooking;

  /// No description provided for @youCanOnlyDeselectTheStartOrEndSlot.
  ///
  /// In en, this message translates to:
  /// **'You can only deselect the start or end slot.'**
  String get youCanOnlyDeselectTheStartOrEndSlot;

  /// No description provided for @pleaseSelectSlotsInSequence.
  ///
  /// In en, this message translates to:
  /// **'Please select slots in sequence.'**
  String get pleaseSelectSlotsInSequence;

  /// No description provided for @contactsPermissionIsRequired.
  ///
  /// In en, this message translates to:
  /// **'Contacts permission is required!'**
  String get contactsPermissionIsRequired;

  /// No description provided for @bookingSuccessful.
  ///
  /// In en, this message translates to:
  /// **'Booking successful'**
  String get bookingSuccessful;

  /// No description provided for @unexpectedErrorOccurred.
  ///
  /// In en, this message translates to:
  /// **'Unexpected error occurred.'**
  String get unexpectedErrorOccurred;

  /// No description provided for @somethingWentWrongGetslots.
  ///
  /// In en, this message translates to:
  /// **'Something went wrong (getSlots)'**
  String get somethingWentWrongGetslots;

  /// No description provided for @invalidOtpPleaseTryAgain.
  ///
  /// In en, this message translates to:
  /// **'Invalid OTP. Please try again.'**
  String get invalidOtpPleaseTryAgain;

  /// No description provided for @errorVerifyingOtpPleaseTryAgain.
  ///
  /// In en, this message translates to:
  /// **'Error verifying OTP. Please try again.'**
  String get errorVerifyingOtpPleaseTryAgain;

  /// No description provided for @anErrorOccurredPleaseTryAgain.
  ///
  /// In en, this message translates to:
  /// **'An error occurred. Please try again.'**
  String get anErrorOccurredPleaseTryAgain;

  /// No description provided for @invalidPromoDataReceivedFromServer.
  ///
  /// In en, this message translates to:
  /// **'Invalid promo data received from server.'**
  String get invalidPromoDataReceivedFromServer;

  /// No description provided for @anUnexpectedErrorOccurredPleaseTryAgain.
  ///
  /// In en, this message translates to:
  /// **'An unexpected error occurred. Please try again.'**
  String get anUnexpectedErrorOccurredPleaseTryAgain;

  /// No description provided for @connectionErrorPleaseCheckYourNetwork.
  ///
  /// In en, this message translates to:
  /// **'Connection error. Please check your network.'**
  String get connectionErrorPleaseCheckYourNetwork;

  /// No description provided for @failedToBook.
  ///
  /// In en, this message translates to:
  /// **'Failed to book.'**
  String get failedToBook;

  /// No description provided for @pleaseEnterTheOtp.
  ///
  /// In en, this message translates to:
  /// **'Please enter the OTP.'**
  String get pleaseEnterTheOtp;

  /// No description provided for @unexpectedResponseFormatFromServer.
  ///
  /// In en, this message translates to:
  /// **'Unexpected response format from server.'**
  String get unexpectedResponseFormatFromServer;

  /// No description provided for @failedToApplyPromoCode.
  ///
  /// In en, this message translates to:
  /// **'Failed to apply promo code.'**
  String get failedToApplyPromoCode;

  /// No description provided for @locationServicesAreDisabled.
  ///
  /// In en, this message translates to:
  /// **'Location services are disabled.'**
  String get locationServicesAreDisabled;

  /// No description provided for @locationPermissionDenied.
  ///
  /// In en, this message translates to:
  /// **'Location permission denied.'**
  String get locationPermissionDenied;

  /// No description provided for @locationPermissionsArePermanentlyDeniedPleaseEnableThemInSettings.
  ///
  /// In en, this message translates to:
  /// **'Location permissions are permanently denied. Please enable them in settings.'**
  String get locationPermissionsArePermanentlyDeniedPleaseEnableThemInSettings;

  /// No description provided for @noAddressFound.
  ///
  /// In en, this message translates to:
  /// **'No address found.'**
  String get noAddressFound;

  /// No description provided for @locationPermissionPermanentlyDeniedPleaseEnableItFromSettings.
  ///
  /// In en, this message translates to:
  /// **'Location permission permanently denied. Please enable it from settings.'**
  String get locationPermissionPermanentlyDeniedPleaseEnableItFromSettings;

  /// No description provided for @noCourtsAvailable.
  ///
  /// In en, this message translates to:
  /// **'No courts available.'**
  String get noCourtsAvailable;

  /// No description provided for @noSlotsAvailableAtThisTime.
  ///
  /// In en, this message translates to:
  /// **'No slots available at this time.'**
  String get noSlotsAvailableAtThisTime;

  /// No description provided for @somethingWentWrong.
  ///
  /// In en, this message translates to:
  /// **'Something went wrong.'**
  String get somethingWentWrong;

  /// No description provided for @pleaseSelectTimeSlotsInSequence.
  ///
  /// In en, this message translates to:
  /// **'Please select time slots in sequence.'**
  String get pleaseSelectTimeSlotsInSequence;

  /// No description provided for @failedToFetchUsers.
  ///
  /// In en, this message translates to:
  /// **'Failed to fetch users'**
  String get failedToFetchUsers;

  /// No description provided for @somethingWentWrongWhileFetchingNotifications.
  ///
  /// In en, this message translates to:
  /// **'Something went wrong while fetching notifications.'**
  String get somethingWentWrongWhileFetchingNotifications;

  /// No description provided for @somethingsWentWrongunreadnotification.
  ///
  /// In en, this message translates to:
  /// **'Somethings went Wrong(unreadNotification)'**
  String get somethingsWentWrongunreadnotification;

  /// No description provided for @somethingsWentWrongdeletenotification.
  ///
  /// In en, this message translates to:
  /// **'Somethings went Wrong(deleteNotification)'**
  String get somethingsWentWrongdeletenotification;

  /// No description provided for @noFavoritePlayerDataFound.
  ///
  /// In en, this message translates to:
  /// **'No favorite player data found.'**
  String get noFavoritePlayerDataFound;

  /// No description provided for @somethingWentWrongGetfavouriteplayerdata.
  ///
  /// In en, this message translates to:
  /// **'Something went wrong (getFavouritePlayerData)'**
  String get somethingWentWrongGetfavouriteplayerdata;

  /// No description provided for @somethingsWentWronggethomedata.
  ///
  /// In en, this message translates to:
  /// **'Somethings went Wrong(getHomeData)'**
  String get somethingsWentWronggethomedata;

  /// No description provided for @somethingsWentWronggetbookingdetails.
  ///
  /// In en, this message translates to:
  /// **'Somethings went Wrong(getBookingDetails)'**
  String get somethingsWentWronggetbookingdetails;

  /// No description provided for @somethingWentWrongGetbookingdetails.
  ///
  /// In en, this message translates to:
  /// **'Something went wrong (getBookingDetails)'**
  String get somethingWentWrongGetbookingdetails;

  /// No description provided for @somethingsWentWrongPleaseTryAgainLater.
  ///
  /// In en, this message translates to:
  /// **'Somethings went wrong. Please try again later!'**
  String get somethingsWentWrongPleaseTryAgainLater;

  /// No description provided for @codeCannotBeEmpty.
  ///
  /// In en, this message translates to:
  /// **'Code cannot be empty'**
  String get codeCannotBeEmpty;

  /// No description provided for @somethingWentWrongGetfacilitiesdata.
  ///
  /// In en, this message translates to:
  /// **'Something went wrong (getFacilitiesData)'**
  String get somethingWentWrongGetfacilitiesdata;

  /// No description provided for @somethingsWentWronggetfacilitiesdata.
  ///
  /// In en, this message translates to:
  /// **'Somethings went Wrong(getFacilitiesData)'**
  String get somethingsWentWronggetfacilitiesdata;

  /// No description provided for @anErrorOccurredWhileFetchingChallengeFacilitiesPleaseTryAgain.
  ///
  /// In en, this message translates to:
  /// **'An error occurred while fetching challenge facilities. Please try again later.'**
  String get anErrorOccurredWhileFetchingChallengeFacilitiesPleaseTryAgain;

  /// No description provided for @pleaseSelectASportFirst.
  ///
  /// In en, this message translates to:
  /// **'Please select a sport first'**
  String get pleaseSelectASportFirst;

  /// No description provided for @pleaseSelectAFacilityFirst.
  ///
  /// In en, this message translates to:
  /// **'Please select a Facility first'**
  String get pleaseSelectAFacilityFirst;

  /// No description provided for @invalidAmountPleaseTryAgainLater.
  ///
  /// In en, this message translates to:
  /// **'Invalid Amount. Please try again later!'**
  String get invalidAmountPleaseTryAgainLater;

  /// No description provided for @somethingsWentWrongcreatechallenge.
  ///
  /// In en, this message translates to:
  /// **'Somethings went wrong(createChallenge)'**
  String get somethingsWentWrongcreatechallenge;

  /// No description provided for @pleaseSelectSlotsInOrder.
  ///
  /// In en, this message translates to:
  /// **'Please select slots in order.'**
  String get pleaseSelectSlotsInOrder;

  /// No description provided for @youCanOnlyDeselectTheFirstOrLastSlot.
  ///
  /// In en, this message translates to:
  /// **'You can only deselect the first or last slot.'**
  String get youCanOnlyDeselectTheFirstOrLastSlot;

  /// No description provided for @started.
  ///
  /// In en, this message translates to:
  /// **'Started'**
  String get started;

  /// No description provided for @invalidTime.
  ///
  /// In en, this message translates to:
  /// **'Invalid time'**
  String get invalidTime;

  /// No description provided for @availableChallenges.
  ///
  /// In en, this message translates to:
  /// **'Available Challenges'**
  String get availableChallenges;

  /// No description provided for @challengesNotAvailableYet.
  ///
  /// In en, this message translates to:
  /// **'Challenges not available yet'**
  String get challengesNotAvailableYet;

  /// No description provided for @availableNearbyCourts.
  ///
  /// In en, this message translates to:
  /// **'Available Nearby Courts'**
  String get availableNearbyCourts;

  /// No description provided for @courtsNotAvailableYet.
  ///
  /// In en, this message translates to:
  /// **'Courts not available yet'**
  String get courtsNotAvailableYet;

  /// No description provided for @pleaseTryAgainLater.
  ///
  /// In en, this message translates to:
  /// **'Please try again later!'**
  String get pleaseTryAgainLater;

  /// No description provided for @upcomingBookings.
  ///
  /// In en, this message translates to:
  /// **'Upcoming Bookings'**
  String get upcomingBookings;

  /// No description provided for @upcomingBookingsNotFound.
  ///
  /// In en, this message translates to:
  /// **'Upcoming Bookings Not Found !!'**
  String get upcomingBookingsNotFound;

  /// No description provided for @typeOfBooking.
  ///
  /// In en, this message translates to:
  /// **'Type of Booking: '**
  String get typeOfBooking;

  /// No description provided for @wholeCourtBooking.
  ///
  /// In en, this message translates to:
  /// **'Whole Court Booking'**
  String get wholeCourtBooking;

  /// No description provided for @areYouSure.
  ///
  /// In en, this message translates to:
  /// **'Are you sure ?'**
  String get areYouSure;

  /// No description provided for @areYouSureYouWantToCancelThisBookingIf.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to cancel this booking? If yes, please press the confirm button. We will deduct the platform fee, and the remaining amount will be transferred to your wallet. Thank you.'**
  String get areYouSureYouWantToCancelThisBookingIf;

  /// No description provided for @yesConfirm.
  ///
  /// In en, this message translates to:
  /// **'Yes, Confirm'**
  String get yesConfirm;

  /// No description provided for @cancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get cancel;

  /// No description provided for @modify.
  ///
  /// In en, this message translates to:
  /// **'Modify'**
  String get modify;

  /// No description provided for @viewBookings.
  ///
  /// In en, this message translates to:
  /// **'View Bookings'**
  String get viewBookings;

  /// No description provided for @hey.
  ///
  /// In en, this message translates to:
  /// **'Hey '**
  String get hey;

  /// No description provided for @loading.
  ///
  /// In en, this message translates to:
  /// **'Loading...'**
  String get loading;

  /// No description provided for @na.
  ///
  /// In en, this message translates to:
  /// **'N/A'**
  String get na;

  /// No description provided for @getAlert.
  ///
  /// In en, this message translates to:
  /// **'Get Alert'**
  String get getAlert;

  /// No description provided for @home.
  ///
  /// In en, this message translates to:
  /// **'Home'**
  String get home;

  /// No description provided for @myBooking.
  ///
  /// In en, this message translates to:
  /// **'My Booking'**
  String get myBooking;

  /// No description provided for @facilities.
  ///
  /// In en, this message translates to:
  /// **'Facilities'**
  String get facilities;

  /// No description provided for @challenges.
  ///
  /// In en, this message translates to:
  /// **'Challenges'**
  String get challenges;

  /// No description provided for @notifications.
  ///
  /// In en, this message translates to:
  /// **'Notifications'**
  String get notifications;

  /// No description provided for @filter.
  ///
  /// In en, this message translates to:
  /// **'Filter'**
  String get filter;

  /// No description provided for @selectSport.
  ///
  /// In en, this message translates to:
  /// **'Select Sport'**
  String get selectSport;

  /// No description provided for @pleaseSelectASport.
  ///
  /// In en, this message translates to:
  /// **'Please select a sport'**
  String get pleaseSelectASport;

  /// No description provided for @date.
  ///
  /// In en, this message translates to:
  /// **'Date'**
  String get date;

  /// No description provided for @time.
  ///
  /// In en, this message translates to:
  /// **'Time'**
  String get time;

  /// No description provided for @amenities.
  ///
  /// In en, this message translates to:
  /// **'Amenities'**
  String get amenities;

  /// No description provided for @filterApply.
  ///
  /// In en, this message translates to:
  /// **'Filter Apply'**
  String get filterApply;

  /// No description provided for @whatDoYouWantToPlay.
  ///
  /// In en, this message translates to:
  /// **'What do you want to play?'**
  String get whatDoYouWantToPlay;

  /// No description provided for @selectSports.
  ///
  /// In en, this message translates to:
  /// **'Select Sports'**
  String get selectSports;

  /// No description provided for @whichTime.
  ///
  /// In en, this message translates to:
  /// **'Which Time'**
  String get whichTime;

  /// No description provided for @skillLevel.
  ///
  /// In en, this message translates to:
  /// **'Skill Level'**
  String get skillLevel;

  /// No description provided for @pleaseSelectSkillLevel.
  ///
  /// In en, this message translates to:
  /// **'Please select skill level'**
  String get pleaseSelectSkillLevel;

  /// No description provided for @apply.
  ///
  /// In en, this message translates to:
  /// **'Apply'**
  String get apply;

  /// No description provided for @filterResult.
  ///
  /// In en, this message translates to:
  /// **'Filter Result'**
  String get filterResult;

  /// No description provided for @enterMobileNumber.
  ///
  /// In en, this message translates to:
  /// **'Enter Mobile Number'**
  String get enterMobileNumber;

  /// No description provided for @continues.
  ///
  /// In en, this message translates to:
  /// **'Continue'**
  String get continues;

  /// No description provided for @rememberMe.
  ///
  /// In en, this message translates to:
  /// **'Remember Me'**
  String get rememberMe;

  /// No description provided for @forgotPassword.
  ///
  /// In en, this message translates to:
  /// **'Forgot Password?'**
  String get forgotPassword;

  /// No description provided for @logIn.
  ///
  /// In en, this message translates to:
  /// **'Log in'**
  String get logIn;

  /// No description provided for @dontHaveAnAccountSignUp.
  ///
  /// In en, this message translates to:
  /// **'Don\'t have an account? Sign Up'**
  String get dontHaveAnAccountSignUp;

  /// No description provided for @alreadyHaveAccount.
  ///
  /// In en, this message translates to:
  /// **'Already have account?'**
  String get alreadyHaveAccount;

  /// No description provided for @joinAChallenge.
  ///
  /// In en, this message translates to:
  /// **'👉 Join a Challenge: '**
  String get joinAChallenge;

  /// No description provided for @competeProveYourSkills.
  ///
  /// In en, this message translates to:
  /// **'Compete prove your skills.'**
  String get competeProveYourSkills;

  /// No description provided for @createAChallenge.
  ///
  /// In en, this message translates to:
  /// **'👉 Create a Challenge: '**
  String get createAChallenge;

  /// No description provided for @inviteOthers.
  ///
  /// In en, this message translates to:
  /// **'Invite others. '**
  String get inviteOthers;

  /// No description provided for @publicOrPrivate.
  ///
  /// In en, this message translates to:
  /// **'👉  Public or Private: '**
  String get publicOrPrivate;

  /// No description provided for @openToAllOrJustYourCrew.
  ///
  /// In en, this message translates to:
  /// **'Open to all or just your crew!'**
  String get openToAllOrJustYourCrew;

  /// No description provided for @letsGetPlaying.
  ///
  /// In en, this message translates to:
  /// **'Let’s get playing!'**
  String get letsGetPlaying;

  /// No description provided for @bookACourt.
  ///
  /// In en, this message translates to:
  /// **'Book a Court'**
  String get bookACourt;

  /// No description provided for @youreAlmostThere.
  ///
  /// In en, this message translates to:
  /// **'You’re Almost There!'**
  String get youreAlmostThere;

  /// No description provided for @enterOtp.
  ///
  /// In en, this message translates to:
  /// **'Enter OTP'**
  String get enterOtp;

  /// No description provided for @verifyOtp.
  ///
  /// In en, this message translates to:
  /// **'Verify OTP'**
  String get verifyOtp;

  /// No description provided for @resendOtp.
  ///
  /// In en, this message translates to:
  /// **'Resend OTP'**
  String get resendOtp;

  /// No description provided for @pleaseEnterYourPhoneNumber.
  ///
  /// In en, this message translates to:
  /// **'Please enter your phone number'**
  String get pleaseEnterYourPhoneNumber;

  /// No description provided for @phoneNumberMustBe810Digits.
  ///
  /// In en, this message translates to:
  /// **'Phone number must be 8-10 digits'**
  String get phoneNumberMustBe810Digits;

  /// No description provided for @enter810DigitPhoneNumber.
  ///
  /// In en, this message translates to:
  /// **'Enter 8-10 digit phone number'**
  String get enter810DigitPhoneNumber;

  /// No description provided for @sendOtp.
  ///
  /// In en, this message translates to:
  /// **'SEND OTP'**
  String get sendOtp;

  /// No description provided for @failedToSendOtpPleaseTryAgain.
  ///
  /// In en, this message translates to:
  /// **'Failed to send OTP. Please try again.'**
  String get failedToSendOtpPleaseTryAgain;

  /// No description provided for @agreeWith.
  ///
  /// In en, this message translates to:
  /// **'Agree with '**
  String get agreeWith;

  /// No description provided for @termsConditions.
  ///
  /// In en, this message translates to:
  /// **'Terms & Conditions'**
  String get termsConditions;

  /// No description provided for @pleaseAcceptTheTermsConditionsToContinue.
  ///
  /// In en, this message translates to:
  /// **'Please accept the Terms & Conditions to continue.'**
  String get pleaseAcceptTheTermsConditionsToContinue;

  /// No description provided for @or.
  ///
  /// In en, this message translates to:
  /// **'OR'**
  String get or;

  /// No description provided for @backToLogin.
  ///
  /// In en, this message translates to:
  /// **'Back to Login'**
  String get backToLogin;


}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>['el', 'en'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {


  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'el': return AppLocalizationsEl();
    case 'en': return AppLocalizationsEn();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.'
  );
}
