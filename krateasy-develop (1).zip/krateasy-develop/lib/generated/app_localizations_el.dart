// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Modern Greek (`el`).
class AppLocalizationsEl extends AppLocalizations {
  AppLocalizationsEl([String locale = 'el']) : super(locale);

  @override
  String get joinNow => 'Εγγραφείτε Τώρα';

  @override
  String get verificationCode => 'Κωδικός Επαλήθευσης';

  @override
  String get enterThe4digitCodeSentToYourPhone =>
      'Εισαγάγετε τον 4ψήφιο κωδικό που στάλθηκε στο τηλέφωνό σας';

  @override
  String get didntReceiveACodeResend => 'Δεν λάβατε κωδικό; Επαναποστολή';

  @override
  String get resendOtpIn50s => 'Επαναποστολή OTP σε 50 δευτερόλεπτα';

  @override
  String get verification => 'Επαλήθευση';

  @override
  String get joinPrivateChallengeByInvitingFriends =>
      'Συμμετάσχετε σε Ιδιωτική Πρόκληση Προσκαλώντας Φίλους';

  @override
  String get accountDeleteSuccessfully => 'Ο Λογαριασμός Διαγράφηκε Επιτυχώς';

  @override
  String get somethingsWentWrongdeleteaccount =>
      'Κάτι πήγε στραβά (διαγραφή λογαριασμού)';

  @override
  String get somethingsWentWrongnotificationtoggle =>
      'Κάτι πήγε στραβά (εναλλαγή ειδοποιήσεων)';

  @override
  String get setPassword => 'Ορίστε Κωδικό Πρόσβασης';

  @override
  String get creteAStrongPasswordItMustContain =>
      'Δημιουργήστε έναν ισχυρό κωδικό πρόσβασης. Πρέπει να περιέχει';

  @override
  String get atLeast6CharactersAnd1SpecialSymbol =>
      'τουλάχιστον 6 χαρακτήρες και 1 ειδικό σύμβολο';

  @override
  String get resetPassword => 'Επαναφορά Κωδικού Πρόσβασης';

  @override
  String get atLeast9CharactersWithUppercase =>
      'Τουλάχιστον 9 χαρακτήρες, με κεφαλαία';

  @override
  String get andLowercaseLetters => 'και πεζά γράμματα';

  @override
  String get password => 'Κωδικός Πρόσβασης';

  @override
  String get successfullyChange => 'Αλλαγή Επιτυχής';

  @override
  String get yourNewPasswordIsNowActive =>
      'Ο νέος σας κωδικός πρόσβασης είναι τώρα ενεργός.';

  @override
  String get staySecure => 'Παραμείνετε Ασφαλείς!';

  @override
  String get yourAccount => 'Ο Λογαριασμός σας';

  @override
  String get successfullyCreated => 'Δημιουργήθηκε Επιτυχώς';

  @override
  String get yourAccountSuccessfullyCreatedClick =>
      'Ο λογαριασμός σας δημιουργήθηκε επιτυχώς! Κάντε κλικ';

  @override
  String get continueToGoToTheHomeScreen =>
      'Συνέχεια για να μεταβείτε στην αρχική οθόνη';

  @override
  String get welcomeEasybooking => 'Καλώς ήρθατε & Εύκολη 📍Κράτηση';

  @override
  String get takeOnTheChallenge => 'Αναλάβετε την Πρόκληση! 💪🏆';

  @override
  String get findBookYourGameInSeconds =>
      'Βρείτε & Κλείστε το Παιχνίδι σας σε Δευτερόλεπτα!';

  @override
  String get joinAChallengeCompeteProveYourSkillsCreateAChallenge =>
      '👉Συμμετάσχετε σε Πρόκληση: Ανταγωνιστείτε αποδείξτε τις δεξιότητές σας. 👉Δημιουργήστε Πρόκληση: Προσκαλέστε άλλους. 👉Δημόσια ή Ιδιωτική: Ανοιχτή σε όλους ή μόνο για την ομάδα σας!';

  @override
  String get selectYourSportChooseALocationPickADateTime =>
      '👉 Επιλέξτε το άθλημά σας, 👉 Επιλέξτε τοποθεσία, 👉 Επιλέξτε ημερομηνία & ώρα 👉 Επιβεβαιώστε & παίξτε!';

  @override
  String get assetslogopng => 'assets/logo.png';

  @override
  String get login => 'Σύνδεση';

  @override
  String get getReadyToUnlockAWorldOf =>
      'Ετοιμαστείτε να ξεκλειδώσετε έναν κόσμο';

  @override
  String get possibilitiessignIntoYourAccountNow =>
      'δυνατοτήτων-Συνδεθείτε στον λογαριασμό σας τώρα';

  @override
  String get forgetPassword => 'Ξεχάσατε τον Κωδικό Πρόσβασης';

  @override
  String get pleaseEnterYourRegisteredNumberTo =>
      'Παρακαλούμε εισαγάγετε τον εγγεγραμμένο αριθμό σας για να';

  @override
  String get receiveAVerificationCode => 'λάβετε έναν κωδικό επαλήθευσης';

  @override
  String get mate => 'Φίλος';

  @override
  String get upcoming => 'Επερχόμενα';

  @override
  String get completeProfile => 'Ολοκληρώστε το Προφίλ';

  @override
  String get fullName => 'Πλήρες Όνομα';

  @override
  String get emailAddress => 'Διεύθυνση Email';

  @override
  String get phoneNumber => 'Αριθμός Τηλεφώνου';

  @override
  String get selectSportsName => 'Επιλέξτε Όνομα Αθλήματος';

  @override
  String get submit => 'Υποβολή';

  @override
  String get fillYourInformationBelowOrRegister =>
      'Συμπληρώστε τις πληροφορίες σας παρακάτω ή εγγραφείτε';

  @override
  String get withYourAccount => 'με τον λογαριασμό σας.';

  @override
  String get badminton => 'Μπάντμιντον';

  @override
  String get hockey => 'Χόκεϊ';

  @override
  String get cricket => 'Κρίκετ';

  @override
  String get tennis => 'Τένις';

  @override
  String get basketball => 'Μπάσκετ';

  @override
  String get football => 'Ποδόσφαιρο';

  @override
  String get failedToLoadTermsConditions =>
      'Αποτυχία φόρτωσης Όρων & Προϋποθέσεων';

  @override
  String get somethingWentWrongPleaseTryAgain =>
      'Κάτι πήγε στραβά. Παρακαλούμε δοκιμάστε ξανά.';

  @override
  String get failedToLoadAboutUs => 'Αποτυχία φόρτωσης Σχετικά με Εμάς';

  @override
  String get somethingsWentWronggetmybookingdata =>
      'Κάτι πήγε στραβά (λήψη δεδομένων κράτησης)';

  @override
  String get somethingsWentWronggetfavouritelistdata =>
      'Κάτι πήγε στραβά (λήψη δεδομένων λίστας αγαπημένων)';

  @override
  String get somethingsWentWronggetmychallengedata =>
      'Κάτι πήγε στραβά (λήψη δεδομένων πρόκλησης)';

  @override
  String get somethingsWentWrongtypeChallenge =>
      'Κάτι πήγε στραβά (Τύπος Πρόκλησης)';

  @override
  String get interestedSports => 'Αθλήματα Ενδιαφέροντος';

  @override
  String get somethingWentWrongGetprofiledataapi =>
      'Κάτι πήγε στραβά (λήψη δεδομένων προφίλ API)';

  @override
  String get errorPleaseSelectSport => 'Σφάλμα: Παρακαλούμε επιλέξτε άθλημα';

  @override
  String get profileUpdateSuccessfully => 'Ενημέρωση Προφίλ Επιτυχής';

  @override
  String get somethingsWentWrongeditMyAccount =>
      'Κάτι πήγε στραβά (Επεξεργασία του Λογαριασμού μου)';

  @override
  String get favoriteSport => 'Αγαπημένο Άθλημα';

  @override
  String get somethingsWentWronggetprofiledataapi =>
      'Κάτι πήγε στραβά (λήψη δεδομένων προφίλ API)';

  @override
  String get paymentSuccessful => 'Πληρωμή Επιτυχής';

  @override
  String get somethingsWentWrongfetchchallenges =>
      'Κάτι πήγε στραβά (ανάκτηση προκλήσεων)';

  @override
  String get somethingsWentWronggetchallengesdetails =>
      'Κάτι πήγε στραβά (λήψη λεπτομερειών προκλήσεων)';

  @override
  String get yourTransactionIsComplete => 'Η συναλλαγή σας ολοκληρώθηκε.';

  @override
  String get enjoyYourBooking => 'Απολαύστε την κράτησή σας! ✅';

  @override
  String get youCanOnlyDeselectTheStartOrEndSlot =>
      'Μπορείτε να αποεπιλέξετε μόνο την αρχική ή την τελική χρονοθυρίδα.';

  @override
  String get pleaseSelectSlotsInSequence =>
      'Παρακαλούμε επιλέξτε χρονοθυρίδες με σειρά.';

  @override
  String get contactsPermissionIsRequired => 'Απαιτείται άδεια επαφών!';

  @override
  String get bookingSuccessful => 'Επιτυχής κράτηση';

  @override
  String get unexpectedErrorOccurred => 'Προέκυψε απροσδόκητο σφάλμα.';

  @override
  String get somethingWentWrongGetslots =>
      'Κάτι πήγε στραβά (λήψη χρονοθυρίδων)';

  @override
  String get invalidOtpPleaseTryAgain =>
      'Μη έγκυρο OTP. Παρακαλούμε δοκιμάστε ξανά.';

  @override
  String get errorVerifyingOtpPleaseTryAgain =>
      'Σφάλμα επαλήθευσης OTP. Παρακαλούμε δοκιμάστε ξανά.';

  @override
  String get anErrorOccurredPleaseTryAgain =>
      'Προέκυψε σφάλμα. Παρακαλούμε δοκιμάστε ξανά.';

  @override
  String get invalidPromoDataReceivedFromServer =>
      'Μη έγκυρα δεδομένα προσφοράς λήφθηκαν από τον διακομιστή.';

  @override
  String get anUnexpectedErrorOccurredPleaseTryAgain =>
      'Προέκυψε απροσδόκητο σφάλμα. Παρακαλούμε δοκιμάστε ξανά.';

  @override
  String get connectionErrorPleaseCheckYourNetwork =>
      'Σφάλμα σύνδεσης. Παρακαλούμε ελέγξτε το δίκτυό σας.';

  @override
  String get failedToBook => 'Αποτυχία κράτησης.';

  @override
  String get pleaseEnterTheOtp => 'Παρακαλούμε εισαγάγετε το OTP.';

  @override
  String get unexpectedResponseFormatFromServer =>
      'Απροσδόκητη μορφή απόκρισης από τον διακομιστή.';

  @override
  String get failedToApplyPromoCode => 'Αποτυχία εφαρμογής κωδικού προσφοράς.';

  @override
  String get locationServicesAreDisabled =>
      'Οι υπηρεσίες τοποθεσίας είναι απενεργοποιημένες.';

  @override
  String get locationPermissionDenied => 'Η άδεια τοποθεσίας απορρίφθηκε.';

  @override
  String get locationPermissionsArePermanentlyDeniedPleaseEnableThemInSettings =>
      'Οι άδειες τοποθεσίας έχουν απορριφθεί οριστικά. Παρακαλούμε ενεργοποιήστε τις στις ρυθμίσεις.';

  @override
  String get noAddressFound => 'Δεν βρέθηκε διεύθυνση.';

  @override
  String get locationPermissionPermanentlyDeniedPleaseEnableItFromSettings =>
      'Η άδεια τοποθεσίας έχει απορριφθεί οριστικά. Παρακαλούμε ενεργοποιήστε την από τις ρυθμίσεις.';

  @override
  String get noCourtsAvailable => 'Δεν υπάρχουν διαθέσιμα γήπεδα.';

  @override
  String get noSlotsAvailableAtThisTime =>
      'Δεν υπάρχουν διαθέσιμες χρονοθυρίδες αυτή τη στιγμή.';

  @override
  String get somethingWentWrong => 'Κάτι πήγε στραβά.';

  @override
  String get pleaseSelectTimeSlotsInSequence =>
      'Παρακαλούμε επιλέξτε χρονοθυρίδες με σειρά.';

  @override
  String get failedToFetchUsers => 'Αποτυχία ανάκτησης χρηστών';

  @override
  String get somethingWentWrongWhileFetchingNotifications =>
      'Κάτι πήγε στραβά κατά την ανάκτηση ειδοποιήσεων.';

  @override
  String get somethingsWentWrongunreadnotification =>
      'Κάτι πήγε στραβά (μη αναγνωσμένη ειδοποίηση)';

  @override
  String get somethingsWentWrongdeletenotification =>
      'Κάτι πήγε στραβά (διαγραφή ειδοποίησης)';

  @override
  String get noFavoritePlayerDataFound =>
      'Δεν βρέθηκαν δεδομένα αγαπημένων παικτών.';

  @override
  String get somethingWentWrongGetfavouriteplayerdata =>
      'Κάτι πήγε στραβά (λήψη δεδομένων αγαπημένων παικτών)';

  @override
  String get somethingsWentWronggethomedata =>
      'Κάτι πήγε στραβά (λήψη δεδομένων αρχικής σελίδας)';

  @override
  String get somethingsWentWronggetbookingdetails =>
      'Κάτι πήγε στραβά (λήψη λεπτομερειών κράτησης)';

  @override
  String get somethingWentWrongGetbookingdetails =>
      'Κάτι πήγε στραβά (λήψη λεπτομερειών κράτησης)';

  @override
  String get somethingsWentWrongPleaseTryAgainLater =>
      'Κάτι πήγε στραβά. Παρακαλούμε δοκιμάστε ξανά αργότερα!';

  @override
  String get codeCannotBeEmpty => 'Ο κωδικός δεν μπορεί να είναι κενός';

  @override
  String get somethingWentWrongGetfacilitiesdata =>
      'Κάτι πήγε στραβά (λήψη δεδομένων εγκαταστάσεων)';

  @override
  String get somethingsWentWronggetfacilitiesdata =>
      'Κάτι πήγε στραβά (λήψη δεδομένων εγκαταστάσεων)';

  @override
  String get anErrorOccurredWhileFetchingChallengeFacilitiesPleaseTryAgain =>
      'Προέκυψε σφάλμα κατά την ανάκτηση εγκαταστάσεων πρόκλησης. Παρακαλούμε δοκιμάστε ξανά αργότερα.';

  @override
  String get pleaseSelectASportFirst => 'Παρακαλούμε επιλέξτε πρώτα ένα άθλημα';

  @override
  String get pleaseSelectAFacilityFirst =>
      'Παρακαλούμε επιλέξτε πρώτα μια εγκατάσταση';

  @override
  String get invalidAmountPleaseTryAgainLater =>
      'Μη έγκυρο ποσό. Παρακαλούμε δοκιμάστε ξανά αργότερα!';

  @override
  String get somethingsWentWrongcreatechallenge =>
      'Κάτι πήγε στραβά (δημιουργία πρόκλησης)';

  @override
  String get pleaseSelectSlotsInOrder =>
      'Παρακαλούμε επιλέξτε χρονοθυρίδες με σειρά.';

  @override
  String get youCanOnlyDeselectTheFirstOrLastSlot =>
      'Μπορείτε να αποεπιλέξετε μόνο την πρώτη ή την τελευταία χρονοθυρίδα.';

  @override
  String get started => 'Ξεκίνησε';

  @override
  String get invalidTime => 'Μη έγκυρη ώρα';

  @override
  String get availableChallenges => 'Διαθέσιμες Προκλήσεις';

  @override
  String get challengesNotAvailableYet =>
      'Οι προκλήσεις δεν είναι ακόμα διαθέσιμες';

  @override
  String get availableNearbyCourts => 'Διαθέσιμα Κοντινά Γήπεδα';

  @override
  String get courtsNotAvailableYet => 'Τα γήπεδα δεν είναι ακόμα διαθέσιμα';

  @override
  String get pleaseTryAgainLater => 'Παρακαλούμε δοκιμάστε ξανά αργότερα!';

  @override
  String get upcomingBookings => 'Επερχόμενες Κρατήσεις';

  @override
  String get upcomingBookingsNotFound => 'Δεν Βρέθηκαν Επερχόμενες Κρατήσεις!!';

  @override
  String get typeOfBooking => 'Τύπος Κράτησης: ';

  @override
  String get wholeCourtBooking => 'Κράτηση Ολόκληρου Γηπέδου';

  @override
  String get areYouSure => 'Είστε σίγουροι;';

  @override
  String get areYouSureYouWantToCancelThisBookingIf =>
      'Είστε σίγουροι ότι θέλετε να ακυρώσετε αυτή την κράτηση; Αν ναι, πατήστε το κουμπί επιβεβαίωσης. Θα αφαιρεθεί η χρέωση πλατφόρμας και το υπόλοιπο ποσό θα μεταφερθεί στο πορτοφόλι σας. Ευχαριστούμε.';

  @override
  String get yesConfirm => 'Ναι, Επιβεβαίωση';

  @override
  String get cancel => 'Ακύρωση';

  @override
  String get modify => 'Τροποποίηση';

  @override
  String get viewBookings => 'Προβολή Κρατήσεων';

  @override
  String get hey => 'Γεια ';

  @override
  String get loading => 'Φόρτωση...';

  @override
  String get na => 'Μ/Δ';

  @override
  String get getAlert => 'Λήψη Ειδοποίησης';

  @override
  String get home => 'Αρχική';

  @override
  String get myBooking => 'Η Κράτησή μου';

  @override
  String get facilities => 'Εγκαταστάσεις';

  @override
  String get challenges => 'Προκλήσεις';

  @override
  String get notifications => 'Ειδοποιήσεις';

  @override
  String get filter => 'Φίλτρο';

  @override
  String get selectSport => 'Επιλέξτε Άθλημα';

  @override
  String get pleaseSelectASport => 'Παρακαλούμε επιλέξτε ένα άθλημα';

  @override
  String get date => 'Ημερομηνία';

  @override
  String get time => 'Ώρα';

  @override
  String get amenities => 'Παροχές';

  @override
  String get filterApply => 'Εφαρμογή Φίλτρου';

  @override
  String get whatDoYouWantToPlay => 'Τι θέλετε να παίξετε;';

  @override
  String get selectSports => 'Επιλέξτε Αθλήματα';

  @override
  String get whichTime => 'Ποια Ώρα';

  @override
  String get skillLevel => 'Επίπεδο Δεξιότητας';

  @override
  String get pleaseSelectSkillLevel =>
      'Παρακαλούμε επιλέξτε επίπεδο δεξιότητας';

  @override
  String get apply => 'Εφαρμογή';

  @override
  String get filterResult => 'Αποτέλεσμα Φίλτρου';

  @override
  String get enterMobileNumber => 'Εισαγάγετε Αριθμό Κινητού';

  @override
  String get continues => 'Συνέχεια';

  @override
  String get rememberMe => 'Θυμήσου Με';

  @override
  String get forgotPassword => 'Ξεχάσατε τον Κωδικό Πρόσβασης;';

  @override
  String get logIn => 'Σύνδεση';

  @override
  String get dontHaveAnAccountSignUp => 'Δεν έχετε λογαριασμό; Εγγραφείτε';

  @override
  String get alreadyHaveAccount => 'Έχετε ήδη λογαριασμό;';

  @override
  String get joinAChallenge => '👉 Συμμετάσχετε σε Πρόκληση: ';

  @override
  String get competeProveYourSkills =>
      'Ανταγωνιστείτε αποδείξτε τις δεξιότητές σας.';

  @override
  String get createAChallenge => '👉 Δημιουργήστε Πρόκληση: ';

  @override
  String get inviteOthers => 'Προσκαλέστε άλλους.';

  @override
  String get publicOrPrivate => '👉 Δημόσια ή Ιδιωτική: ';

  @override
  String get openToAllOrJustYourCrew =>
      'Ανοιχτή σε όλους ή μόνο για την ομάδα σας!';

  @override
  String get letsGetPlaying => 'Ας ξεκινήσουμε να παίζουμε!';

  @override
  String get bookACourt => 'Κλείστε Γήπεδο';

  @override
  String get youreAlmostThere => 'Είστε Σχεδόν Εκεί!';

  @override
  String get enterOtp => 'Εισαγάγετε OTP';

  @override
  String get verifyOtp => 'Επαλήθευση OTP';

  @override
  String get resendOtp => 'Επαναποστολή OTP';

  @override
  String get pleaseEnterYourPhoneNumber =>
      'Παρακαλούμε εισαγάγετε τον αριθμό τηλεφώνου σας';

  @override
  String get phoneNumberMustBe810Digits =>
      'Ο αριθμός τηλεφώνου πρέπει να είναι 8-10 ψηφία';

  @override
  String get enter810DigitPhoneNumber =>
      'Εισαγάγετε αριθμό τηλεφώνου 8-10 ψηφίων';

  @override
  String get sendOtp => 'ΑΠΟΣΤΟΛΗ OTP';

  @override
  String get failedToSendOtpPleaseTryAgain =>
      'Αποτυχία αποστολής OTP. Παρακαλούμε δοκιμάστε ξανά.';

  @override
  String get agreeWith => 'Συμφωνώ με ';

  @override
  String get termsConditions => 'Όρους & Προϋποθέσεις';

  @override
  String get pleaseAcceptTheTermsConditionsToContinue =>
      'Παρακαλούμε αποδεχτείτε τους Όρους & Προϋποθέσεις για να συνεχίσετε.';

  @override
  String get or => 'Ή';

  @override
  String get backToLogin => 'Επιστροφή στη Σύνδεση';
}
