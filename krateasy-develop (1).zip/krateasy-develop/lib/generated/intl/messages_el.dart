// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a el locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'el';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
    "aboutUs": MessageLookupByLibrary.simpleMessage("Σχετικά με Εμάς"),
    "accountDeleteSuccessfully": MessageLookupByLibrary.simpleMessage(
      "Ο Λογαριασμός Διαγράφηκε Επιτυχώς",
    ),
    "active": MessageLookupByLibrary.simpleMessage("Ενεργό"),
    "activeChallenges": MessageLookupByLibrary.simpleMessage(
      "Ενεργές Προκλήσεις",
    ),
    "add": MessageLookupByLibrary.simpleMessage("Προσθήκη"),
    "addAddress": MessageLookupByLibrary.simpleMessage("Προσθήκη Διεύθυνσης"),
    "addAnotherRecipient": MessageLookupByLibrary.simpleMessage(
      "Προσθήκη άλλου παραλήπτη",
    ),
    "addCard": MessageLookupByLibrary.simpleMessage("Προσθήκη Κάρτας"),
    "addFriends": MessageLookupByLibrary.simpleMessage("Προσθήκη Φίλων"),
    "addFriendsSplitTheCost": MessageLookupByLibrary.simpleMessage(
      "Προσθέστε Φίλους & Διαχωρίστε το Κόστος! ⚽🏀",
    ),
    "addMore": MessageLookupByLibrary.simpleMessage("Προσθήκη Περισσοτέρων"),
    "added": MessageLookupByLibrary.simpleMessage("Προστέθηκε"),
    "addedAmount": MessageLookupByLibrary.simpleMessage("Προστιθέμενο Ποσό"),
    "addedFriends": MessageLookupByLibrary.simpleMessage("Προστέθηκαν φίλοι"),
    "address": MessageLookupByLibrary.simpleMessage("Διεύθυνση"),
    "agreeWith": MessageLookupByLibrary.simpleMessage("Συμφωνώ με "),
    "allPlayersWillUseThisLinkToMakentheirSplitPayment":
        MessageLookupByLibrary.simpleMessage(
          "Όλοι οι παίκτες θα χρησιμοποιήσουν αυτόν τον σύνδεσμο για να κάνουν την πληρωμή διαίρεσης",
        ),
    "alreadyHaveAccount": MessageLookupByLibrary.simpleMessage(
      "Έχετε ήδη λογαριασμό;",
    ),
    "alreadyHaveAccountS": MessageLookupByLibrary.simpleMessage(
      "Εγγραφή/Είσοδος",
    ),
    "amenities": MessageLookupByLibrary.simpleMessage("Παροχές"),
    "amenitiesclg": MessageLookupByLibrary.simpleMessage("Παροχές: "),
    "anErrorOccurredPleaseTryAgain": MessageLookupByLibrary.simpleMessage(
      "Προέκυψε σφάλμα. Παρακαλώ δοκιμάστε ξανά.",
    ),
    "anErrorOccurredWhileFetchingChallengeFacilitiesPleaseTryAgain":
        MessageLookupByLibrary.simpleMessage(
          "Προέκυψε σφάλμα κατά την ανάκτηση εγκαταστάσεων πρόκλησης. Δοκιμάστε ξανά αργότερα.",
        ),
    "anUnexpectedErrorOccurredPleaseTryAgain":
        MessageLookupByLibrary.simpleMessage(
          "Προέκυψε απροσδόκητο σφάλμα. Παρακαλώ δοκιμάστε ξανά.",
        ),
    "andLowercaseLetters": MessageLookupByLibrary.simpleMessage(
      "και πεζά γράμματα",
    ),
    "appVersion": MessageLookupByLibrary.simpleMessage("Έκδοση Εφαρμογής"),
    "applePay": MessageLookupByLibrary.simpleMessage("Apple Pay"),
    "applied": MessageLookupByLibrary.simpleMessage("Εφαρμόστηκε"),
    "apply": MessageLookupByLibrary.simpleMessage("Εφαρμογή"),
    "areYouSure": MessageLookupByLibrary.simpleMessage("Είστε σίγουροι;"),
    "areYouSureYouWantToCancelThisBookingIf": MessageLookupByLibrary.simpleMessage(
      "Είστε σίγουροι ότι θέλετε να ακυρώσετε αυτήν την κράτηση; Αν ναι, πατήστε το κουμπί επιβεβαίωσης. Θα αφαιρεθεί η χρέωση πλατφόρμας και το υπόλοιπο ποσό θα μεταφερθεί στο πορτοφόλι σας. Ευχαριστούμε.",
    ),
    "areYouSureYouWantToCancelThisChallengeIf":
        MessageLookupByLibrary.simpleMessage(
          "Είστε σίγουροι ότι θέλετε να ακυρώσετε αυτήν την πρόκληση; Αν ναι, πατήστε το κουμπί επιβεβαίωσης. Θα αφαιρεθεί η χρέωση πλατφόρμας και το υπόλοιπο ποσό θα μεταφερθεί στο πορτοφόλι σας. Ευχαριστούμε.",
        ),
    "areYouSureYouWantToExit": MessageLookupByLibrary.simpleMessage(
      "Είστε σίγουροι ότι θέλετε να εξέλθετε;",
    ),
    "areYouSureYouWantToLogoutYourAccount":
        MessageLookupByLibrary.simpleMessage(
          "Είστε σίγουροι ότι θέλετε να αποσυνδεθείτε από τον λογαριασμό σας;",
        ),
    "assetslogopng": MessageLookupByLibrary.simpleMessage("assets/logo.png"),
    "atLeast6CharactersAnd1SpecialSymbol": MessageLookupByLibrary.simpleMessage(
      "τουλάχιστον 6 χαρακτήρες και 1 ειδικό σύμβολο",
    ),
    "atLeast9CharactersWithUppercase": MessageLookupByLibrary.simpleMessage(
      "Τουλάχιστον 9 χαρακτήρες, με κεφαλαία",
    ),
    "available": MessageLookupByLibrary.simpleMessage("Διαθέσιμο"),
    "availableChallenges": MessageLookupByLibrary.simpleMessage(
      "Διαθέσιμες Προκλήσεις",
    ),
    "availableNearbyCourts": MessageLookupByLibrary.simpleMessage(
      "Διαθέσιμα Κοντινά Γήπεδα",
    ),
    "back": MessageLookupByLibrary.simpleMessage("Πίσω"),
    "backToLogin": MessageLookupByLibrary.simpleMessage(
      "Επιστροφή στη Σύνδεση",
    ),
    "badminton": MessageLookupByLibrary.simpleMessage("Μπάντμιντον"),
    "basketball": MessageLookupByLibrary.simpleMessage("Μπάσκετ"),
    "bookACourt": MessageLookupByLibrary.simpleMessage("Κλείστε ένα Γήπεδο"),
    "bookNow": MessageLookupByLibrary.simpleMessage("Κλείστε Τώρα"),
    "booking": MessageLookupByLibrary.simpleMessage("Κράτηση"),
    "bookingDetails": MessageLookupByLibrary.simpleMessage(
      "Λεπτομέρειες Κράτησης",
    ),
    "bookingId": MessageLookupByLibrary.simpleMessage(
      "Αναγνωριστικό Κράτησης: ",
    ),
    "bookingNotAvailableYet": MessageLookupByLibrary.simpleMessage(
      "Η κράτηση δεν είναι ακόμα διαθέσιμη",
    ),
    "bookingSuccessful": MessageLookupByLibrary.simpleMessage(
      "Κράτηση επιτυχής",
    ),
    "bookings": MessageLookupByLibrary.simpleMessage("Κρατήσεις"),
    "camera": MessageLookupByLibrary.simpleMessage("Κάμερα"),
    "cancel": MessageLookupByLibrary.simpleMessage("Ακύρωση"),
    "cancelBooking": MessageLookupByLibrary.simpleMessage("Ακύρωση Κράτησης"),
    "cancelBookings": MessageLookupByLibrary.simpleMessage("Ακύρωση Κρατήσεων"),
    "cancelChallenge": MessageLookupByLibrary.simpleMessage(
      "Ακύρωση Πρόκλησης",
    ),
    "cantDeleteNotificationNotFound": MessageLookupByLibrary.simpleMessage(
      "Δεν μπορεί να διαγραφεί, η ειδοποίηση δεν βρέθηκε.",
    ),
    "cantReadNotificationNotFound": MessageLookupByLibrary.simpleMessage(
      "Δεν μπορεί να διαβαστεί, η ειδοποίηση δεν βρέθηκε.",
    ),
    "cantUnreadNotificationNotFound": MessageLookupByLibrary.simpleMessage(
      "Δεν μπορεί να γίνει αδιάβαστη, η ειδοποίηση δεν βρέθηκε.",
    ),
    "challengeNotFound": MessageLookupByLibrary.simpleMessage(
      "Challenge not found",
    ),
    "challengeType": MessageLookupByLibrary.simpleMessage("Τύπος Πρόκλησης"),
    "challengeYourFriendsCompeteTogetherAndnenjoyExclusiveMatches":
        MessageLookupByLibrary.simpleMessage(
          "Προκαλέστε τους φίλους σας, αγωνιστείτε μαζί και\\ναπολαύστε αποκλειστικούς αγώνες!",
        ),
    "challenges": MessageLookupByLibrary.simpleMessage("Προκλήσεις"),
    "challengesNotAvailableYet": MessageLookupByLibrary.simpleMessage(
      "Οι προκλήσεις δεν είναι ακόμα διαθέσιμες",
    ),
    "checkout": MessageLookupByLibrary.simpleMessage("Ολοκλήρωση Πληρωμής"),
    "choosePaymentMethod": MessageLookupByLibrary.simpleMessage(
      "Επιλέξτε Τρόπο Πληρωμής",
    ),
    "city": MessageLookupByLibrary.simpleMessage("Πόλη"),
    "codeCannotBeEmpty": MessageLookupByLibrary.simpleMessage(
      "Ο κωδικός δεν μπορεί να είναι κενός",
    ),
    "competeProveYourSkills": MessageLookupByLibrary.simpleMessage(
      "Διαγωνιστείτε, αποδείξτε τις δεξιότητές σας.",
    ),
    "completeProfile": MessageLookupByLibrary.simpleMessage(
      "Ολοκλήρωση Προφίλ",
    ),
    "completed": MessageLookupByLibrary.simpleMessage("Ολοκληρώθηκε"),
    "completedChallenges": MessageLookupByLibrary.simpleMessage(
      "Ολοκληρωμένες Προκλήσεις",
    ),
    "confirm": MessageLookupByLibrary.simpleMessage("Επιβεβαίωση"),
    "confirmPayment": MessageLookupByLibrary.simpleMessage(
      "Επιβεβαίωση Πληρωμής",
    ),
    "connectionErrorPleaseCheckYourNetwork":
        MessageLookupByLibrary.simpleMessage(
          "Σφάλμα σύνδεσης. Ελέγξτε το δίκτυό σας.",
        ),
    "contactListIsEmpty": MessageLookupByLibrary.simpleMessage(
      "Η λίστα επαφών είναι κενή!",
    ),
    "contactsPermissionIsRequired": MessageLookupByLibrary.simpleMessage(
      "Απαιτείται άδεια επαφών!",
    ),
    "continueToGoToTheHomeScreen": MessageLookupByLibrary.simpleMessage(
      "Συνέχεια για να μεταβείτε στην αρχική οθόνη",
    ),
    "continues": MessageLookupByLibrary.simpleMessage("Συνέχεια"),
    "country": MessageLookupByLibrary.simpleMessage("Χώρα"),
    "courtBooking": MessageLookupByLibrary.simpleMessage("Κράτηση Γηπέδου"),
    "courtSize": MessageLookupByLibrary.simpleMessage("Μέγεθος Γηπέδου"),
    "courts": MessageLookupByLibrary.simpleMessage("Γήπεδα"),
    "courtsNotAvailableYet": MessageLookupByLibrary.simpleMessage(
      "Τα γήπεδα δεν είναι ακόμα διαθέσιμα",
    ),
    "courtsnavailableoblic": MessageLookupByLibrary.simpleMessage(
      "Γήπεδα Διαθέσιμα",
    ),
    "createAChallenge": MessageLookupByLibrary.simpleMessage(
      "👉 Δημιουργήστε Πρόκληση: ",
    ),
    "createChallengeBt": MessageLookupByLibrary.simpleMessage(
      "Δημιουργία Πρόκλησης",
    ),
    "createdBy": MessageLookupByLibrary.simpleMessage("Δημιουργήθηκε Από"),
    "creditDebitCard": MessageLookupByLibrary.simpleMessage(
      "Πιστωτική & Χρεωστική Κάρτα",
    ),
    "creteAStrongPasswordItMustContain": MessageLookupByLibrary.simpleMessage(
      "Δημιουργήστε έναν ισχυρό κωδικό πρόσβασης. Πρέπει να περιέχει",
    ),
    "cricket": MessageLookupByLibrary.simpleMessage("Κρίκετ"),
    "data": MessageLookupByLibrary.simpleMessage("Δεδομένα"),
    "date": MessageLookupByLibrary.simpleMessage("Ημερομηνία"),
    "deleteAccount": MessageLookupByLibrary.simpleMessage(
      "Διαγραφή Λογαριασμού",
    ),
    "deleteAll": MessageLookupByLibrary.simpleMessage("Διαγραφή Όλων"),
    "description": MessageLookupByLibrary.simpleMessage("Περιγραφή: "),
    "detectMyLocation": MessageLookupByLibrary.simpleMessage(
      "Εντοπισμός της τοποθεσίας μου",
    ),
    "didntReceiveACodeResend": MessageLookupByLibrary.simpleMessage(
      "Δεν λάβατε κωδικό; Επαναποστολή",
    ),
    "doYouReallyWantToDeleteThisAccount": MessageLookupByLibrary.simpleMessage(
      "Θέλετε πραγματικά να διαγράψετε αυτόν τον λογαριασμό;",
    ),
    "doYouWantRecordedOrNot": MessageLookupByLibrary.simpleMessage(
      "Θέλετε να καταγραφεί ή όχι;",
    ),
    "dontHaveAnAccountSignUp": MessageLookupByLibrary.simpleMessage(
      "Δεν έχετε λογαριασμό; Εγγραφείτε",
    ),
    "editProfile": MessageLookupByLibrary.simpleMessage("Επεξεργασία Προφίλ"),
    "emailAddress": MessageLookupByLibrary.simpleMessage("Διεύθυνση Email"),
    "enableLocation": MessageLookupByLibrary.simpleMessage(
      "Ενεργοποίηση Τοποθεσίας",
    ),
    "english": MessageLookupByLibrary.simpleMessage("Αγγλικά"),
    "enjoyYourBooking": MessageLookupByLibrary.simpleMessage(
      "Απολαύστε την κράτησή σας! ✅",
    ),
    "enter810DigitPhoneNumber": MessageLookupByLibrary.simpleMessage(
      "Εισαγάγετε αριθμό τηλεφώνου 8-10 ψηφίων",
    ),
    "enterCode": MessageLookupByLibrary.simpleMessage("Εισαγάγετε Κωδικό"),
    "enterInviteChallengeCode": MessageLookupByLibrary.simpleMessage(
      "Εισαγάγετε Κωδικό Πρόσκλησης Πρόκλησης",
    ),
    "enterMobileNumber": MessageLookupByLibrary.simpleMessage(
      "Εισαγάγετε Αριθμό Κινητού",
    ),
    "enterOtp": MessageLookupByLibrary.simpleMessage("Εισαγάγετε OTP"),
    "enterPassword": MessageLookupByLibrary.simpleMessage(
      "Εισαγάγετε Κωδικό Πρόσβασης",
    ),
    "enterThe4digitCodeSentToYourPhone": MessageLookupByLibrary.simpleMessage(
      "Εισαγάγετε τον 4ψήφιο κωδικό που στάλθηκε στο τηλέφωνό σας",
    ),
    "enterYourEmail": MessageLookupByLibrary.simpleMessage(
      "Εισαγάγετε το Email σας",
    ),
    "enterYourName": MessageLookupByLibrary.simpleMessage(
      "Εισαγάγετε το Όνομά σας",
    ),
    "error": MessageLookupByLibrary.simpleMessage("Σφάλμα"),
    "errorPleaseEnterYourEmail": MessageLookupByLibrary.simpleMessage(
      "Σφάλμα: Παρακαλώ εισαγάγετε το email σας",
    ),
    "errorPleaseEnterYourName": MessageLookupByLibrary.simpleMessage(
      "Σφάλμα: Παρακαλώ εισαγάγετε το όνομά σας",
    ),
    "errorPleaseSelectSkills": MessageLookupByLibrary.simpleMessage(
      "Σφάλμα: Παρακαλώ επιλέξτε δεξιότητες",
    ),
    "errorPleaseSelectSport": MessageLookupByLibrary.simpleMessage(
      "Σφάλμα: Παρακαλώ επιλέξτε άθλημα",
    ),
    "errorVerifyingOtpPleaseTryAgain": MessageLookupByLibrary.simpleMessage(
      "Σφάλμα επαλήθευσης OTP. Παρακαλώ δοκιμάστε ξανά.",
    ),
    "exit": MessageLookupByLibrary.simpleMessage("Έξοδος"),
    "exitApp": MessageLookupByLibrary.simpleMessage("Έξοδος από την Εφαρμογή"),
    "facilities": MessageLookupByLibrary.simpleMessage("Εγκαταστάσεις"),
    "facilitiesListing": MessageLookupByLibrary.simpleMessage(
      "Λίστα Εγκαταστάσεων",
    ),
    "facilitiesNotAvailable": MessageLookupByLibrary.simpleMessage(
      "Οι εγκαταστάσεις δεν είναι διαθέσιμες.",
    ),
    "facilityDetails": MessageLookupByLibrary.simpleMessage(
      "Λεπτομέρειες Εγκατάστασης",
    ),
    "failedToApplyPromoCode": MessageLookupByLibrary.simpleMessage(
      "Αποτυχία εφαρμογής κωδικού προσφοράς.",
    ),
    "failedToBook": MessageLookupByLibrary.simpleMessage("Αποτυχία κράτησης."),
    "failedToFetchUsers": MessageLookupByLibrary.simpleMessage(
      "Αποτυχία ανάκτησης χρηστών",
    ),
    "failedToLoadAboutUs": MessageLookupByLibrary.simpleMessage(
      "Αποτυχία φόρτωσης Πληροφοριών για Εμάς",
    ),
    "failedToLoadTermsConditions": MessageLookupByLibrary.simpleMessage(
      "Αποτυχία φόρτωσης Όρων & Προϋποθέσεων",
    ),
    "failedToSendOtpPleaseTryAgain": MessageLookupByLibrary.simpleMessage(
      "Αποτυχία αποστολής OTP. Παρακαλώ δοκιμάστε ξανά.",
    ),
    "favoriteCourts": MessageLookupByLibrary.simpleMessage("Αγαπημένα Γήπεδα"),
    "favoriteCourtsNotAvailable": MessageLookupByLibrary.simpleMessage(
      "Τα Αγαπημένα Γήπεδα Δεν Είναι Διαθέσιμα",
    ),
    "favoriteSport": MessageLookupByLibrary.simpleMessage("Αγαπημένο Άθλημα"),
    "feeds": MessageLookupByLibrary.simpleMessage("Ροές"),
    "fetchingCurrentLocation": MessageLookupByLibrary.simpleMessage(
      "Ανάκτηση Τρέχουσας Τοποθεσίας...",
    ),
    "fillYourInformationBelowOrRegister": MessageLookupByLibrary.simpleMessage(
      "Συμπληρώστε τις πληροφορίες σας παρακάτω ή εγγραφείτε",
    ),
    "filter": MessageLookupByLibrary.simpleMessage("Φίλτρο"),
    "filterApply": MessageLookupByLibrary.simpleMessage("Εφαρμογή Φίλτρου"),
    "filterResult": MessageLookupByLibrary.simpleMessage("Αποτέλεσμα Φίλτρου"),
    "findBookYourGameInSeconds": MessageLookupByLibrary.simpleMessage(
      "Βρείτε & Κλείστε το Παιχνίδι σας σε Δευτερόλεπτα!",
    ),
    "football": MessageLookupByLibrary.simpleMessage("Ποδόσφαιρο"),
    "forgetPassword": MessageLookupByLibrary.simpleMessage(
      "Ξεχάσατε τον Κωδικό Πρόσβασης",
    ),
    "forgotPassword": MessageLookupByLibrary.simpleMessage(
      "Ξεχάσατε τον Κωδικό Πρόσβασης;",
    ),
    "found": MessageLookupByLibrary.simpleMessage("Βρέθηκε"),
    "friend": MessageLookupByLibrary.simpleMessage("Φίλος"),
    "friendListIsEmpty": MessageLookupByLibrary.simpleMessage(
      "Η λίστα φίλων είναι κενή!",
    ),
    "from": MessageLookupByLibrary.simpleMessage("Από "),
    "fullName": MessageLookupByLibrary.simpleMessage("Πλήρες Όνομα"),
    "fullPaid": MessageLookupByLibrary.simpleMessage("Πλήρως Πληρωμένο"),
    "gallery": MessageLookupByLibrary.simpleMessage("Γκαλερί"),
    "getAlert": MessageLookupByLibrary.simpleMessage("Λήψη Ειδοποίησης"),
    "getReadyToUnlockAWorldOf": MessageLookupByLibrary.simpleMessage(
      "Ετοιμαστείτε να ξεκλειδώσετε έναν κόσμο",
    ),
    "goToHome": MessageLookupByLibrary.simpleMessage("Μετάβαση στην Αρχική"),
    "going": MessageLookupByLibrary.simpleMessage("πηγαίνει"),
    "googlePay": MessageLookupByLibrary.simpleMessage("Google Pay"),
    "greek": MessageLookupByLibrary.simpleMessage("Ελληνικά"),
    "hey": MessageLookupByLibrary.simpleMessage("Γεια "),
    "hockey": MessageLookupByLibrary.simpleMessage("Χόκεϊ"),
    "home": MessageLookupByLibrary.simpleMessage("Αρχική"),
    "iAgreeToTheTermsConditions": MessageLookupByLibrary.simpleMessage(
      "Συμφωνώ με τους Όρους και Προϋποθέσεις.",
    ),
    "inactive": MessageLookupByLibrary.simpleMessage("Ανενεργό"),
    "interestedSports": MessageLookupByLibrary.simpleMessage(
      "Αθλήματα Ενδιαφέροντος",
    ),
    "invalidAmountPleaseTryAgainLater": MessageLookupByLibrary.simpleMessage(
      "Μη έγκυρο ποσό. Δοκιμάστε ξανά αργότερα!",
    ),
    "invalidOtp": MessageLookupByLibrary.simpleMessage("Μη έγκυρο OTP"),
    "invalidOtpPleaseTryAgain": MessageLookupByLibrary.simpleMessage(
      "Μη έγκυρο OTP. Παρακαλώ δοκιμάστε ξανά.",
    ),
    "invalidPromoDataReceivedFromServer": MessageLookupByLibrary.simpleMessage(
      "Μη έγκυρα δεδομένα προσφοράς λήφθηκαν από τον διακομιστή.",
    ),
    "invalidSportSelection": MessageLookupByLibrary.simpleMessage(
      "Μη έγκυρη επιλογή αθλήματος.",
    ),
    "invalidTime": MessageLookupByLibrary.simpleMessage("Μη έγκυρη ώρα"),
    "inviteCode": MessageLookupByLibrary.simpleMessage("ΚΩΔΙΚΟΣ ΠΡΟΣΚΛΗΣΗΣ: "),
    "inviteOthers": MessageLookupByLibrary.simpleMessage(
      "Προσκαλέστε άλλους. ",
    ),
    "joinAChallenge": MessageLookupByLibrary.simpleMessage(
      "👉 Συμμετάσχετε σε Πρόκληση: ",
    ),
    "joinAChallengeCompeteProveYourSkillsCreateAChallenge":
        MessageLookupByLibrary.simpleMessage(
          "👉Συμμετάσχετε σε Πρόκληση: Διαγωνιστείτε, αποδείξτε τις δεξιότητές σας. 👉Δημιουργήστε Πρόκληση: Προσκαλέστε άλλους. 👉Δημόσια ή Ιδιωτική: Ανοιχτή σε όλους ή μόνο για την ομάδα σας!",
        ),
    "joinChallenge": MessageLookupByLibrary.simpleMessage(
      "Συμμετοχή σε Πρόκληση",
    ),
    "joinNow": MessageLookupByLibrary.simpleMessage("Εγγραφείτε Τώρα"),
    "joinPrivateChallengeByInvitingFriends":
        MessageLookupByLibrary.simpleMessage(
          "Συμμετάσχετε σε Ιδιωτική Πρόκληση Προσκαλώντας Φίλους",
        ),
    "joinUs": MessageLookupByLibrary.simpleMessage("ΕΛΑΤΕ ΜΑΖΙ ΜΑΣ"),
    "kratEasy": MessageLookupByLibrary.simpleMessage("Krat Easy"),
    "left": MessageLookupByLibrary.simpleMessage("Απομένει"),
    "letsGetPlaying": MessageLookupByLibrary.simpleMessage(
      "Ας αρχίσουμε να παίζουμε!",
    ),
    "level": MessageLookupByLibrary.simpleMessage("Επίπεδο: "),
    "listOfFacilities": MessageLookupByLibrary.simpleMessage(
      "Λίστα Εγκαταστάσεων",
    ),
    "loading": MessageLookupByLibrary.simpleMessage("Φόρτωση..."),
    "locationNotAvailable": MessageLookupByLibrary.simpleMessage(
      "Η τοποθεσία δεν είναι διαθέσιμη.",
    ),
    "locationNotFetchedPleaseTryAgain": MessageLookupByLibrary.simpleMessage(
      "Η τοποθεσία δεν ελήφθη. Παρακαλώ δοκιμάστε ξανά.",
    ),
    "locationPermissionDenied": MessageLookupByLibrary.simpleMessage(
      "Άδεια τοποθεσίας απορρίφθηκε.",
    ),
    "locationPermissionNotGranted": MessageLookupByLibrary.simpleMessage(
      "Η άδεια τοποθεσίας δεν χορηγήθηκε.",
    ),
    "locationPermissionPermanentlyDeniedPleaseEnableItFromSettings":
        MessageLookupByLibrary.simpleMessage(
          "Η άδεια τοποθεσίας απορρίφθηκε οριστικά. Ενεργοποιήστε την από τις ρυθμίσεις.",
        ),
    "locationPermissionsArePermanentlyDeniedPleaseEnableThemInSettings":
        MessageLookupByLibrary.simpleMessage(
          "Οι άδειες τοποθεσίας απορρίφθηκαν οριστικά. Ενεργοποιήστε τις από τις ρυθμίσεις.",
        ),
    "locationServicesAreDisabled": MessageLookupByLibrary.simpleMessage(
      "Οι υπηρεσίες τοποθεσίας είναι απενεργοποιημένες.",
    ),
    "locationServicesAreDisabledPleaseTurnOnGpsToContinue":
        MessageLookupByLibrary.simpleMessage(
          "Οι υπηρεσίες τοποθεσίας είναι απενεργοποιημένες. Ενεργοποιήστε το GPS για να συνεχίσετε.",
        ),
    "logIn": MessageLookupByLibrary.simpleMessage("Σύνδεση"),
    "login": MessageLookupByLibrary.simpleMessage("Σύνδεση"),
    "logout": MessageLookupByLibrary.simpleMessage("Αποσύνδεση"),
    "matchType": MessageLookupByLibrary.simpleMessage("Τύπος Αγώνα: "),
    "mate": MessageLookupByLibrary.simpleMessage("Φίλος"),
    "miles": MessageLookupByLibrary.simpleMessage("μίλια"),
    "minTimeToBook": MessageLookupByLibrary.simpleMessage(
      "Ελάχ. Χρόνος Κράτησης: ",
    ),
    "mobileNumber": MessageLookupByLibrary.simpleMessage("Αριθμός Κινητού"),
    "modify": MessageLookupByLibrary.simpleMessage("Τροποποίηση"),
    "modifyBooking": MessageLookupByLibrary.simpleMessage(
      "Τροποποίηση κράτησης",
    ),
    "morePaymentsOptions": MessageLookupByLibrary.simpleMessage(
      "Περισσότερες Επιλογές Πληρωμής",
    ),
    "myAccount": MessageLookupByLibrary.simpleMessage("Ο Λογαριασμός Μου"),
    "myBooking": MessageLookupByLibrary.simpleMessage("Η Κράτησή Μου"),
    "myFavouritePlayers": MessageLookupByLibrary.simpleMessage(
      "Οι Αγαπημένοι Μου Παίκτες",
    ),
    "na": MessageLookupByLibrary.simpleMessage("Μ/Δ"),
    "nearbyCourts": MessageLookupByLibrary.simpleMessage("Κοντινά Γήπεδα"),
    "no": MessageLookupByLibrary.simpleMessage("Όχι"),
    "noAddressFound": MessageLookupByLibrary.simpleMessage(
      "Δεν βρέθηκε διεύθυνση.",
    ),
    "noChallengesAvailable": MessageLookupByLibrary.simpleMessage(
      "Δεν Υπάρχουν Διαθέσιμες Προκλήσεις",
    ),
    "noCourtsAvailable": MessageLookupByLibrary.simpleMessage(
      "Δεν υπάρχουν διαθέσιμα γήπεδα.",
    ),
    "noDataAvailable": MessageLookupByLibrary.simpleMessage(
      "Δεν υπάρχουν διαθέσιμα δεδομένα",
    ),
    "noDataFound": MessageLookupByLibrary.simpleMessage(
      "Δεν βρέθηκαν δεδομένα.",
    ),
    "noFavoritePlayerDataFound": MessageLookupByLibrary.simpleMessage(
      "Δεν βρέθηκαν δεδομένα αγαπημένων παικτών.",
    ),
    "noFavouritePlayersFound": MessageLookupByLibrary.simpleMessage(
      "Δεν βρέθηκαν αγαπημένοι παίκτες!",
    ),
    "noNotificationsAvailable": MessageLookupByLibrary.simpleMessage(
      "Δεν υπάρχουν διαθέσιμες ειδοποιήσεις.",
    ),
    "noNumber": MessageLookupByLibrary.simpleMessage("Χωρίς Αριθμό"),
    "noSlotsAvailableAtThisTime": MessageLookupByLibrary.simpleMessage(
      "Δεν υπάρχουν διαθέσιμες χρονοθυρίδες αυτή τη στιγμή.",
    ),
    "noTransactionsFound": MessageLookupByLibrary.simpleMessage(
      "Δεν βρέθηκαν συναλλαγές.",
    ),
    "noteHeader": MessageLookupByLibrary.simpleMessage("Σημείωση: "),
    "notifications": MessageLookupByLibrary.simpleMessage("Ειδοποιήσεις"),
    "numberOfPlayer": MessageLookupByLibrary.simpleMessage("Αριθμός Παικτών"),
    "openForAnyoneToJoin": MessageLookupByLibrary.simpleMessage(
      "Ανοιχτό για όλους να συμμετάσχουν.",
    ),
    "openSettings": MessageLookupByLibrary.simpleMessage("Άνοιγμα Ρυθμίσεων"),
    "openToAllOrJustYourCrew": MessageLookupByLibrary.simpleMessage(
      "Ανοιχτή σε όλους ή μόνο για την ομάδα σας!",
    ),
    "or": MessageLookupByLibrary.simpleMessage("Ή"),
    "otpRequired": MessageLookupByLibrary.simpleMessage("Απαιτείται OTP"),
    "outOf": MessageLookupByLibrary.simpleMessage("Από "),
    "paid": MessageLookupByLibrary.simpleMessage("Πληρωμένο"),
    "paidAmount": MessageLookupByLibrary.simpleMessage("Πληρωμένο Ποσό"),
    "password": MessageLookupByLibrary.simpleMessage("Κωδικός Πρόσβασης"),
    "payAmount": MessageLookupByLibrary.simpleMessage("Πληρωτέο Ποσό"),
    "paymentSuccessful": MessageLookupByLibrary.simpleMessage(
      "Πληρωμή Επιτυχής",
    ),
    "phoneNumber": MessageLookupByLibrary.simpleMessage("Αριθμός Τηλεφώνου"),
    "phoneNumberMustBe810Digits": MessageLookupByLibrary.simpleMessage(
      "Ο αριθμός τηλεφώνου πρέπει να είναι 8-10 ψηφία",
    ),
    "playAgain": MessageLookupByLibrary.simpleMessage("Παίξε Ξανά"),
    "playerGoing": MessageLookupByLibrary.simpleMessage(
      "Παίκτης που συμμετέχει",
    ),
    "players": MessageLookupByLibrary.simpleMessage("Παίκτες"),
    "pleaseAcceptTheTermsConditionsToContinue":
        MessageLookupByLibrary.simpleMessage(
          "Παρακαλώ αποδεχτείτε τους Όρους & Προϋποθέσεις για να συνεχίσετε.",
        ),
    "pleaseAddFriendsToSplitTheCost": MessageLookupByLibrary.simpleMessage(
      "Παρακαλώ προσθέστε φίλους για να διαχωρίσετε το κόστος.",
    ),
    "pleaseEnterPromoCode": MessageLookupByLibrary.simpleMessage(
      "Παρακαλώ εισαγάγετε κωδικό προσφοράς",
    ),
    "pleaseEnterTheOtp": MessageLookupByLibrary.simpleMessage(
      "Παρακαλώ εισαγάγετε το OTP.",
    ),
    "pleaseEnterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
      "Παρακαλώ εισαγάγετε τον αριθμό τηλεφώνου σας",
    ),
    "pleaseEnterYourRegisteredNumberTo": MessageLookupByLibrary.simpleMessage(
      "Εισαγάγετε τον καταχωρημένο αριθμό σας για να",
    ),
    "pleaseSelectADate": MessageLookupByLibrary.simpleMessage(
      "Παρακαλώ επιλέξτε μια ημερομηνία.",
    ),
    "pleaseSelectAFacilityFirst": MessageLookupByLibrary.simpleMessage(
      "Παρακαλώ επιλέξτε πρώτα μια εγκατάσταση",
    ),
    "pleaseSelectAPaymentMethod": MessageLookupByLibrary.simpleMessage(
      "Παρακαλώ επιλέξτε μια μέθοδο πληρωμής",
    ),
    "pleaseSelectASlotToContinue": MessageLookupByLibrary.simpleMessage(
      "Παρακαλώ επιλέξτε μια χρονοθυρίδα για να συνεχίσετε.",
    ),
    "pleaseSelectASortingOption": MessageLookupByLibrary.simpleMessage(
      "Παρακαλώ επιλέξτε μια επιλογή ταξινόμησης.",
    ),
    "pleaseSelectASport": MessageLookupByLibrary.simpleMessage(
      "Παρακαλώ επιλέξτε ένα άθλημα",
    ),
    "pleaseSelectASportFirst": MessageLookupByLibrary.simpleMessage(
      "Παρακαλώ επιλέξτε πρώτα ένα άθλημα",
    ),
    "pleaseSelectATime": MessageLookupByLibrary.simpleMessage(
      "Παρακαλώ επιλέξτε μια ώρα",
    ),
    "pleaseSelectAValidLocation": MessageLookupByLibrary.simpleMessage(
      "Παρακαλώ επιλέξτε μια έγκυρη τοποθεσία.",
    ),
    "pleaseSelectAtLeastOneAmenity": MessageLookupByLibrary.simpleMessage(
      "Παρακαλώ επιλέξτε τουλάχιστον μία παροχή.",
    ),
    "pleaseSelectAtLeastOneSlotToContinue":
        MessageLookupByLibrary.simpleMessage(
          "Παρακαλώ επιλέξτε τουλάχιστον μία υποδοχή για να συνεχίσετε.",
        ),
    "pleaseSelectAtLeastOneTimeSlot": MessageLookupByLibrary.simpleMessage(
      "Παρακαλώ επιλέξτε τουλάχιστον μία χρονική υποδοχή.",
    ),
    "pleaseSelectSkillLevel": MessageLookupByLibrary.simpleMessage(
      "Παρακαλώ επιλέξτε επίπεδο δεξιότητας",
    ),
    "pleaseSelectSlotsInOrder": MessageLookupByLibrary.simpleMessage(
      "Παρακαλώ επιλέξτε χρονοθυρίδες με σειρά.",
    ),
    "pleaseSelectSlotsInSequence": MessageLookupByLibrary.simpleMessage(
      "Παρακαλώ επιλέξτε χρονοθυρίδες στη σειρά.",
    ),
    "pleaseSelectTimeSlotsInSequence": MessageLookupByLibrary.simpleMessage(
      "Παρακαλώ επιλέξτε χρονοθυρίδες στη σειρά.",
    ),
    "pleaseTryAgainLater": MessageLookupByLibrary.simpleMessage(
      "Παρακαλώ δοκιμάστε ξανά αργότερα!",
    ),
    "possibilitiessignIntoYourAccountNow": MessageLookupByLibrary.simpleMessage(
      "δυνατοτήτων-Συνδεθείτε στον λογαριασμό σας τώρα",
    ),
    "priceMinMax": MessageLookupByLibrary.simpleMessage(
      "Τιμή (Ελάχιστο & Μέγιστο)",
    ),
    "privacyPolicy": MessageLookupByLibrary.simpleMessage("Πολιτική Απορρήτου"),
    "private": MessageLookupByLibrary.simpleMessage("Ιδιωτική"),
    "profileUpdateSuccessfully": MessageLookupByLibrary.simpleMessage(
      "Ενημέρωση Προφίλ Επιτυχής",
    ),
    "promoCode": MessageLookupByLibrary.simpleMessage("Κωδικός Προσφοράς"),
    "public": MessageLookupByLibrary.simpleMessage("Δημόσια"),
    "publicOrPrivate": MessageLookupByLibrary.simpleMessage(
      "👉 Δημόσια ή Ιδιωτική: ",
    ),
    "quickRebook": MessageLookupByLibrary.simpleMessage("Γρήγορη Επανεκράτηση"),
    "radiusDistance": MessageLookupByLibrary.simpleMessage("Ακτίνα (Απόσταση)"),
    "rateTheCourt": MessageLookupByLibrary.simpleMessage(
      "Βαθμολογήστε το Γήπεδο",
    ),
    "rating": MessageLookupByLibrary.simpleMessage("Βαθμολογία"),
    "readAllNew": MessageLookupByLibrary.simpleMessage("Διάβασε Όλα"),
    "readall": MessageLookupByLibrary.simpleMessage("διάβασε όλα"),
    "rebook": MessageLookupByLibrary.simpleMessage("Επανάληψη Κράτησης"),
    "receiveAVerificationCode": MessageLookupByLibrary.simpleMessage(
      "λάβετε έναν κωδικό επαλήθευσης",
    ),
    "reenterPassword": MessageLookupByLibrary.simpleMessage(
      "Επανεισαγάγετε Κωδικό Πρόσβασης",
    ),
    "refundMinusASmallConvenienceFee": MessageLookupByLibrary.simpleMessage(
      "Επιστροφή χρημάτων μείον μια μικρή χρέωση ευκολίας",
    ),
    "refunded": MessageLookupByLibrary.simpleMessage("Επιστράφηκε"),
    "rememberMe": MessageLookupByLibrary.simpleMessage("Να με θυμάσαι"),
    "remove": MessageLookupByLibrary.simpleMessage("Αφαίρεση"),
    "resendIn": MessageLookupByLibrary.simpleMessage("Επαναποστολή σε"),
    "resendOtp": MessageLookupByLibrary.simpleMessage("Επαναποστολή OTP"),
    "resendOtpIn50s": MessageLookupByLibrary.simpleMessage(
      "Επαναποστολή OTP σε 50 δευτερόλεπτα",
    ),
    "resetPassword": MessageLookupByLibrary.simpleMessage(
      "Επαναφορά Κωδικού Πρόσβασης",
    ),
    "review": MessageLookupByLibrary.simpleMessage("Κριτική"),
    "reviews": MessageLookupByLibrary.simpleMessage("Κριτικές"),
    "rules": MessageLookupByLibrary.simpleMessage("Κανόνες: "),
    "s": MessageLookupByLibrary.simpleMessage("ες"),
    "saveProfile": MessageLookupByLibrary.simpleMessage("Αποθήκευση Προφίλ"),
    "searchByFacilityNameOrCourtName": MessageLookupByLibrary.simpleMessage(
      "Αναζήτηση με Όνομα Εγκατάστασης ή Όνομα Γηπέδου",
    ),
    "searchChallenges": MessageLookupByLibrary.simpleMessage(
      "Αναζήτηση Προκλήσεων",
    ),
    "searchContact": MessageLookupByLibrary.simpleMessage("Αναζήτηση Επαφής"),
    "searchCourts": MessageLookupByLibrary.simpleMessage("Αναζήτηση Γηπέδων"),
    "searchFacility": MessageLookupByLibrary.simpleMessage(
      "Αναζήτηση Εγκατάστασης",
    ),
    "searchPlace": MessageLookupByLibrary.simpleMessage(
      "Αναζήτηση τοποθεσίας...",
    ),
    "seeAll": MessageLookupByLibrary.simpleMessage("Δες Όλα"),
    "select": MessageLookupByLibrary.simpleMessage("Επιλογή"),
    "selectDate": MessageLookupByLibrary.simpleMessage("Επιλέξτε Ημερομηνία"),
    "selectFacility": MessageLookupByLibrary.simpleMessage(
      "Επιλέξτε Εγκατάσταση",
    ),
    "selectLanguage": MessageLookupByLibrary.simpleMessage("Επιλέξτε Γλώσσα"),
    "selectLocation": MessageLookupByLibrary.simpleMessage(
      "Επιλέξτε Τοποθεσία",
    ),
    "selectLocationManually": MessageLookupByLibrary.simpleMessage(
      "Επιλέξτε Τοποθεσία Χειροκίνητα",
    ),
    "selectSpecificUsersToChallenge": MessageLookupByLibrary.simpleMessage(
      "Επιλέξτε συγκεκριμένους χρήστες για πρόκληση.",
    ),
    "selectSport": MessageLookupByLibrary.simpleMessage("Επιλέξτε Άθλημα"),
    "selectSports": MessageLookupByLibrary.simpleMessage("Επιλέξτε Αθλήματα"),
    "selectSportsName": MessageLookupByLibrary.simpleMessage(
      "Επιλέξτε Όνομα Αθλήματος",
    ),
    "selectYourSportChooseALocationPickADateTime":
        MessageLookupByLibrary.simpleMessage(
          "👉 Επιλέξτε το άθλημά σας, 👉 Επιλέξτε τοποθεσία, 👉 Επιλέξτε ημερομηνία & ώρα 👉 Επιβεβαιώστε & παίξτε!",
        ),
    "sendOtp": MessageLookupByLibrary.simpleMessage("ΑΠΟΣΤΟΛΗ OTP"),
    "setPassword": MessageLookupByLibrary.simpleMessage(
      "Ορίστε Κωδικό Πρόσβασης",
    ),
    "setYourLocationToStartExploringnSportsCourtsAroundYou":
        MessageLookupByLibrary.simpleMessage(
          "Ορίστε την τοποθεσία σας για να ξεκινήσετε να εξερευνάτε γήπεδα αθλημάτων γύρω σας.",
        ),
    "share": MessageLookupByLibrary.simpleMessage("Κοινοποίηση"),
    "sharePaymentLink": MessageLookupByLibrary.simpleMessage(
      "Κοινοποίηση Συνδέσμου Πληρωμής",
    ),
    "signUp": MessageLookupByLibrary.simpleMessage("Εγγραφή"),
    "skillLevel": MessageLookupByLibrary.simpleMessage("Επίπεδο Δεξιότητας"),
    "skillSet": MessageLookupByLibrary.simpleMessage("Σύνολο Δεξιοτήτων"),
    "slotNotAvailable": MessageLookupByLibrary.simpleMessage(
      "Η χρονοθυρίδα δεν είναι διαθέσιμη.",
    ),
    "slots": MessageLookupByLibrary.simpleMessage("Χρονοθυρίδες"),
    "somethingWentWrong": MessageLookupByLibrary.simpleMessage(
      "Κάτι πήγε στραβά.",
    ),
    "somethingWentWrongGetbookingdetails": MessageLookupByLibrary.simpleMessage(
      "Κάτι πήγε στραβά (λήψη λεπτομερειών κράτησης)",
    ),
    "somethingWentWrongGetfacilitiesdata": MessageLookupByLibrary.simpleMessage(
      "Κάτι πήγε στραβά (λήψη δεδομένων εγκαταστάσεων)",
    ),
    "somethingWentWrongGetfavouriteplayerdata":
        MessageLookupByLibrary.simpleMessage(
          "Κάτι πήγε στραβά (λήψη δεδομένων αγαπημένων παικτών)",
        ),
    "somethingWentWrongGetprofiledataapi": MessageLookupByLibrary.simpleMessage(
      "Κάτι πήγε στραβά (λήψη δεδομένων προφίλ)",
    ),
    "somethingWentWrongGetslots": MessageLookupByLibrary.simpleMessage(
      "Κάτι πήγε στραβά (λήψη χρονοθυρίδων)",
    ),
    "somethingWentWrongPleaseTryAgain": MessageLookupByLibrary.simpleMessage(
      "Κάτι πήγε στραβά. Παρακαλώ δοκιμάστε ξανά.",
    ),
    "somethingWentWrongWhileFetchingNotifications":
        MessageLookupByLibrary.simpleMessage(
          "Κάτι πήγε στραβά κατά την ανάκτηση ειδοποιήσεων.",
        ),
    "somethingsWentWrongPleaseTryAgainLater":
        MessageLookupByLibrary.simpleMessage(
          "Κάτι πήγε στραβά. Παρακαλώ δοκιμάστε ξανά αργότερα!",
        ),
    "somethingsWentWrongcreatechallenge": MessageLookupByLibrary.simpleMessage(
      "Κάτι πήγε στραβά (δημιουργία πρόκλησης)",
    ),
    "somethingsWentWrongdeleteaccount": MessageLookupByLibrary.simpleMessage(
      "Κάτι πήγε στραβά (διαγραφή λογαριασμού)",
    ),
    "somethingsWentWrongdeletenotification":
        MessageLookupByLibrary.simpleMessage(
          "Κάτι πήγε στραβά (διαγραφή ειδοποίησης)",
        ),
    "somethingsWentWrongeditMyAccount": MessageLookupByLibrary.simpleMessage(
      "Κάτι πήγε στραβά (επεξεργασία λογαριασμού)",
    ),
    "somethingsWentWrongfetchchallenges": MessageLookupByLibrary.simpleMessage(
      "Κάτι πήγε στραβά (λήψη προκλήσεων)",
    ),
    "somethingsWentWronggetbookingdetails":
        MessageLookupByLibrary.simpleMessage(
          "Κάτι πήγε στραβά (λήψη λεπτομερειών κράτησης)",
        ),
    "somethingsWentWronggetchallengesdetails":
        MessageLookupByLibrary.simpleMessage(
          "Κάτι πήγε στραβά (λήψη λεπτομερειών προκλήσεων)",
        ),
    "somethingsWentWronggetfacilitiesdata":
        MessageLookupByLibrary.simpleMessage(
          "Κάτι πήγε στραβά (λήψη δεδομένων εγκαταστάσεων)",
        ),
    "somethingsWentWronggetfavouritelistdata":
        MessageLookupByLibrary.simpleMessage(
          "Κάτι πήγε στραβά (λήψη δεδομένων λίστας αγαπημένων)",
        ),
    "somethingsWentWronggethomedata": MessageLookupByLibrary.simpleMessage(
      "Κάτι πήγε στραβά (λήψη δεδομένων αρχικής σελίδας)",
    ),
    "somethingsWentWronggetmybookingdata": MessageLookupByLibrary.simpleMessage(
      "Κάτι πήγε στραβά (λήψη δεδομένων κράτησης)",
    ),
    "somethingsWentWronggetmychallengedata":
        MessageLookupByLibrary.simpleMessage(
          "Κάτι πήγε στραβά (λήψη δεδομένων πρόκλησης)",
        ),
    "somethingsWentWronggetprofiledataapi":
        MessageLookupByLibrary.simpleMessage(
          "Κάτι πήγε στραβά (λήψη δεδομένων προφίλ)",
        ),
    "somethingsWentWrongnotificationtoggle":
        MessageLookupByLibrary.simpleMessage(
          "Κάτι πήγε στραβά (εναλλαγή ειδοποιήσεων)",
        ),
    "somethingsWentWrongtypeChallenge": MessageLookupByLibrary.simpleMessage(
      "Κάτι πήγε στραβά (τύπος πρόκλησης)",
    ),
    "somethingsWentWrongunreadnotification":
        MessageLookupByLibrary.simpleMessage(
          "Κάτι πήγε στραβά (μη αναγνωσμένη ειδοποίηση)",
        ),
    "sort": MessageLookupByLibrary.simpleMessage("Ταξινόμηση"),
    "split": MessageLookupByLibrary.simpleMessage("Διαίρεση"),
    "splitPaymentWithFriends": MessageLookupByLibrary.simpleMessage(
      "Διαίρεση πληρωμής με φίλους",
    ),
    "started": MessageLookupByLibrary.simpleMessage("Ξεκίνησε"),
    "staySecure": MessageLookupByLibrary.simpleMessage("Παραμείνετε Ασφαλείς!"),
    "submit": MessageLookupByLibrary.simpleMessage("Υποβολή"),
    "successful": MessageLookupByLibrary.simpleMessage("Επιτυχής"),
    "successfullyChange": MessageLookupByLibrary.simpleMessage(
      "Αλλαγή Επιτυχής",
    ),
    "successfullyCreated": MessageLookupByLibrary.simpleMessage(
      "Δημιουργήθηκε Επιτυχώς",
    ),
    "takeOnTheChallenge": MessageLookupByLibrary.simpleMessage(
      "Αναλάβετε την Πρόκληση! 💪🏆",
    ),
    "tennis": MessageLookupByLibrary.simpleMessage("Τένις"),
    "termsAndConditions": MessageLookupByLibrary.simpleMessage(
      "Όροι και Προϋποθέσεις",
    ),
    "termsConditions": MessageLookupByLibrary.simpleMessage(
      "Όρους & Προϋποθέσεις",
    ),
    "termsOfService": MessageLookupByLibrary.simpleMessage("Όροι Υπηρεσίας"),
    "time": MessageLookupByLibrary.simpleMessage("Ώρα"),
    "totalAmount": MessageLookupByLibrary.simpleMessage("Συνολικό Ποσό"),
    "transaction": MessageLookupByLibrary.simpleMessage("Συναλλαγή"),
    "transactionDetails": MessageLookupByLibrary.simpleMessage(
      "Λεπτομέρειες Συναλλαγής",
    ),
    "transactionId": MessageLookupByLibrary.simpleMessage(
      "Αναγνωριστικό Συναλλαγής ",
    ),
    "transactionInfo": MessageLookupByLibrary.simpleMessage(
      "Πληροφορίες συναλλαγής: ",
    ),
    "transactions": MessageLookupByLibrary.simpleMessage("Συναλλαγές"),
    "typeOfBooking": MessageLookupByLibrary.simpleMessage("Τύπος Κράτησης: "),
    "unableToFetchBookingId": MessageLookupByLibrary.simpleMessage(
      "Αδυναμία ανάκτησης αναγνωριστικού κράτησης",
    ),
    "unexpectedErrorOccurred": MessageLookupByLibrary.simpleMessage(
      "Προέκυψε απροσδόκητο σφάλμα.",
    ),
    "unexpectedResponseFormatFromServer": MessageLookupByLibrary.simpleMessage(
      "Απροσδόκητη μορφή απόκρισης από τον διακομιστή.",
    ),
    "unreadAll": MessageLookupByLibrary.simpleMessage("Αδιάβαστα Όλα"),
    "upcoming": MessageLookupByLibrary.simpleMessage("Επερχόμενα"),
    "upcomingBookings": MessageLookupByLibrary.simpleMessage(
      "Επερχόμενες Κρατήσεις",
    ),
    "upcomingBookingsNotFound": MessageLookupByLibrary.simpleMessage(
      "Δεν Βρέθηκαν Επερχόμενες Κρατήσεις !!",
    ),
    "verification": MessageLookupByLibrary.simpleMessage("Επαλήθευση"),
    "verificationCode": MessageLookupByLibrary.simpleMessage(
      "Κωδικός Επαλήθευσης",
    ),
    "verify": MessageLookupByLibrary.simpleMessage("Επαλήθευση"),
    "verifyOtp": MessageLookupByLibrary.simpleMessage("Επαλήθευση OTP"),
    "verifyYourPhoneNumberWithOtp": MessageLookupByLibrary.simpleMessage(
      "Επαληθεύστε τον αριθμό του κινητού σας χρησιμοποιώντας το OTP.",
    ),
    "viewAll": MessageLookupByLibrary.simpleMessage("Προβολή Όλων"),
    "viewBookings": MessageLookupByLibrary.simpleMessage("Προβολή Κρατήσεων"),
    "viewChallenge": MessageLookupByLibrary.simpleMessage("Δείτε την πρόκληση"),
    "viewCourtDetails": MessageLookupByLibrary.simpleMessage(
      "Προβολή Λεπτομερειών Γηπέδου",
    ),
    "viewDetail": MessageLookupByLibrary.simpleMessage("Προβολή Λεπτομερειών"),
    "wallet": MessageLookupByLibrary.simpleMessage("Πορτοφόλι"),
    "weHaveSuccessfullySendTheQrCodeToYourEmailuse":
        MessageLookupByLibrary.simpleMessage(
          "Στείλαμε επιτυχώς τον κωδικό QR στο email σας. Χρησιμοποιήστε τον για την είσοδό σας",
        ),
    "welcomeEasybooking": MessageLookupByLibrary.simpleMessage(
      "Καλώς Ήρθατε & Εύκολη Κράτηση 📍",
    ),
    "welcomeTo": MessageLookupByLibrary.simpleMessage("Καλώς Ήρθατε στο"),
    "whatDoYouWantToPlay": MessageLookupByLibrary.simpleMessage(
      "Τι θέλετε να παίξετε;",
    ),
    "whatSportDoYouWantToPlay": MessageLookupByLibrary.simpleMessage(
      "Ποιο άθλημα θέλετε να παίξετε;",
    ),
    "whichTime": MessageLookupByLibrary.simpleMessage("Ποια Ώρα"),
    "wholeCourtBooking": MessageLookupByLibrary.simpleMessage(
      "Κράτηση Ολόκληρου Γηπέδου",
    ),
    "withYourAccount": MessageLookupByLibrary.simpleMessage(
      "με τον λογαριασμό σας.",
    ),
    "writeTheComment": MessageLookupByLibrary.simpleMessage("Γράψτε το σχόλιο"),
    "yesConfirm": MessageLookupByLibrary.simpleMessage("Ναι, Επιβεβαίωση"),
    "youCanOnlyDeselectTheFirstOrLastSlot": MessageLookupByLibrary.simpleMessage(
      "Μπορείτε να αποεπιλέξετε μόνο την πρώτη ή την τελευταία χρονοθυρίδα.",
    ),
    "youCanOnlyDeselectTheStartOrEndSlot": MessageLookupByLibrary.simpleMessage(
      "Μπορείτε να αποεπιλέξετε μόνο την αρχή ή το τέλος της χρονοθυρίδας.",
    ),
    "yourAccount": MessageLookupByLibrary.simpleMessage("Ο Λογαριασμός Σας"),
    "yourAccountSuccessfullyCreatedClick": MessageLookupByLibrary.simpleMessage(
      "Ο λογαριασμός σας δημιουργήθηκε επιτυχώς! Κάντε κλικ",
    ),
    "yourNewPasswordIsNowActive": MessageLookupByLibrary.simpleMessage(
      "Ο νέος σας κωδικός πρόσβασης είναι πλέον ενεργός.",
    ),
    "yourSportsCommunityApp": MessageLookupByLibrary.simpleMessage(
      "Η Εφαρμογή της Αθλητικής σας Κοινότητας",
    ),
    "yourTransactionIsComplete": MessageLookupByLibrary.simpleMessage(
      "Η συναλλαγή σας ολοκληρώθηκε.",
    ),
    "youreAlmostThere": MessageLookupByLibrary.simpleMessage(
      "Είστε Σχεδόν Εκεί!",
    ),
  };
}
