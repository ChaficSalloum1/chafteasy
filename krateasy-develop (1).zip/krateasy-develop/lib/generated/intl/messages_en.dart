// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a en locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'en';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
    "aboutUs": MessageLookupByLibrary.simpleMessage("About Us"),
    "accountDeleteSuccessfully": MessageLookupByLibrary.simpleMessage(
      "Account Delete Successfully",
    ),
    "active": MessageLookupByLibrary.simpleMessage("Active"),
    "activeChallenges": MessageLookupByLibrary.simpleMessage(
      "Active Challenges",
    ),
    "add": MessageLookupByLibrary.simpleMessage("Add"),
    "addAddress": MessageLookupByLibrary.simpleMessage("Add Address"),
    "addAnotherRecipient": MessageLookupByLibrary.simpleMessage(
      "Add another Recipient",
    ),
    "addCard": MessageLookupByLibrary.simpleMessage("Add Card"),
    "addFriends": MessageLookupByLibrary.simpleMessage("Add Friends"),
    "addFriendsSplitTheCost": MessageLookupByLibrary.simpleMessage(
      "Add Friends & Split the Cost! ⚽🏀",
    ),
    "addMore": MessageLookupByLibrary.simpleMessage("Add More"),
    "added": MessageLookupByLibrary.simpleMessage("Added"),
    "addedAmount": MessageLookupByLibrary.simpleMessage("Added Amount"),
    "addedFriends": MessageLookupByLibrary.simpleMessage("Added Friends"),
    "address": MessageLookupByLibrary.simpleMessage("Address"),
    "agreeWith": MessageLookupByLibrary.simpleMessage("Agree with "),
    "allPlayersWillUseThisLinkToMakentheirSplitPayment":
        MessageLookupByLibrary.simpleMessage(
          "All players will use this link to make their split payment",
        ),
    "alreadyHaveAccount": MessageLookupByLibrary.simpleMessage(
      "Already have account?",
    ),
    "alreadyHaveAccountS": MessageLookupByLibrary.simpleMessage(
      "Register/ Login",
    ),
    "amenities": MessageLookupByLibrary.simpleMessage("Amenities"),
    "amenitiesclg": MessageLookupByLibrary.simpleMessage("Amenities : "),
    "anErrorOccurredPleaseTryAgain": MessageLookupByLibrary.simpleMessage(
      "An error occurred. Please try again.",
    ),
    "anErrorOccurredWhileFetchingChallengeFacilitiesPleaseTryAgain":
        MessageLookupByLibrary.simpleMessage(
          "An error occurred while fetching challenge facilities. Please try again later.",
        ),
    "anUnexpectedErrorOccurredPleaseTryAgain":
        MessageLookupByLibrary.simpleMessage(
          "An unexpected error occurred. Please try again.",
        ),
    "andLowercaseLetters": MessageLookupByLibrary.simpleMessage(
      "and lowercase letters",
    ),
    "appVersion": MessageLookupByLibrary.simpleMessage("App Version"),
    "applePay": MessageLookupByLibrary.simpleMessage("Apple Pay"),
    "applied": MessageLookupByLibrary.simpleMessage("Applied"),
    "apply": MessageLookupByLibrary.simpleMessage("Apply"),
    "areYouSure": MessageLookupByLibrary.simpleMessage("Are you sure ?"),
    "areYouSureYouWantToCancelThisBookingIf": MessageLookupByLibrary.simpleMessage(
      "Are you sure you want to cancel this booking? If yes, please press the confirm button. We will deduct the platform fee, and the remaining amount will be transferred to your wallet. Thank you.",
    ),
    "areYouSureYouWantToCancelThisChallengeIf":
        MessageLookupByLibrary.simpleMessage(
          "Are you sure you want to cancel this challenge? If yes, please press the confirm button. We will deduct the platform fee, and the remaining amount will be transferred to your wallet. Thank you.",
        ),
    "areYouSureYouWantToExit": MessageLookupByLibrary.simpleMessage(
      "Are you sure you want to exit?",
    ),
    "areYouSureYouWantToLogoutYourAccount":
        MessageLookupByLibrary.simpleMessage(
          "Are you sure you want to logout your account?",
        ),
    "assetslogopng": MessageLookupByLibrary.simpleMessage("assets/logo.png"),
    "atLeast6CharactersAnd1SpecialSymbol": MessageLookupByLibrary.simpleMessage(
      "at least 6 characters and 1 special symbol",
    ),
    "atLeast9CharactersWithUppercase": MessageLookupByLibrary.simpleMessage(
      "At least 9 characters, with uppercase",
    ),
    "available": MessageLookupByLibrary.simpleMessage("Available"),
    "availableChallenges": MessageLookupByLibrary.simpleMessage(
      "Available Challenges",
    ),
    "availableNearbyCourts": MessageLookupByLibrary.simpleMessage(
      "Available Nearby Courts",
    ),
    "back": MessageLookupByLibrary.simpleMessage("Back"),
    "backToLogin": MessageLookupByLibrary.simpleMessage("Back to Login"),
    "badminton": MessageLookupByLibrary.simpleMessage("Badminton"),
    "basketball": MessageLookupByLibrary.simpleMessage("Basketball"),
    "bookACourt": MessageLookupByLibrary.simpleMessage("Book a Court"),
    "bookNow": MessageLookupByLibrary.simpleMessage("Book Now"),
    "booking": MessageLookupByLibrary.simpleMessage("Booking"),
    "bookingDetails": MessageLookupByLibrary.simpleMessage("Booking Details"),
    "bookingId": MessageLookupByLibrary.simpleMessage("Booking ID: "),
    "bookingNotAvailableYet": MessageLookupByLibrary.simpleMessage(
      "Booking Not Available yet",
    ),
    "bookingSuccessful": MessageLookupByLibrary.simpleMessage(
      "Booking successful",
    ),
    "bookings": MessageLookupByLibrary.simpleMessage("Bookings"),
    "camera": MessageLookupByLibrary.simpleMessage("Camera"),
    "cancel": MessageLookupByLibrary.simpleMessage("Cancel"),
    "cancelBooking": MessageLookupByLibrary.simpleMessage("Cancel Booking"),
    "cancelBookings": MessageLookupByLibrary.simpleMessage("Cancel Bookings"),
    "cancelChallenge": MessageLookupByLibrary.simpleMessage("Cancel Challenge"),
    "cantDeleteNotificationNotFound": MessageLookupByLibrary.simpleMessage(
      "Can\'t delete notification not found",
    ),
    "cantReadNotificationNotFound": MessageLookupByLibrary.simpleMessage(
      "Can\'t read notification not found",
    ),
    "cantUnreadNotificationNotFound": MessageLookupByLibrary.simpleMessage(
      "Can\'t unread notification not found",
    ),
    "challengeNotFound": MessageLookupByLibrary.simpleMessage(
      "Challenge not found",
    ),
    "challengeType": MessageLookupByLibrary.simpleMessage("Challenge Type"),
    "challengeYourFriendsCompeteTogetherAndnenjoyExclusiveMatches":
        MessageLookupByLibrary.simpleMessage(
          "Challenge your friends, compete together, and\\nenjoy exclusive matches!",
        ),
    "challenges": MessageLookupByLibrary.simpleMessage("Challenges"),
    "challengesNotAvailableYet": MessageLookupByLibrary.simpleMessage(
      "Challenges not available yet",
    ),
    "checkout": MessageLookupByLibrary.simpleMessage("Checkout"),
    "choosePaymentMethod": MessageLookupByLibrary.simpleMessage(
      "Choose Payment Method",
    ),
    "city": MessageLookupByLibrary.simpleMessage("City"),
    "codeCannotBeEmpty": MessageLookupByLibrary.simpleMessage(
      "Code cannot be empty",
    ),
    "competeProveYourSkills": MessageLookupByLibrary.simpleMessage(
      "Compete prove your skills.",
    ),
    "completeProfile": MessageLookupByLibrary.simpleMessage("Complete Profile"),
    "completed": MessageLookupByLibrary.simpleMessage("Completed"),
    "completedChallenges": MessageLookupByLibrary.simpleMessage(
      "Completed Challenges",
    ),
    "confirm": MessageLookupByLibrary.simpleMessage("Confirm"),
    "confirmPayment": MessageLookupByLibrary.simpleMessage("Confirm Payment"),
    "connectionErrorPleaseCheckYourNetwork":
        MessageLookupByLibrary.simpleMessage(
          "Connection error. Please check your network.",
        ),
    "contactListIsEmpty": MessageLookupByLibrary.simpleMessage(
      "Contact List is empty !",
    ),
    "contactsPermissionIsRequired": MessageLookupByLibrary.simpleMessage(
      "Contacts permission is required!",
    ),
    "continueToGoToTheHomeScreen": MessageLookupByLibrary.simpleMessage(
      "Continue to go to the home screen",
    ),
    "continues": MessageLookupByLibrary.simpleMessage("Continue"),
    "country": MessageLookupByLibrary.simpleMessage("Country"),
    "courtBooking": MessageLookupByLibrary.simpleMessage("Court Booking"),
    "courtSize": MessageLookupByLibrary.simpleMessage("Court Size"),
    "courts": MessageLookupByLibrary.simpleMessage("Courts"),
    "courtsNotAvailableYet": MessageLookupByLibrary.simpleMessage(
      "Courts not available yet",
    ),
    "courtsnavailableoblic": MessageLookupByLibrary.simpleMessage(
      "Courts Available",
    ),
    "createAChallenge": MessageLookupByLibrary.simpleMessage(
      "👉 Create a Challenge: ",
    ),
    "createChallengeBt": MessageLookupByLibrary.simpleMessage(
      "Create Challenge",
    ),
    "createdBy": MessageLookupByLibrary.simpleMessage("Created By"),
    "creditDebitCard": MessageLookupByLibrary.simpleMessage(
      "Credit & Debit Card",
    ),
    "creteAStrongPasswordItMustContain": MessageLookupByLibrary.simpleMessage(
      "Crete a strong password. It must contain",
    ),
    "cricket": MessageLookupByLibrary.simpleMessage("Cricket"),
    "data": MessageLookupByLibrary.simpleMessage("Data"),
    "date": MessageLookupByLibrary.simpleMessage("Date"),
    "deleteAccount": MessageLookupByLibrary.simpleMessage("Delete Account"),
    "deleteAll": MessageLookupByLibrary.simpleMessage("Delete All"),
    "description": MessageLookupByLibrary.simpleMessage("Description : "),
    "detectMyLocation": MessageLookupByLibrary.simpleMessage(
      "Detect my location",
    ),
    "didntReceiveACodeResend": MessageLookupByLibrary.simpleMessage(
      "Didn\'t receive a code? Resend",
    ),
    "doYouReallyWantToDeleteThisAccount": MessageLookupByLibrary.simpleMessage(
      "Do you really want to delete this account?",
    ),
    "doYouWantRecordedOrNot": MessageLookupByLibrary.simpleMessage(
      "Do you want recorded or not ?",
    ),
    "dontHaveAnAccountSignUp": MessageLookupByLibrary.simpleMessage(
      "Don\'t have an account? Sign Up",
    ),
    "editProfile": MessageLookupByLibrary.simpleMessage("Edit Profile"),
    "emailAddress": MessageLookupByLibrary.simpleMessage("Email Address"),
    "enableLocation": MessageLookupByLibrary.simpleMessage("Enable Location"),
    "english": MessageLookupByLibrary.simpleMessage("English"),
    "enjoyYourBooking": MessageLookupByLibrary.simpleMessage(
      "Enjoy your booking! ✅",
    ),
    "enter810DigitPhoneNumber": MessageLookupByLibrary.simpleMessage(
      "Enter 8-10 digit phone number",
    ),
    "enterCode": MessageLookupByLibrary.simpleMessage("Enter Code"),
    "enterInviteChallengeCode": MessageLookupByLibrary.simpleMessage(
      "Enter Invite Challenge Code",
    ),
    "enterMobileNumber": MessageLookupByLibrary.simpleMessage(
      "Enter Mobile Number",
    ),
    "enterOtp": MessageLookupByLibrary.simpleMessage("Enter OTP"),
    "enterPassword": MessageLookupByLibrary.simpleMessage("Enter Password"),
    "enterThe4digitCodeSentToYourPhone": MessageLookupByLibrary.simpleMessage(
      "Enter the 4-digit code sent to your phone",
    ),
    "enterYourEmail": MessageLookupByLibrary.simpleMessage("Enter Your Email"),
    "enterYourName": MessageLookupByLibrary.simpleMessage("Enter Your Name"),
    "error": MessageLookupByLibrary.simpleMessage("Error"),
    "errorPleaseEnterYourEmail": MessageLookupByLibrary.simpleMessage(
      "Error: Please enter your email",
    ),
    "errorPleaseEnterYourName": MessageLookupByLibrary.simpleMessage(
      "Error: Please enter your name",
    ),
    "errorPleaseSelectSkills": MessageLookupByLibrary.simpleMessage(
      "Error: Please select skills",
    ),
    "errorPleaseSelectSport": MessageLookupByLibrary.simpleMessage(
      "Error: Please select sport",
    ),
    "errorVerifyingOtpPleaseTryAgain": MessageLookupByLibrary.simpleMessage(
      "Error verifying OTP. Please try again.",
    ),
    "exit": MessageLookupByLibrary.simpleMessage("Exit"),
    "exitApp": MessageLookupByLibrary.simpleMessage("Exit App"),
    "facilities": MessageLookupByLibrary.simpleMessage("Facilities"),
    "facilitiesListing": MessageLookupByLibrary.simpleMessage(
      "Facilities Listing",
    ),
    "facilitiesNotAvailable": MessageLookupByLibrary.simpleMessage(
      "Facilities not available",
    ),
    "facilityDetails": MessageLookupByLibrary.simpleMessage("Facility Details"),
    "failedToApplyPromoCode": MessageLookupByLibrary.simpleMessage(
      "Failed to apply promo code.",
    ),
    "failedToBook": MessageLookupByLibrary.simpleMessage("Failed to book."),
    "failedToFetchUsers": MessageLookupByLibrary.simpleMessage(
      "Failed to fetch users",
    ),
    "failedToLoadAboutUs": MessageLookupByLibrary.simpleMessage(
      "Failed to load About us",
    ),
    "failedToLoadTermsConditions": MessageLookupByLibrary.simpleMessage(
      "Failed to load Terms & Conditions",
    ),
    "failedToSendOtpPleaseTryAgain": MessageLookupByLibrary.simpleMessage(
      "Failed to send OTP. Please try again.",
    ),
    "favoriteCourts": MessageLookupByLibrary.simpleMessage("Favorite Courts"),
    "favoriteCourtsNotAvailable": MessageLookupByLibrary.simpleMessage(
      "Favorite Courts Not Available",
    ),
    "favoriteSport": MessageLookupByLibrary.simpleMessage("Favorite Sport"),
    "feeds": MessageLookupByLibrary.simpleMessage("Feeds"),
    "fetchingCurrentLocation": MessageLookupByLibrary.simpleMessage(
      "Fetching Current Location...",
    ),
    "fillYourInformationBelowOrRegister": MessageLookupByLibrary.simpleMessage(
      "Fill your information below or register",
    ),
    "filter": MessageLookupByLibrary.simpleMessage("Filter"),
    "filterApply": MessageLookupByLibrary.simpleMessage("Filter Apply"),
    "filterResult": MessageLookupByLibrary.simpleMessage("Filter Result"),
    "findBookYourGameInSeconds": MessageLookupByLibrary.simpleMessage(
      "Find & Book Your Game in Seconds!",
    ),
    "football": MessageLookupByLibrary.simpleMessage("Football"),
    "forgetPassword": MessageLookupByLibrary.simpleMessage("Forget Password"),
    "forgotPassword": MessageLookupByLibrary.simpleMessage("Forgot Password?"),
    "found": MessageLookupByLibrary.simpleMessage("Found"),
    "friend": MessageLookupByLibrary.simpleMessage("Friend"),
    "friendListIsEmpty": MessageLookupByLibrary.simpleMessage(
      "Friend List Is Empty!",
    ),
    "from": MessageLookupByLibrary.simpleMessage("From "),
    "fullName": MessageLookupByLibrary.simpleMessage("Full Name"),
    "fullPaid": MessageLookupByLibrary.simpleMessage("Full Paid"),
    "gallery": MessageLookupByLibrary.simpleMessage("Gallery"),
    "getAlert": MessageLookupByLibrary.simpleMessage("Get Alert"),
    "getReadyToUnlockAWorldOf": MessageLookupByLibrary.simpleMessage(
      "Get ready to unlock a world of",
    ),
    "goToHome": MessageLookupByLibrary.simpleMessage("Go to Home"),
    "going": MessageLookupByLibrary.simpleMessage("going"),
    "googlePay": MessageLookupByLibrary.simpleMessage("Google Pay"),
    "greek": MessageLookupByLibrary.simpleMessage("Greek"),
    "hey": MessageLookupByLibrary.simpleMessage("Hey "),
    "hockey": MessageLookupByLibrary.simpleMessage("Hockey"),
    "home": MessageLookupByLibrary.simpleMessage("Home"),
    "iAgreeToTheTermsConditions": MessageLookupByLibrary.simpleMessage(
      "I agree to the Terms & Conditions",
    ),
    "inactive": MessageLookupByLibrary.simpleMessage("Inactive"),
    "interestedSports": MessageLookupByLibrary.simpleMessage(
      "Interested Sports",
    ),
    "invalidAmountPleaseTryAgainLater": MessageLookupByLibrary.simpleMessage(
      "Invalid Amount. Please try again later!",
    ),
    "invalidOtp": MessageLookupByLibrary.simpleMessage("Invalid Otp"),
    "invalidOtpPleaseTryAgain": MessageLookupByLibrary.simpleMessage(
      "Invalid OTP. Please try again.",
    ),
    "invalidPromoDataReceivedFromServer": MessageLookupByLibrary.simpleMessage(
      "Invalid promo data received from server.",
    ),
    "invalidSportSelection": MessageLookupByLibrary.simpleMessage(
      "Invalid sport selection.",
    ),
    "invalidTime": MessageLookupByLibrary.simpleMessage("Invalid time"),
    "inviteCode": MessageLookupByLibrary.simpleMessage("INVITE CODE: "),
    "inviteOthers": MessageLookupByLibrary.simpleMessage("Invite others. "),
    "joinAChallenge": MessageLookupByLibrary.simpleMessage(
      "👉 Join a Challenge: ",
    ),
    "joinAChallengeCompeteProveYourSkillsCreateAChallenge":
        MessageLookupByLibrary.simpleMessage(
          "👉Join a Challenge: Compete prove your skills. 👉Create a Challenge: Invite others. 👉Public or Private: Open to all or just your crew!",
        ),
    "joinChallenge": MessageLookupByLibrary.simpleMessage("Join Challenge"),
    "joinNow": MessageLookupByLibrary.simpleMessage("Join Now"),
    "joinPrivateChallengeByInvitingFriends":
        MessageLookupByLibrary.simpleMessage(
          "Join Private Challenge by Inviting Friends",
        ),
    "joinUs": MessageLookupByLibrary.simpleMessage("JOIN US"),
    "kratEasy": MessageLookupByLibrary.simpleMessage("Krat Easy"),
    "left": MessageLookupByLibrary.simpleMessage("Left"),
    "letsGetPlaying": MessageLookupByLibrary.simpleMessage(
      "Let’s get playing!",
    ),
    "level": MessageLookupByLibrary.simpleMessage("Level: "),
    "listOfFacilities": MessageLookupByLibrary.simpleMessage(
      "List of Facilities",
    ),
    "loading": MessageLookupByLibrary.simpleMessage("Loading..."),
    "locationNotAvailable": MessageLookupByLibrary.simpleMessage(
      "Location not available",
    ),
    "locationNotFetchedPleaseTryAgain": MessageLookupByLibrary.simpleMessage(
      "Location not fetched. Please try again.",
    ),
    "locationPermissionDenied": MessageLookupByLibrary.simpleMessage(
      "Location permission denied.",
    ),
    "locationPermissionNotGranted": MessageLookupByLibrary.simpleMessage(
      "Location permission not granted.",
    ),
    "locationPermissionPermanentlyDeniedPleaseEnableItFromSettings":
        MessageLookupByLibrary.simpleMessage(
          "Location permission permanently denied. Please enable it from settings.",
        ),
    "locationPermissionsArePermanentlyDeniedPleaseEnableThemInSettings":
        MessageLookupByLibrary.simpleMessage(
          "Location permissions are permanently denied. Please enable them in settings.",
        ),
    "locationServicesAreDisabled": MessageLookupByLibrary.simpleMessage(
      "Location services are disabled.",
    ),
    "locationServicesAreDisabledPleaseTurnOnGpsToContinue":
        MessageLookupByLibrary.simpleMessage(
          "Location services are disabled. Please turn on GPS to continue.",
        ),
    "logIn": MessageLookupByLibrary.simpleMessage("Log in"),
    "login": MessageLookupByLibrary.simpleMessage("Login"),
    "logout": MessageLookupByLibrary.simpleMessage("Logout"),
    "matchType": MessageLookupByLibrary.simpleMessage("Match Type: "),
    "mate": MessageLookupByLibrary.simpleMessage("Mate"),
    "miles": MessageLookupByLibrary.simpleMessage("miles"),
    "minTimeToBook": MessageLookupByLibrary.simpleMessage(
      "Min. Time to Book: ",
    ),
    "mobileNumber": MessageLookupByLibrary.simpleMessage("Mobile Number"),
    "modify": MessageLookupByLibrary.simpleMessage("Modify"),
    "modifyBooking": MessageLookupByLibrary.simpleMessage("Modify Booking"),
    "morePaymentsOptions": MessageLookupByLibrary.simpleMessage(
      "More Payments Options",
    ),
    "myAccount": MessageLookupByLibrary.simpleMessage("My Account"),
    "myBooking": MessageLookupByLibrary.simpleMessage("My Booking"),
    "myFavouritePlayers": MessageLookupByLibrary.simpleMessage(
      "My Favourite Players",
    ),
    "na": MessageLookupByLibrary.simpleMessage("N/A"),
    "nearbyCourts": MessageLookupByLibrary.simpleMessage("Nearby Courts"),
    "no": MessageLookupByLibrary.simpleMessage("No"),
    "noAddressFound": MessageLookupByLibrary.simpleMessage("No address found."),
    "noChallengesAvailable": MessageLookupByLibrary.simpleMessage(
      "No Challenges Available",
    ),
    "noCourtsAvailable": MessageLookupByLibrary.simpleMessage(
      "No courts available.",
    ),
    "noDataAvailable": MessageLookupByLibrary.simpleMessage(
      "No data available",
    ),
    "noDataFound": MessageLookupByLibrary.simpleMessage("No data found."),
    "noFavoritePlayerDataFound": MessageLookupByLibrary.simpleMessage(
      "No favorite player data found.",
    ),
    "noFavouritePlayersFound": MessageLookupByLibrary.simpleMessage(
      "No favourite players found!",
    ),
    "noNotificationsAvailable": MessageLookupByLibrary.simpleMessage(
      "No notifications available",
    ),
    "noNumber": MessageLookupByLibrary.simpleMessage("No Number"),
    "noSlotsAvailableAtThisTime": MessageLookupByLibrary.simpleMessage(
      "No slots available at this time.",
    ),
    "noTransactionsFound": MessageLookupByLibrary.simpleMessage(
      "No transactions found.",
    ),
    "noteHeader": MessageLookupByLibrary.simpleMessage("Note: "),
    "notifications": MessageLookupByLibrary.simpleMessage("Notifications"),
    "numberOfPlayer": MessageLookupByLibrary.simpleMessage("Number of Player"),
    "openForAnyoneToJoin": MessageLookupByLibrary.simpleMessage(
      "Open for anyone to join.",
    ),
    "openSettings": MessageLookupByLibrary.simpleMessage("Open Settings"),
    "openToAllOrJustYourCrew": MessageLookupByLibrary.simpleMessage(
      "Open to all or just your crew!",
    ),
    "or": MessageLookupByLibrary.simpleMessage("OR"),
    "otpRequired": MessageLookupByLibrary.simpleMessage("Otp Required"),
    "outOf": MessageLookupByLibrary.simpleMessage("Out of "),
    "paid": MessageLookupByLibrary.simpleMessage("Paid"),
    "paidAmount": MessageLookupByLibrary.simpleMessage("Paid Amount"),
    "password": MessageLookupByLibrary.simpleMessage("Password"),
    "payAmount": MessageLookupByLibrary.simpleMessage("Pay Amount"),
    "paymentSuccessful": MessageLookupByLibrary.simpleMessage(
      "Payment Successful",
    ),
    "phoneNumber": MessageLookupByLibrary.simpleMessage("Phone Number"),
    "phoneNumberMustBe810Digits": MessageLookupByLibrary.simpleMessage(
      "Phone number must be 8-10 digits",
    ),
    "playAgain": MessageLookupByLibrary.simpleMessage("Play Again"),
    "playerGoing": MessageLookupByLibrary.simpleMessage("Player going"),
    "players": MessageLookupByLibrary.simpleMessage("Players"),
    "pleaseAcceptTheTermsConditionsToContinue":
        MessageLookupByLibrary.simpleMessage(
          "Please accept the Terms & Conditions to continue.",
        ),
    "pleaseAddFriendsToSplitTheCost": MessageLookupByLibrary.simpleMessage(
      "Please add friends to split the cost.",
    ),
    "pleaseEnterPromoCode": MessageLookupByLibrary.simpleMessage(
      "Please enter promo code",
    ),
    "pleaseEnterTheOtp": MessageLookupByLibrary.simpleMessage(
      "Please enter the OTP.",
    ),
    "pleaseEnterYourPhoneNumber": MessageLookupByLibrary.simpleMessage(
      "Please enter your phone number",
    ),
    "pleaseEnterYourRegisteredNumberTo": MessageLookupByLibrary.simpleMessage(
      "Please Enter your registered number to",
    ),
    "pleaseSelectADate": MessageLookupByLibrary.simpleMessage(
      "Please select a date",
    ),
    "pleaseSelectAFacilityFirst": MessageLookupByLibrary.simpleMessage(
      "Please select a Facility first",
    ),
    "pleaseSelectAPaymentMethod": MessageLookupByLibrary.simpleMessage(
      "Please select a payment method",
    ),
    "pleaseSelectASlotToContinue": MessageLookupByLibrary.simpleMessage(
      "Please select a slot to continue.",
    ),
    "pleaseSelectASortingOption": MessageLookupByLibrary.simpleMessage(
      "Please select a sorting option",
    ),
    "pleaseSelectASport": MessageLookupByLibrary.simpleMessage(
      "Please select a sport",
    ),
    "pleaseSelectASportFirst": MessageLookupByLibrary.simpleMessage(
      "Please select a sport first",
    ),
    "pleaseSelectATime": MessageLookupByLibrary.simpleMessage(
      "Please select a time",
    ),
    "pleaseSelectAValidLocation": MessageLookupByLibrary.simpleMessage(
      "Please select a valid location.",
    ),
    "pleaseSelectAtLeastOneAmenity": MessageLookupByLibrary.simpleMessage(
      "Please select at least one amenity",
    ),
    "pleaseSelectAtLeastOneSlotToContinue":
        MessageLookupByLibrary.simpleMessage(
          "Please select at least one slot to continue.",
        ),
    "pleaseSelectAtLeastOneTimeSlot": MessageLookupByLibrary.simpleMessage(
      "Please select at least one time slot",
    ),
    "pleaseSelectSkillLevel": MessageLookupByLibrary.simpleMessage(
      "Please select skill level",
    ),
    "pleaseSelectSlotsInOrder": MessageLookupByLibrary.simpleMessage(
      "Please select slots in order.",
    ),
    "pleaseSelectSlotsInSequence": MessageLookupByLibrary.simpleMessage(
      "Please select slots in sequence.",
    ),
    "pleaseSelectTimeSlotsInSequence": MessageLookupByLibrary.simpleMessage(
      "Please select time slots in sequence.",
    ),
    "pleaseTryAgainLater": MessageLookupByLibrary.simpleMessage(
      "Please try again later!",
    ),
    "possibilitiessignIntoYourAccountNow": MessageLookupByLibrary.simpleMessage(
      "possibilities-Sign into your account now",
    ),
    "priceMinMax": MessageLookupByLibrary.simpleMessage("Price (Min & Max)"),
    "privacyPolicy": MessageLookupByLibrary.simpleMessage("Privacy Policy"),
    "private": MessageLookupByLibrary.simpleMessage("Private"),
    "profileUpdateSuccessfully": MessageLookupByLibrary.simpleMessage(
      "Profile Update Successfully",
    ),
    "promoCode": MessageLookupByLibrary.simpleMessage("Promo Code"),
    "public": MessageLookupByLibrary.simpleMessage("Public"),
    "publicOrPrivate": MessageLookupByLibrary.simpleMessage(
      "👉  Public or Private: ",
    ),
    "quickRebook": MessageLookupByLibrary.simpleMessage("Quick Rebook"),
    "radiusDistance": MessageLookupByLibrary.simpleMessage("Radius (Distance)"),
    "rateTheCourt": MessageLookupByLibrary.simpleMessage("Rate the Court"),
    "rating": MessageLookupByLibrary.simpleMessage("Rating"),
    "readAllNew": MessageLookupByLibrary.simpleMessage("Read All"),
    "readall": MessageLookupByLibrary.simpleMessage("readAll"),
    "rebook": MessageLookupByLibrary.simpleMessage("Rebook"),
    "receiveAVerificationCode": MessageLookupByLibrary.simpleMessage(
      "receive a verification code",
    ),
    "reenterPassword": MessageLookupByLibrary.simpleMessage(
      "Re-Enter Password",
    ),
    "refundMinusASmallConvenienceFee": MessageLookupByLibrary.simpleMessage(
      "Refund minus a small convenience fee",
    ),
    "refunded": MessageLookupByLibrary.simpleMessage("Refunded"),
    "rememberMe": MessageLookupByLibrary.simpleMessage("Remember Me"),
    "remove": MessageLookupByLibrary.simpleMessage("Remove"),
    "resendIn": MessageLookupByLibrary.simpleMessage("Resend in"),
    "resendOtp": MessageLookupByLibrary.simpleMessage("Resend OTP"),
    "resendOtpIn50s": MessageLookupByLibrary.simpleMessage("Resend OTP in 50s"),
    "resetPassword": MessageLookupByLibrary.simpleMessage("Reset Password"),
    "review": MessageLookupByLibrary.simpleMessage("Review"),
    "reviews": MessageLookupByLibrary.simpleMessage("Reviews"),
    "rules": MessageLookupByLibrary.simpleMessage("Rules : "),
    "s": MessageLookupByLibrary.simpleMessage("s"),
    "saveProfile": MessageLookupByLibrary.simpleMessage("Save Profile"),
    "searchByFacilityNameOrCourtName": MessageLookupByLibrary.simpleMessage(
      "Search by Facility Name or Court Name",
    ),
    "searchChallenges": MessageLookupByLibrary.simpleMessage(
      "Search Challenges",
    ),
    "searchContact": MessageLookupByLibrary.simpleMessage("Search Contact"),
    "searchCourts": MessageLookupByLibrary.simpleMessage("Search Courts"),
    "searchFacility": MessageLookupByLibrary.simpleMessage("Search Facility"),
    "searchPlace": MessageLookupByLibrary.simpleMessage("Search place..."),
    "seeAll": MessageLookupByLibrary.simpleMessage("See All"),
    "select": MessageLookupByLibrary.simpleMessage("Select"),
    "selectDate": MessageLookupByLibrary.simpleMessage("Select Date"),
    "selectFacility": MessageLookupByLibrary.simpleMessage("Select Facility"),
    "selectLanguage": MessageLookupByLibrary.simpleMessage("Select Language"),
    "selectLocation": MessageLookupByLibrary.simpleMessage("Select Location"),
    "selectLocationManually": MessageLookupByLibrary.simpleMessage(
      "Select Location Manually",
    ),
    "selectSpecificUsersToChallenge": MessageLookupByLibrary.simpleMessage(
      "Select specific users to challenge.",
    ),
    "selectSport": MessageLookupByLibrary.simpleMessage("Select Sport"),
    "selectSports": MessageLookupByLibrary.simpleMessage("Select Sports"),
    "selectSportsName": MessageLookupByLibrary.simpleMessage(
      "Select Sports Name",
    ),
    "selectYourSportChooseALocationPickADateTime":
        MessageLookupByLibrary.simpleMessage(
          "👉 Select your sport, 👉 Choose a location, 👉 Pick a date & time 👉 Confirm & play!",
        ),
    "sendOtp": MessageLookupByLibrary.simpleMessage("SEND OTP"),
    "setPassword": MessageLookupByLibrary.simpleMessage("Set Password"),
    "setYourLocationToStartExploringnSportsCourtsAroundYou":
        MessageLookupByLibrary.simpleMessage(
          "Set your location to start exploring sports courts around you.",
        ),
    "share": MessageLookupByLibrary.simpleMessage("Share"),
    "sharePaymentLink": MessageLookupByLibrary.simpleMessage(
      "Share Payment Link",
    ),
    "signUp": MessageLookupByLibrary.simpleMessage("Sign up"),
    "skillLevel": MessageLookupByLibrary.simpleMessage("Skill Level"),
    "skillSet": MessageLookupByLibrary.simpleMessage("Skill Set"),
    "slotNotAvailable": MessageLookupByLibrary.simpleMessage(
      "Slot not available.",
    ),
    "slots": MessageLookupByLibrary.simpleMessage("Slots"),
    "somethingWentWrong": MessageLookupByLibrary.simpleMessage(
      "Something went wrong.",
    ),
    "somethingWentWrongGetbookingdetails": MessageLookupByLibrary.simpleMessage(
      "Something went wrong (getBookingDetails)",
    ),
    "somethingWentWrongGetfacilitiesdata": MessageLookupByLibrary.simpleMessage(
      "Something went wrong (getFacilitiesData)",
    ),
    "somethingWentWrongGetfavouriteplayerdata":
        MessageLookupByLibrary.simpleMessage(
          "Something went wrong (getFavouritePlayerData)",
        ),
    "somethingWentWrongGetprofiledataapi": MessageLookupByLibrary.simpleMessage(
      "Something went wrong (getProfileDataApi)",
    ),
    "somethingWentWrongGetslots": MessageLookupByLibrary.simpleMessage(
      "Something went wrong (getSlots)",
    ),
    "somethingWentWrongPleaseTryAgain": MessageLookupByLibrary.simpleMessage(
      "Something went wrong. Please try again.",
    ),
    "somethingWentWrongWhileFetchingNotifications":
        MessageLookupByLibrary.simpleMessage(
          "Something went wrong while fetching notifications.",
        ),
    "somethingsWentWrongPleaseTryAgainLater":
        MessageLookupByLibrary.simpleMessage(
          "Somethings went wrong. Please try again later!",
        ),
    "somethingsWentWrongcreatechallenge": MessageLookupByLibrary.simpleMessage(
      "Somethings went wrong(createChallenge)",
    ),
    "somethingsWentWrongdeleteaccount": MessageLookupByLibrary.simpleMessage(
      "Somethings went wrong(deleteAccount)",
    ),
    "somethingsWentWrongdeletenotification":
        MessageLookupByLibrary.simpleMessage(
          "Somethings went Wrong(deleteNotification)",
        ),
    "somethingsWentWrongeditMyAccount": MessageLookupByLibrary.simpleMessage(
      "Somethings went wrong(Edit My Account)",
    ),
    "somethingsWentWrongfetchchallenges": MessageLookupByLibrary.simpleMessage(
      "Somethings went Wrong(fetchChallenges)",
    ),
    "somethingsWentWronggetbookingdetails":
        MessageLookupByLibrary.simpleMessage(
          "Somethings went Wrong(getBookingDetails)",
        ),
    "somethingsWentWronggetchallengesdetails":
        MessageLookupByLibrary.simpleMessage(
          "Somethings went Wrong(getChallengesDetails)",
        ),
    "somethingsWentWronggetfacilitiesdata":
        MessageLookupByLibrary.simpleMessage(
          "Somethings went Wrong(getFacilitiesData)",
        ),
    "somethingsWentWronggetfavouritelistdata":
        MessageLookupByLibrary.simpleMessage(
          "Somethings went Wrong(getFavouriteListData)",
        ),
    "somethingsWentWronggethomedata": MessageLookupByLibrary.simpleMessage(
      "Somethings went Wrong(getHomeData)",
    ),
    "somethingsWentWronggetmybookingdata": MessageLookupByLibrary.simpleMessage(
      "Somethings went Wrong(getMyBookingData)",
    ),
    "somethingsWentWronggetmychallengedata":
        MessageLookupByLibrary.simpleMessage(
          "Somethings went Wrong(getMyChallengeData)",
        ),
    "somethingsWentWronggetprofiledataapi":
        MessageLookupByLibrary.simpleMessage(
          "Somethings went Wrong(getProfileDataApi)",
        ),
    "somethingsWentWrongnotificationtoggle":
        MessageLookupByLibrary.simpleMessage(
          "Somethings went wrong(notificationToggle)",
        ),
    "somethingsWentWrongtypeChallenge": MessageLookupByLibrary.simpleMessage(
      "Somethings went Wrong(Type Challenge)",
    ),
    "somethingsWentWrongunreadnotification":
        MessageLookupByLibrary.simpleMessage(
          "Somethings went Wrong(unreadNotification)",
        ),
    "sort": MessageLookupByLibrary.simpleMessage("Sort"),
    "split": MessageLookupByLibrary.simpleMessage("Split"),
    "splitPaymentWithFriends": MessageLookupByLibrary.simpleMessage(
      "Split payment with friends",
    ),
    "started": MessageLookupByLibrary.simpleMessage("Started"),
    "staySecure": MessageLookupByLibrary.simpleMessage("Stay Secure!"),
    "submit": MessageLookupByLibrary.simpleMessage("Submit"),
    "successful": MessageLookupByLibrary.simpleMessage("Successful"),
    "successfullyChange": MessageLookupByLibrary.simpleMessage(
      "Successfully Change",
    ),
    "successfullyCreated": MessageLookupByLibrary.simpleMessage(
      "Successfully Created",
    ),
    "takeOnTheChallenge": MessageLookupByLibrary.simpleMessage(
      "Take on the Challenge! 💪🏆",
    ),
    "tennis": MessageLookupByLibrary.simpleMessage("Tennis"),
    "termsAndConditions": MessageLookupByLibrary.simpleMessage(
      "Terms and Conditions",
    ),
    "termsConditions": MessageLookupByLibrary.simpleMessage(
      "Terms & Conditions",
    ),
    "termsOfService": MessageLookupByLibrary.simpleMessage("Terms of Service"),
    "time": MessageLookupByLibrary.simpleMessage("Time"),
    "totalAmount": MessageLookupByLibrary.simpleMessage("Total Amount"),
    "transaction": MessageLookupByLibrary.simpleMessage("Transaction"),
    "transactionDetails": MessageLookupByLibrary.simpleMessage(
      "Transaction Details",
    ),
    "transactionId": MessageLookupByLibrary.simpleMessage("Transaction ID "),
    "transactionInfo": MessageLookupByLibrary.simpleMessage(
      "Transaction info: ",
    ),
    "transactions": MessageLookupByLibrary.simpleMessage("Transactions"),
    "typeOfBooking": MessageLookupByLibrary.simpleMessage("Type of Booking: "),
    "unableToFetchBookingId": MessageLookupByLibrary.simpleMessage(
      "Unable to fetch booking id",
    ),
    "unexpectedErrorOccurred": MessageLookupByLibrary.simpleMessage(
      "Unexpected error occurred.",
    ),
    "unexpectedResponseFormatFromServer": MessageLookupByLibrary.simpleMessage(
      "Unexpected response format from server.",
    ),
    "unreadAll": MessageLookupByLibrary.simpleMessage("Unread All"),
    "upcoming": MessageLookupByLibrary.simpleMessage("Upcoming"),
    "upcomingBookings": MessageLookupByLibrary.simpleMessage(
      "Upcoming Bookings",
    ),
    "upcomingBookingsNotFound": MessageLookupByLibrary.simpleMessage(
      "Upcoming Bookings Not Found !!",
    ),
    "verification": MessageLookupByLibrary.simpleMessage("Verification"),
    "verificationCode": MessageLookupByLibrary.simpleMessage(
      "Verification Code",
    ),
    "verify": MessageLookupByLibrary.simpleMessage("Verify"),
    "verifyOtp": MessageLookupByLibrary.simpleMessage("Verify OTP"),
    "verifyYourPhoneNumberWithOtp": MessageLookupByLibrary.simpleMessage(
      "Please verify your mobile number using the OTP.",
    ),
    "viewAll": MessageLookupByLibrary.simpleMessage("View All"),
    "viewBookings": MessageLookupByLibrary.simpleMessage("View Bookings"),
    "viewChallenge": MessageLookupByLibrary.simpleMessage("View Challenge"),
    "viewCourtDetails": MessageLookupByLibrary.simpleMessage(
      "View Court Details",
    ),
    "viewDetail": MessageLookupByLibrary.simpleMessage("View Detail"),
    "wallet": MessageLookupByLibrary.simpleMessage("Wallet"),
    "weHaveSuccessfullySendTheQrCodeToYourEmailuse":
        MessageLookupByLibrary.simpleMessage(
          "We have successfully send the QR code to your email.Use it for your entry",
        ),
    "welcomeEasybooking": MessageLookupByLibrary.simpleMessage(
      "Welcome & Easy📍Booking",
    ),
    "welcomeTo": MessageLookupByLibrary.simpleMessage("Welcome to"),
    "whatDoYouWantToPlay": MessageLookupByLibrary.simpleMessage(
      "What do you want to play?",
    ),
    "whatSportDoYouWantToPlay": MessageLookupByLibrary.simpleMessage(
      "What sport do you want to play?",
    ),
    "whichTime": MessageLookupByLibrary.simpleMessage("Which Time"),
    "wholeCourtBooking": MessageLookupByLibrary.simpleMessage(
      "Whole Court Booking",
    ),
    "withYourAccount": MessageLookupByLibrary.simpleMessage(
      "with your account.",
    ),
    "writeTheComment": MessageLookupByLibrary.simpleMessage(
      "Write the comment",
    ),
    "yesConfirm": MessageLookupByLibrary.simpleMessage("Yes, Confirm"),
    "youCanOnlyDeselectTheFirstOrLastSlot":
        MessageLookupByLibrary.simpleMessage(
          "You can only deselect the first or last slot.",
        ),
    "youCanOnlyDeselectTheStartOrEndSlot": MessageLookupByLibrary.simpleMessage(
      "You can only deselect the start or end slot.",
    ),
    "yourAccount": MessageLookupByLibrary.simpleMessage("Your Account"),
    "yourAccountSuccessfullyCreatedClick": MessageLookupByLibrary.simpleMessage(
      "Your account successfully created! Click",
    ),
    "yourNewPasswordIsNowActive": MessageLookupByLibrary.simpleMessage(
      "Your new password is now active.",
    ),
    "yourSportsCommunityApp": MessageLookupByLibrary.simpleMessage(
      "Your Sports Community App",
    ),
    "yourTransactionIsComplete": MessageLookupByLibrary.simpleMessage(
      "Your transaction is complete.",
    ),
    "youreAlmostThere": MessageLookupByLibrary.simpleMessage(
      "You’re Almost There!",
    ),
  };
}
