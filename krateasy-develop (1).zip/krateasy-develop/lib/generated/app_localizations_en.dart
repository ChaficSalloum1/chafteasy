// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get joinNow => 'Join Now';

  @override
  String get verificationCode => 'Verification Code';

  @override
  String get enterThe4digitCodeSentToYourPhone =>
      'Enter the 4-digit code sent to your phone';

  @override
  String get didntReceiveACodeResend => 'Didn\'t receive a code? Resend';

  @override
  String get resendOtpIn50s => 'Resend OTP in 50s';

  @override
  String get verification => 'Verification';

  @override
  String get joinPrivateChallengeByInvitingFriends =>
      'Join Private Challenge by Inviting Friends';

  @override
  String get accountDeleteSuccessfully => 'Account Delete Successfully';

  @override
  String get somethingsWentWrongdeleteaccount =>
      'Somethings went wrong(deleteAccount)';

  @override
  String get somethingsWentWrongnotificationtoggle =>
      'Somethings went wrong(notificationToggle)';

  @override
  String get setPassword => 'Set Password';

  @override
  String get creteAStrongPasswordItMustContain =>
      'Crete a strong password. It must contain';

  @override
  String get atLeast6CharactersAnd1SpecialSymbol =>
      'at least 6 characters and 1 special symbol';

  @override
  String get resetPassword => 'Reset Password';

  @override
  String get atLeast9CharactersWithUppercase =>
      'At least 9 characters, with uppercase';

  @override
  String get andLowercaseLetters => 'and lowercase letters';

  @override
  String get password => 'Password';

  @override
  String get successfullyChange => 'Successfully Change';

  @override
  String get yourNewPasswordIsNowActive => 'Your new password is now active.';

  @override
  String get staySecure => 'Stay Secure!';

  @override
  String get yourAccount => 'Your Account';

  @override
  String get successfullyCreated => 'Successfully Created';

  @override
  String get yourAccountSuccessfullyCreatedClick =>
      'Your account successfully created! Click';

  @override
  String get continueToGoToTheHomeScreen => 'Continue to go to the home screen';

  @override
  String get welcomeEasybooking => 'Welcome & Easy📍Booking';

  @override
  String get takeOnTheChallenge => 'Take on the Challenge! 💪🏆';

  @override
  String get findBookYourGameInSeconds => 'Find & Book Your Game in Seconds!';

  @override
  String get joinAChallengeCompeteProveYourSkillsCreateAChallenge =>
      '👉Join a Challenge: Compete prove your skills. 👉Create a Challenge: Invite others. 👉Public or Private: Open to all or just your crew!';

  @override
  String get selectYourSportChooseALocationPickADateTime =>
      '👉 Select your sport, 👉 Choose a location, 👉 Pick a date & time 👉 Confirm & play!';

  @override
  String get assetslogopng => 'assets/logo.png';

  @override
  String get login => 'Login';

  @override
  String get getReadyToUnlockAWorldOf => 'Get ready to unlock a world of';

  @override
  String get possibilitiessignIntoYourAccountNow =>
      'possibilities-Sign into your account now';

  @override
  String get forgetPassword => 'Forget Password';

  @override
  String get pleaseEnterYourRegisteredNumberTo =>
      'Please Enter your registered number to';

  @override
  String get receiveAVerificationCode => 'receive a verification code';

  @override
  String get mate => 'Mate';

  @override
  String get upcoming => 'upcoming';

  @override
  String get completeProfile => 'Complete Profile';

  @override
  String get fullName => 'Full Name';

  @override
  String get emailAddress => 'Email Address';

  @override
  String get phoneNumber => 'Phone Number';

  @override
  String get selectSportsName => 'Select Sports Name';

  @override
  String get submit => 'Submit';

  @override
  String get fillYourInformationBelowOrRegister =>
      'Fill your information below or register';

  @override
  String get withYourAccount => 'with your account.';

  @override
  String get badminton => 'Badminton';

  @override
  String get hockey => 'Hockey';

  @override
  String get cricket => 'Cricket';

  @override
  String get tennis => 'Tennis';

  @override
  String get basketball => 'Basketball';

  @override
  String get football => 'Football';

  @override
  String get failedToLoadTermsConditions => 'Failed to load Terms & Conditions';

  @override
  String get somethingWentWrongPleaseTryAgain =>
      'Something went wrong. Please try again.';

  @override
  String get failedToLoadAboutUs => 'Failed to load About us';

  @override
  String get somethingsWentWronggetmybookingdata =>
      'Somethings went Wrong(getMyBookingData)';

  @override
  String get somethingsWentWronggetfavouritelistdata =>
      'Somethings went Wrong(getFavouriteListData)';

  @override
  String get somethingsWentWronggetmychallengedata =>
      'Somethings went Wrong(getMyChallengeData)';

  @override
  String get somethingsWentWrongtypeChallenge =>
      'Somethings went Wrong(Type Challenge)';

  @override
  String get interestedSports => 'Interested Sports';

  @override
  String get somethingWentWrongGetprofiledataapi =>
      'Something went wrong (getProfileDataApi)';

  @override
  String get errorPleaseSelectSport => 'Error: Please select sport';

  @override
  String get profileUpdateSuccessfully => 'Profile Update Successfully';

  @override
  String get somethingsWentWrongeditMyAccount =>
      'Somethings went wrong(Edit My Account)';

  @override
  String get favoriteSport => 'Favorite Sport';

  @override
  String get somethingsWentWronggetprofiledataapi =>
      'Somethings went Wrong(getProfileDataApi)';

  @override
  String get paymentSuccessful => 'Payment Successful';

  @override
  String get somethingsWentWrongfetchchallenges =>
      'Somethings went Wrong(fetchChallenges)';

  @override
  String get somethingsWentWronggetchallengesdetails =>
      'Somethings went Wrong(getChallengesDetails)';

  @override
  String get yourTransactionIsComplete => 'Your transaction is complete.';

  @override
  String get enjoyYourBooking => 'Enjoy your booking! ✅';

  @override
  String get youCanOnlyDeselectTheStartOrEndSlot =>
      'You can only deselect the start or end slot.';

  @override
  String get pleaseSelectSlotsInSequence => 'Please select slots in sequence.';

  @override
  String get contactsPermissionIsRequired => 'Contacts permission is required!';

  @override
  String get bookingSuccessful => 'Booking successful';

  @override
  String get unexpectedErrorOccurred => 'Unexpected error occurred.';

  @override
  String get somethingWentWrongGetslots => 'Something went wrong (getSlots)';

  @override
  String get invalidOtpPleaseTryAgain => 'Invalid OTP. Please try again.';

  @override
  String get errorVerifyingOtpPleaseTryAgain =>
      'Error verifying OTP. Please try again.';

  @override
  String get anErrorOccurredPleaseTryAgain =>
      'An error occurred. Please try again.';

  @override
  String get invalidPromoDataReceivedFromServer =>
      'Invalid promo data received from server.';

  @override
  String get anUnexpectedErrorOccurredPleaseTryAgain =>
      'An unexpected error occurred. Please try again.';

  @override
  String get connectionErrorPleaseCheckYourNetwork =>
      'Connection error. Please check your network.';

  @override
  String get failedToBook => 'Failed to book.';

  @override
  String get pleaseEnterTheOtp => 'Please enter the OTP.';

  @override
  String get unexpectedResponseFormatFromServer =>
      'Unexpected response format from server.';

  @override
  String get failedToApplyPromoCode => 'Failed to apply promo code.';

  @override
  String get locationServicesAreDisabled => 'Location services are disabled.';

  @override
  String get locationPermissionDenied => 'Location permission denied.';

  @override
  String get locationPermissionsArePermanentlyDeniedPleaseEnableThemInSettings =>
      'Location permissions are permanently denied. Please enable them in settings.';

  @override
  String get noAddressFound => 'No address found.';

  @override
  String get locationPermissionPermanentlyDeniedPleaseEnableItFromSettings =>
      'Location permission permanently denied. Please enable it from settings.';

  @override
  String get noCourtsAvailable => 'No courts available.';

  @override
  String get noSlotsAvailableAtThisTime => 'No slots available at this time.';

  @override
  String get somethingWentWrong => 'Something went wrong.';

  @override
  String get pleaseSelectTimeSlotsInSequence =>
      'Please select time slots in sequence.';

  @override
  String get failedToFetchUsers => 'Failed to fetch users';

  @override
  String get somethingWentWrongWhileFetchingNotifications =>
      'Something went wrong while fetching notifications.';

  @override
  String get somethingsWentWrongunreadnotification =>
      'Somethings went Wrong(unreadNotification)';

  @override
  String get somethingsWentWrongdeletenotification =>
      'Somethings went Wrong(deleteNotification)';

  @override
  String get noFavoritePlayerDataFound => 'No favorite player data found.';

  @override
  String get somethingWentWrongGetfavouriteplayerdata =>
      'Something went wrong (getFavouritePlayerData)';

  @override
  String get somethingsWentWronggethomedata =>
      'Somethings went Wrong(getHomeData)';

  @override
  String get somethingsWentWronggetbookingdetails =>
      'Somethings went Wrong(getBookingDetails)';

  @override
  String get somethingWentWrongGetbookingdetails =>
      'Something went wrong (getBookingDetails)';

  @override
  String get somethingsWentWrongPleaseTryAgainLater =>
      'Somethings went wrong. Please try again later!';

  @override
  String get codeCannotBeEmpty => 'Code cannot be empty';

  @override
  String get somethingWentWrongGetfacilitiesdata =>
      'Something went wrong (getFacilitiesData)';

  @override
  String get somethingsWentWronggetfacilitiesdata =>
      'Somethings went Wrong(getFacilitiesData)';

  @override
  String get anErrorOccurredWhileFetchingChallengeFacilitiesPleaseTryAgain =>
      'An error occurred while fetching challenge facilities. Please try again later.';

  @override
  String get pleaseSelectASportFirst => 'Please select a sport first';

  @override
  String get pleaseSelectAFacilityFirst => 'Please select a Facility first';

  @override
  String get invalidAmountPleaseTryAgainLater =>
      'Invalid Amount. Please try again later!';

  @override
  String get somethingsWentWrongcreatechallenge =>
      'Somethings went wrong(createChallenge)';

  @override
  String get pleaseSelectSlotsInOrder => 'Please select slots in order.';

  @override
  String get youCanOnlyDeselectTheFirstOrLastSlot =>
      'You can only deselect the first or last slot.';

  @override
  String get started => 'Started';

  @override
  String get invalidTime => 'Invalid time';

  @override
  String get availableChallenges => 'Available Challenges';

  @override
  String get challengesNotAvailableYet => 'Challenges not available yet';

  @override
  String get availableNearbyCourts => 'Available Nearby Courts';

  @override
  String get courtsNotAvailableYet => 'Courts not available yet';

  @override
  String get pleaseTryAgainLater => 'Please try again later!';

  @override
  String get upcomingBookings => 'Upcoming Bookings';

  @override
  String get upcomingBookingsNotFound => 'Upcoming Bookings Not Found !!';

  @override
  String get typeOfBooking => 'Type of Booking: ';

  @override
  String get wholeCourtBooking => 'Whole Court Booking';

  @override
  String get areYouSure => 'Are you sure ?';

  @override
  String get areYouSureYouWantToCancelThisBookingIf =>
      'Are you sure you want to cancel this booking? If yes, please press the confirm button. We will deduct the platform fee, and the remaining amount will be transferred to your wallet. Thank you.';

  @override
  String get yesConfirm => 'Yes, Confirm';

  @override
  String get cancel => 'Cancel';

  @override
  String get modify => 'Modify';

  @override
  String get viewBookings => 'View Bookings';

  @override
  String get hey => 'Hey ';

  @override
  String get loading => 'Loading...';

  @override
  String get na => 'N/A';

  @override
  String get getAlert => 'Get Alert';

  @override
  String get home => 'Home';

  @override
  String get myBooking => 'My Booking';

  @override
  String get facilities => 'Facilities';

  @override
  String get challenges => 'Challenges';

  @override
  String get notifications => 'Notifications';

  @override
  String get filter => 'Filter';

  @override
  String get selectSport => 'Select Sport';

  @override
  String get pleaseSelectASport => 'Please select a sport';

  @override
  String get date => 'Date';

  @override
  String get time => 'Time';

  @override
  String get amenities => 'Amenities';

  @override
  String get filterApply => 'Filter Apply';

  @override
  String get whatDoYouWantToPlay => 'What do you want to play?';

  @override
  String get selectSports => 'Select Sports';

  @override
  String get whichTime => 'Which Time';

  @override
  String get skillLevel => 'Skill Level';

  @override
  String get pleaseSelectSkillLevel => 'Please select skill level';

  @override
  String get apply => 'Apply';

  @override
  String get filterResult => 'Filter Result';

  @override
  String get enterMobileNumber => 'Enter Mobile Number';

  @override
  String get continues => 'Continue';

  @override
  String get rememberMe => 'Remember Me';

  @override
  String get forgotPassword => 'Forgot Password?';

  @override
  String get logIn => 'Log in';

  @override
  String get dontHaveAnAccountSignUp => 'Don\'t have an account? Sign Up';

  @override
  String get alreadyHaveAccount => 'Already have account?';

  @override
  String get joinAChallenge => '👉 Join a Challenge: ';

  @override
  String get competeProveYourSkills => 'Compete prove your skills.';

  @override
  String get createAChallenge => '👉 Create a Challenge: ';

  @override
  String get inviteOthers => 'Invite others. ';

  @override
  String get publicOrPrivate => '👉  Public or Private: ';

  @override
  String get openToAllOrJustYourCrew => 'Open to all or just your crew!';

  @override
  String get letsGetPlaying => 'Let’s get playing!';

  @override
  String get bookACourt => 'Book a Court';

  @override
  String get youreAlmostThere => 'You’re Almost There!';

  @override
  String get enterOtp => 'Enter OTP';

  @override
  String get verifyOtp => 'Verify OTP';

  @override
  String get resendOtp => 'Resend OTP';

  @override
  String get pleaseEnterYourPhoneNumber => 'Please enter your phone number';

  @override
  String get phoneNumberMustBe810Digits => 'Phone number must be 8-10 digits';

  @override
  String get enter810DigitPhoneNumber => 'Enter 8-10 digit phone number';

  @override
  String get sendOtp => 'SEND OTP';

  @override
  String get failedToSendOtpPleaseTryAgain =>
      'Failed to send OTP. Please try again.';

  @override
  String get agreeWith => 'Agree with ';

  @override
  String get termsConditions => 'Terms & Conditions';

  @override
  String get pleaseAcceptTheTermsConditionsToContinue =>
      'Please accept the Terms & Conditions to continue.';

  @override
  String get or => 'OR';

  @override
  String get backToLogin => 'Back to Login';
}
