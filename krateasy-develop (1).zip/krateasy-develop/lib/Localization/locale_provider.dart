import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LocaleProvider extends ChangeNotifier {
  Locale _locale = const Locale('en');

  Locale get locale => _locale;

  static final List<Locale> supportedLocales = [
    const Locale('en'),
    const Locale('el'),
  ];

  /// Initialize locale from SharedPreferences
  Future<void> initLocale() async {
    final prefs = await SharedPreferences.getInstance();
    final langCode = prefs.getString('language_code') ?? 'en';
    _locale = Locale(langCode);
    notifyListeners();
  }

  /// Change locale and save it
  Future<void> setLocale(Locale locale) async {
    if (!supportedLocales.contains(locale)) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('language_code', locale.languageCode);
    _locale = locale;
    notifyListeners();
  }
}
