// import 'package:firebase_core/firebase_core.dart';
// import 'package:flutter/services.dart';
// import 'package:flutter_localizations/flutter_localizations.dart';
// import 'package:kratEasyApp/Localization/locale_provider.dart';
// import 'package:kratEasyApp/core/initialization.dart';
// import 'package:kratEasyApp/generated/l10n.dart'; // contains class S
// import 'package:kratEasyApp/services/Firebase/firebase_services.dart';
// import 'package:kratEasyApp/services/Firebase/notification_services.dart';
// import 'package:kratEasyApp/GlobalUtils/app_providers.dart';
// import 'package:kratEasyApp/GlobalUtils/app_routes.dart';
// import 'package:kratEasyApp/services/local/local_service.dart';
// import 'GlobalUtils/app_imports.dart';
// import 'GlobalUtils/app_navigation.dart';
// import 'firebase_options.dart';
//
// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//   SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
//     statusBarColor: Colors.white,
//     statusBarIconBrightness: Brightness.dark,
//     statusBarBrightness: Brightness.light,
//   ));
//   await SystemChrome.setPreferredOrientations([
//     DeviceOrientation.portraitUp,
//     DeviceOrientation.portraitDown,
//   ]);
//
//   await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
//
//   final bool permissionsGranted =
//       await NotificationService.requestNotificationPermissions();
//   print('Notification permissions granted: $permissionsGranted');
//
//   await Future.wait([
//     FirebaseService.initialize().catchError((e) {
//       print('FirebaseService initialization failed: $e');
//     }),
//     NotificationService.initialize().catchError((e) {
//       print('NotificationService initialization failed: $e');
//     }),
//     LocalService.instance.init().catchError((e) {
//       print('LocalService initialization failed: $e');
//     }),
//     dotenv.load(fileName: ".env").catchError((e) {
//       print('Dotenv loading failed: $e');
//     }),
//     Initialization.setLocalTimeZone()
//   ]);
//
//   final localeProvider = LocaleProvider();
//   await localeProvider.initLocale();
//   runApp(MyApp(
//     localeProvider: localeProvider,
//   ));
// }
//
// class MyApp extends StatelessWidget {
//   final LocaleProvider localeProvider;
//   const MyApp({super.key, required this.localeProvider});
//
//   @override
//   Widget build(BuildContext context) {
//     return MultiProvider(
//       providers: [
//         ChangeNotifierProvider.value(value: localeProvider),
//         ...AppProviders.providers
//             .where((p) => p is! ChangeNotifierProvider<LocaleProvider>),
//       ],
//       child: Builder(
//         builder: (context) => MaterialApp(
//
//           locale: Provider.of<LocaleProvider>(context).locale,
//           localizationsDelegates: [
//             S.delegate,
//             GlobalMaterialLocalizations.delegate,
//             GlobalWidgetsLocalizations.delegate,
//             GlobalCupertinoLocalizations.delegate,
//           ],
//           supportedLocales: S.delegate.supportedLocales,
//           debugShowCheckedModeBanner: false,
//           title: "KratEasyBooking",
//           theme: ThemeData(
//             fontFamily: 'Outfit',
//             dialogTheme: const DialogThemeData(
//               backgroundColor: Colors.white,
//             ),
//           ),
//           navigatorKey: NavigationService.navigatorKey,
//           routes: AppRoutes.routes,
//           initialRoute: RouteNames.splash,
//         ),
//       ),
//     );
//   }
// }


import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

import 'package:kratEasyApp/Localization/locale_provider.dart';
import 'package:kratEasyApp/core/initialization.dart';
import 'package:kratEasyApp/generated/l10n.dart'; // class S
import 'package:kratEasyApp/services/Firebase/firebase_services.dart';
import 'package:kratEasyApp/services/Firebase/notification_services.dart';
import 'package:kratEasyApp/services/local/local_service.dart';
import 'GlobalUtils/app_providers.dart';
import 'GlobalUtils/app_routes.dart';
import 'GlobalUtils/app_navigation.dart';
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.white,
    statusBarIconBrightness: Brightness.dark,
    statusBarBrightness: Brightness.light,
  ));

  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Catch all uncaught async errors
  runZonedGuarded(() async {
    // Initialize Firebase only (fast and required for many services)
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );

    // Prepare locale
    final localeProvider = LocaleProvider();
    await localeProvider.initLocale();

    runApp(MyApp(localeProvider: localeProvider));

    // 🔹 Run heavy initializations in background AFTER UI is shown
    unawaited(_initializeServices());
  }, (error, stack) {
    debugPrint('Uncaught error in main: $error\n$stack');
  });
}

/// Background service initialization (doesn’t block startup)
Future<void> _initializeServices() async {
  try {
    await Future.wait([
      FirebaseService.initialize().catchError((e) {
        debugPrint('FirebaseService init failed: $e');
      }),
      NotificationService.initialize().catchError((e) {
        debugPrint('NotificationService init failed: $e');
      }),
      LocalService.instance.init().catchError((e) {
        debugPrint('LocalService init failed: $e');
      }),
      dotenv.load(fileName: ".env").catchError((e) {
        debugPrint('Dotenv load failed: $e');
      }),
      Initialization.setLocalTimeZone(),
    ]);

    // Request notification permissions AFTER splash/home screen is shown
    final granted = await NotificationService.requestNotificationPermissions();
    debugPrint('Notification permissions granted: $granted');
  } catch (e, s) {
    debugPrint('Service initialization failed: $e\n$s');
  }
}

class MyApp extends StatelessWidget {
  final LocaleProvider localeProvider;
  const MyApp({super.key, required this.localeProvider});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: localeProvider),
        ...AppProviders.providers
            .where((p) => p is! ChangeNotifierProvider<LocaleProvider>),
      ],
      child: Builder(
        builder: (context) => MaterialApp(
          locale: Provider.of<LocaleProvider>(context).locale,
          localizationsDelegates: const [
            l10n.delegate,
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          supportedLocales: l10n.delegate.supportedLocales,
          debugShowCheckedModeBanner: false,
          title: "KratEasyBooking",
          theme: ThemeData(
            fontFamily: 'Outfit',
            dialogTheme:  DialogThemeData(
              backgroundColor: Colors.white,
            ),
          ),
          navigatorKey: NavigationService.navigatorKey,
          routes: AppRoutes.routes,
          initialRoute: RouteNames.splash,
        ),
      ),
    );
  }
}
// ColoredPrint.green("FCM Token: $token");
