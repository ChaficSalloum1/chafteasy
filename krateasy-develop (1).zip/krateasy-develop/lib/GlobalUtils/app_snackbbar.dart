import 'package:flutter/material.dart';
import 'package:kratEasyApp/GlobalUtils/app_colors.dart';
import 'package:another_flushbar/flushbar.dart';


void showSnackbar(
    {required BuildContext context,
    required String message,
    Color backgroundColor = AppColors.primaryColor,
    Duration duration = const Duration(seconds: 2),
    SnackBarAction? action}) {
  final snackBar = SnackBar(
    content: Text(message,
        style: TextStyle(
            color: AppColors.black, fontSize: 16, fontWeight: FontWeight.w600)),
    backgroundColor: backgroundColor,
    duration: duration,
    action: action,
  );
  ScaffoldMessenger.of(context).showSnackBar(snackBar);
}




void showSnackbarError(
    {required BuildContext context,
    required String message,
    Color backgroundColor = AppColors.red323,
    Duration duration = const Duration(seconds: 2),
    SnackBarAction? action}) {
  final snackBar = SnackBar(
    content: Text(message,
        style: TextStyle(
            color: AppColors.white, fontSize: 16, fontWeight: FontWeight.w600)),
    backgroundColor: backgroundColor,

    duration: duration,
    action: action,
  );
  ScaffoldMessenger.of(context).showSnackBar(snackBar);
}

normalSnackBar({required String msg, required BuildContext context}) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
}
