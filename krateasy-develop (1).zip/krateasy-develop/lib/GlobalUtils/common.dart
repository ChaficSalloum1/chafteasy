import 'package:flutter/material.dart';
import 'package:kratEasyApp/GlobalUtils/app_colors.dart';
import 'package:kratEasyApp/GlobalUtils/app_navigation.dart';
import 'package:kratEasyApp/generated/l10n.dart';

Widget loaderWidget() =>
    Center(child: CircularProgressIndicator(color: AppColors.primaryColor));

Widget noDataWidget({String? text}) {
  return Padding(
    padding: const EdgeInsets.all(8.0),
    child: Center(
      child: Text(
        "${l10n.of(NavigationService.navigatorKey.currentContext!).no} ${text ?? l10n.of(NavigationService.navigatorKey.currentContext!).data} ${l10n.of(NavigationService.navigatorKey.currentContext!).found}",
        style: TextStyle(color: AppColors.black, fontWeight: FontWeight.w500),
      ),
    ),
  );
}

double h = 800;
double w = 320;
