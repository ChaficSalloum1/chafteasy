
// import 'package:flutter/material.dart';

// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter_svg/flutter_svg.dart';
// import 'package:shimmer/shimmer.dart';

// import 'app_images.dart';
// import 'common.dart'; // Assuming you use flutter_svg for SvgPic

// class NetworkImageWidget extends StatelessWidget {
//   final String image;
//   final double? height;
//   final double? width;
//   final Color color;
//   final BoxFit fit;

//   const NetworkImageWidget({
//     super.key,
//     required this.image,
//     this.height,
//     this.width,
//     this.fit = BoxFit.cover,
//     this.color = Colors.blue, // Replace with AppColors.primary if defined elsewhere
//   });

//   @override
//   Widget build(BuildContext context) {
//     return CachedNetworkImage(
//       imageUrl: image,
//       height: height,
//       width: width,
//       fit: fit,
//       placeholder: (context, url) => Shimmer.fromColors(
//         baseColor: Colors.grey[300]!,
//         highlightColor: Colors.grey[100]!,
//         child: Container(
//           height: height,
//           width: width,
//           color: Colors.white,
//         ),
//       ),
//       errorWidget: (context, url, error) => Container(
//         height: height,
//         width: width,
//         child: FittedBox(
//           child: Padding(
//             padding:  EdgeInsets.all(width == null ? w *0.08 : width! * 0.5),
//             child: Image.asset("assets/logo.png",
//               height: height,
//               width: width,
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }


// class AssetImageWidget extends StatelessWidget {
//   final String image;
//   final double? height;
//   final double? width;
//   final Color color;
//   final BoxFit? fit;

//   const AssetImageWidget({
//     Key? key,
//     required this.image,
//     this.height,
//     this.width,
//     this.fit,
//     this.color = Colors.white,
//   }) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return FutureBuilder(
//       future: _loadAssetImage(context , image),
//       builder: (context, snapshot) {
//         if (snapshot.connectionState == ConnectionState.done) {
//           if (snapshot.hasError) {
//             // Error loading asset
//             return SizedBox(
//               height: height,
//               width: width,
//               child: Center(child: const Icon(Icons.error, color: Colors.red)),
//             );
//           }

//           // Successfully loaded asset image
//           return Image.asset(
//             image,
//             height: height,
//             width: width,
//             fit: fit ?? BoxFit.cover,
//           );
//         } else {
//           // Show shimmer loading
//           return loaderWidget();
//         }
//       },
//     );
//   }

//   Future<void> _loadAssetImage(BuildContext context, String assetPath) async {
//     await precacheImage(AssetImage(assetPath), context);
//   }

// }





import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';

class NetworkImageWidget extends StatelessWidget {
  final String image;
  final double? height;
  final double? width;
  final BoxFit fit;

  const NetworkImageWidget({
    super.key,
    required this.image,
    this.height,
    this.width,
    this.fit = BoxFit.cover,
  });

  @override
  Widget build(BuildContext context) {
    return CachedNetworkImage(
      imageUrl: image,
      height: height,
      width: width,
      fit: fit,
      placeholder: (context, url) => Container(
        height: height,
        width: width,
        color: Colors.grey[200],
      ),
      errorWidget: (context, url, error) => Container(
        height: height,
        width: width,
        alignment: Alignment.center,
        child:  Container(
          color: Color(0xFFF4F9EC),
          child: Center(
            child: Image.asset(
              'assets/icons/footer.png', 
              fit: BoxFit.cover,
            ),
          ),
        ),
        // child: Icon(Icons.broken_image, size: 28, color: Colors.grey[400]),
      ),
    );
  }
}
