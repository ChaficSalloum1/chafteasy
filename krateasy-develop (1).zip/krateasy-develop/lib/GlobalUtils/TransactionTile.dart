import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import '../Models/TransactionDetailsModel.dart';
import '../NavBarScreens/AddAmountWallet/TransactionDetailsScreen.dart';
import 'app_constants.dart';

class TransactionTile extends StatelessWidget {
  final TransactionDetailsModel transaction;

  const TransactionTile({Key? key, required this.transaction})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    String statusLabel;
    Color amountColor;
    Color tagBgColor;

    switch (transaction.type) {
      case 'Add':
        statusLabel = l10n.of(context).addedAmount;
        amountColor = Colors.black;
        tagBgColor = Colors.black;
        break;
      case 'Credit':
        statusLabel = l10n.of(context).addedAmount;
        amountColor = Colors.black;
        tagBgColor = Colors.black;
        break;
      case 'Debit':
        statusLabel =l10n.of(context).paidAmount;
        amountColor = const Color(0xFFFF0200);
        tagBgColor = const Color(0xFF3B747D);
        break;
      case 'Refund':
        statusLabel = l10n.of(context).refunded;
        amountColor = const Color(0xFF8DC63F);
        tagBgColor = const Color(0xFF5EA101);
        break;
      default:
        statusLabel =l10n.of(context).cancel;
        amountColor = Colors.grey;
        tagBgColor = Colors.grey;
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5),
        color: Color(0xFFF4F4F4).withValues(alpha: 0.5),
      ),
      margin: const EdgeInsets.only(top: 15),
      child: Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) =>
                    TransactionDetailsScreen(transaction: transaction),
              ),
            );
          },
          child: Stack(
            children: [
              ListTile(
                contentPadding: EdgeInsets.zero,
                tileColor: Colors.white,
                leading: Padding(
                  padding: EdgeInsets.only(left: 6),
                  child: Image.asset(
                    'assets/icons/txn.png',
                    height: 48,
                    width: 49,
                    fit: BoxFit.cover,
                  ),
                ),
                title: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                     l10n.of(context).transactionId,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      transaction.transactionId,
                      style: const TextStyle(
                        color: Color(0xFF686868),
                        fontSize: 12,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Image.asset(
                          'assets/icons/calender.png',
                          height: 13,
                          width: 13,
                          fit: BoxFit.cover,
                        ),
                        Expanded(
                          child: Text(
                            DateFormat(
                              'dd MMM, yyyy | hh:mm a',
                            ).format(transaction.createdAt),
                            style: const TextStyle(
                              color: Color(0xFF555555),
                              fontSize: 10,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                trailing: Padding(
                  padding: const EdgeInsets.only(right: 12),
                  child: Text(
                    '${transaction.type == 'Debit' ? '-' : '+'}${AppConstants.appCurrency}${transaction.amount.toStringAsFixed(1)}',
                    style: TextStyle(
                      color: amountColor,
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
              Positioned(
                top: 0,
                right: 0,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: tagBgColor,
                    borderRadius: const BorderRadius.only(
                      topRight: Radius.circular(10),
                      bottomLeft: Radius.circular(4),
                    ),
                  ),
                  child: Text(
                    statusLabel,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
