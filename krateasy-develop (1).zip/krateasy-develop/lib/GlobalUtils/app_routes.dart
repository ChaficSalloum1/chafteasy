import 'package:kratEasyApp/BottomNavScreens/CreateChallengeScreen/CreateChallengeScreen.dart';
import 'package:kratEasyApp/BottomNavScreens/FacilitiesViewScreen.dart';
import 'package:kratEasyApp/EntranceScreens/guest_booking.dart';
import 'package:kratEasyApp/EntranceScreens/guest_payment_screen.dart';
import 'package:kratEasyApp/NavBarScreens/AboutUsScreen.dart';
import 'app_imports.dart';

class AppRoutes {
  static Map<String, WidgetBuilder> routes = {
    RouteNames.splash: (context) => SplashScreen(),
    RouteNames.onboarding: (context) => OnboardingScreen(),
    RouteNames.login: (context) => LoginScreen(),
    RouteNames.signup: (context) => SignUpScreen(),
    RouteNames.verification: (context) => VerificationScreen(),
    RouteNames.setPassword: (context) => SetPasswordScreen(),
    RouteNames.completeProfile: (context) => CompleteProfileScreen(),
    RouteNames.profileCreated: (context) => ProfileCreatedScreen(),
    RouteNames.forgotPassword: (context) => ForgotPasswordScreen(),
    RouteNames.resetVerification: (context) => VerificationResetPassScreen(),
    RouteNames.resetPassword: (context) => ResetPasswordScreen(),
    RouteNames.resetSuccess: (context) => PasswordResetSuccessScreen(),
    RouteNames.dashboard: (context) => DashboardScreen(),
    RouteNames.myAccount: (context) => MyAccountScreen(),
    RouteNames.editProfile: (context) => EditScreen(),
    RouteNames.terms: (context) => TermsAndConditionsScreen(),
    RouteNames.privacy: (context) => PrivacyPolicyScreen(),
    RouteNames.createChallenge: (context) => CreateChallengeScreen(),
    RouteNames.featuredFacilities: (context) => FeaturedFacilityScreen(),
    // RouteNames.facilityBook: (context) => FacilityBookingScreen(),
    RouteNames.myBookings: (context) => MyBookingScreen(),
    RouteNames.wallet: (context) => WalletScreen(),
    // RouteNames.addAmount: (context) => AddAmountScreen(),
    // RouteNames.withdrawAmount: (context) => WithdrawAmountScreen(),
    // RouteNames.addAmountSuccess: (context) => AmountAddedSuccessScreen(),
    // RouteNames.addFriends: (context) => FacilityAddFriendsScreen(),
    // RouteNames.checkout: (context) => CheckoutScreen(),
    // RouteNames.successPayment: (context) => SuccessPaymentScreen(),
    // RouteNames.bookingDetails: (context) => BookingDetailsScreen(),
    RouteNames.facility: (context) => FacilitiesViewScreen(),
    RouteNames.favouritePlayers: (context) => MyFavouriteScreen(),
    // RouteNames.viewUpcoming: (context) => ViewChallengeBookingUpcomingScreen(),
    // RouteNames.viewCompleted: (context) => ViewChallengeBookingCompleteScreen(),
    RouteNames.viewCourtDetailsComplete: (context) =>
        ViewCourtDetailsCompleteScreen(),
    // RouteNames.viewCourtDetails: (context) => ViewCourtDetailsScreen(),
    // RouteNames.joinChallenge: (context) => JoinChallengeScreen(),
    // RouteNames.viewChallenge: (context) => ViewChallengeScreen(),
    // RouteNames.challengeSuccess: (context) => ChallengeSuccessScreen(),
    // RouteNames.sharePayment: (context) => SharePaymentLinkScreen(),
    RouteNames.feeds: (context) => FeedsScreen(),
    RouteNames.favouriteCourts: (context) => FavouriteCourtsScreen(),
    // RouteNames.facilitiesListing: (context) => FacilitiesListingScreen(),
    RouteNames.guestBooking: (context) => GuestBookingScreen(),
    RouteNames.guestPayment: (context) => GuestPaymentScreen(),
    RouteNames.guestSharePayment: (context) => GuestSharePaymentScreen(),
    RouteNames.guestSuccess: (context) => GuestSuccessPaymentScreen(),
    RouteNames.addedFriends: (context) => AddedFriendsScreen(),
    RouteNames.chooseSports: (context) => ChooseSportsToPlayScreen(),
    RouteNames.myLocation: (context) => MyLocationScreen(),
    RouteNames.searchCourts: (context) => SearchCourtScreen(),
    RouteNames.guestTabs: (context) => GuestTabsScreen(),
    RouteNames.allWalletTxn: (context) => AllTransactionsScreen(),
    // RouteNames.bookingScreen: (context) => BookingScreen(),
    RouteNames.aboutUs: (context) => AboutUsScreen(),
  };
}

class RouteNames {
  static const String splash = '/';
  static const String onboarding = '/onboarding';
  static const String login = '/login';
  static const String signup = '/signup';
  static const String verification = '/verification';
  static const String setPassword = '/set_password';
  static const String completeProfile = '/complete_profile';
  static const String profileCreated = '/profile_created';
  static const String forgotPassword = '/forgotPassword';
  static const String resetVerification = '/reset_verification_code';
  static const String resetPassword = '/reset_password';
  static const String resetSuccess = '/success_reset_password';
  static const String dashboard = '/dashboard';
  static const String myAccount = '/myAccount';
  static const String editProfile = '/editprofile';
  static const String terms = '/termsAndConditions';
  static const String privacy = '/privacyPolicy';
  static const String createChallenge = '/createChallenge';
  static const String featuredFacilities = '/featuredFacilities';
  // static const String facilityBook = '/facilityBook';
  static const String myBookings = '/myBookings';
  static const String wallet = '/wallet';
  // static const String addAmount = '/addAmount';
  // static const String withdrawAmount = '/withdrawAmount';
  // static const String addAmountSuccess = '/addAmountSuccess';
  // static const String addFriends = '/addFriends';
  // static const String checkout = '/checkOut';
  // static const String successPayment = '/successPayment';
  // static const String bookingDetails = '/bookingDetails';
  static const String facility = '/facility';
  static const String favouritePlayers = '/favouritePlayers';
  // static const String viewUpcoming = '/viewChallengeBookingUpcomingScreen';
  // static const String viewCompleted = '/viewChallengeBookingCompleteScreen';
  static const String viewCourtDetailsComplete =
      '/viewCourtDetailsCompleteScreen';
  // static const String viewCourtDetails = '/viewCourtDetailsScreen';
  // static const String joinChallenge = '/joinChallengeScreen';
  static const String viewChallenge = '/viewChallengeScreen';
  // static const String challengeSuccess = '/challengeSuccessScreen';
  // static const String sharePayment = '/sharePaymentLinkScreen';
  static const String feeds = '/feedsScreen';
  static const String favouriteCourts = '/favouriteCourtsScreen';
  // static const String facilitiesListing = '/facilitiesListingScreen';
  static const String guestBooking = '/guestBookingScreen';
  static const String guestPayment = '/guestPaymentScreen';
  static const String guestSharePayment = '/guestSharePaymentScreen';
  static const String guestSuccess = '/guestSuccessPaymentScreen';
  static const String addedFriends = '/addedFriendsScreen';
  static const String chooseSports = '/chooseSportsToPlay';
  static const String myLocation = '/myLocation';
  static const String searchCourts = '/searchCourts';
  static const String guestTabs = '/guestTabsScreen';
  static const String allWalletTxn = '/allWalletTxn';
  // static const String bookingScreen = '/bookingScreen';
  static const String aboutUs = '/aboutUs';
}
