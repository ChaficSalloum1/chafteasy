import 'package:flutter/material.dart';
import 'package:kratEasyApp/GlobalUtils/app_colors.dart';
import 'package:kratEasyApp/GlobalUtils/app_images.dart';
import 'package:kratEasyApp/GlobalUtils/common_app_bar.dart';

class FeedsScreen extends StatefulWidget {
  const FeedsScreen({super.key});

  @override
  State<FeedsScreen> createState() => _FeedsScreenState();
}

class _FeedsScreenState extends State<FeedsScreen> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(color: AppColors.white, image: DecorationImage(image: AssetImage(AppImages.pngFeedsBg), fit: BoxFit.fill)),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: CommonAppBar(title: "Feeds", bg: Colors.transparent),
        body: SafeArea(
          child: ListView.builder(
            itemCount: 2,
            itemBuilder: (context, index) {
              return Column(
                children: [
                  SizedBox(height: 20),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 15, left: 15, right: 15),
                    child: Row(
                      children: [
                        ClipRRect(borderRadius: BorderRadius.circular(35), child: SizedBox(height: 35, width: 35, child: Image.asset(AppImages.pngUser, fit: BoxFit.fill))),
                        SizedBox(width: 5),
                        Expanded(child: Text("Edgbaston Priory", style: TextStyle(fontSize: 14, fontWeight: FontWeight.normal, color: AppColors.black))),
                        Container(
                          padding: EdgeInsets.all(10),
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(5), color: AppColors.primaryColor),
                          child: Center(child: Text("13 February", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.black))),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 10),
                  SizedBox(height: MediaQuery.of(context).size.height * .5, width: double.infinity, child: Image.asset("assets/icons/feeds_bg_big.png", fit: BoxFit.fill)),
                  SizedBox(height: 30),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}
