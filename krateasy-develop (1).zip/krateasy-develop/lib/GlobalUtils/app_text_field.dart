import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
// import 'package:google_fonts/google_fonts.dart';
import 'package:kratEasyApp/ViewModel/EntranceViewModel/booking_provider.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:provider/provider.dart';

import 'app_colors.dart';

class AppTextField extends StatelessWidget {
  final String? titleText;
  final TextStyle? textstyle;
  final TextEditingController? controller;
  final int? maxLines;
  final bool? isReadOnly;
  final bool? isEnabled;
  final int? maxLength;
  final bool? obscureText;
  final TextInputType? keyboardType;
  final Function(String)? onchanged;
  final FormFieldValidator? validator;
  final Function()? onTap;
  final String? hintText;
  final TextStyle? hintTextStyle;
  final List<TextInputFormatter>? inputFormatters;
  final String? prefix;
  final Widget? prefixWidget;
  final Widget? suffix;
  final TextAlign? textAlign;
  final bool? autoValidate;
  final EdgeInsets? contentPadding;
  final bool? isCapital;
  final bool? isFilled;
  final ValueChanged<String>? onFieldSubmitted;
  final double? borderRadius;
  final Color? borderColor;
  final Color? fillColor;
  final String? labelText;
  final Color? prefixColor;
  final Color? cursorColor;
  final double? height;
  final double? width;

  const AppTextField({
    super.key,
    this.titleText,
    this.textstyle,
    this.controller,
    this.maxLines,
    this.isReadOnly = false,
    this.isEnabled,
    this.maxLength,
    this.obscureText = false,
    this.keyboardType,
    this.onchanged,
    this.validator,
    this.onTap,
    this.hintText,
    this.hintTextStyle,
    this.inputFormatters,
    this.prefix,
    this.prefixWidget,
    this.suffix,
    this.textAlign,
    this.autoValidate = false,
    this.contentPadding,
    this.isCapital,
    this.onFieldSubmitted,
    this.isFilled = true,
    this.borderRadius = 10,
    this.borderColor = AppColors.greyGreen47D,
    this.fillColor = AppColors.white,
    this.labelText,
    this.prefixColor = AppColors.black555,
    this.cursorColor,
    this.height = 50,
    this.width = double.infinity,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (titleText != null && titleText!.isNotEmpty) ...[
          Text(
            titleText!,
            style: TextStyle(
              fontFamily: "Outfit",
              fontSize: 12,
              color: Theme.of(context).textTheme.bodySmall!.color!,
            ),
          ),
          SizedBox(height: 6),
        ] else ...[
          const SizedBox.shrink(),
        ],
        SizedBox(
          width: width,
          child: TextFormField(
            controller: controller,
            inputFormatters: inputFormatters,
            style: textstyle ??
                TextStyle(
                    fontFamily: "Outfit",
                    fontSize: 16,
                    fontWeight: FontWeight.normal,
                    color: AppColors.grey769),
            maxLines: maxLines ?? 1,
            readOnly: isReadOnly!,
            enabled: isEnabled,
            maxLength: maxLength,
            obscureText: obscureText!,
            decoration: InputDecoration(
              errorMaxLines: 5,
              filled: isFilled,
              fillColor: fillColor,
              contentPadding: contentPadding ??
                  EdgeInsets.only(left: 15, top: 10, right: 15, bottom: 10),
              hintText: hintText,
              hintStyle: hintTextStyle ??
                  TextStyle(
                    fontFamily: "Outfit",
                    fontSize: 16,
                    fontWeight: FontWeight.normal,
                    color: AppColors.grey8A8,
                  ),
              labelText: labelText,
              labelStyle: Theme.of(context).textTheme.headlineSmall!.copyWith(
                    letterSpacing: -0.1,
                    fontSize: 14,
                    color: AppColors.black555,
                  ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(
                  maxLines == null ? borderRadius! : 8,
                ),
                borderSide: isFilled!
                    ? BorderSide(width: 1.0, color: borderColor!)
                    : BorderSide.none,
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(
                  maxLines == null ? borderRadius! : 8,
                ),
                borderSide: isFilled!
                    ? BorderSide(width: 1.0, color: borderColor!)
                    : BorderSide.none,
              ),
              disabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(
                  maxLines == null ? borderRadius! : 8,
                ),
                borderSide: isFilled!
                    ? BorderSide(width: 1.0, color: borderColor!)
                    : BorderSide.none,
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(
                  maxLines == null ? borderRadius! : 8,
                ),
                borderSide: isFilled!
                    ? BorderSide(width: 1.0, color: borderColor!)
                    : BorderSide.none,
              ),
              prefixIcon: prefixWidget ??
                  (prefix == null
                      ? null
                      : Padding(
                          padding: const EdgeInsets.only(
                            left: 10,
                            top: 10.0,
                            bottom: 10,
                            right: 6,
                          ),
                          child: SvgPicture.asset(
                            prefix!,
                            width: 30,
                            height: 30,
                            colorFilter: ColorFilter.mode(
                              prefixColor!,
                              BlendMode.srcIn,
                            ),
                          ),
                        )),
              prefixIconConstraints: BoxConstraints(
                minHeight: 15,
                minWidth: 15,
              ),
              suffixIcon: Padding(
                padding: EdgeInsets.symmetric(horizontal: 10),
                child: suffix,
              ),
              suffixIconConstraints: BoxConstraints(
                minHeight: 20,
                minWidth: 20,
              ),
              counterText: "",
            ),
            keyboardType: keyboardType ?? TextInputType.text,
            cursorColor: cursorColor ?? AppColors.black555,
            onChanged: onchanged ?? (val) {},
            onTap: onTap ?? () {},
            validator: validator,
            autovalidateMode: autoValidate!
                ? AutovalidateMode.onUserInteraction
                : AutovalidateMode.onUserInteraction,
          ),
        ),
      ],
    );
  }
}

class OtpTextFormField extends StatefulWidget {
  final TextEditingController? controller;
  final void Function(String str) onchanged;
  final AutovalidateMode? autovalidateMode;
  final double width;
  final int length;
  final FocusNode? focusNode;
  final bool isValidator;

  const OtpTextFormField({
    super.key,
    required this.controller,
    required this.onchanged,
    this.autovalidateMode,
    this.width = double.infinity,
    this.length = 5,
    this.focusNode,
    this.isValidator = false,
  });

  @override
  State<OtpTextFormField> createState() => _OtpTextFormFieldState();
}

class _OtpTextFormFieldState extends State<OtpTextFormField> {
  // late TextEditingController _internalController;
  //
  // @override
  // void initState() {
  //   super.initState();
  //   _internalController = widget.controller ?? TextEditingController();
  // }

  // @override
  // void dispose() {
  //   if (widget.controller == null) {
  //     _internalController.dispose();
  //   }
  //   super.dispose();
  // }

  @override
  Widget build(BuildContext context) {
    return Consumer<BookingProvider>(builder: (context, viewModel, _) {
      return Container(
        width: widget.width,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: PinCodeTextField(
          focusNode: widget.focusNode,
          appContext: context,
          length: widget.length,
          controller: viewModel.otpController,
          autoDisposeControllers: false,
          onChanged: widget.onchanged,
          keyboardType: TextInputType.number,
          autovalidateMode:
              widget.autovalidateMode ?? AutovalidateMode.disabled,
          cursorColor: AppColors.black,
          enableActiveFill: true,
          pinTheme: PinTheme(
            shape: PinCodeFieldShape.box,
            borderRadius: BorderRadius.circular(10),
            fieldWidth: MediaQuery.of(context).size.width * .15,
            fieldHeight: 60,            activeFillColor: AppColors.white,
            inactiveFillColor: AppColors.white,
            selectedFillColor: AppColors.white,borderWidth: 0.5,
            activeColor: AppColors.primaryColor,
            inactiveColor: AppColors.tealLight,
            selectedColor: AppColors.primaryColor,
          ),
          // pinTheme: PinTheme(
          //   shape: PinCodeFieldShape.box,
          //   borderRadius: BorderRadius.circular(10),
          //   fieldWidth: MediaQuery.of(context).size.width * .15,
          //   fieldHeight: 60,
          //   activeFillColor: AppColors.white,
          //   inactiveFillColor: AppColors.white,
          //   selectedFillColor: AppColors.white,
          // ),
          validator: widget.isValidator
              ? (val) {
                  if (val == null || val.isEmpty) return l10n.of(context).otpRequired;
                  if (val.length != widget.length) return l10n.of(context).invalidOtp;
                  return null;
                }
              : null,
        ),
      );
    });
  }
}

// Todo : Global print function
void printLog(String text) {
  debugPrint("LOG > ${text.toString()}");
}
