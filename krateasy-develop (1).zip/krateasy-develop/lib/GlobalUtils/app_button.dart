import 'package:flutter/material.dart';
import 'app_colors.dart';

class AppButton extends StatelessWidget {
  final String? label;
  final Function()? onPressed;
  final double? width;
  final bool? isLoading;
  final double height;
  final double textSize;
  final double radius;
  final EdgeInsets margin;
  final bool isButonDisabled;
  final double iconSize;
  final Color? bgColor;
  final Color? textColor;
  final Color? borderColor;
  final Color? disabledColor;
  final Color? isLoadingColor;
  final bool isBorder;
  final Widget? suffixIcon;
  final Widget? prefixIcon;
  final MainAxisAlignment mainAxisAlignment;
  final TextStyle? textStyle;
  final Widget? child;
  final FontWeight? fontWeight;

  const AppButton({
    super.key,
    this.label,
    this.onPressed,
    this.width,
    this.isButonDisabled = false,
    this.height = 50,
    this.textSize = 16,
    this.child,
    this.radius = 10,
    this.margin = EdgeInsets.zero,
    this.iconSize = 20,
    this.bgColor,
    this.borderColor,
    this.textColor,
    this.isBorder = false,
    this.suffixIcon,
    this.mainAxisAlignment = MainAxisAlignment.center,
    this.prefixIcon,
    this.textStyle,
    this.isLoading,
    this.disabledColor,
    this.isLoadingColor = AppColors.black,
    this.fontWeight,
  });

  @override
  Widget build(BuildContext context) {
    return MaterialButton(
      height: height,
      color: bgColor ?? AppColors.primaryColor,
      minWidth: width ?? MediaQuery.of(context).size.width,
      elevation: 0,
      hoverElevation: 0,
      focusElevation: 0,
      disabledColor: disabledColor ?? Color(0xffa0a0a0).withOpacity(.3),
      disabledElevation: 0,
      highlightElevation: 0,
      splashColor: Colors.white.withOpacity(0.2),
      highlightColor: Colors.white.withOpacity(0.2),
      shape: RoundedRectangleBorder(
          side: BorderSide(color: borderColor ?? Colors.transparent),
          borderRadius: BorderRadius.circular(radius)),
      onPressed: onPressed,
      child: child ??
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: mainAxisAlignment,
            children: [
              if (isLoading == true)
                CircularProgressIndicator(color: isLoadingColor)
              else ...[
                if (prefixIcon != null)
                  Padding(
                      padding: EdgeInsets.symmetric(horizontal: 2),
                      child: prefixIcon!),
                Text(
                  label ?? "",
                  textAlign: TextAlign.center,
                  softWrap: false,
                  maxLines: 1,
                  overflow: TextOverflow.clip,
                  style: textStyle ??
                      TextStyle(
                          color: textColor ?? AppColors.black,
                          fontSize: 16,
                          fontWeight: fontWeight ?? FontWeight.w600),
                ),
                if (suffixIcon != null)
                  Padding(
                      padding: EdgeInsets.symmetric(horizontal: 8),
                      child: suffixIcon!),
              ],
            ],
          ),
    );
  }
}

class AppButtonCommon extends StatelessWidget {
  final String? label;
  final Function()? onPressed;
  final double? width;
  final bool? isLoading;
  final double height;
  final double textSize;
  final double radius;
  final EdgeInsets margin;
  final bool isButonDisabled;
  final double iconSize;
  final Color? bgColor;
  final Color? textColor;
  final Color? borderColor;
  final Color? disabledColor;
  final Color? isLoadingColor;
  final Color? bgContainerColor;
  final bool isBorder;
  final Widget? suffixIcon;
  final Widget? prefixIcon;
  final MainAxisAlignment mainAxisAlignment;
  final TextStyle? textStyle;
  final Widget? child;
  final FontWeight? fontWeight;

  const AppButtonCommon({
    super.key,
    this.label,
    this.onPressed,
    this.width,
    this.isButonDisabled = false,
    this.height = 50,
    this.textSize = 17,
    this.child,
    this.radius = 10,
    this.margin = EdgeInsets.zero,
    this.iconSize = 20,
    this.bgColor = AppColors.primaryColor,
    this.borderColor,
    this.textColor,
    this.isBorder = false,
    this.suffixIcon,
    this.mainAxisAlignment = MainAxisAlignment.center,
    this.prefixIcon,
    this.textStyle,
    this.isLoading,
    this.disabledColor,
    this.fontWeight,
    this.isLoadingColor = AppColors.black,
    this.bgContainerColor = AppColors.green033,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
            height: height + 4,
            width: double.infinity,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(radius),
                color: bgContainerColor)),
        MaterialButton(
          height: height,
          color: bgColor ?? AppColors.primaryColor,
          minWidth: width ?? MediaQuery.of(context).size.width,
          elevation: 0,
          hoverElevation: 0,
          focusElevation: 0,
          disabledColor: disabledColor ?? Color(0xffa0a0a0).withOpacity(.3),
          disabledElevation: 0,
          highlightElevation: 0,
          splashColor: Colors.white.withOpacity(0.2),
          highlightColor: Colors.white.withOpacity(0.2),
          shape: RoundedRectangleBorder(
              side: BorderSide(color: borderColor ?? Colors.transparent),
              borderRadius: BorderRadius.circular(radius)),
          onPressed: onPressed,
          child: child ??
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: mainAxisAlignment,
                children: [
                  if (isLoading == true)
                    CircularProgressIndicator(color: isLoadingColor)
                  else ...[
                    if (prefixIcon != null)
                      Padding(
                          padding: EdgeInsets.symmetric(horizontal: 8),
                          child: prefixIcon!),
                    Text(
                      label ?? "",
                      textAlign: TextAlign.center,
                      softWrap: false,
                      maxLines: 1,
                      style: textStyle ??
                          TextStyle(
                              color: textColor ?? AppColors.black,
                              fontSize: 16,
                              fontWeight: fontWeight ?? FontWeight.w500),
                    ),
                    if (suffixIcon != null)
                      Padding(
                          padding: EdgeInsets.symmetric(horizontal: 8),
                          child: suffixIcon!),
                  ],
                ],
              ),
        ),
      ],
    );
  }
}
