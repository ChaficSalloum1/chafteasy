import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/utils/extension.dart';

class FacilityCard extends StatelessWidget {
  final String name, price, rating, image, reviewsRate;
  final VoidCallback onBookPressed;

  const FacilityCard({
    required this.name,
    required this.price,
    required this.reviewsRate,
    required this.rating,
    required this.image,
    required this.onBookPressed,
  });

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;

    // Access ViewModel
    // final facilityViewModel = Provider.of<FacilitiesViewModel>(
    //   context,
    //   listen: false,
    // );

    return Container(
      decoration: BoxDecoration(color: Colors.white, border: Border.all(color: Color(0xFfD0D0D0), width: 1.2), borderRadius: BorderRadius.circular(5)),
      // Ensures background color is white
      margin: EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          children: [
            Container(
              height: 80,
              width: 80,
              child: FittedBox(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(5),
                  child: NetworkImageWidget(image: image, width: 80, height: 80, fit: BoxFit.cover),
                ),
              ),
            ),
            SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(name.capitalizeFirstLetter(),maxLines: 1,overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
                  SizedBox(height: 5),
                  Text(price, style: TextStyle(color: Color(0xFF3B747D), fontWeight: FontWeight.w600, fontSize: 16)),
                  SizedBox(height: 5),
                  Row(
                    children: [
                      Image.asset(
                        'assets/icons/rate.png',
                        width: 20,
                        height: 17,
                      ),
                      Text(
                        rating,
                        style: TextStyle(
                          color: Color(0xFF555555),
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      SizedBox(width: 3),
                      Container(height: 15, width: 2, color: AppColors.greyD9D9),
                      SizedBox(width: 3),
                      Text(
                        "($reviewsRate ${l10n.of(context).reviews})",
                        style: TextStyle(
                          color: Color(0xFF555555),
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF8DC63F),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              onPressed: onBookPressed,
              child: Text(
                l10n.of(context).bookNow,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: screenWidth * 0.03,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
