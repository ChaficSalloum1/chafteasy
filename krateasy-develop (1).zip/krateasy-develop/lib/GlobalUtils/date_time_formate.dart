// import 'package:intl/intl.dart';

// // String formatDateTime(String isoDate) {
// //   DateTime dateTime = DateTime.parse(isoDate).toLocal(); // Convert to local time zone

// //   String formattedDate = DateFormat("dd MMM, yyyy  |  hh:mm a").format(dateTime);
// //   return formattedDate;
// // }