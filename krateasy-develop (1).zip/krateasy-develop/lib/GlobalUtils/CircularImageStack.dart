import 'package:flutter/material.dart';

import 'app_imports.dart';

class CircularImageStackOld extends StatelessWidget {
  final List<String>? imageUrls;
  final int maxImages;

  const CircularImageStackOld({Key? key, required this.imageUrls, this.maxImages = 5}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double overlap = 15;

    List<Widget> imageWidgets = [];
    int extraCount = (imageUrls?.length ?? 0) - maxImages;

    for (int i = 0; i < ((imageUrls?.length ?? 0) > maxImages ? maxImages : (imageUrls?.length ?? 0)); i++) {
      imageWidgets.add(

          Positioned(
            left: i * overlap.toDouble(),
            child: CircleAvatar(
              radius: 16,
              backgroundColor: Colors.white,
              child: CircleAvatar(
                radius: 16,
                backgroundColor: Colors.grey[200],
                child: ClipOval(
                  child: CachedNetworkImage(
                    imageUrl: (imageUrls?[i] == null || imageUrls?[i] == "")
                        ? ""
                        : imageUrls![i],
                    width: 32,
                    height: 32,
                    fit: BoxFit.cover,
                    errorWidget: (context, url, error) => Image.asset(
                      'assets/png/user_logo.png',
                      width: 32,
                      height: 32,
                      fit: BoxFit.cover,
                    ),
                    placeholder: (context, url) => Container(
                      width: 32,
                      height: 32,
                      alignment: Alignment.center,
                      child: SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 1),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          )
        // Positioned(
        //   left: i * overlap.toDouble(),
        //   child: CircleAvatar(
        //     radius: 16,
        //     backgroundColor: Colors.white,
        //     child: CircleAvatar(
        //       radius: 16,
        //       backgroundImage: NetworkImage((imageUrls?[i] == null || imageUrls?[i] == "") ? "https://cdn.pixabay.com/photo/2020/07/01/12/58/icon-5359553_1280.png" : imageUrls![i]),
        //     ),
        //   ),
        // ),
      );
    }

    if (extraCount > 0) {
      imageWidgets.add(
        Positioned(
          left: maxImages * overlap.toDouble(),
          child: CircleAvatar(radius: 16, backgroundColor: Colors.black, child: Text("+$extraCount", style: TextStyle(color: Colors.white, fontSize: 16))),
        ),
      );
    }
    return SizedBox(height: 35, width: ((maxImages + 1) * overlap + 20).toDouble(), child: Stack(children: imageWidgets));
  }
}
