import 'package:flutter/cupertino.dart';
import 'package:kratEasyApp/Localization/locale_provider.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/services/local/local_keys.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'app_imports.dart';

class SideDrawerScreen extends StatefulWidget {
  // final String username;

  const SideDrawerScreen({
    super.key,
  });

  @override
  _SideDrawerScreenState createState() => _SideDrawerScreenState();
}

class _SideDrawerScreenState extends State<SideDrawerScreen> {
  String? selectedLang;

  @override
  void initState() {
    // TODO: implement initState

    selectedLang = context.read<LocaleProvider>().locale.languageCode;

    super.initState();
  }

  void _onLangChange(String langCode) {
    final provider = context.read<LocaleProvider>();
    provider.setLocale(Locale(langCode));
    setState(() {
      selectedLang = langCode;
    });
  }

  bool _languageExpanded = false;
  @override
  Widget build(BuildContext context) {
    final viewModel = SideDrawerViewModel();
    final double screenWidth = MediaQuery.of(context).size.width;
    final double screenHeight = MediaQuery.of(context).size.height;

    return Drawer(
      width: screenWidth * .85,
      child: Container(
        color: Colors.white,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            Container(
              padding: EdgeInsets.only(
                top: screenHeight * 0.05,
                bottom: screenHeight * 0.02,
                left: screenWidth * 0.04,
                right: screenWidth * 0.04,
              ),
              child: Column(
                children: [
                  Align(
                    alignment: Alignment.centerRight,
                    child: InkWell(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        height: 35,
                        width: 35,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color.fromARGB(255, 240, 238, 238),
                        ),
                        child: Icon(Icons.close,
                            color: AppColors.black555, size: 18),
                      ),
                    ),
                  ), // SizedBox(height: screenHeight * 0.01),
                  Consumer<MyAccountViewModel>(
                    builder: (BuildContext context, myAccountViewModel,
                        Widget? child) {
                      return Column(
                        children: [
                          Builder(
                            builder: (context) {
                              String image = "";
                              bool isAvailable = false;
                              if (LocalService.instance.getData(
                                          LocalKeys.instance.userImage) !=
                                      null &&
                                  LocalService.instance.getData(
                                          LocalKeys.instance.userImage) !=
                                      "") {
                                image = myAccountViewModel.image.toString();
                                isAvailable = true;
                              } else {
                                image = 'assets/icons/user.png';
                              }
                              printLog("Image Drawer : ${image}");
                              return InkWell(
                                onTap: () {
                                  Navigator.pushNamed(
                                      NavigationService.context, '/myAccount');
                                },
                                child: Stack(
                                  children: [
                                    Container(
                                      height: 120,
                                      width: 120,
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                            color: AppColors.primaryColor,
                                            width: 1),
                                        shape: BoxShape.circle,
                                        color:
                                            Color.fromARGB(255, 240, 238, 238),
                                      ),
                                      child: ClipOval(
                                        child: isAvailable
                                            ? Image.network(
                                                fit: BoxFit.cover,
                                                myAccountViewModel.userImage)
                                            : Image.asset(
                                                image,
                                                fit: BoxFit.cover,
                                              ),
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 1,
                                      right: 5,
                                      child: Container(
                                        height: 30,
                                        width: 30,
                                        decoration: BoxDecoration(
                                          border: Border.all(
                                              color: AppColors.white,
                                              width: 0.5),
                                          shape: BoxShape.circle,
                                          color: AppColors.primaryColor,
                                        ),
                                        child: Icon(Icons.camera_alt_rounded,
                                            color: AppColors.white, size: 16),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                          SizedBox(height: screenHeight * 0.03),
                          Text(
                            myAccountViewModel.name,
                            style: TextStyle(
                              color: Colors.black,
                              fontSize:
                                  screenWidth * 0.04, // Responsive font size
                              fontWeight: FontWeight.bold,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      );
                    },
                  ),
                ],
              ),
            ),
            _buildListTile(context,
                icon: 'assets/icons/account.png',
                title: l10n.of(context).myAccount,
                onTap: viewModel.navigateToMyAccount),
            _buildListTile(context,
                icon: 'assets/icons/wallet.png',
                title: l10n.of(context).transactions,
                onTap: viewModel.navigateToWallet),
            _buildListTile(context,
                icon: "assets/icons/fav_court.png",
                title: l10n.of(context).favoriteCourts,
                onTap: viewModel.navigateToFavCourtsScreen),
            _buildListTile(context,
                icon: 'assets/icons/favourite.png',
                title: l10n.of(context).myFavouritePlayers,
                onTap: viewModel.navigateToFavouritePlayers),
            _buildListTile(
              context,
              icon: 'assets/icons/notification.png',
              title: l10n.of(context).notifications,
              trailing: SizedBox(
                height: 30,
                width: 46,
                child: FittedBox(
                  fit: BoxFit.cover,
                  child: Consumer<SideDrawerViewModel>(
                    builder: (BuildContext context, viewModel1, Widget? child) {
                      return Switch(
                        value: viewModel1.isNotificationSwitched,
                        activeColor: Colors.white,
                        activeTrackColor: AppColors.primaryColor,
                        inactiveThumbColor: AppColors.white,
                        inactiveTrackColor: AppColors.greyD0D0,
                        trackOutlineColor:
                            WidgetStateProperty.all(Colors.transparent),
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        onChanged: (value) {
                          viewModel1.switchNotification(value, context);
                        },
                      );
                    },
                  ),
                ),
              ),
              onTap: () {},
            ),

            Container(
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 0),
              margin: EdgeInsets.only(left: 14, right: 14, top: 4, bottom: 4),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                      width: 1, color: AppColors.greyDEE3.withOpacity(.3))),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  /// Language Header with Toggle Icon
                  ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    onTap: () {
                      setState(() {
                        _languageExpanded = !_languageExpanded;
                      });
                    },
                    leading: Icon(
                      Icons.language_rounded,
                      size: 20,
                    ),
                    title: Text(l10n.of(context).selectLanguage,
                        style: TextStyle(
                            color: Colors.black, fontSize: screenWidth * 0.04)),
                    trailing: Icon(
                      color: AppColors.black555,
                      _languageExpanded
                          ? Icons.keyboard_arrow_up
                          : Icons.keyboard_arrow_down,
                    ),
                  ),

                  /// Expandable Section
                  if (_languageExpanded)
                    Consumer<LocaleProvider>(
                      builder: (context, localeProvider, child) {
                        return Column(
                          children: [
                            RadioListTile<String>(
                                fillColor: MaterialStateProperty.all(
                                    AppColors.primaryColor),
                                value: "en",
                                groupValue: localeProvider.locale.languageCode,
                                onChanged: (value) => _onLangChange(value!),
                                title: Text(
                                  "${l10n.of(context).english} (EN)" ,
                                  style: TextStyle(
                                    color: AppColors.black555,
                                  ),
                                )),
                            RadioListTile<String>(
                              value: "el",
                              fillColor: MaterialStateProperty.all(
                                  AppColors.primaryColor),
                              groupValue: localeProvider.locale.languageCode,
                              onChanged: (value) => _onLangChange(value!),
                              title: Text(
                                "${l10n.of(context).greek} (GR)",
                                style: TextStyle(
                                  color: AppColors.black555,
                                ),
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                ],
              ),
            ),
            // Container(
            //   margin: EdgeInsets.symmetric(horizontal: 15, vertical: 7),
            //   decoration: BoxDecoration(
            //       borderRadius: BorderRadius.circular(10),
            //       border: Border.all(
            //           width: 1, color: AppColors.greyDEE3.withOpacity(.3))),
            //   child: ListTile(
            //     leading: Icon(Icons.language_rounded),
            //     title: Text("Greek/English",
            //         style: TextStyle(
            //             color: Colors.black, fontSize: screenWidth * 0.04)),
            //     trailing: SizedBox(
            //       height: 30,
            //       width: 46,
            //       child: FittedBox(
            //         fit: BoxFit.cover,
            //         child: Consumer<SideDrawerViewModel>(
            //           builder:
            //               (BuildContext context, viewModel1, Widget? child) {
            //             return Switch(
            //               value: viewModel1.isLanguageSwitched,
            //               activeColor: Colors.white,
            //               activeTrackColor: AppColors.primaryColor,
            //               inactiveThumbColor: AppColors.white,
            //               inactiveTrackColor: AppColors.greyD0D0,
            //               trackOutlineColor:
            //                   WidgetStateProperty.all(Colors.transparent),
            //               materialTapTargetSize:
            //                   MaterialTapTargetSize.shrinkWrap,
            //               onChanged: (value) {
            //                 viewModel1.switchLanguage(value, context);
            //               },
            //             );
            //           },
            //         ),
            //       ),
            //     ),
            //     onTap: () {},
            //   ),
            // ),
            // //in this the state of toggle is not chgiung
            _buildListTile(context,
                icon: 'assets/icons/tc.png',
                title: l10n.of(context).termsAndConditions,
                onTap: viewModel.showTermsAndConditions),
            _buildListTile(context,
                icon: 'assets/icons/tc.png',
                title: l10n.of(context).privacyPolicy,
                onTap: viewModel.showPrivacyPolicy),
            _buildListTile(
              context,
              icon: 'assets/icons/delete2.png',
              title: l10n.of(context).deleteAccount,
              onTap: () {
                print(
                    "data options ${Provider.of<MyAccountViewModel>(NavigationService.context, listen: false).mobileno}");
                print(
                    "data options ${Provider.of<MyAccountViewModel>(NavigationService.context, listen: false).countryCode}");
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return Dialog(
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      child: Stack(
                        clipBehavior: Clip.none, // Allows overflow
                        children: [
                          Padding(
                            padding: EdgeInsets.symmetric(
                                vertical: 20, horizontal: 20),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  padding: EdgeInsets.all(15),
                                  decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                          color: Color(0xFF8DC63F), width: 1)),
                                  child: Image.asset(
                                      "assets/icons/frmdelete.png",
                                      width: 60,
                                      height: 60),
                                ),
                                SizedBox(height: 15),
                                Text(l10n.of(context).deleteAccount,
                                    style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w600)),
                                SizedBox(height: 10),
                                Text(
                                    l10n
                                        .of(context)
                                        .doYouReallyWantToDeleteThisAccount,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontSize: 16,
                                        color: Color(0xFF676769))),
                                SizedBox(height: 20),
                                Padding(
                                  padding: EdgeInsets.symmetric(horizontal: 40),
                                  child: AppButton(
                                    label: l10n.of(context).yesConfirm,
                                    height: 35,
                                    isLoading: viewModel.isLoading,
                                    onPressed: () {
                                      viewModel.deleteAccount(context);
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Positioned(
                            top: -20,
                            right: -15,
                            child: GestureDetector(
                              onTap: () {
                                Navigator.of(context).pop();
                              },
                              child: Container(
                                width: 35,
                                height: 35,
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: AppColors.black),
                                child: Center(
                                  // Ensures the image is centered within the container
                                  child: Icon(CupertinoIcons.clear,
                                      size: 20, color: AppColors.white),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
            _buildListTile(
              context,
              icon: 'assets/icons/logout.png',
              title: l10n.of(context).logout,
              onTap: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return Dialog(
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      child: Stack(
                        clipBehavior: Clip.none, // Allows overflow
                        children: [
                          Padding(
                            padding: EdgeInsets.symmetric(
                                vertical: 20, horizontal: 14),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  padding: EdgeInsets.all(
                                      12), // Adjust padding as needed
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: Color(0xFF8DC63F), // Border color
                                      width: 1, // Border width
                                    ),
                                  ),
                                  child: Image.asset(
                                    "assets/icons/logoutIcon.png",
                                    width: 55,
                                    height: 55,
                                  ),
                                ),
                                SizedBox(height: 15),
                                Text(l10n.of(context).logout,
                                    style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w600)),
                                SizedBox(height: 10),
                                Text(
                                    l10n
                                        .of(context)
                                        .areYouSureYouWantToLogoutYourAccount,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w400,
                                        color: Color(0xFF676769))),
                                SizedBox(height: 20),
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: Color(0xFF8DC63F),
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(10))),
                                  onPressed:viewModel.islogoutloading?null: ()
                                  async {
                                    LocalService.instance.clearAllData();
                                    final prefs =
                                        await SharedPreferences.getInstance();
                                    await prefs
                                        .clear(); // Clears all stored data
                                    await prefs.remove(
                                        'auth_token'); // Removes only the sports list
                                    // Navigator.push(context, MaterialPageRoute(builder: (context) => ChooseSportsToPlayScreen()));
                                    viewModel.logout();
                                  },
                                  child: Text(l10n.of(context).yesConfirm,
                                      style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w600,
                                          color: Colors.black)),
                                ),
                              ],
                            ),
                          ),
                          Positioned(
                            top: -20, // Moves it slightly above the dialog
                            right: -15, // Moves it outside the right border
                            child: GestureDetector(
                              onTap: () {
                                Navigator.of(context).pop(); // Close dialog
                              },
                              child: Container(
                                width: 35, // Match the size of the image
                                height: 35, // Match the size of the image
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors
                                      .black, // Background color of close button
                                ),
                                child: Center(
                                  // Ensures the image is centered within the container
                                  child: Icon(CupertinoIcons.clear,
                                      size: 20, color: AppColors.white),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
            SizedBox(height: screenHeight * 0.04),
            Padding(
                padding: EdgeInsets.all(screenWidth * 0.04),
                child: Center(
                    child: Text('${l10n.of(context).appVersion} 0.0.01',
                        style: TextStyle(
                            color: Colors.grey,
                            fontSize: screenWidth * 0.035)))),
          ],
        ),
      ),
    );
  }

  /// Helper function to create a responsive ListTile
  Widget _buildListTile(
    BuildContext context, {
    required String icon,
    required String title,
    required VoidCallback onTap,
    Color titleColor = Colors.black,
    Color trailingColor = AppColors.black555,
    Widget? trailing,
  }) {
    final double screenWidth = MediaQuery.of(context).size.width;
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 0),
      margin: EdgeInsets.only(left: 14, right: 14, top: 4, bottom: 4),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border:
              Border.all(width: 1, color: AppColors.greyDEE3.withOpacity(.3))),
      child: ListTile(
        contentPadding: EdgeInsets.zero,
        dense: true,
        leading: Image.asset(
          icon,
          width: screenWidth * 0.05, // Responsive icon size
          height: screenWidth * 0.05,
        ),
        title: Text(title,
            style: TextStyle(color: titleColor, fontSize: screenWidth * 0.04)),
        trailing: trailing ??
            Icon(Icons.arrow_forward_ios,
                size: screenWidth * 0.04, color: trailingColor),
        onTap: onTap,
      ),
    );
  }
}
