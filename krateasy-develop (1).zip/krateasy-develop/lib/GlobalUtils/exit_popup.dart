import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:kratEasyApp/generated/l10n.dart';

class ExitConfirmationDialog extends StatelessWidget {
  const ExitConfirmationDialog({super.key});

  static void showExitDialog(BuildContext context) {
    showCupertinoDialog(
      context: context,
      builder:
          (context) => CupertinoAlertDialog(
            title:  Text(l10n.of(context).exitApp),
            content:  Text(l10n.of(context).areYouSureYouWantToExit),
            actions: [
              CupertinoDialogAction(
                onPressed: () => Navigator.of(context).pop(),
                child:  Text(l10n.of(context).cancel),
              ),
              CupertinoDialogAction(
                onPressed: () {
                  SystemNavigator.pop();
                },
                isDestructiveAction: true,
                child:  Text(l10n.of(context).exit),
              ),
            ],
          ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
