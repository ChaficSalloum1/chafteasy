// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';

// class RuleItem extends StatelessWidget {
//   final String text;
//   RuleItem({required this.text});

//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 4.0),
//       child: Row(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Image.asset(
//             'assets/icons/tick.png', // Ensure this file is in assets folder
//             width: 20,
//             height: 17,
//           ),
//           SizedBox(width: 8),
//           Expanded(
//             child: Text(
//               text,
//               style: TextStyle(fontSize: 12, color: Color(0xFF555555)),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }


// Api data 
//  "this is best game\nfollow all rules\nkkkk\nkkk",

import 'package:flutter/material.dart';

class RuleList extends StatelessWidget {
  final String text;

  RuleList({required this.text});

  @override
  Widget build(BuildContext context) {
    final List<String> rules = text.split('\n');

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: rules
          .where((rule) => rule.trim().isNotEmpty) // Skip empty lines
          .map((rule) => RuleItem(text: rule.trim()))
          .toList(),
    );
  }
}

class RuleItem extends StatelessWidget {
  final String text;

  RuleItem({required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Image.asset(
            'assets/icons/tick.png',
            width: 20,
            height: 17,
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: TextStyle(fontSize: 12, color: Color(0xFF555555)),
            ),
          ),
        ],
      ),
    );
  }
}
