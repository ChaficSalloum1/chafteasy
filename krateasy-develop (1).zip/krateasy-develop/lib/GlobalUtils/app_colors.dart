import 'dart:ui';

class AppColors{
  static const primaryColor = Color(0xFF8DC63F);
  static const lightPrimaryColor9EC = Color(0xFFF4F9EC);
  static const lightPrimaryColorFFE5 = Color(0xFFF5FFE5);
  static const green8B2 = Color(0xFFD1E8B2);
  static const tealLight = Color(0xFFA5BFC3);



  // dark
  static const dark747D = Color(0xFF3B747D);

  // default
  static const white = Color(0xFFffffff);
  static const black = Color(0xFF000000);
  static const lightGold = Color(0xFFFFF4D1);
  static const lightWhiteBF1 = Color(0xFFF7FBF1);
  static const lightYellowF9EC = Color(0xFFF4F9EC);
  static const greenCF3 = Color(0xFFF8FCF3);

  // red
  static const red323 = Color(0xFFDD2323);
  // black
  static const black555 = Color(0xFF555555);
  static const blackA2A = Color(0xFF2A2A2A);

  // grey + green
  static const greyGreen47D = Color(0xFF3B747D);
  static const greyGreen63F = Color(0xFF8DC63F);

  // green
  static const green033 = Color(0xFF72A033);
  static const green67B = Color(0xFF3D767B);
  static const greenC748 = Color(0xFF16C748);
  static const lightGreen = Color(0xFFF4F9EC);
  static const dark348Green62ELg = [
    Color(0xFF044349), // Dark Green
    Color(0xFF61862E), // Olive Green
  ];
  // grey
  static const grey3E3 = Color(0xFFE3E3E3);
  static const grey8A8 = Color(0xFFA8A8A8);
  static const grey585 = Color(0xFF858585);
  static const grey1E1 = Color(0xFFE1E1E1);
  static const grey769 = Color(0xFF676769);
  static const greyD0D0 = Color(0xFFD0D0D0);
  static const greyD9D9 = Color(0xFFD9D9D9);
  static const greyDEE3 = Color(0xFFDEDEE3);
  static const greyE9EA = Color(0xFFE9E9EA);
  static const greyEFEF = Color(0xFFEFEFEF);
  static const greyBEBE = Color(0xFFBEBEBE);
  static const greyE6E6 = Color(0xFFE6E6E6);
  static const greyE5E5 = Color(0xffE5E5E5);
  
  //teal color
  static const deepTeal = Color(0xFF3B747D);
  static const teal747D = Color(0xFF3B747D);


  

}