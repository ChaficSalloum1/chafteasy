import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';


class CommonTitleScaffold extends StatefulWidget {
  CommonTitleScaffold({
    super.key,
    this.isBackVisible = false,
    this.isMenuButtonVisible = false,
    this.onMenuPressed,
    this.onMenuSelected,
    this.menuItems,
    this.height,
    this.floatingActionButton,
    this.onFilterPressed,
    this.isFilterButtonVisible,
    required this.title,
    required this.body,
    this.isSearchBarVisible = false,
    this.hintSearch,
    this.onSearch,
    this.onSearchCLear,
    this.searchController,
    this.searchFocusNode,
    this.endDrawer,
    this.scaffoldKey,
    this.actionWidget1,
  });

  final String title;
  final Widget body;
  final Widget? floatingActionButton;
  final bool? isBackVisible;
  final double? height;
  bool? isFilterButtonVisible = false;
  final VoidCallback? onFilterPressed;
  final bool? isMenuButtonVisible;
  final VoidCallback? onMenuPressed;
  final Key? scaffoldKey;
  final void Function(String)? onMenuSelected;
  final List<PopupMenuEntry<String>>? menuItems;

  // New properties for the search bar
  final bool isSearchBarVisible;
  final String? hintSearch;
  final Drawer? endDrawer;
  final TextEditingController? searchController;
  final FocusNode? searchFocusNode;
  final void Function(String)? onSearch;
  final void Function(String)? onSearchCLear;
  final Widget? actionWidget1 ;

  @override
  State<CommonTitleScaffold> createState() => _CommonTitleScaffoldState();
}

class _CommonTitleScaffoldState extends State<CommonTitleScaffold> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: widget.scaffoldKey ,

      floatingActionButton: widget.floatingActionButton ,
      endDrawer : widget.endDrawer,
      appBar: AppBar(
          title: Text(widget.title) ,
      ),
      body: Column(
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(50),
                topRight: Radius.circular(50),
              ),
              child: Container(
                height: widget.height ?? MediaQuery.of(context).size.height - MediaQuery.of(context).size.height * 0.1,
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(color: AppColors.white),
                child: widget.body,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

