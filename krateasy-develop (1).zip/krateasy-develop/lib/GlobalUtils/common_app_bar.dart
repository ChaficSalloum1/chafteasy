import 'package:flutter/material.dart';
import 'package:kratEasyApp/GlobalUtils/app_colors.dart';
import 'app_navigation.dart';

PreferredSizeWidget CommonAppBar({
  String? title,
  Widget? titleWidget,
  double? toolBarHeight,
  Color? backgroundColor,
  Color? bg,
  List<Widget>? action,
  Widget? leading,
  bool isBack = true,
  bool? centerTile,
  bool isLeading = true,
  Color? backIconColor,
  double fontsize = 18,
  VoidCallback? onTap,
  FontWeight ?fontWeight,
}) {
  return AppBar(
    elevation: 0,
    centerTitle: centerTile ?? true,
    toolbarHeight: toolBarHeight,
    backgroundColor: bg ?? Colors.white,
    automaticallyImplyLeading: false,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(bottom: Radius.circular(0)),
    ),
    leading: isBack
        ? GestureDetector(
            onTap: onTap ??
                () {
                  Navigator.of(NavigationService.navigatorKey.currentContext!)
                      .pop(); // <-- Add () here
                },
            child: isLeading
                ? Row(
                    children: [
                      SizedBox(
                        width: 7,
                      ),
                      Container(
                        width: 32,
                        height: 32,
                        margin: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: const Color(0xFF8DC63F),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(5),
                          child: Icon(
                            Icons.arrow_back_ios_rounded,
                            color: backIconColor ?? Colors.white,
                            size: 19,
                          ),
                        ),
                      ),
                    ],
                  )
                : const SizedBox(),
          )
        : null,
    title: titleWidget ??
        Text(
          title ?? '',
          style: TextStyle(
            fontFamily: "Outfit",
            fontSize: fontsize,
            fontWeight: fontWeight??FontWeight.normal,
            color: AppColors.black,
          ),
        ),
    actions: action,
  );
}
