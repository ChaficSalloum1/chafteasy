import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/material.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'app_colors.dart';

class CommonDropdownMenu<T> extends StatelessWidget {
  final List<T> items;
  final T? initialSelection ;
  final String hintText;
  final void Function(T?)? onSelected;
  final String Function(T) displayLabel;
  final EdgeInsets expandedInsets;
  final EdgeInsets contentPadding;
  final Color fillColor;
  final Color? borderColor;
  final bool isInitialSelected;
  final bool? enableSearch;
  final TextStyle? textStyle;
  final String? errorText ;
  final Key? key ;

  CommonDropdownMenu({
    required this.items,
    required this.hintText,
    required this.onSelected,
    required this.displayLabel,
    this.expandedInsets = const EdgeInsets.symmetric(horizontal: 8.0),
    this.contentPadding = const EdgeInsets.symmetric(vertical: 0, horizontal: 8.0),
    this.fillColor = Colors.white,
    this.isInitialSelected = false,
    this.initialSelection ,
    this.textStyle,
    this.borderColor,
    this.errorText,
    this.key,
    this.enableSearch,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(10),
      ),
      child: DropdownMenu<T>(
        expandedInsets: expandedInsets,
        errorText: errorText,
        key: key,

        enableSearch: enableSearch ?? false,
        textStyle: textStyle,
        // menuHeight: 50,
        // initialSelection: isInitialSelected ? items[0] : null ,
        initialSelection: initialSelection != null ? (initialSelection ?? items[0] ): null ,
        inputDecorationTheme: InputDecorationTheme(
          contentPadding: contentPadding,
          outlineBorder: const BorderSide(
            color: Colors.transparent,
            width: 0,
          ),
          enabledBorder: InputBorder.none,
          disabledBorder: InputBorder.none,
          border: InputBorder.none,
          activeIndicatorBorder: BorderSide.none,
          focusedBorder: InputBorder.none,
          filled: true,
          constraints: const BoxConstraints(),
          fillColor: fillColor,
        ),
        hintText: hintText,
        onSelected: onSelected,
        dropdownMenuEntries: items.map<DropdownMenuEntry<T>>((T value) {
          return DropdownMenuEntry<T>(
            value: value,
            label: displayLabel(value),
          );
        }).toList(),
      ),
    );
  }
}


class CommonDropDownObject extends StatelessWidget {
  final List<String> items;
  final String? initialSelection;
  final String? hintText;
  final String selectedValue;
  final ValueChanged<String> onChanged;
  final Key? key ;
  final String? errorText ;
  final Color? fillColor ;
  final bool? enableSearch ;

  const CommonDropDownObject({
    required this.items,
    required this.selectedValue ,
    required this.onChanged ,
    this.errorText ,
    this.initialSelection,
    this.key,
    this.hintText,
    this.fillColor,
    this.enableSearch,
  });

  @override
  Widget build(BuildContext context) {
    return CommonDropdownMenu(
      items: items,
      initialSelection: initialSelection,
      key: key,
      fillColor: fillColor ?? Colors.white,
      errorText: errorText,
      hintText: hintText ?? l10n.of(context).select,
      enableSearch : enableSearch,
      onSelected: (newValue) {
        if (newValue != null) {
          onChanged(newValue.toString());
        }
      },
      displayLabel: (val) => "$val",
    );
  }
}

class CommonDropDownObjectNew extends StatelessWidget {
  final DropdownSearchOnFind<String> items;
  final String? initialSelection;
  final String? hintText;
  final String selectedValue;
  final ValueChanged<String> onChanged;
  final Key? key;
  final String? errorText;
  final Color? fillColor;
  final bool? enableSearch;

  const CommonDropDownObjectNew({
    required this.items,
    required this.selectedValue,
    required this.onChanged,
    this.errorText,
    this.initialSelection,
    this.key,
    this.hintText,
    this.fillColor,
    this.enableSearch,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      decoration: BoxDecoration(
        color: fillColor ?? Colors.white,
        borderRadius: BorderRadius.circular(10),
      ),
      child: DropdownSearch<String>(
        decoratorProps:
          DropDownDecoratorProps(
          decoration: InputDecoration(
            hintText: hintText,
            border: InputBorder.none,
          ),
        ),
        items: items,
        onChanged: (val) {
          if (val != null) {
            onChanged(val);
          }
        },
        selectedItem: selectedValue,
        popupProps: PopupProps.menu(
          showSearchBox: enableSearch ?? false,
        ),

        dropdownBuilder: (context, selectedItem) {
          return Text(
            (selectedItem == null || selectedItem == "") ? hintText ?? l10n.of(context).select : selectedItem,
            style: TextStyle(color: Colors.black),
          );
        },
        validator: errorText != null
            ? (value) => value == null || value.isEmpty ? errorText : null
            : null,
      ),
    );
  }
}
