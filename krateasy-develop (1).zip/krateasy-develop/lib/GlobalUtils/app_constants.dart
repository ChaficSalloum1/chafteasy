class AppConstants {

  // static String appCurrency = "${AppConstants.appCurrency}" ;
  static String appCurrency = "€" ;

}