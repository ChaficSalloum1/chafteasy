import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/Localization/locale_provider.dart';
import 'package:kratEasyApp/ViewModel/modifyBookingModel.dart';
// import 'package:kratEasyApp/ViewModel/FacilityBookViewModel/BookingDetailsViewModel.dart';
import 'package:provider/single_child_widget.dart';

import '../paymentprovider.dart';

class AppProviders {
  static List<SingleChildWidget> providers = [
    ChangeNotifierProvider(create: (_) => SplashViewModel()),
    // ChangeNotifierProvider(create: (_) => LocaleProvider()),
    ChangeNotifierProvider(create: (_) => OnboardingViewModel()),
    ChangeNotifierProvider(create: (_) => LoginViewModel()),
    ChangeNotifierProvider(create: (_) => SignupViewModel()),
    ChangeNotifierProvider(create: (_) => VerificationViewModel()),
    ChangeNotifierProvider(create: (_) => SetPasswordViewModel()),
    ChangeNotifierProvider(create: (_) => CompleteProfileViewModel()),
    ChangeNotifierProvider(create: (_) => ProfileCompletedViewModel()),
    ChangeNotifierProvider(create: (_) => ForgotPasswordViewModel()),
    ChangeNotifierProvider(create: (_) => VerificationResetPassViewModel()),
    ChangeNotifierProvider(create: (_) => ResetPasswordViewModel()),
    ChangeNotifierProvider(create: (_) => ResetPasswordSuccessViewModel()),
    ChangeNotifierProvider(create: (_) => DashboardViewModel()),
    ChangeNotifierProvider(create: (_) => MyAccountViewModel()),
    ChangeNotifierProvider(create: (_) => EditScreenViewModel()),
    ChangeNotifierProvider(create: (_) => TermsAndConditionsViewModel()),
    ChangeNotifierProvider(create: (_) => PrivacyPolicyViewModel()),
    ChangeNotifierProvider(create: (_) => HomeViewModel(SearchCourtsApi())),
    ChangeNotifierProvider(create: (_) => NotificationsViewModel()),
    // ChangeNotifierProvider(create: (_) => OpeningsViewModel()),
    ChangeNotifierProvider(create: (_) => ChallengeViewModel()),
    ChangeNotifierProvider(create: (_) => CreateChallengeViewModel()),
    ChangeNotifierProvider(create: (_) => FacilitiesViewModel()),
    ChangeNotifierProvider(create: (_) => FeaturedFacilityViewModel()),
    ChangeNotifierProvider(create: (_) => SideDrawerViewModel()),
    ChangeNotifierProvider(create: (_) => MyBookingsViewModel()),
    ChangeNotifierProvider(create: (_) => ActiveChallengeViewModel()),
    ChangeNotifierProvider(create: (_) => CompletedChallengeViewModel()),
    ChangeNotifierProvider(create: (_) => CompletedBookingViewModel()),
    ChangeNotifierProvider(create: (_) => UpComingViewModel()),
    ChangeNotifierProvider(create: (_) => WalletViewModel()),
    // ChangeNotifierProvider(create: (_) => AddAmountViewModel()),
    // ChangeNotifierProvider(create: (_) => ShowTxnDetailsViewModel()),
    // ChangeNotifierProvider(create: (_) => FacilityAddFriendsViewModel()),
    ChangeNotifierProvider(create: (_) => CheckoutViewModel()),
    // ChangeNotifierProvider(create: (_) => SuccessPaymentViewModel()),
    // ChangeNotifierProvider(create: (_) => BookingDetailsViewModel()),
    ChangeNotifierProvider(create: (_) => MyFavouriteViewModel()),
    ChangeNotifierProvider(create: (_) => NearbyCourtsViewModel()),
    ChangeNotifierProvider(create: (_) => BookingProvider()),
    ChangeNotifierProvider(create: (_) => ChooseSportsViewModel()),
    ChangeNotifierProvider(create: (_) => MyLocationViewModel()),
    ChangeNotifierProvider(
        create: (_) => SearchCourtViewModel(SearchCourtsApi())),
    // ChangeNotifierProvider(create: (_) => CourtGuestTabViewModel()),
    ChangeNotifierProvider(create: (_) => AvailableChallengeGuestViewModel()),
    ChangeNotifierProvider(create: (_) => ModifybookingModel()), // ✅ Add this

    ChangeNotifierProvider(create: (_) => PaymentProvider()),

  ];
}
