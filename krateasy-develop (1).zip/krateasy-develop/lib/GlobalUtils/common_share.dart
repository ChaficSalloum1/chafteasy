import 'dart:io';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

Future<void> openWhatsAppChat(String phoneNumber) async {
  var androidUrl = "whatsapp://send?phone=$phoneNumber";
  var iosUrl = "https://wa.me/$phoneNumber";
  try {
    if (Platform.isIOS) {
      await launchUrl(Uri.parse(iosUrl));
    } else {
      await launchUrl(Uri.parse(androidUrl));
    }
  } on Exception {
    // toast('WhatsApp is not installed !');
  }
}

Future<void> openDialer(String phoneNumber) async {
  // Ensure the phone number is formatted correctly
  final uri = Uri.parse('tel:$phoneNumber');
  if (await canLaunchUrl(uri)) {
    await launchUrl(uri);
  } else {
    print('Could not launch $uri');
  }
}

Future<void> openEmail(
  String emailAddress, {
  String? subject,
  String? body,
}) async {
  final Uri emailUri = Uri(
    scheme: 'mailto',
    path: emailAddress,
    query: encodeQueryParameters(<String, String>{'subject': "$subject"}),
  );

  if (await canLaunchUrl(emailUri)) {
    await launchUrl(emailUri);
  } else {
    print('Could not launch $emailUri');
  }
}

String? encodeQueryParameters(Map<String, String> params) {
  return params.entries
      .map(
        (MapEntry<String, String> e) =>
            '${Uri.encodeComponent(e.key)}=${Uri.encodeComponent(e.value)}',
      )
      .join('&');
}

String? _buildQuery(String? subject, String? body) {
  final queryParameters = <String, String>{};
  if (subject != null) queryParameters['subject'] = subject;
  if (body != null) queryParameters['body'] = body;

  return Uri(queryParameters: queryParameters).query;
}

Future<void> openLink(String url) async {
  try {
    // Ensure the URL has a scheme (http/https)
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://$url'; // Default to https
    }

    final Uri uri = Uri.parse(url);

    // Check if the URL can be launched
    if (true) {
      await launchUrl(
        uri,
        mode: LaunchMode.externalApplication,
      ); // Force open in an external browser
    }
  } catch (e) {
    //   printLog('Error launching URL: $e');
    //   toast('Error launching URL!');
  }
}

Future<void> shareData(String data) async {
  try {
    await Share.share("Checkout our app: \n $data");
  } catch (e) {
    //   printLog('Error launching URL: $e');
    //   toast('Error launching URL!');
  }
}

///

final ValueNotifier<bool> isSharingNotifier = ValueNotifier<bool>(false);
Future<void> shareDataNew(
    String data, ValueNotifier<bool> isSharingNotifier) async {
  if (isSharingNotifier.value) return; // Prevent multiple taps

  isSharingNotifier.value = true;

  try {
    await Share.share("Checkout our app: \n$data");
  } catch (e) {
    // Handle error if needed
  } finally {
    isSharingNotifier.value = false;
  }
}
