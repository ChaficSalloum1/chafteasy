class AppImages{
  // Icons
  static const String iconPath = "assets/svg";
  static const String iconPathPng = "assets/png";
  static const String svgSearch = "$iconPath/svg_search.svg";
  static const String svgFilter = "$iconPath/svg_filter.svg";
  static const String svgMenu = "$iconPath/svg_menu.svg";
  static const String svgSort = "$iconPath/svg_sort.svg";
  static const String svgCalender = "$iconPath/svg_calender.svg";
  static const String svgClock = "$iconPath/svg_clock.svg";
  static const String svgCoins = "$iconPath/svg_coins.svg";
  static const String svgDistance = "$iconPath/svg_distance.svg";
  static const String pngUser = "$iconPathPng/user.png";
  static const String pngRightClick = "$iconPathPng/right_click.png";
  static const String pngVideo = "$iconPathPng/png_video.png";
  static const String pngBg = "$iconPathPng/bg_image.png";
  static const String pngSmallBg = "$iconPathPng/small_image.png";
  static const String pngPrivateIcon = "$iconPathPng/private_icon.png";
  static const String pngPublicIcon = "$iconPathPng/public_icon.png";
  static const String pngBar = "$iconPathPng/bar.png";
  static const String pngSwiming = "$iconPathPng/swiming.png";
  static const String pngGym = "$iconPathPng/gym.png";
  static const String pngDialogCancel = "$iconPathPng/dialog_cancel.png";
  static const String pngDialogLke = "$iconPathPng/dialog_like.png";
  static const String pngDialogCross = "$iconPathPng/dialog_cross.png";
  static const String pngLocationCircle = "$iconPathPng/location_circle.png";
  static const String pngLocationGreen = "$iconPathPng/location_green.png";
  static const String pngLocationGrey = "$iconPathPng/location_grey.png";
  static const String pngCourtBooking = "$iconPathPng/court_booking.png";
  static const String pngFeedsBg = "$iconPathPng/feeds_bg.png";
  static const String pngFeedsBigBG = "$iconPathPng/feeds_big_image.png";
  static const String pngRate = "$iconPathPng/rate_grey.png";
  static const String pngQrCode = "assets/png/qr_code.png";
  static const String pngTick = "assets/icons/tick.png";
  static const String pngMap = "assets/icons/map.png";
}