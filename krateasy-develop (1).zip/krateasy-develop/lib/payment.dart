import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/paymentprovider.dart';

import 'API_CALLS/GlobalAPIUtils.dart';

class VivaWebViewScreen extends StatefulWidget {
  final String checkoutUrl;
  final int orderCode;
  final String? bookingId;
  final String? userId;
  final dynamic amount;
  final bool isSplit;

  const VivaWebViewScreen({
    Key? key,
    required this.checkoutUrl,
    required this.orderCode,
    required this.amount,
    required this.bookingId,
    required this.userId,
    required this.isSplit,
  }) : super(key: key);

  @override
  State<VivaWebViewScreen> createState() => _VivaWebViewScreenState();
}

class _VivaWebViewScreenState extends State<VivaWebViewScreen> {
  late final WebViewController _controller;
  bool _loading = true;

  bool _handledSuccess = false;
  bool _resultSent = false;

  static String kBackendUrl = GlobalAPIUtils.getBaseUrl();
  final authToken = GlobalAPIUtils.getAuthToken();

  // (No longer needed but safe to keep if you use elsewhere)
  static const Duration kAutoCloseDelay = Duration(seconds: 3);
  Timer? _autoCloseTimer;

  static const String kHost = '103.189.173.7';
  static const int kPort = 7881;
  static const String kSuccessPath = '/success';

  /// NEW: prevent dialog duplication
  bool _successDialogShowing = false;

  @override
  void initState() {
    super.initState();

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) => setState(() => _loading = true),
          onPageFinished: (url) {
            setState(() => _loading = false);
            _maybeHandleRedirect(url);
          },
          onNavigationRequest: (request) {
            _maybeHandleRedirect(request.url);
            return NavigationDecision.navigate;
          },
          onWebResourceError: (err) {
            debugPrint('Web error: ${err.errorCode} ${err.description}');
          },
        ),
      )
      ..loadRequest(Uri.parse(widget.checkoutUrl));
  }

  @override
  void dispose() {
    _autoCloseTimer?.cancel();
    super.dispose();
  }

  Future<void> _updatePaymentIntent(String sessionId) async {
    try {
      final response = await http.post(
        Uri.parse('$kBackendUrl/app/payment/update-payment-intent'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $authToken',
        },
        body: jsonEncode({
          'sessionId': sessionId
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        debugPrint(
            '✅ PaymentIntent updated: ${data['payment']['paymentIntentId']}');
      } else {
        debugPrint('❌ Error  PaymentIntent: ${response.statusCode}');
        debugPrint('Response: ${response.body}');
      }
    } catch (e) {
      debugPrint('❌ Excepción  PaymentIntent: $e');
    }
  }

  void _maybeHandleRedirect(String url) async {
    if (!mounted || _handledSuccess) return;

    final uri = Uri.tryParse(url);
    if (uri == null) return;

    debugPrint('WebView URL => $url');

    // ✅ Check if URL contains "success" anywhere
    if (url.toLowerCase().contains("success")) {
      _handledSuccess = true;

      final sessionId = uri.queryParameters['session_id'];
      context.read<PaymentProvider>().setSessioid(sessionId ?? "");
      debugPrint("✅ Session ID: $sessionId");

      // ✅ ACTUALIZAR: Llamar al endpoint para actualizar el PaymentIntent
      if (sessionId != null && sessionId.isNotEmpty) {
       await _updatePaymentIntent(sessionId);
      } else {
        debugPrint('⚠️ Session ID no encontrado en la URL');
      }

      // Ensure page is loaded
      await _ensureLoadedInWebView(uri);

      // Show success dialog
      _showSuccessDialog();
    }

    // (Optional) handle cancel/failed
    if (url.toLowerCase().contains("canceled") ||
        url.toLowerCase().contains("failed")) {
      _sendResult(false);
    }
  }

  Future<void> _ensureLoadedInWebView(Uri uri) async {
    final current = await _controller.currentUrl();
    if (current != uri.toString()) {
      await _controller.loadRequest(uri);
    }
  }

  /// NEW: success dialog
  Future<void> _showSuccessDialog() async {
    if (!mounted || _successDialogShowing) return;
    _successDialogShowing = true;

    await showDialog<void>(
      context: context,
      barrierDismissible: false, // force explicit tap
      builder: (ctx) {
        return AlertDialog(
          title: const Text('Payment Successful'),
          content: Text(
            'Paid successfully.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                // Close the dialog first…
                Navigator.of(ctx, rootNavigator: true).pop();
                // …then return success
                _sendResult(true);
              },
              child: const Text('Continue'),
            ),
          ],
        );
      },
    );

    _successDialogShowing = false;
  }

  void _sendResult(bool success) {
    if (!mounted || _resultSent) return;
    _resultSent = true;
    Navigator.of(context).pop(success);
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        _sendResult(_handledSuccess);
        return false;
      },
      child: Scaffold(
        backgroundColor: AppColors.primaryColor,
        appBar: AppBar(
          title: const Text('Payment'),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => _sendResult(_handledSuccess),
          ),
        ),
        body: Stack(
          children: [
            WebViewWidget(controller: _controller),
            if (_loading) const LinearProgressIndicator(minHeight: 2),
          ],
        ),
      ),
    );
  }
}
