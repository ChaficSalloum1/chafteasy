import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/cupertino.dart';
import 'package:kratEasyApp/API_CALLS/GlobalAPIUtils.dart';
import 'package:kratEasyApp/payment.dart';
import 'package:kratEasyApp/stripe_payment_detail_model.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'GlobalUtils/app_imports.dart';

class PaymentProvider with ChangeNotifier {
  int _orderid = 0;

  int get orderid => _orderid;

  bool _success = false;

  bool get success => _success;

  bool _loading = false;

  bool get loading => _loading;

  setloadding(bool value) {
    _loading = value;
    notifyListeners();
  }

  String? _trnid;

  String? _bookingId;

  String? get bookingId => _bookingId;

  String? get trnid => _trnid;

  setBookingId(String? id) {
    _bookingId = id;
    notifyListeners();
  }

  settrnid(String? id) {
    _trnid = id;
    notifyListeners();
  }

  setstauts(bool value) {
    _success = value;
    notifyListeners();
  }

  setOrderid(int value) {
    _orderid = value;
    notifyListeners();
  }

  final String accessToken =
      'eyJhbGciOiJSUzI1NiIsImtpZCI6IjBEOEZCOEQ2RURFQ0Y1Qzk3RUY1MjdDMDYxNkJCMjMzM0FCNjVGOUZSUzI1NiIsIng1dCI6IkRZLTQxdTNzOWNsLTlTZkFZV3V5TXpxMlg1OCIsInR5cCI6ImF0K2p3dCJ9.eyJpc3MiOiJodHRwczovL2RlbW8tYWNjb3VudHMudml2YXBheW1lbnRzLmNvbSIsIm5iZiI6MTc1MDgyOTE0OSwiaWF0IjoxNzUwODI5MTQ5LCJleHAiOjE3NTA4MzI3NDksImF1ZCI6WyJiaXNlcnZpY2VzX2FwaSIsImNvcmVfYXBpIiwiZWNyX2FwaSIsImh0dHBzOi8vZGVtby1hY2NvdW50cy52aXZhcGF5bWVudHMuY29tL3Jlc291cmNlcyJdLCJzY29wZSI6WyJ1cm46dml2YTpwYXltZW50czpiaXNlcnZpY2VzOm1lcmNoYW50YXBpIiwidXJuOnZpdmE6cGF5bWVudHM6Y29yZTphcGk6YWNxdWlyaW5nIiwidXJuOnZpdmE6cGF5bWVudHM6Y29yZTphcGk6YWNxdWlyaW5nOnRyYW5zYWN0aW9ucyIsInVybjp2aXZhOnBheW1lbnRzOmNvcmU6YXBpOmlzdiIsInVybjp2aXZhOnBheW1lbnRzOmNvcmU6YXBpOm5hdGl2ZWNoZWNrb3V0djIiLCJ1cm46dml2YTpwYXltZW50czpjb3JlOmFwaTpyZWRpcmVjdGNoZWNrb3V0IiwidXJuOnZpdmE6cGF5bWVudHM6ZWNyOmFwaSJdLCJjbGllbnRfaWQiOiI0NXQ0dzgzbHJqbTJ4Mm16dTIwNG5mejBieGVpN2Nvazd6dTh2bGI1MGV4eTQuYXBwcy52aXZhcGF5bWVudHMuY29tIiwidXJuOnZpdmE6cGF5bWVudHM6Y2xpZW50X3BlcnNvbl9pZCI6IjcyNDQ0RkIxLTBENkEtNDI1RC05MjZELTlGNEQxNTY2Q0VBOSJ9.Q9xoZqMRTS44poKyHE5ucIoAS0_oJNZXQOnK9z6e17_0sOGINoR5wawkKUrAEpqCHlINweajr3vRRTuzP7c_YS3a3StMPmAklTM-Z2Xny6UgxRSGNhORtgKhgjZK2HkPkECWtLORP-CStEArvQzplfsvyNQ8qIoToJRWGXnA0-b6OceEi_sFRa3qrRpVWlGi67al5WjLbvoaZZBvsIQCF6emOAXWAtGa1oDc5cQcuSsu_UfEVgccldr_sDwbkVfQd179XBvSfwusTxim5KeWXURAssY47vjYms9Vkv6hoFs-Y33WreLsTteZNmOSyKWoXpnktBaHEsYHDDeUY_77Pw';

  Future<void> createOrderWithToken(
      BuildContext context,
      dynamic amount,
      bool isSplit,
      String email,
      String name,
      String phone,
      // String? ownerid,
      String countryCode,
      String? challengeid,
      String? friendid,
      {String type = 'challenge'}) async {
    try {
      setloadding(true);
      setstauts(false);

      String? authToken = await GlobalAPIUtils.getAuthToken();
      debugPrint('AuthToken: $authToken');

      if (authToken == null || authToken.isEmpty) {
        throw 'Auth token is null or empty';
      }

      final url = Uri.parse(
        'https://backend.krateasy.gr/api/app/wallet/viva/create-order',
      );

      final Map<String, dynamic> orderData = {
        "amount": double.parse(amount.toString()),
        "isSplit": isSplit,
        "type": type,
        "facility_ownerid": context.read<BookingProvider>().ownerid,
        "payer": {
          "email": email,
          "fullName": name,
          "phone": phone,
          "countryCode": countryCode
        },
        "challengeId": challengeid ?? "",
        "description": "Booking amount",
        "merchantNote": "Full",
        "friendId": friendid ?? "",
      };

      debugPrint('Sending request: ${jsonEncode(orderData)}');

      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $authToken',
        },
        body: jsonEncode(orderData),
      );

      debugPrint('Response status: ${response.statusCode}');
      debugPrint('Response body: ${response.body}');

      setloadding(false);

      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        final checkoutUrl = jsonResponse['checkoutUrl'];
        final orderCode = jsonResponse['orderCode'];
        setOrderid(orderCode);

        final result = await Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => VivaWebViewScreen(
              checkoutUrl: checkoutUrl,
              orderCode: 2333, // replace with orderCode when you wire it
              amount: amount,
              userId: friendid,
              bookingId: bookingId,
              isSplit: isSplit,
            ),
          ),
        );
      } else {
        // Show actual error message
        final errorBody = jsonDecode(response.body);
        throw 'Failed to create order: ${errorBody['message'] ?? 'Unknown error'}';
      }
    } catch (e, stackTrace) {
      setloadding(false);
      debugPrint('Exception in createOrderWithToken: $e');
      debugPrint('StackTrace: $stackTrace');

      // Optionally show user an error
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Error: $e'),
        backgroundColor: Colors.red,
      ));
    }
  }

  // Future<void> createOrderWithToken(
  //   BuildContext context,
  //   dynamic amount,
  //   bool isSplit,
  //   String email,
  //   String name,
  //   String phone,
  //   String countryCode,
  //     String ?challengeid,
  //     String ? friendid,{String type = 'challenge'}
  // )
  // async {
  //   setloadding(true);
  //   setstauts(false);
  //   String? authToken = await GlobalAPIUtils.getAuthToken();
  //   print('authToken');
  //   print(authToken);
  //   final url = Uri.parse(
  //       'https://backend.krateasy.gr/api/app/wallet/viva/create-order');
  //
  //   final Map<String, dynamic> orderData = {
  //     "amount": double.parse(amount.toString()),
  //     "isSplit": isSplit,
  //     "type": type,
  //     "payer": {
  //       "email": email,
  //       "fullName": name,
  //       "phone": phone,
  //       "countryCode": countryCode
  //     },
  //     "challengeId":challengeid??"",
  //     "description": "Booking amount",
  //     "merchantNote": "Full",
  //     "friendId":friendid??"",
  //   };
  //
  //   print('Sending request: ${jsonEncode(orderData)}');
  //
  //   final response = await http.post(
  //     url,
  //     headers: {
  //       'Content-Type': 'application/json',
  //       'Authorization': 'Bearer $authToken',
  //     },
  //     body: jsonEncode(orderData),
  //   );
  //
  //
  //
  //   if (response.statusCode == 200) {
  //     final jsonResponse = jsonDecode(response.body);
  //     final checkoutUrl = jsonResponse['checkoutUrl'];
  //     final orderCode = jsonResponse['orderCode'];
  //     setOrderid(jsonResponse['orderCode']);
  //     // Open in WebView and wait for result
  //     setloadding(false);
  //
  //
  //     final result = await Navigator.push(
  //       context,
  //       MaterialPageRoute(
  //         builder: (_) => VivaWebViewScreen(
  //           checkoutUrl: checkoutUrl,
  //           orderCode: orderCode,
  //           amount: amount,
  //           isSplit: isSplit,
  //         ),
  //       ),
  //     );
  //
  //   } else {
  //
  //     setloadding(false);
  //     throw 'Failed to create Viva payment order';
  //   }
  // }

  Future<bool> checkTransactionStatus(
      BuildContext context, int orderCode, dynamic amount, bool isSplit) async {
    settrnid(null);
    final statusUrl = Uri.parse(
        'https://backend.krateasy.gr/api/app/wallet/viva/getTransaction?orderCode=$orderCode');

    final response = await http.get(statusUrl);

    if (response.statusCode == 200) {
      final statusData = jsonDecode(response.body);
      final transactionId = statusData['transactionId'];

      settrnid(statusData['transactionId']);
      setstauts(true);
      await showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text("Payment Success"),
          content: Text("Status: Success"),
          actions: [
            TextButton(
              onPressed: () async {
                Navigator.pop(context); // Close dialog
                Navigator.pop(context); // Maybe close WebView or screen?
                // if (isSplit) {
                //   await captureTransaction(
                //     context: context,
                //     amount: double.parse(amount.toString()),
                //     transactionId: transactionId,
                //     isSplit: isSplit,
                //   );
                // }
              },
              child: Text("OK"),
            )
          ],
        ),
      );

      return true;
    } else {
      await showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text("Payment Failed"),
          content: Text("Status: Failed"),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("OK"),
            )
          ],
        ),
      );
      return false;
    }
  }

  Future<void> captureTransaction({
    required BuildContext context,
    required dynamic amount,
    required String transactionId,
    required bool isSplit,
  }) async {
    String? authToken = await GlobalAPIUtils.getAuthToken();
    final url = Uri.parse(
        'https://backend.krateasy.gr/api/app/wallet/viva/captureTransaction');

    final Map<String, dynamic> captureData = {
      "amount": double.parse(amount.toString()),
      "transactionId": transactionId,
      "isSplit": isSplit,
    };

    final response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $authToken',
      },
      body: jsonEncode(captureData),
    );

    print('Status code: ${response.statusCode}');
    print('Response body: ${response.body}');

    if (response.statusCode == 200) {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text("Payment Successful"),
          content: Text("Transaction ID: $transactionId"),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.pop(context);
                Navigator.pop(context);
              },
              child: Text("OK"),
            )
          ],
        ),
      );
    } else {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text("Payment Failed"),
          content: Text("Status: Failed"),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);

                Navigator.pop(context);
                Navigator.pop(context);
              },
              child: Text("OK"),
            )
          ],
        ),
      );
    }
  }

  //
  // Future<void> stripepayment(
  //     BuildContext context,
  //     dynamic amount,
  //     bool isSplit,
  //     String? courtid,
  //     String? userid,
  //     String? member,
  //    List <String> slotid,
  //     String? date,
  //     {String type = 'challenge'}
  //     ) async {
  //   try {
  //     SharedPreferences preferences = await SharedPreferences.getInstance();
  //     setloadding(true);
  //     setstauts(false);
  //
  //     String? authToken = await GlobalAPIUtils.getAuthToken();
  //     debugPrint('AuthToken: $authToken');
  //
  //     if (authToken == null || authToken.isEmpty) {
  //       throw 'Auth token is null or empty';
  //     }
  //
  //     final url = Uri.parse(
  //       'https://backend.krateasy.gr/api/app/payment/create-payment-intent',
  //     );
  //
  //     final Map<String, dynamic> orderData = {
  //       "amount": double.parse(amount.toString()),
  //       "courtId": courtid,
  //       "isSplit": isSplit,
  //       "type": type,
  //       "userId": userid,
  //       "member":member,
  //       "slotId":slotid,
  //       "date":date,
  //
  //     };
  //
  //     debugPrint('Sending request: ${jsonEncode(orderData)}');
  //
  //     final response = await http.post(
  //       url,
  //       headers: {
  //         'Content-Type': 'application/json',
  //         'Authorization': 'Bearer $authToken',
  //       },
  //       body: jsonEncode(orderData),
  //     );
  //
  //     debugPrint('Response status: ${response.statusCode}');
  //     debugPrint('Response body: ${response.body}');
  //
  //     setloadding(false);
  //
  //     if (response.statusCode == 200) {
  //       final jsonResponse = jsonDecode(response.body);
  //       final checkoutUrl = jsonResponse['url'];
  //       // final orderCode = jsonResponse['orderCode'];
  //       // setOrderid(orderCode);
  //
  //       final result = await Navigator.push(
  //         context,
  //         MaterialPageRoute(
  //           builder: (_) => VivaWebViewScreen(
  //             checkoutUrl: checkoutUrl,
  //             orderCode: 2333,
  //             amount: amount,
  //             isSplit: isSplit,
  //           ),
  //         ),
  //       );
  //     } else {
  //       // Show actual error message
  //       final errorBody = jsonDecode(response.body);
  //       throw 'Failed to create order: ${errorBody['message'] ?? 'Unknown error'}';
  //     }
  //
  //   } catch (e, stackTrace) {
  //     setloadding(false);
  //     debugPrint('Exception in createOrderWithToken: $e');
  //     debugPrint('StackTrace: $stackTrace');
  //
  //     // Optionally show user an error
  //     ScaffoldMessenger.of(context).showSnackBar(SnackBar(
  //       content: Text('Error: $e'),
  //       backgroundColor: Colors.red,
  //     ));
  //   }
  // }

  String _sessioid = "";

  String get sessionid => _sessioid;

  void setSessioid(String val) {
    _sessioid = val;
    notifyListeners();
  }

  String formatDate(String date) {
    try {
      // Try parsing ISO format first
      DateTime parsedDate =
          DateTime.tryParse(date) ?? DateFormat("dd-MM-yyyy").parse(date);
      return DateFormat('yyyy-MM-dd').format(parsedDate);
    } catch (e) {
      return date; // fallback if parsing fails
    }
  }

  Future<bool> stripePayment(
    BuildContext context,
    dynamic amount,
    bool isSplit,
    String? courtId,
    String? userid,
    String? member,
    List<String> slotid,
    String? date,
    String? bookingId, {
    String type = 'challenge',
  }) async {
    try {
      setloadding(true);
      setstauts(false);
      setSessioid("");

      final authToken = await GlobalAPIUtils.getAuthToken();
      if (authToken == null || authToken.isEmpty) {
        throw 'Auth token is null or empty';
      }

      final url = Uri.parse(
          'https://backend.krateasy.gr/api/app/payment/create-payment-intent');

      final orderData = {
        "amount": double.parse(amount.toString()),
        "courtId": courtId,
        "isSplit": isSplit,
        "type": type,
        "userId": userid,
        "member": member,
        "slotId": slotid,
        "date": formatDate(date!),
        "bookingId": bookingId,
      };
      print("order data: $orderData");

      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $authToken',
        },
        body: jsonEncode(orderData),
      );

      setloadding(false);

      if (response.statusCode != 200) {
        final errorBody = jsonDecode(response.body);
        throw 'Failed to create order: ${errorBody ?? 'Unknown error'}';
      }
      setBookingId(bookingId);

      final jsonResponse = jsonDecode(response.body);
      final checkoutUrl = jsonResponse['url'] as String;
      // final orderCode = jsonResponse['orderCode'] as int; // use if your API returns it

      final ok = await Navigator.push<bool>(
        context,
        MaterialPageRoute(
          builder: (_) => VivaWebViewScreen(
            checkoutUrl: checkoutUrl,
            orderCode: 2333, // replace with orderCode when you wire it
            amount: amount,
            userId: userid,
            bookingId: bookingId,
            isSplit: isSplit,
          ),
        ),
      );

      // WebView will pop(true) after 3s on success page.
      final success = ok == true;

      setstauts(success);
      if (!success) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Payment ')),
          );
        }
      } else {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('✅ Payment successful')),
          );
          return true;
        }
        return true;
        // (Optional) call a confirm/fulfillment endpoint here if your backend needs it.
        // await confirmPaymentOnBackend(orderCode);
      }

      return success;
    } catch (e, st) {
      setloadding(false);
      debugPrint('stripepayment error: $e\n$st');
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
        );
      }
      return false;
    }
  }

  PaymentDetails? _lastPaymentDetails;

  PaymentDetails? get lastPaymentDetails => _lastPaymentDetails;

  Future<PaymentDetails?> fetchPaymentDetails(String bookingId) async {
    try {
      setloadding(true);

      final uri = Uri.parse(
        'https://backend.krateasy.gr/api/app/payment/payment-details/$bookingId',
      );

      // If this endpoint needs auth, uncomment:
      // final authToken = await GlobalAPIUtils.getAuthToken();
      // final headers = {
      //   'Content-Type': 'application/json',
      //   if (authToken != null && authToken.isNotEmpty)
      //     'Authorization': 'Bearer $authToken',
      // };

      final res = await http.get(
        uri,
        headers: {
          'Content-Type': 'application/json',
          // ...headers,
        },
      );

      setloadding(false);

      if (res.statusCode != 200) {
        throw 'Server responded ${res.statusCode}: ${res.body}';
      }

      final map = jsonDecode(res.body) as Map<String, dynamic>;
      final api = PaymentDetailsResponse.fromJson(map);

      if (api.status && api.data != null) {
        _lastPaymentDetails = api.data;
        notifyListeners();
        return _lastPaymentDetails;
      } else {
        throw api.message.isNotEmpty ? api.message : 'Unknown API error';
      }
    } catch (e, st) {
      setloadding(false);
      debugPrint('fetchPaymentDetails error: $e\n$st');
      return null;
    }
  }
}
