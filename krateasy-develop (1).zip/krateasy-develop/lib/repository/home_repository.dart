import 'dart:developer';
import 'package:kratEasyApp/services/remote/api_ends.dart';
import 'package:kratEasyApp/services/remote/remote_service.dart';
import 'package:kratEasyApp/services/remote/responce_helper.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomeRepository {
  /// get notification data repo handle
  Future<ResponseHelper> getHomeDataApi() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var lat = await prefs.getDouble("current_lat");
    var long = await prefs.getDouble("current_long");
    print("${ApiEnds.instance.getHomeData}?latitude=$lat&longitude=$long");
    final url = "${ApiEnds.instance.getHomeData}?latitude=$lat&longitude=$long";
    try {
      final ResponseHelper responseHelper =
          await RemoteService().get(url: url, returnData: true);
      print(responseHelper.body);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch users');
    }
  }

  Future<ResponseHelper> getBookingDetailsApi(String? bookingId) async {
    final url = "${ApiEnds.instance.getBookingDetails}/$bookingId";
    try {
      final ResponseHelper responseHelper =
          await RemoteService().get(url: url, returnData: true);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to get booking details');
    }
  }

  Future<ResponseHelper> gechallengetBookingDetailsApi(String? bookingId) async {
    final url = "${ApiEnds.instance.getchallengeBookingDetails}/$bookingId";
    try {
      final ResponseHelper responseHelper =
      await RemoteService().get(url: url, returnData: true);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to get booking details');
    }
  }



  Future<ResponseHelper> getcourtbookingdetail(String? bookingId) async {
    final url = "${ApiEnds.instance.getcourtBookingDetails}/$bookingId";
    try {
      final ResponseHelper responseHelper =
      await RemoteService().get(url: url, returnData: true);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to get booking details');
    }
  }

  Future<ResponseHelper> getCourtDetailsApi(String? courtId) async {
    final url = "${ApiEnds.instance.getCourtDetails}/$courtId";
    try {
      final ResponseHelper responseHelper =
          await RemoteService().get(url: url, returnData: true);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to get booking details');
    }
  }

  Future<ResponseHelper> favouriteCourtApi(
      Map<String, dynamic> requestBody) async {
    String url = ApiEnds.instance.addFavouriteCourt;
    try {
      final ResponseHelper responseHelper =
          await RemoteService().post(url: url, body: requestBody);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to add court to favourite list');
    }
  }

  Future<ResponseHelper> friendpaymentApi(
      Map<String, dynamic> requestBody,String? id) async {
    final url = "${ApiEnds.instance.friendpayment}/$id";
    try {
      final ResponseHelper responseHelper =
      await RemoteService().post(url: url, body: requestBody);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to add court to favourite list');
    }
  }



  Future<ResponseHelper> favouritePlayerApi(
      Map<String, dynamic> requestBody) async {
    String url = ApiEnds.instance.favouritePlayer;
    try {
      final ResponseHelper responseHelper =
          await RemoteService().post(url: url, body: requestBody);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to add court to favourite list');
    }
  }

  /// login repo handle
  Future<ResponseHelper> setUserPreferencesApi(
      Map<String, dynamic> requestBody) async {
    try {
      final ResponseHelper responseHelper = await RemoteService()
          .post(url: ApiEnds.instance.editMyAccount, body: requestBody);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch users');
    }
  }

//fetch sports
  Future<ResponseHelper> getSportsListDataApi() async {
    final url = ApiEnds.instance.sportsList;
    try {
      final ResponseHelper responseHelper = await RemoteService().get(url: url);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch users');
    }
  }

  //modify Booking detail
  Future<ResponseHelper> getModifyBookingDetailsApi(String? bookingId) async {
    final url = "${ApiEnds.instance.modifyBookingDetail}$bookingId";
    try {
      final ResponseHelper responseHelper =
          await RemoteService().get(url: url, returnData: true);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to get booking details');
    }
  }
}
