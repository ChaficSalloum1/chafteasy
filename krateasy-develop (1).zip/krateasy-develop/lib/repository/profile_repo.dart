import 'dart:developer';
import 'package:kratEasyApp/services/remote/api_ends.dart';
import 'package:kratEasyApp/services/remote/remote_service.dart';
import 'package:kratEasyApp/services/remote/responce_helper.dart';

class ProfileRepo {
  /// get profile data repo handle
  Future<ResponseHelper> getProfileDataApi() async {
    final url = ApiEnds.instance.myAccount;
    try {
      final ResponseHelper responseHelper = await RemoteService().get(url: url);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch users');
    }
  }

  /// get profile data repo handle
  Future<ResponseHelper> getSportsListDataApi() async {
    final url = ApiEnds.instance.sportsList;
    try {
      final ResponseHelper responseHelper = await RemoteService().get(url: url);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch users');
    }
  }

  /// login repo handle
  Future<ResponseHelper> editMyAccount(Map<String, dynamic> requestBody) async {
    try {
      final ResponseHelper responseHelper = await RemoteService()
          .post(url: ApiEnds.instance.editMyAccount, body: requestBody);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch users');
    }
  }

  /// delete account repo handle
  Future<ResponseHelper> deleteAccount(Map<String, dynamic> requestBody) async {
    String url = ApiEnds.instance.deleteAccount;
    try {
      final ResponseHelper responseHelper =
          await RemoteService().post(url: url, body: requestBody);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch users');
    }
  }

  /// notification On or off repo handle
  Future<ResponseHelper> notificationOnOff() async {
    String url = ApiEnds.instance.notificationOnOff;
    try {
      final ResponseHelper responseHelper =
          await RemoteService().post(url: url, body: {});
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch users');
    }
  }
}
