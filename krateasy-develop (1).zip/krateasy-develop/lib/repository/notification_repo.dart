import 'dart:developer';
import 'package:kratEasyApp/services/remote/api_ends.dart';
import 'package:kratEasyApp/services/remote/remote_service.dart';
import 'package:kratEasyApp/services/remote/responce_helper.dart';

class NotificationRepository {
  /// get notification data repo handle
  Future<ResponseHelper> getNotificationDataApi() async {
    final url = ApiEnds.instance.notification;
    try {
      final ResponseHelper responseHelper = await RemoteService().get(url: url);
      
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch users');
    }
  }

  /// read notification data repo handle
  Future<ResponseHelper> readNotificationDataApi({String? id}) async {
    final String url = id?.isNotEmpty == true ? "${ApiEnds.instance.readNotification}/$id" : ApiEnds.instance.readNotification;
    try {
      final ResponseHelper responseHelper = await RemoteService().get(url: url);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch users');
    }
  }

  /// unread notification data repo handle
  Future<ResponseHelper> unreadNotificationDataApi() async {
    final String url =  ApiEnds.instance.unReadNotification;
    try {
      final ResponseHelper responseHelper = await RemoteService().get(url: url);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch users');
    }
  }

  /// get notification data repo handle
  Future<ResponseHelper> deleteNotificationDataApi({String? id}) async {
    final String url = id?.isNotEmpty == true ? "${ApiEnds.instance.deleteNotification}/$id" : ApiEnds.instance.deleteNotification;
    try {
      final ResponseHelper responseHelper = await RemoteService().get(url: url);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch users');
    }
  }
}
