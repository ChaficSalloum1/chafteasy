import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:kratEasyApp/Models/guest_Public_Challenges_Model.dart';
import 'package:kratEasyApp/services/remote/api_ends.dart';
import 'package:kratEasyApp/services/remote/remote_service.dart';
import 'package:kratEasyApp/services/remote/responce_helper.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class AvailableChallengeRepository {
  /// get Available Challenge data repo handle
  Future<ResponseHelper> getAvailableChallengeApi({
    double? minPrice,
    double? maxPrice,
    String? sort, // 'a-z', 'z-a', 'earliest', 'latest'
    String? date,
    String? startTime,
    List<String>? sportId,
    List<String>? amenities,
  }) async {
    final url = ApiEnds.instance.availableChallenge;

    // Build query parameters
    final Map<String, dynamic> queryParams = {
      if (minPrice != null) 'min_price': minPrice,
      if (maxPrice != null) 'max_price': maxPrice,
      if (sort != null) 'sort': sort,
      if (date != null) 'date': date,
      if (startTime != null) 'time': startTime,
      // if (sportId != null) 'sport_id': sportId,
      if (sportId != null && sportId.isNotEmpty)
        'sport_id': sportId.join(','),
      if (amenities != null && amenities.isNotEmpty)
        'amenities': amenities.join(','), // assuming comma-separated
    };

    debugPrint("queryParams $queryParams");

    try {
      final ResponseHelper responseHelper = await RemoteService().get(
        url: url,
        queryParams: queryParams,
      );
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch challenges');
    }
  }


  /// get Available court Challenge data repo handle
  Future<ResponseHelper> getAvailableCourtChallengeApi(body,) async {
    final url = ApiEnds.instance.availableCourtChallenge;
    try {
      final ResponseHelper responseHelper = await RemoteService().post(url: url, body: body);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch users');
    }
  }

//new

  Future<List<PublicChallenge>> fetchPublicChallenges({
    List? amenities,
    String? startTime,
    required String sportId,
    required String date,
    required BuildContext context,
  }) async {
    List<PublicChallenge> challengeList = [];

    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();

      final lat = prefs.getDouble("current_lat");
      final long = prefs.getDouble("current_long");
      final url;
      //  final    url =
      //            "https://backend.krateasy.gr/api/app/challenges/available-public-challenges";
      if (startTime == null) {
        //|| amenities == null
        url = "https://backend.krateasy.gr/api/app/challenges/available-public-challenges?sportId=$sportId&date=$date&latitude=$lat&longitude=$long";
      } else {
        url = "https://backend.krateasy.gr/api/app/challenges/available-public-challenges?sportId=$sportId&date=$date&latitude=$lat&longitude=$long&startTime=$startTime"; //&amenities=$amenities;
      }
      print("urlllll-----$url");
      // if (startTime == null || amenities == null) {
      //   url =
      //       "https://backend.krateasy.gr/api/app/challenges/available-public-challenges?sportId=$sportId&date=$date&latitude=$lat&longitude=$long";
      // } else {
      //   url =
      //       "https://backend.krateasy.gr/api/app/challenges/available-public-challenges?sportId=$sportId&date=$date&latitude=$lat&longitude=$long&startTime=$startTime&amenities=$amenities";
      // }
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final jsonBody = json.decode(response.body);
        final parsed = GuestPublicChallengeModel.fromJson(jsonBody);

        if (parsed.status == true && parsed.data != null) {
          challengeList = parsed.data!;
        } else {
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(parsed.message ?? "Something went wrong")),
            );
          }
        }
      } else {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("HTTP ${response.statusCode}: ${response.reasonPhrase}")),
          );
        }
      }
    } catch (e) {
      print("Exception in fetchPublicChallenges: $e");
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Something went wrong. Please try again.")),
        );
      }
    }

    return challengeList;
  }

  // Future<ResponseHelper> getAvailableChallengeApiNew(
  //     {required String sportId,
  //     required String date,
  //     required  lat,
  //     required  long}) async {
  //   // final url = ApiEnds.instance.availableChallenge;
  //   final url =
  //       "app/challenges/available-public-challenges?sportId=$sportId&date=$date&latitude=$lat&longitude=$long";
  //   try {
  //     final ResponseHelper responseHelper = await RemoteService().get(url: url);
  //     return responseHelper;
  //   } catch (e) {
  //     log("error ====> $e");
  //     throw Exception('Failed to fetch users');
  //   }
  // }

  Future<ResponseHelper2> createChallengeApi(var mapDta, {bool returnData = false}) async {
    final url = ApiEnds.instance.createChallenge;
    try {
      final ResponseHelper2 responseHelper = await RemoteService().post2(url: url, body: mapDta, returnData: true);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to Create Challenge');
    }
  }

  Future<ResponseHelper> getChallengesDetailsApi(String? challengesId) async {
    final url = "${ApiEnds.instance.getChallengesDetails}/$challengesId";
    try {
      final ResponseHelper responseHelper = await RemoteService().get(url: url, returnData: true);

      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to get challenges details');
    }
  }

  /// join challenge repo handle
  Future<ResponseHelper> joinChallenge(Map<String, dynamic> requestBody) async {
    try {
      final ResponseHelper responseHelper = await RemoteService().post(url: ApiEnds.instance.joinChallenges, body: requestBody, returnData: true);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch users');
    }
  }
}
