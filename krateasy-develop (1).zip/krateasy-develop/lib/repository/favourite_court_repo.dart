import 'dart:developer';

import 'package:kratEasyApp/services/remote/api_ends.dart';
import 'package:kratEasyApp/services/remote/remote_service.dart';
import 'package:kratEasyApp/services/remote/responce_helper.dart';

class FavouriteRepository {
  /// get notification data repo handle
  Future<ResponseHelper> getFavouriteCourtApi() async {
    final url = ApiEnds.instance.favouriteCourt;
    try {
      final ResponseHelper responseHelper = await RemoteService().get(url: url);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch users');
    }
  }

  /// get notification data repo handle
  Future<ResponseHelper> getFavouritePlayerApi() async {
    final url = ApiEnds.instance.favouritePlayer;
    try {
      final ResponseHelper responseHelper = await RemoteService().get(url: url);
      print("responseHelper is ${responseHelper.body}");
      return responseHelper;
    } catch (e, stackTrace) {
      print("exceptipn is $e $stackTrace");
      log("error ====> $e");
      throw Exception('Failed to fetch users');
    }
  }
}
