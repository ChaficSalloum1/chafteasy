import 'dart:developer';
import 'package:kratEasyApp/services/remote/api_ends.dart';
import 'package:kratEasyApp/services/remote/remote_service.dart';
import 'package:kratEasyApp/services/remote/responce_helper.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FacilitiesRepository {
  /*{
    "date": "2025-04-17",
    "sport_ids": [
        "68149938f33c649d5954663b"
    ],
    // "amenities": [
    //     "67cb06b6bd32ec2bca46ad0d"// ID 
    //      ],
    // "time": {
    //     "start": "08:00 AM",
    //     "end": "12:00 AM"
    // },
    "sortBy": "a-z"
}*/
  /// get notification data repo handle
  Future<ResponseHelper> getFacilitiesApisNew({request}) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var lat = await prefs.getDouble("current_lat");
    var long = await prefs.getDouble("current_long");
    // final url = ApiEnds.instance.filterFacilities;
    final url = "${ApiEnds.instance.filterFacilities}?latitude=$lat&longitude=$long";
    // "?sport_ids=${sportIdList?.join(',') ?? ''}"
    // "&amenities=${amenitiesList?.join(',') ?? ''}"
    // "&sort=${sort ?? ''}"
    // "&order=${orderStatus ?? ''}"
    // "&min_price=${minPrice ?? ''}"
    // "&max_price=${maxPrice ?? ''}"
    // "&radius=${radius ?? ''}"
    // "&date=${date ?? ''}"
    // "&time=${time ?? ''}"
    // "&latitude=${latitude ?? ''}"
    // "&longitude=${longitude ?? ''}";
    try {
      final ResponseHelper responseHelper =
          await RemoteService().post(url: url, body: request, returnData: true);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch users');
    }
  }




  Future<ResponseHelper> getFacilitiesApis(
      {String? sportIdList,
      List<String>? amenitiesList,
      String? sort,
      String? orderStatus,
      String? minRating,
      String? maxRating,
      String? time,
      String? radius,
      String? date,
      double? latitude,
      double? longitude}) async {
    String url = "${ApiEnds.instance.facilities}";
    if(latitude!=null){
      url+= "?latitude=${(latitude ?? 0.0).toDouble()}";
    }
    if(sportIdList!=null && sportIdList!.isNotEmpty){
      url+= "&sport_ids=${sportIdList}";
      // url+= "&sport_ids= ${sportIdList.join(',') ?? ''}";
    }

    if(amenitiesList!=null && amenitiesList!.isNotEmpty){
      url+= "&amenities=${amenitiesList?.join(',') ?? ''}";
    }

if(sort!=null && sort!.isNotEmpty){
      url+= "&sort=${sort ?? ''}";
    }


    if(orderStatus!=null && orderStatus!.isNotEmpty){
      url+= "&order=${orderStatus ?? ''}";
    }

    // if(minRating!=null && minRating!.isNotEmpty){
    //   url+=  "&min_rating=${minRating ?? ''}";
    // }
    //
    // if(maxRating!=null && maxRating!.isNotEmpty){
    //   url+=  "&max_rating=${maxRating ?? ''}";
    // }

    if(radius!=null && radius!.isNotEmpty){
      url+=  "&radius=${radius ?? ''}";
    }

    if(date!=null && date!.isNotEmpty){
      url+="&date=${date ?? ''}";
    }
    if(time!=null && time!.isNotEmpty){
      url+="&time=${time ?? ''}";
    }

    if(longitude!=null){
      url+= "&longitude=${(longitude ?? 0.0).toDouble()}";
    }


    try {
      final ResponseHelper responseHelper = await RemoteService().get(url: url);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch users');
    }
  }

  /// facility share details Post api
  Future<ResponseHelper> getShareFacility(
      Map<String, dynamic> requestBody) async {
    final url = ApiEnds.instance.shareFacility;
    try {
      final ResponseHelper responseHelper = await RemoteService()
          .post(url: url, body: requestBody, returnData: true);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch users');
    }
  }
}
