import 'dart:convert';
import 'dart:math' as math;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/ViewModel/EntranceViewModel/booking_provider.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';
import 'package:crypto/crypto.dart';

class SocialLoginRepository {
static final FirebaseAuth _auth = FirebaseAuth.instance;

/// Google Sign-In
static Future<Map<String ,dynamic>>  signInWithGoogle(BuildContext context) async {
  // try {
    if (_auth.currentUser != null) {
      await GoogleSignIn().signOut();
      await _auth.signOut();
    }
      Map<String, dynamic> data = {
    "name": null,
    "email": null,
    "id": null,
    "type": "Google",
    "countryCode":null ,
    "phone": null,
    "isSuccess": false,
    "isExist": false,
  };
print("start");
print("data $data");
  try {
    // Sign user out first (defensive – avoids stale creds)
    if (_auth.currentUser != null) {
      await GoogleSignIn().signOut();
      await _auth.signOut();
    }
print("try ");

    final GoogleSignInAccount? gUser = await GoogleSignIn().signIn();
    if (gUser == null) {
      showSnackBarAboveSheet(context, "Google login cancelled");
      return data;
    }
print("Google login cancelled");

    // Basic profile info
    data["name"]  = gUser.displayName ?? "";
    data["email"] = gUser.email;
    data["id"]    = gUser.id;


    data["isSuccess"] = true;
data["isExist"]= await Provider.of<BookingProvider>(context,listen:false).checkSocialLoginUser(context: context, socialId: data["id"], type: "Google");
    print("asdfgdfdfgf ${data   ["isExist"]}");
    Navigator.pop(context);              // close bottom-sheet if any
    // showSnackBarAboveSheet(context, "Google login successful");
print("Google login data pass");
    
    return data;
  } catch (e) {
    showSnackBarAboveSheet(context, "Google login failed: $e");
    print("error $e");
    return data;
  }



}

static void showSnackBarAboveSheet(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(message),
      behavior: SnackBarBehavior.floating,
      margin: EdgeInsets.only(
        bottom:
            MediaQuery.of(context).viewInsets.bottom + 80, // adjusts position
        left: 16,
        right: 16,
      ),
    ),
  );
}

/// Facebook Sign-In
static Future<Map<String ,dynamic>> signInWithFacebook({
  required BuildContext context,
}) async {
  try {
    final LoginResult loginResult = await FacebookAuth.instance.login();
    print("status of fb .... ${loginResult.accessToken}");
    print("status  .... ${loginResult.status}");
    print("full  .... ${loginResult}");
Map<String,dynamic> data ={
"name":null,
"isSuccess":false,
"email":null,
"id":null,
"type":"Facebook",
"isExist":false

};
    if (loginResult.status == LoginStatus.success) {
      final accessToken = loginResult.accessToken;

      if (accessToken == null) {
        showSnackBarAboveSheet(context, "Facebook access token missing");
        return data;
      }

      final userData = await FacebookAuth.instance.getUserData(
        fields: "name,email,picture.width(200),first_name,last_name,id",
      );

      data["email"] = userData["email"] ?? "";
      data["name"] = userData["name"] ?? "";
      data["id"] = userData["id"];
      data["isSuccess"]=true; 
      // your backend might expect this

data["isExist"]= await Provider.of<BookingProvider>(context,listen:false).checkSocialLoginUser(context: context, socialId: data["id"], type: "Facebook");
      Navigator.pop(context);



      return data;
    } else if (loginResult.status == LoginStatus.cancelled) {
      showSnackBarAboveSheet(context, "Facebook login cancelled");
      return data;

    } else {
      showSnackBarAboveSheet(
          context, "Facebook login failed: ${loginResult.message}");
          return data;
    }
  } catch (e) {
    showSnackBarAboveSheet(context, "Facebook login error: $e");
  return {"isSuccess":false}; }
}

/// Apple Sign-In
static Future<void> loginWithApple(BuildContext context) async {
  try {
    final rawNonce = generateNonce();
    final nonce = sha256ofString(rawNonce);

    final appleCredential = await SignInWithApple.getAppleIDCredential(
      scopes: [
        AppleIDAuthorizationScopes.email,
        AppleIDAuthorizationScopes.fullName,
      ],
      nonce: nonce,
    );

    final authCredential = OAuthProvider("apple.com").credential(
      idToken: appleCredential.identityToken,
      rawNonce: rawNonce,
      accessToken: appleCredential.authorizationCode,
    );


  } catch (e) {
    _showSnackBar(context, "Apple login failed: $e");
    printLog( "Apple login failed: $e");

    return null;
  }
}

/// Helper: Generate Nonce for Apple
static String generateNonce([int length = 32]) {
  const charset =
      '0123456789ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvwxyz-._';
  final random = math.Random.secure();
  return List.generate(length, (_) => charset[random.nextInt(charset.length)])
      .join();
}

/// Helper: SHA256 Hash
static String sha256ofString(String input) {
  final bytes = utf8.encode(input);
  final digest = sha256.convert(bytes);
  return digest.toString();
}

/// Show SnackBar (You can replace with your custom snackbar)
static void _showSnackBar(BuildContext context, String message) {
  final snackBar = SnackBar(
    content: Text(message, style: const TextStyle(color: Colors.white)),
    backgroundColor: Colors.redAccent,
  );
  ScaffoldMessenger.of(context).showSnackBar(snackBar);
}

static Future<void> logoutFromFacebook() async {
try {
  await FacebookAuth.instance.logOut();
  print("Facebook logout successful");
  
} catch (e) {
  print("Facebook logout failed: $e");
  // Show error toast/snackbar if needed
}
}

}
