import 'dart:developer';
import 'package:kratEasyApp/GlobalUtils/app_text_field.dart';
import 'package:kratEasyApp/services/remote/api_ends.dart';
import 'package:kratEasyApp/services/remote/remote_service.dart';
import 'package:kratEasyApp/services/remote/responce_helper.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BookingRepository {
  /// get my booking repo handle
  Future<ResponseHelper> getMyBookingApi(String type,
      {bool returnData = false}) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var lat = await prefs.getDouble("current_lat");
    var long = await prefs.getDouble("current_long");
    final url =
        "${ApiEnds.instance.myBooking}?type=$type&latitude=$lat&longitude=$long&limit=50";
    try {
      final ResponseHelper responseHelper =
          await RemoteService().get(url: url, returnData: returnData);
      printLog("Reponse helper :${responseHelper.body}");
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch bookings');
    }
  }

  /// get type challenge repo handle
  Future<ResponseHelper> getMyChallengeData(String type,
      {bool returnData = false}) async {
    final url = "${ApiEnds.instance.typeChallenge}?type=$type&limit=50";
    try {
      final ResponseHelper responseHelper =
          await RemoteService().get(url: url, returnData: returnData);
      printLog("Reponse helper :${responseHelper.body}");
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch challenge');
    }
  }

  /// cancel booking
  Future<ResponseHelper> cancelBookingApi(String bookingId,
      {bool returnData = false}) async {
    final url = "${ApiEnds.instance.cancelBooking}/$bookingId";
    try {
      final ResponseHelper responseHelper =
          await RemoteService().post(url: url, body: {});
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to Cancel');
    }
  }

  Future<ResponseHelper> rateBookingApi(String bookingId, var body,
      {bool returnData = false}) async {
    final url = "${ApiEnds.instance.rateBooking}/$bookingId";
    try {
      final ResponseHelper responseHelper = await RemoteService()
          .post(url: url, body: body, returnData: returnData);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch users');
    }
  }

//cancel challenge
  Future<ResponseHelper> cancelChallengeApi(String challengeId,
      {bool returnData = false}) async {
    final url = "${ApiEnds.instance.cancelChallenge}/$challengeId";
    try {
      final ResponseHelper responseHelper =
          await RemoteService().put(url: url, body: {});
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to Cancel');
    }
  }

  /// get slot
  Future<ResponseHelper> getSlotsApi(var body,
      {bool returnData = false}) async {
    final url = ApiEnds.instance.getSlots;
    try {
      final ResponseHelper responseHelper = await RemoteService()
          .post(url: url, body: body, returnData: returnData);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to Cancel');
    }
  }

  //moodify booking
  Future<ResponseHelper> modifyBookingApi(var body,var id,
      {bool returnData = false}) async {
    print("uriii   ${ApiEnds.instance.modifyBookingApiEndPoint}$id");
    final url = "${ApiEnds.instance.modifyBookingApiEndPoint}$id";
    try {
      final ResponseHelper responseHelper = await RemoteService()
          .put(url: url, body: body, );
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to Cancel');
    }
  }
}
