import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class MyInputDatePickerFormField extends StatefulWidget {
  MyInputDatePickerFormField({
    super.key,
    DateTime? initialDate,
    required DateTime firstDate,
    required DateTime lastDate,
    this.onDateSubmitted,
    this.onDateSaved,
    this.selectableDayPredicate,
    this.errorFormatText,
    this.errorInvalidText,
    this.fieldHintText,
    this.fieldLabelText,
    this.keyboardType,
    this.autofocus = false,
    this.acceptEmptyDate = false,
    this.focusNode,
  })  : initialDate = initialDate != null ? DateUtils.dateOnly(initialDate) : null,
        firstDate = DateUtils.dateOnly(firstDate),
        lastDate = DateUtils.dateOnly(lastDate) {
    assert(!this.lastDate.isBefore(this.firstDate));
    assert(initialDate == null || !this.initialDate!.isBefore(this.firstDate));
    assert(initialDate == null || !this.initialDate!.isAfter(this.lastDate));
    assert(
    selectableDayPredicate == null ||
        initialDate == null ||
        selectableDayPredicate!(this.initialDate!),
    );
  }

  final DateTime? initialDate;
  final DateTime firstDate;
  final DateTime lastDate;
  final ValueChanged<DateTime>? onDateSubmitted;
  final ValueChanged<DateTime>? onDateSaved;
  final SelectableDayPredicate? selectableDayPredicate;
  final String? errorFormatText;
  final String? errorInvalidText;
  final String? fieldHintText;
  final String? fieldLabelText;
  final TextInputType? keyboardType;
  final bool autofocus;
  final bool acceptEmptyDate;
  final FocusNode? focusNode;

  @override
  State<MyInputDatePickerFormField> createState() =>
      _MyInputDatePickerFormFieldState();
}

class _MyInputDatePickerFormFieldState
    extends State<MyInputDatePickerFormField> {
  final TextEditingController _controller = TextEditingController();
  DateTime? _selectedDate;
  String? _inputText;
  bool _autoSelected = false;

  @override
  void initState() {
    super.initState();
    _selectedDate = widget.initialDate;
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _updateValueForSelectedDate();
  }

  @override
  void didUpdateWidget(MyInputDatePickerFormField oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.initialDate != oldWidget.initialDate) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        setState(() {
          _selectedDate = widget.initialDate;
          _updateValueForSelectedDate();
        });
      });
    }
  }

  void _updateValueForSelectedDate() {
    if (_selectedDate != null) {
      _inputText = DateFormat('dd/MM/yyyy').format(_selectedDate!);
      TextEditingValue textEditingValue = TextEditingValue(text: _inputText!);
      if (widget.autofocus && !_autoSelected) {
        textEditingValue = textEditingValue.copyWith(
          selection:
          TextSelection(baseOffset: 0, extentOffset: _inputText!.length),
        );
        _autoSelected = true;
      }
      _controller.value = textEditingValue;
    } else {
      _inputText = '';
      _controller.value = TextEditingValue(text: _inputText!);
    }
  }

  DateTime? _tryParseDate(String? text) {
    try {
      return DateFormat('dd/MM/yyyy').parseStrict(text!);
    } catch (_) {
      return null;
    }
  }

  bool _isValidAcceptableDate(DateTime? date) {
    return date != null &&
        !date.isBefore(widget.firstDate) &&
        !date.isAfter(widget.lastDate) &&
        (widget.selectableDayPredicate == null ||
            widget.selectableDayPredicate!(date));
  }

  String? _validateDate(String? text) {
    if ((text == null || text.isEmpty) && widget.acceptEmptyDate) {
      return null;
    }

    final DateTime? date = _tryParseDate(text);
    if (date == null) {
      return widget.errorFormatText ?? "Please enter the date in dd/MM/yyyy format";
    }
    if (!_isValidAcceptableDate(date)) {
      return widget.errorInvalidText ?? "Date is out of range or not selectable";
    }
    return null;
  }

  void _updateDate(String? text, ValueChanged<DateTime>? callback) {
    if (text == null) return;
    final DateTime? date = _tryParseDate(text);
    if (date != null && _isValidAcceptableDate(date)) {
      _selectedDate = date;
      _inputText = text;
      callback?.call(date);
    }
  }

  void _handleSaved(String? text) {
    _updateDate(text, widget.onDateSaved);
  }

  void _handleSubmitted(String text) {
    _updateDate(text, widget.onDateSubmitted);
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final bool useMaterial3 = theme.useMaterial3;
    final DatePickerThemeData datePickerTheme = theme.datePickerTheme;
    final InputDecorationTheme inputTheme = theme.inputDecorationTheme;
    final InputBorder effectiveInputBorder =
        datePickerTheme.inputDecorationTheme?.border ??
            theme.inputDecorationTheme.border ??
            (useMaterial3
                ? const OutlineInputBorder()
                : const UnderlineInputBorder());

    return Semantics(
      container: true,
      child: TextFormField(
        decoration: InputDecoration(
          hintText: widget.fieldHintText ?? 'dd/MM/yyyy',
          labelText: widget.fieldLabelText ?? 'Date',
        ).applyDefaults(
          inputTheme
              .merge(datePickerTheme.inputDecorationTheme)
              .copyWith(border: effectiveInputBorder),
        ),
        validator: _validateDate,
        keyboardType: widget.keyboardType ?? TextInputType.datetime,
        onSaved: _handleSaved,
        onFieldSubmitted: _handleSubmitted,
        autofocus: widget.autofocus,
        controller: _controller,
        focusNode: widget.focusNode,
      ),
    );
  }
}
