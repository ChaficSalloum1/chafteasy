import 'package:flutter/material.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:provider/provider.dart';
import '../ViewModel/VerificationResetPassViewModel.dart';

class VerificationResetPassScreen extends StatelessWidget {
  const VerificationResetPassScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final viewModel = Provider.of<VerificationResetPassViewModel>(context);
    double commonWidth =
        MediaQuery.of(context).size.width * 0.9; // Increased width
    double commonHeight = 55; // Standardized height
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Spacer(flex: 4),
          Center(
            child: Column(
              children: [
                Text(
                  l10n.of(context).verification,
                  style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 5),
                Text(
                 l10n.of(context).enterThe4digitCodeSentToYourPhone,
                  style: TextStyle(fontSize: 15, color: Colors.grey[700]),
                ),
                SizedBox(height: 30),

                // OTP Input Fields
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(4, (index) {
                    return Container(
                      width: 60, // Larger width
                      height: 60, // Larger height
                      margin: EdgeInsets.symmetric(horizontal: 8),
                      child: TextField(
                        controller: viewModel.otpControllers[index],
                        focusNode: viewModel.otpFocusNodes[index],
                        keyboardType: TextInputType.number,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                        maxLength: 1,
                        decoration: InputDecoration(
                          counterText: "", // Hide counter
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                    );
                  }),
                ),

                SizedBox(height: 20),

                // Didn't receive OTP? & Resend OTP
                Text(
                  l10n.of(context).didntReceiveACodeResend,
                  style: TextStyle(fontSize: 14, color: Colors.black54),
                ),
                SizedBox(height: 5),
                Text(
                  l10n.of(context).resendOtpIn50s,
                  style: TextStyle(fontSize: 14, color: Colors.black54),
                ),

                SizedBox(height: 30),
                SizedBox(
                  width: commonWidth,
                  height: commonHeight,
                  child: ElevatedButton(
                    onPressed: () {
                      viewModel.onVerify(context); // Pass context to navigate
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF8DC63F),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: Text(
                      l10n.of(context).verify,
                      style: TextStyle(fontSize: 18, color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Spacer(flex: 5),
        ],
      ),
    );
  }
}
