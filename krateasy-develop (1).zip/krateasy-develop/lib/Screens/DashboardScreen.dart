import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:kratEasyApp/API_CALLS/API/AmenitiesListAPI.dart';
import 'package:kratEasyApp/BottomNavScreens/FacilitiesViewScreen.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/GlobalUtils/exit_popup.dart';
import 'package:kratEasyApp/Models/AmenitiesList.dart';
import 'package:kratEasyApp/Models/sports_list_model.dart';
import 'package:kratEasyApp/Screens/filterScreen.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/utils/widgets/common_widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shimmer/shimmer.dart';
import '../BottomNavScreens/ChallengeViewScreen.dart';
import '../BottomNavScreens/HomeViewScreen.dart';
import '../BottomNavScreens/NotificationsViewScreen.dart';
import '../GlobalUtils/SideDrawerScreen.dart';
import '../services/local/local_keys.dart';
import 'package:kratEasyApp/plugin/editedd_date_picker.dart';



class DashboardScreen extends StatefulWidget {
  int? initialIndex;
  DashboardScreen({super.key, this.initialIndex});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final ValueNotifier<RangeValues> rangeValuesNotifier = ValueNotifier(
    const RangeValues(1, 3),
  );
  String address = "";
  // Function to get the saved location
  // ignore: body_might_complete_normally_nullable
  Future<String?> getSavedLocation() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    address = await prefs.getString('saved_location') ?? "";
  }

  MyAccountViewModel? accountProvider;
  late MyAccountViewModel myAccountViewModel;
  late MyLocationViewModel myLocationViewModel;
  late DashboardViewModel dashboardViewModel;
  bool shouldShow = false;

  String? sportID;
  @override
  void initState() {
    super.initState();
    myAccountViewModel = context.read<MyAccountViewModel>();
    myLocationViewModel = context.read<MyLocationViewModel>();
    dashboardViewModel = context.read<DashboardViewModel>();
    dashboardViewModel.changeIndex(0);
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (widget.initialIndex != null) {
        dashboardViewModel.changeIndex(widget.initialIndex!);
      }

      // context.watch<NotificationsViewModel>().getNotificationListData(context: context);

      SharedPreferences prefs = await SharedPreferences.getInstance();
      sportID = prefs.getString("sportID");

      final isFilled = prefs.getBool('userFilledInfo') ?? false;
      final lastShownDate = prefs.getString('popupLastShownDate');

      final today = DateTime.now();
      final todayStr = "${today.year}-${today.month}-${today.day}";

      if (!isFilled && lastShownDate != todayStr) {
        shouldShow = true; // ✅ Now only shown conditionally
      }
      // shouldShow = prefs.getBool("showBottomSheet") ?? false;

      await AmenitiesListApi().fetchAndSaveAmenities();
      getSavedLocation();

      // final homeProvider = Provider.of<HomeViewModel>(context, listen: false);
      // await homeProvider.getSportsDataApi().then((v) {
      //   if (shouldShow) {
      //     showWhatToPlayDialog(context); // show sheet
      //   }
      // });

      // context.read<HomeViewModel>().setIsHomeFilter(false);
      await myLocationViewModel.getCurrentLocation(context: context);
      await myAccountViewModel.getProfileDataApi();
    });
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = Provider.of<DashboardViewModel>(context);

    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) async {
        if (!didPop) {
          final viewModel =
              Provider.of<DashboardViewModel>(context, listen: false);
          if (viewModel.currentIndex != 0) {
            // If not on Home tab, switch to Home tab (index 0)
            viewModel.changeIndex(0);
          } else {
            // If on Home tab, show exit dialog and handle result
            final shouldExit = await showCupertinoDialog<bool>(
              context: context,
              builder: (context) => CupertinoAlertDialog(
                title: Text(l10n.of(context).exitApp),
                content: Text(l10n.of(context).areYouSureYouWantToExit),
                actions: [
                  CupertinoDialogAction(
                    onPressed: () => Navigator.of(context).pop(false), // Cancel
                    child: Text(l10n.of(context).cancel),
                  ),
                  CupertinoDialogAction(
                    onPressed: () => Navigator.of(context).pop(true), // Exit
                    isDestructiveAction: true,
                    child: Text(l10n.of(context).exit),
                  ),
                ],
              ),
            );
            if (shouldExit == true) {
              SystemNavigator.pop();
            }
          }
        }
      }, // onPopInvoked: (val) async {

      child: Scaffold(
        appBar: viewModel.currentIndex == 0
            ? AppBar(
                elevation: 0,
                titleSpacing: 0,
                bottom: PreferredSize(
                  preferredSize: Size.fromHeight(1.0),
                  child: Container(
                    color: AppColors.primaryColor,
                    height: 1.0,
                  ),
                ),
                backgroundColor: Colors.white,
                title: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Main Text
                          Consumer<MyAccountViewModel>(
                            builder: (BuildContext context,
                                myAccountViewModel1, Widget? child) {
                              return RichText(
                                text: TextSpan(
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.black,
                                  ),
                                  children: <TextSpan>[
                                    TextSpan(
                                        text: l10n.of(context).hey,
                                        style: TextStyle(
                                            fontWeight: FontWeight.w600,
                                            fontSize: 14,
                                            color: AppColors.black)),
                                    TextSpan(
                                      text: myAccountViewModel1.isLoading
                                          ? ""
                                          : myAccountViewModel1
                                                      .profileModel.name !=
                                                  null
                                              ? "${myAccountViewModel1.profileModel.name?.split(' ').first} !"
                                              : l10n.of(context).mate + "!",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Row(
                            children: [
                              Image.asset(
                                'assets/icons/location.png', // Change to your asset path
                                width: 10, // Adjust size as needed
                                height: 10,
                              ),
                              SizedBox(width: 5),
                              Expanded(child: Consumer<MyLocationViewModel>(
                                builder: (BuildContext context,
                                    myLocationViewModel, Widget? child) {
                                  return myLocationViewModel.isLoading
                                      ? Text(l10n.of(context).loading,
                                          style: TextStyle(
                                            fontSize: 12,
                                            color: Colors.grey[700],
                                          ))
                                      : Text(
                                          (LocalService.instance.getData(LocalKeys
                                                          .instance
                                                          .currentLocation) ==
                                                      null ||
                                                  LocalService.instance
                                                          .getData(LocalKeys
                                                              .instance
                                                              .currentLocation) ==
                                                      "")
                                              ? l10n.of(context).na
                                              : LocalService.instance.getData(
                                                  LocalKeys.instance
                                                      .currentLocation),
                                          style: TextStyle(
                                            fontSize: 12,
                                            color: Colors.grey[700],
                                          ),
                                          overflow: TextOverflow.ellipsis,
                                          maxLines: 1,
                                        );
                                },
                              )),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                leading: Builder(
                  builder: (context) => IconButton(
                    icon: Image.asset(
                      'assets/icons/drawer.png',
                      width: 30,
                      height: 30,
                    ),
                    onPressed: () => Scaffold.of(context).openDrawer(),
                  ),
                ),
                actions: [
                  Row(
                    children: [
                      // if (shouldShow)
                      //   InkWell(
                      //     onTap: () {
                      //       showWhatToPlayDialog(context);
                      //     },
                      //     child: Column(
                      //       mainAxisSize: MainAxisSize.min,
                      //       children: [
                      //         Image.asset(
                      //           'assets/icons/ring.png',
                      //           width: 20,
                      //           height: 20,
                      //         ),
                      //         Text(
                      //           S.of(context).getAlert,
                      //           style: TextStyle(
                      //             fontSize: 10,
                      //             fontWeight: FontWeight.w400,
                      //             color: AppColors.black,
                      //           ),
                      //         ),
                      //       ],
                      //     ),
                      //   ),
                      InkWell(
                        onTap: () {
                          Navigator.pushNamed(
                              NavigationService.context, '/searchCourts');
                        },
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 5),
                          child: Image.asset(
                            'assets/icons/search.png',
                            width: 33,
                            height: 33,
                          ),
                        ),
                      ),

                      InkWell(

                        onTap: () {

                          _showFilterDialog(context);
                        },
                        child: Image.asset(
                          'assets/icons/filter.png',
                          width: 25,
                          height: 25,
                        ),
                      ),
                      SizedBox(width: 12),
                    ],
                  ),
                ],
              )
            : null,
        drawer: viewModel.currentIndex == 0 ? SideDrawerScreen() : null,
        body: switch (viewModel.currentIndex) {
          0 => HomeViewScreen(),
          1 => MyBookingScreen(),
          2 => FacilitiesViewScreen(),
          3 => ChallengeViewScreen(),
          4 => NotificationsViewScreen(),
          int() => NotificationsViewScreen(),
        },

        bottomNavigationBar: BottomNavigationBar(
          backgroundColor: Colors.white,
          type: BottomNavigationBarType.fixed,
          showSelectedLabels: true,
          showUnselectedLabels: true,
          currentIndex: viewModel.currentIndex,
          onTap: (v) {
            viewModel.changeIndex(
              v,
            );
          },
          selectedItemColor: const Color(0xFF8DC63F),
          unselectedItemColor: Colors.grey,
          selectedLabelStyle: TextStyle(fontSize: 11),
          unselectedLabelStyle: TextStyle(fontSize: 10),
          items: [
            BottomNavigationBarItem(
              icon: ImageIcon(AssetImage('assets/bottomnavImg/home.png')),
              label: l10n.of(context).home,
            ),
            BottomNavigationBarItem(
              icon: ImageIcon(AssetImage("assets/bottomnavImg/bookings.png")),
              label: l10n.of(context).myBooking,
            ),
            BottomNavigationBarItem(
              icon:
                  ImageIcon(AssetImage('assets/bottomnavImg/facilities.png')),
              label: l10n.of(context).facilities,
            ),
            BottomNavigationBarItem(
              icon:
                  ImageIcon(AssetImage('assets/bottomnavImg/challenges.png')),
              label: l10n.of(context).challenges,
            ),
            BottomNavigationBarItem(
              icon: ImageIcon(
                context.watch<NotificationsViewModel>().hasUnreadNotifications ? AssetImage('assets/bottomnavImg/notificationunread.png') : AssetImage('assets/bottomnavImg/notifications.png'),

              ),
              label: l10n.of(context).notifications,
            ),
          ],
        ),
      ),
    );
  }



  void _showFilterDialog(BuildContext context) {
    printLog("open");
    final _formKey = GlobalKey<FormState>();
    final homeViewModel = Provider.of<HomeViewModel>(context, listen: false);

    // Reset all fields
    homeViewModel.resetFilters();
    showDialog(
        context: context,
        builder: (context) {
          return Dialog(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            insetPadding: EdgeInsets.all(16),
            child: Consumer<HomeViewModel>(
                builder: (context, homeViewModel, child) {
              return Padding(
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                child: Form(
                  key: _formKey,
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Title
                        Row(
                          children: [
                            Text(l10n.of(context).filter,
                                style: TextStyle(
                                    color: AppColors.black555,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w700)),
                            Spacer(),
                            GestureDetector(
                              onTap: () => Navigator.pop(context),
                              child: Image.asset(
                                'assets/icons/cross.png',
                                width: 26,
                                height: 26,
                              ),
                            ),
                          ],
                        ),
                        Divider(color: Color(0xffE3E3E3)),
                        SizedBox(height: 20),
                        DropdownButtonFormField<String>(
                          value: homeViewModel.selectedSport,
                          hint: Text(l10n.of(context).selectSport,
                              style: TextStyle(fontSize: 12)),
                          icon: Image.asset("assets/icons/lowarrow.png",
                              height: 14, width: 12),
                          items: homeViewModel.sportsListModel.map((sport) {
                            return DropdownMenuItem<String>(
                                value: sport.id,
                                child: Text(sport.name ?? "",
                                    style: TextStyle(
                                        fontSize: 12, color: Colors.black)));
                          }).toList(),
                          onChanged: (value1) {
                            print("selected sport is $value1");
                            homeViewModel.setSelectedSport(value1);
                          },
                          style: TextStyle(fontSize: 12),
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Color(0xFFF4F9EC),
                            enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide:
                                    BorderSide(color: Colors.transparent)),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide:
                                    BorderSide(color: Colors.transparent)),
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 12, vertical: 10),
                            hintStyle: TextStyle(fontSize: 12),
                          ),
                          validator: (value) => value == null
                              ? l10n.of(context).pleaseSelectASport
                              : null,
                        ),

                        SizedBox(height: 12),

                        Consumer<MyLocationViewModel>(
                          builder: (context, myLocationViewModel, _) {
                            return TextFormField(
                              controller:
                                  myLocationViewModel.locationController,
                              readOnly: true,
                              onTap: () {
                                if (!myLocationViewModel.isLoadingManually) {
                                  myLocationViewModel.getAndNavigateToMapScreen(
                                      context, true);
                                }
                              },
                              style: TextStyle(fontSize: 12),
                              decoration: _inputDecoration(address).copyWith(
                                filled: true,
                                fillColor: Color(0xFFF4F9EC),
                                suffixIcon: Padding(
                                    padding: EdgeInsets.all(15),
                                    child: SizedBox(
                                      height: 10,
                                      width: 10,
                                      child:
                                          myLocationViewModel.isLoadingManually
                                              ? CircularProgressIndicator(
                                                  color: AppColors.primaryColor,
                                                  strokeWidth: 0.8)
                                              : Image.asset(
                                                  fit: BoxFit.cover,
                                                  'assets/icons/location.png',
                                                ),
                                    )),
                                hintStyle: TextStyle(fontSize: 12),
                              ),
                            );
                          },
                        ),

                        SizedBox(height: 12),

                        TextFormField(
                          onTap: () async {
                            DateTime? picked = await myshowDatePicker(
                              context: context,
                              initialDate: DateTime.now(),
                              firstDate: DateTime.now(),
                              lastDate: DateTime(2100),
                              fieldHintText: 'dd/mm/yyyy',
                              builder: (context, child) {
                                return Theme(
                                  data: Theme.of(context).copyWith(
                                    colorScheme: ColorScheme.light(
                                      primary: AppColors.primaryColor,
                                      onPrimary: Colors.white,
                                      onSurface: Colors.black,
                                    ),
                                    textButtonTheme: TextButtonThemeData(
                                      style: TextButton.styleFrom(
                                        foregroundColor: AppColors.primaryColor,
                                      ),
                                    ),
                                  ),
                                  child: child!,
                                );
                              },
                            );
                            if (picked != null) {
                             var pickedDate =  DateFormat("dd/MM/yyyy").format(picked);
                              /*homeViewModel.dateController.text =
                                  picked.toLocal().toString().split(' ')[0];*/
                              homeViewModel.dateController.text = pickedDate;
                            }
                            print("selected date is ${homeViewModel.dateController.text}");
                            print("selectesdfsffsdfd date is ${picked}");



                          },
                          controller: homeViewModel.dateController,
                          readOnly: true,
                          style: TextStyle(fontSize: 12, color: Colors.black),
                          decoration: inputDecoration(
                            hintText: l10n.of(context).date,
                          ).copyWith(
                            filled: true,
                            fillColor: Color(0xFFF4F9EC),
                            suffixIcon: Padding(
                              padding: EdgeInsets.all(10),
                              child:
                                  Icon(Icons.calendar_month_outlined, size: 20),
                            ),
                          ),
                          // validator: (val) => val == null || val.isEmpty
                          //     ? "Select a date"
                          //     : null,
                        ),
                        SizedBox(height: 12),
                        TextFormField(
                          readOnly: true,
                          controller: timeController,
                          decoration: InputDecoration(
                            hintText: l10n.of(context).time,
                            hintStyle: TextStyle(fontSize: 12),
                            filled: true,
                            fillColor: Color(0xFFF4F9EC),
                            suffixIcon: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 18),
                              child: Image.asset("assets/icons/lowarrow.png",
                                  height: 16, width: 14),
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide.none,
                            ),
                          ),
                          style: TextStyle(fontSize: 12, color: Colors.black),
                          onTap: () => showDialog(
                            context: context,
                            builder: (_) => HourPickerDialog(
                              onTimeSelected: (value) {
                                timeController.text = value;
                                homeViewModel.setSelectedTimeSlot(
                                    value); // use your ViewModel
                              },
                            ),
                          ),
                        ),


                        SizedBox(height: 12),

                        DropdownButtonFormField<String>(
                          value: homeViewModel.selectedAmenities,
                          hint: Text(l10n.of(context).amenities),
                          icon: Image.asset("assets/icons/lowarrow.png",
                              height: 16, width: 14),
                          items: homeViewModel.amenititesList.map((sport) {
                            return DropdownMenuItem<String>(
                                value: sport.id, child: Text(sport.name));
                          }).toList(),
                          onChanged: (value1) {
                            homeViewModel.setSelectedAminities(value1);
                          },
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Color(0xFFF4F9EC),
                            enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide:
                                    BorderSide(color: Colors.transparent)),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide:
                                    BorderSide(color: Colors.transparent)),
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 12, vertical: 10),
                          ),
                        ),

                        SizedBox(height: 16),

                        homeViewModel.isHomeFilter
                            ? SizedBox(
                                width: double.infinity,
                                height: 48,
                                child: Shimmer.fromColors(
                                  baseColor: Colors.grey[300]!,
                                  highlightColor: Colors.grey[100]!,
                                  child: ElevatedButton(
                                    onPressed: () {},
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Color(0xFF8DC63F),
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(10)),
                                    ),
                                    child: Text(l10n.of(context).filterApply,
                                        style: TextStyle(color: Colors.black)),
                                  ),
                                ),
                              )
                            : SizedBox(
                                width: double.infinity,
                                height: 48,
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: homeViewModel.isAnyFilterSelected
                                        ? Color(0xFF8DC63F)
                                        : AppColors.greyE5E5,
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(10)),
                                  ),

                                  onPressed: homeViewModel.isAnyFilterSelected
                                      ?
                                      () {
                                    if (_formKey.currentState!.validate()) {
                                      homeViewModel.setIsHomeFilter(true);

                                      SportsListModel? selectedSport;
                                      try {
                                        selectedSport = homeViewModel.sportsListModel.firstWhere(
                                              (sport) => sport.id == homeViewModel.selectedSport,
                                        );
                                      } catch (_) {}

                                      AmenitiesList? selectedAmenity;
                                      try {
                                        selectedAmenity = homeViewModel.amenititesList.firstWhere(
                                              (a) => a.id == homeViewModel.selectedAmenities,
                                        );
                                      } catch (_) {}

                                      String? selectedDate;
                                      final dateText = homeViewModel.dateController.text.trim();
                                      if (dateText.isNotEmpty) {
                                        final parsedDate = DateFormat('dd/MM/yyyy').parse(dateText);
                                        selectedDate = DateFormat('yyyy-MM-dd').format(parsedDate);
                                      }

                                      final selectedTime = homeViewModel.selectedTimeSlot;

                                      Navigator.pop(context);
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (_) => CourtFilterscreen(
                                            sport: selectedSport!,
                                            amenity: selectedAmenity,
                                            date: selectedDate, // ✅ null if not selected
                                            time: selectedTime,
                                          ),
                                        ),
                                      );
                                    }
                                  }

                                  //     () {
                                  //   if (_formKey.currentState!.validate()) {
                                  //     homeViewModel.setIsHomeFilter(true);
                                  //
                                  //     SportsListModel? selectedSport;
                                  //     try {
                                  //       selectedSport = homeViewModel.sportsListModel.firstWhere(
                                  //             (sport) => sport.id == homeViewModel.selectedSport,
                                  //       );
                                  //     } catch (_) {}
                                  //
                                  //     AmenitiesList? selectedAmenity;
                                  //     try {
                                  //       selectedAmenity = homeViewModel.amenititesList.firstWhere(
                                  //             (a) => a.id == homeViewModel.selectedAmenities,
                                  //       );
                                  //     } catch (_) {}
                                  //
                                  //     final parsedDate = DateFormat('dd/MM/yyyy').parse(homeViewModel.dateController.text);
                                  //
                                  //     final selectedDate =  DateFormat('yyyy-MM-dd').format(parsedDate);
                                  //     final selectedTime = homeViewModel.selectedTimeSlot;
                                  //
                                  //     Navigator.pop(context);
                                  //     Navigator.push(
                                  //       context,
                                  //       MaterialPageRoute(
                                  //         builder: (_) => CourtFilterscreen(
                                  //           sport: selectedSport!,
                                  //           amenity: selectedAmenity,
                                  //           date: selectedDate,
                                  //           time: selectedTime,
                                  //         ),
                                  //       ),
                                  //     );
                                  //   }
                                  // }
                                      : null,

                                  child: Text(l10n.of(context).filterApply,
                                      style: TextStyle(color: Colors.black)),
                                ),
                              )
                      ],
                    ),
                  ),
                ),
              );
            }),
          );
        });
  }

  InputDecoration _inputDecoration(String hintText) {
    return InputDecoration(
      hintText: hintText,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.transparent), // Transparent border
      ),
      enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: Colors.transparent)),
      focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: Colors.transparent)),
      filled: true,
      fillColor: Colors.white,
      // Background color
      contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 14),
    );
  }
  //
  // void showWhatToPlayDialog(BuildContext context) async {
  //   final _formKey = GlobalKey<FormState>();
  //
  //   showModalBottomSheet(
  //     context: context,
  //     backgroundColor: Colors.white,
  //     isScrollControlled: true,
  //     shape: RoundedRectangleBorder(
  //         borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
  //     builder: (BuildContext context) {
  //       return Consumer<HomeViewModel>(builder: (context, value, child) {
  //         return SingleChildScrollView(
  //           padding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
  //           child: Form(
  //             key: _formKey,
  //             child: Column(
  //               mainAxisSize: MainAxisSize.min,
  //               crossAxisAlignment: CrossAxisAlignment.start,
  //               children: [
  //                 // Header row
  //                 Row(
  //                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                   children: [
  //                     Text(S.of(context).whatDoYouWantToPlay,
  //                         style: TextStyle(
  //                             fontSize: 16,
  //                             fontWeight: FontWeight.w700,
  //                             color: Color(0xFF555555))),
  //                     GestureDetector(
  //                       onTap: () => Navigator.pop(context),
  //                       child: Image.asset('assets/icons/cross.png',
  //                           width: 24, height: 24),
  //                     ),
  //                   ],
  //                 ),
  //                 SizedBox(height: 18),
  //                 // Dropdown for sport selection
  //
  //                 DropdownButtonFormField<String>(
  //                   value: value.selectedSport, // ID
  //                   hint: Text(S.of(context).selectSports,
  //                       style: TextStyle(fontSize: 14)),
  //                   icon: Image.asset("assets/icons/lowarrow.png",
  //                       height: 14, width: 12),
  //                   items: value.sportsListModel.map((sport) {
  //                     return DropdownMenuItem<String>(
  //                       value: sport.id,
  //                       child: Text(sport.name ?? "",
  //                           style:
  //                               TextStyle(fontSize: 14, color: Colors.black)),
  //                     );
  //                   }).toList(),
  //                   onChanged: value.setSelectedSport, // Will update and save
  //                   style: TextStyle(fontSize: 14),
  //                   decoration: InputDecoration(
  //                     filled: true,
  //                     fillColor: Color(0xFFF4F9EC),
  //                     enabledBorder: OutlineInputBorder(
  //                       borderRadius: BorderRadius.circular(10),
  //                       borderSide: BorderSide(color: Colors.transparent),
  //                     ),
  //                     focusedBorder: OutlineInputBorder(
  //                       borderRadius: BorderRadius.circular(10),
  //                       borderSide: BorderSide(color: Colors.transparent),
  //                     ),
  //                     contentPadding:
  //                         EdgeInsets.symmetric(horizontal: 12, vertical: 10),
  //                     hintStyle: TextStyle(fontSize: 14),
  //                   ),
  //                   validator: (value) =>
  //                       value == null ? S.of(context).pleaseSelectASport : null,
  //                 ),
  //
  //                 SizedBox(height: 16),
  //                 // FutureBuilder for location (keeping it as is)
  //                 FutureBuilder<String?>(
  //                   future: getSavedLocation(),
  //                   builder: (context, snapshot) {
  //                     String location = snapshot.data ??
  //                         "${LocalService.instance.getData(LocalKeys.instance.currentLocation)}";
  //                     return TextFormField(
  //                       readOnly: true,
  //                       style: TextStyle(fontSize: 14),
  //                       decoration: _inputDecoration(location).copyWith(
  //                         filled: true,
  //                         fillColor: Color(0xFFF4F9EC),
  //                         suffixIcon: Padding(
  //                           padding: EdgeInsets.all(10),
  //                           child: Image.asset('assets/icons/location.png',
  //                               width: 10, height: 10),
  //                         ),
  //                         hintStyle: TextStyle(fontSize: 14),
  //                       ),
  //                     );
  //                   },
  //                 ),
  //                 SizedBox(height: 16),
  //                 // Dropdown for time selection
  //                 DropdownButtonFormField<String>(
  //                   decoration: InputDecoration(
  //                     hintText: S.of(context).whichTime,
  //                     hintStyle: TextStyle(fontSize: 14),
  //                     filled: true,
  //                     fillColor: Color(0xFFF4F9EC),
  //                     border: OutlineInputBorder(
  //                         borderRadius: BorderRadius.circular(8),
  //                         borderSide: BorderSide.none),
  //                   ),
  //                   style: TextStyle(fontSize: 14, color: Colors.black),
  //                   items: [
  //                     "12:00 AM",
  //                     "01:00 AM",
  //                     "02:00 AM",
  //                     "03:00 AM",
  //                     "04:00 AM",
  //                     "05:00 AM",
  //                     "06:00 AM",
  //                     "07:00 AM",
  //                     "08:00 AM",
  //                     "09:00 AM",
  //                     "10:00 AM",
  //                     "11:00 AM",
  //                     "12:00 PM",
  //                     "01:00 PM",
  //                     "02:00 PM",
  //                     "03:00 PM",
  //                     "04:00 PM",
  //                     "05:00 PM",
  //                     "06:00 PM",
  //                     "07:00 PM",
  //                     "08:00 PM",
  //                     "09:00 PM",
  //                     "10:00 PM",
  //                     "11:00 PM"
  //                   ]
  //                       .map((time) => DropdownMenuItem(
  //                           value: time,
  //                           child: Text(time, style: TextStyle(fontSize: 14))))
  //                       .toList(),
  //                   onChanged: (v) {
  //                     print('Selected time: $v');
  //                     value.setSelectedTimeSlot(
  //                         v); // Make sure this updates the time slot value
  //                   },
  //                   validator: (value) =>
  //                       value == null ? S.of(context).pleaseSelectATime : null,
  //                 ),
  //
  //                 SizedBox(height: 16),
  //
  //                 DropdownButtonFormField<String>(
  //                   decoration: InputDecoration(
  //                     filled: true,
  //                     hintText: S.of(context).skillLevel,
  //                     fillColor: Color(0xFFF4F9EC),
  //                     border: OutlineInputBorder(
  //                         borderRadius: BorderRadius.circular(8),
  //                         borderSide: BorderSide.none),
  //                   ),
  //                   style: TextStyle(fontSize: 14),
  //                   items: ['Beginner', 'Intermediate', 'Advanced']
  //                       .map((skill) => DropdownMenuItem(
  //                           value: skill,
  //                           child: Text(skill,
  //                               style: TextStyle(
  //                                   fontSize: 14, color: Colors.black))))
  //                       .toList(),
  //                   onChanged: (v) {
  //                     print('Selected skill: $v');
  //                     value.setSelectedSkillLevel(
  //                         v); // Make sure this updates the skill level
  //                   },
  //                   validator: (value) => value == null
  //                       ? S.of(context).pleaseSelectSkillLevel
  //                       : null,
  //                 ),
  //                 SizedBox(height: 16),
  //                 // Radius slider
  //                 ValueListenableBuilder<RangeValues>(
  //                   valueListenable: rangeValuesNotifier,
  //                   builder: (context, rangeValues, child) {
  //                     // Round the values to the nearest integer between 1 and 6
  //                     int startHour = rangeValues.start.round().clamp(1, 6);
  //                     int endHour = rangeValues.end.round().clamp(1, 6);
  //
  //                     return Text('$startHour hr - $endHour hr',
  //                         style: const TextStyle(
  //                             fontSize: 14, color: Colors.black));
  //                   },
  //                 ),
  //                 ValueListenableBuilder<RangeValues>(
  //                   valueListenable: rangeValuesNotifier,
  //                   builder: (context, rangeValues, child) {
  //                     return RangeSlider(
  //                       values: rangeValues,
  //                       min: 1,
  //                       max: 6,
  //                       activeColor: Color(0XFF8DC63F),
  //                       inactiveColor: Color(0XFF3B747D),
  //                       labels: RangeLabels(
  //                         '${rangeValues.start.round()}hr',
  //                         '${rangeValues.end.round()}hr',
  //                       ),
  //                       onChanged: (values) {
  //                         rangeValuesNotifier.value = RangeValues(
  //                           rangeValues.start,
  //                           values.end < rangeValues.start
  //                               ? rangeValues.start
  //                               : values.end,
  //                         );
  //                       },
  //                     );
  //                   },
  //                 ),
  //                 SizedBox(height: 16),
  //                 // Apply button
  //                 Padding(
  //                   padding: EdgeInsets.symmetric(horizontal: 20),
  //                   child: Stack(
  //                     children: [
  //                       Container(
  //                         height: 52,
  //                         width: double.infinity,
  //                         decoration: BoxDecoration(
  //                             borderRadius: BorderRadius.circular(10),
  //                             color: Color(0xFF72A033)),
  //                       ),
  //                       GestureDetector(
  //                         onTap: value.isUserPreferencesLoading
  //                             ? () {}
  //                             : () async {
  //                                 if (_formKey.currentState?.validate() ??
  //                                     false) {
  //                                   // Collect the form data
  //                                   String sportId = value.selectedSport ?? '';
  //                                   String skillLevel =
  //                                       value.selectedSkillLevel ?? '';
  //                                   String timeSlot =
  //                                       value.selectedTimeSlot ?? '';
  //                                   RangeValues timeRadius =
  //                                       rangeValuesNotifier.value;
  //
  //                                   // Calculate the midpoint of the selected range
  //                                   double midpoint =
  //                                       (timeRadius.start + timeRadius.end) / 2;
  //
  //                                   // Round the midpoint to the nearest whole number
  //                                   int roundedTimeRadius = midpoint.round();
  //
  //                                   // Ensure the value is between 1 and 6
  //                                   roundedTimeRadius =
  //                                       roundedTimeRadius.clamp(1, 6).toInt();
  //
  //                                   // Convert values to lists
  //                                   List<String> sportIds = [sportId];
  //                                   List<String> skillLevels = [skillLevel];
  //                                   List<String> timeSlots = [timeSlot];
  //
  //                                   print(".sportIds.....$sportIds");
  //                                   print("....skillLevels..$skillLevels");
  //                                   print(".timeSlots.....$timeSlots");
  //                                   print("....timeRadius..$roundedTimeRadius");
  //
  //                                   // Submit to API
  //                                   await value.setUserPreferences(
  //                                     context: context,
  //                                     sportIds: sportIds,
  //                                     skillLevel: skillLevels,
  //                                     timeSlot: timeSlots,
  //                                     timeRadius: roundedTimeRadius
  //                                         .toString(), // Send the number as string
  //                                   );
  //                                   setState(() {
  //                                     shouldShow = false;
  //                                   });
  //                                 }
  //                               },
  //                         child: Container(
  //                           height: 47,
  //                           width: double.infinity,
  //                           decoration: BoxDecoration(
  //                               color: Color(0xFF8DC63F),
  //                               borderRadius: BorderRadius.circular(10)),
  //                           child: Center(
  //                             child: value.isUserPreferencesLoading
  //                                 ? CircularProgressIndicator(
  //                                     color: Colors.white,
  //                                   )
  //                                 : Text(S.of(context).apply,
  //                                     style: TextStyle(
  //                                         color: Colors.black,
  //                                         fontSize: 14,
  //                                         fontWeight: FontWeight.w600)),
  //                           ),
  //                         ),
  //                       ),
  //                     ],
  //                   ),
  //                 ),
  //               ],
  //             ),
  //           ),
  //         );
  //       });
  //     },
  //   );
  // }

  final timeController = TextEditingController();
}

class HourPickerDialog extends StatefulWidget {
  final Function(String) onTimeSelected;

  const HourPickerDialog({required this.onTimeSelected});

  @override
  State<HourPickerDialog> createState() => _HourPickerDialogState();
}

class _HourPickerDialogState extends State<HourPickerDialog> {
  final List<String> hours = List.generate(
    24,
    (index) => DateFormat.jm().format(DateTime(0, 0, 0, index)),
  );

  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      backgroundColor: Colors.white,
      contentPadding: EdgeInsets.all(16),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            "Select Time",
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
          ),
          SizedBox(height: 8),
          SizedBox(
            height: 100,
            child: ListWheelScrollView.useDelegate(
              itemExtent: 39,
              perspective: 0.004,
              diameterRatio: 1.5,
              physics: FixedExtentScrollPhysics(),
              onSelectedItemChanged: (index) {
                setState(() {
                  selectedIndex = index;
                });
              },
              childDelegate: ListWheelChildBuilderDelegate(
                builder: (context, index) {
                  if (index < 0 || index >= hours.length) return null;
                  return Center(
                    child: Text(
                      hours[index],
                      style: TextStyle(
                        fontSize: 16,
                        color:
                            index == selectedIndex ? Colors.black : Colors.grey,
                        fontWeight: index == selectedIndex
                            ? FontWeight.w500
                            : FontWeight.normal,
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          SizedBox(height: 25),
          ElevatedButton(
            onPressed: () {
              widget.onTimeSelected(hours[selectedIndex]);
              Navigator.of(context).pop();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryColor,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              padding: EdgeInsets.symmetric(horizontal: 30, vertical: 2),
            ),
            child: Text("Select", style: TextStyle(color: Colors.white)),
          )
        ],
      ),
    );
  }
}
