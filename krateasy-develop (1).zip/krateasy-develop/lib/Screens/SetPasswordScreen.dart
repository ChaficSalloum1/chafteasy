import 'package:flutter/material.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:provider/provider.dart';
import '../ViewModel/SetPasswordViewModel.dart';

class SetPasswordScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => SetPasswordViewModel(),
      child: Consumer<SetPasswordViewModel>(
        builder: (context, viewModel, child) {
          return Scaffold(
            body: LayoutBuilder(
              builder: (context, constraints) {
                double commonWidth = constraints.maxWidth * 0.85;
                double commonHeight = constraints.maxHeight * 0.07;

                return Center(
                  child: SingleChildScrollView(
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            l10n.of(context).setPassword,
                            style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold),
                          ),
                          SizedBox(height: 5),
                          Text(
                            l10n.of(context).creteAStrongPasswordItMustContain,
                            style: TextStyle(fontSize: 15, color: Colors.grey[700]),
                          ),
                          Text(
                            l10n.of(context).atLeast6CharactersAnd1SpecialSymbol,
                            style: TextStyle(fontSize: 14, color: Colors.black54),
                          ),
                          SizedBox(height: 30),
                          _buildPasswordField(context, viewModel, l10n.of(context).enterPassword),
                          SizedBox(height: 10),
                          _buildPasswordField(context, viewModel, l10n.of(context).reenterPassword),
                          SizedBox(height: 30),
                          SizedBox(
                            width: commonWidth,
                            height: commonHeight,
                            child: ElevatedButton(
                              onPressed: () {
                                viewModel.onSubmit(context);
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF8DC63F),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                              ),
                              child: Text(
                                l10n.of(context).submit,
                                style: TextStyle(fontSize: 18, color: Colors.white),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }

  Widget _buildPasswordField(BuildContext context, SetPasswordViewModel viewModel, String label) {
    return Consumer<SetPasswordViewModel>(
      builder: (context, viewModel, child) {
        return SizedBox(
          width: MediaQuery.of(context).size.width * 0.85,
          child: TextField(
            obscureText: viewModel.isPasswordHidden,
            decoration: InputDecoration(
              labelText: label,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              suffixIcon: IconButton(
                icon: Icon(viewModel.isPasswordHidden ? Icons.visibility_off : Icons.visibility),
                onPressed: () {
                  viewModel.togglePasswordVisibility();
                },
              ),
            ),
          ),
        );
      },
    );
  }
}
