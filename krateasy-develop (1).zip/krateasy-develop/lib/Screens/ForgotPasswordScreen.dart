import 'package:country_picker/country_picker.dart';
import 'package:flutter/material.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:provider/provider.dart';

import '../ViewModel/ForgotPasswordViewModel.dart';

class ForgotPasswordScreen extends StatelessWidget {
  const ForgotPasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final viewModel = Provider.of<ForgotPasswordViewModel>(context);

    return Scaffold(
      body: LayoutBuilder(
        builder: (context, constraints) {
          double screenWidth = constraints.maxWidth;
          double commonWidth = screenWidth * 0.9; // Responsive width
          double commonHeight = 55; // Standardized height
          double fontSize = screenWidth * 0.05; // Scalable font size

          return Center(
            child: SingleChildScrollView(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Image.asset(viewModel.logoPath,
                        width: screenWidth * 0.4, height: screenWidth * 0.4),
                    SizedBox(height: screenWidth * 0.02),
                    Text(
                      l10n.of(context).forgetPassword,
                      style: TextStyle(
                          fontSize: fontSize * 1.5,
                          fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: screenWidth * 0.01),
                    Text(
                      l10n.of(context).pleaseEnterYourRegisteredNumberTo,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: fontSize * 0.9, color: Colors.grey[700]),
                    ),
                    Text(
                      l10n.of(context).receiveAVerificationCode,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: fontSize * 0.9, color: Colors.grey[700]),
                    ),
                    SizedBox(height: screenWidth * 0.08),

                    // Mobile Number Field with Country Picker
                    SizedBox(
                      width: commonWidth,
                      height: commonHeight,
                      child: Container(
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Row(
                          children: [
                            GestureDetector(
                              onTap: () {
                                showCountryPicker(
                                  context: context,
                                  showPhoneCode: true,
                                  onSelect: (Country country) {
                                    viewModel.setCountryCode(country.phoneCode);
                                    viewModel.setCountryFlag(country.flagEmoji);
                                  },
                                );
                              },
                              child: Padding(
                                padding: EdgeInsets.symmetric(horizontal: 12),
                                child: Row(
                                  children: [
                                    Text(viewModel.selectedCountryFlag,
                                        style: TextStyle(
                                            fontSize: fontSize * 0.9)),
                                    SizedBox(width: 6),
                                    Text(
                                      "+${viewModel.selectedCountryCode}",
                                      style: TextStyle(
                                          fontSize: fontSize * 0.7,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Container(
                                height: commonHeight * 0.8,
                                width: 1,
                                color: Colors.grey),
                            Expanded(
                              child: TextField(
                                controller: viewModel.phoneController,
                                keyboardType: TextInputType.phone,
                                decoration: InputDecoration(
                                  contentPadding:
                                      EdgeInsets.symmetric(horizontal: 12),
                                  hintText: l10n.of(context).enterMobileNumber,
                                  border: InputBorder.none,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: screenWidth * 0.03),

                    // Continue Button
                    SizedBox(
                      width: commonWidth,
                      height: commonHeight,
                      child: ElevatedButton(
                        onPressed: () => viewModel.onContinue(context),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF8DC63F),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                        ),
                        child: Text(
                          l10n.of(context).continues,
                          style: TextStyle(
                              fontSize: fontSize * 1.1, color: Colors.white),
                        ),
                      ),
                    ),
                    SizedBox(height: screenWidth * 0.05),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
