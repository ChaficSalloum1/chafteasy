import 'package:kratEasyApp/generated/l10n.dart';
import 'package:shimmer/shimmer.dart';
import '../BottomNavScreens/CreateChallengeScreen/CreateChallengeScreen.dart';
import '../GlobalUtils/app_imports.dart';
import '../GlobalUtils/common_share.dart';

class AllUpcomingBookings extends StatefulWidget {
  const AllUpcomingBookings({super.key});

  @override
  State<AllUpcomingBookings> createState() => _AllUpcomingBookingsState();
}

class _AllUpcomingBookingsState extends State<AllUpcomingBookings> {
  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: AppColors.white,
      appBar: CommonAppBar(title: l10n.of(context).upcomingBookings),
      body: Consumer<HomeViewModel>(
        builder: (BuildContext context, viewModel, Widget? child) {
          return viewModel.homeResponseModel.data?.upcomingBookings?.isEmpty ==
                  true
              ? Center(
                  child: Text(l10n.of(context).upcomingBookingsNotFound,
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: AppColors.black555)))
              : ListView.builder(
                  shrinkWrap: true,
                  physics: AlwaysScrollableScrollPhysics(),
                  padding: EdgeInsets.only(left: 14, right: 14, bottom: 20),
                  itemCount: viewModel
                      .homeResponseModel.data?.upcomingBookings?.length,
                  itemBuilder: (BuildContext context, int index) {
                    var opening = viewModel
                        .homeResponseModel.data?.upcomingBookings?[index];
                    final bookingDay = opening?.date != null
                        ? "${DateTime.parse(opening?.date.toString() ?? DateTime.now().toString()).day}"
                        : "";
                    final bookingMonthYear = opening?.date != null
                        ? DateFormat('MMM yyyy').format(DateTime.parse(
                            opening?.date.toString() ??
                                DateTime.now().toString()))
                        : "";
                    return Container(
                      width: 330, // Adjust width as needed
                      margin: EdgeInsets.only(
                          right: screenWidth * 0.01), // Space between cards
                      child: Card(
                        color: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        elevation: 0.1,
                        child: Padding(
                          padding: EdgeInsets.all(screenWidth * 0.02),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(8),
                                    child: NetworkImageWidget(
                                        image: opening?.courtImage ?? "",
                                        width: 90,
                                        height: 100,
                                        fit: BoxFit.fill),
                                  ),
                                  SizedBox(width: screenWidth * 0.025),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text('#${opening?.bookingId ?? ""}',
                                            style: TextStyle(
                                                fontSize: 13,
                                                fontWeight: FontWeight.w400,
                                                color: Color(0xFF555555))),
                                        Text(opening?.courtName ?? "",
                                            style: TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.w600,
                                                color: Colors.black)),
                                        SizedBox(height: screenHeight * 0.005),
                                        Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Image.asset("assets/icons/rate.png",
                                                width: 15,
                                                height: 15,
                                                fit: BoxFit.cover),
                                            SizedBox(
                                                width: screenWidth * 0.012),
                                            Text("4.7",
                                                style: TextStyle(
                                                    fontSize: 13,
                                                    fontWeight: FontWeight.w700,
                                                    color: Color(0xFF555555))),
                                            // Text(opening?.rating, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: Color(0xFF555555))),
                                            SizedBox(
                                                width: screenWidth * 0.012),
                                            Expanded(
                                              child: Text(
                                                opening?.facilityAddress ?? "",
                                                maxLines: 2,
                                                style: TextStyle(
                                                    fontSize: 11,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    fontWeight: FontWeight.w400,
                                                    color: Color(0xFF555555)),
                                              ),
                                            ),
                                          ],
                                        ),
                                        SizedBox(height: screenHeight * 0.005),
                                        Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Image.asset(
                                                'assets/icons/location.png',
                                                width: 14,
                                                height: 14),
                                            SizedBox(
                                                width: screenWidth * 0.012),
                                            Expanded(
                                              child: Text(
                                                opening?.facilityAddress ?? "",
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    fontWeight: FontWeight.w400,
                                                    color: Color(0xFF555555)),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  Column(
                                    children: [
                                      Text(opening?.startTime ?? "",
                                          style: TextStyle(
                                              fontSize: 10,
                                              fontWeight: FontWeight.w700,
                                              color: Color(0xFF000000))),
                                      Container(
                                        padding: EdgeInsets.symmetric(
                                            vertical: 2, horizontal: 3),
                                        decoration: BoxDecoration(
                                          color: Color(0xFF8DC63F)
                                              .withOpacity(0.2), // 20% opacity
                                          borderRadius:
                                              BorderRadius.circular(5),
                                        ),
                                        child: Column(
                                          children: [
                                            Row(
                                              children: [
                                                SizedBox(
                                                    height: 14,
                                                    width: 13,
                                                    child: Image.asset(
                                                        "assets/icons/calender.png")),
                                                SizedBox(width: 3),
                                                Text(bookingDay,
                                                    style: TextStyle(
                                                        fontSize: 14,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        color:
                                                            Color(0xFF8DC63F))),
                                              ],
                                            ),
                                            Text(bookingMonthYear,
                                                style: TextStyle(
                                                    fontSize: 10,
                                                    fontWeight: FontWeight.w600,
                                                    color: Color(0xFF555555))),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(height: 8),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text.rich(
                                    TextSpan(
                                      text: l10n.of(context).typeOfBooking,
                                      style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w400,
                                          color: Color(0xFF555555)),
                                      children: [
                                        TextSpan(
                                            text: l10n.of(context).wholeCourtBooking,
                                            style: TextStyle(
                                                fontWeight: FontWeight.w700,
                                                color: Color(0xFF555555)))
                                      ],
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      Image.asset('assets/icons/amount.png',
                                          width: 15, height: 15),
                                      SizedBox(width: screenWidth * 0.010),
                                      Text(
                                          "${AppConstants.appCurrency} ${opening?.price}",
                                          style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.black)),
                                    ],
                                  ),
                                ],
                              ),
                              Divider(
                                thickness: 0.93, // Set the thickness to 0.93px
                                color: Color(0xFFE3E3E3), // Set the color
                              ),
                              FittedBox(
                                fit: BoxFit
                                    .scaleDown, // Ensures content fits inside the Row
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Image.asset("assets/icons/football.png",
                                        width: 20, height: 20),
                                    SizedBox(width: screenWidth * 0.010),
                                    Text(opening?.sportName ?? "",
                                        style: TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w600,
                                            color: Color(0xFF3B747B))),
                                    SizedBox(width: screenWidth * 0.040),
                                    Container(
                                      width: 25, // Set width
                                      height: 25, // Set height
                                      decoration: BoxDecoration(
                                        color: Color(
                                            0xFF8DC63F), // Background color
                                        shape: BoxShape
                                            .circle, // Makes it circular
                                      ),
                                      child: IconButton(
                                        onPressed: () {
                                          shareData(
                                              'KratEasy.com/LHYN20568231');
                                        },
                                        icon: Image.asset(
                                            'assets/icons/share3.png',
                                            width: 15,
                                            height: 15),
                                        padding: EdgeInsets
                                            .zero, // Remove default padding for better centering
                                      ),
                                    ),
                                    SizedBox(width: screenWidth * 0.010),
                                    ElevatedButton(
                                      onPressed: () {
                                        showDialog(
                                          context: context,
                                          builder: (BuildContext context) {
                                            return Dialog(
                                              backgroundColor: AppColors.white,
                                              child: ListView(
                                                shrinkWrap: true,
                                                children: [
                                                  Stack(
                                                    children: [
                                                      Container(
                                                        width: double.infinity,
                                                        padding: EdgeInsets
                                                            .symmetric(
                                                                horizontal: 16,
                                                                vertical: 20),
                                                        decoration: BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        12)),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .center,
                                                          children: [
                                                            SizedBox(
                                                                height: 100,
                                                                width: 100,
                                                                child: Image.asset(
                                                                    AppImages
                                                                        .pngDialogCancel,
                                                                    fit: BoxFit
                                                                        .fill)),
                                                            SizedBox(
                                                                height: 10),
                                                            Text(
                                                                l10n.of(context).areYouSure,
                                                                style: TextStyle(
                                                                    color: AppColors
                                                                        .black,
                                                                    fontSize:
                                                                        20,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w600)),
                                                            SizedBox(
                                                                height: 10),
                                                            Text(
                                                              l10n.of(context).areYouSureYouWantToCancelThisBookingIf,
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              style: TextStyle(
                                                                  color: AppColors
                                                                      .grey769,
                                                                  fontSize: 16,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .normal),
                                                            ),
                                                            SizedBox(
                                                                height: 10),
                                                            Stack(
                                                              children: [
                                                                Container(
                                                                  height: 36,
                                                                  width: 150,
                                                                  decoration: BoxDecoration(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              10),
                                                                      color: AppColors
                                                                          .green033),
                                                                ),
                                                                GestureDetector(
                                                                  onTap:
                                                                      () async {
                                                                    Navigator.pop(
                                                                        context);
                                                                    await context
                                                                        .read<
                                                                            MyBookingsViewModel>()
                                                                        .cancelBooking(context:context,bookingId:
                                                                            opening?.id ??
                                                                                "",
                                                                            fromHome:
                                                                                true);
                                                                  },
                                                                  child:
                                                                      Container(
                                                                    height: 32,
                                                                    width: 150,
                                                                    decoration: BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.circular(
                                                                                10),
                                                                        color: AppColors
                                                                            .primaryColor),
                                                                    child:
                                                                        Center(
                                                                      child:
                                                                          Text(
                                                                        l10n.of(context).yesConfirm,
                                                                        style: TextStyle(
                                                                            color: AppColors
                                                                                .black,
                                                                            fontSize:
                                                                                12,
                                                                            fontWeight:
                                                                                FontWeight.w600),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Positioned(
                                                        top: 0,
                                                        right: 0,
                                                        child:
                                                            Transform.translate(
                                                          offset:
                                                              Offset(15, -15),
                                                          child:
                                                              GestureDetector(
                                                            onTap: () {
                                                              Navigator.pop(
                                                                  context);
                                                            },
                                                            child: SizedBox(
                                                                height: 40,
                                                                width: 40,
                                                                child: Image.asset(
                                                                    AppImages
                                                                        .pngDialogCross,
                                                                    fit: BoxFit
                                                                        .fill)),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            );
                                          },
                                        );
                                      },
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Color(0xFFFFEAFA),
                                        foregroundColor: Color(0xFFFF0000),
                                        minimumSize: Size(50, 25),
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(4)),
                                        padding: EdgeInsets.zero,
                                      ),
                                      child: Text(l10n.of(context).cancel,
                                          style: TextStyle(
                                              fontSize: 10,
                                              fontWeight: FontWeight.w700)),
                                    ),
                                    SizedBox(width: screenWidth * 0.010),
                                    ElevatedButton(
                                      onPressed: () {
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    CreateChallengeScreen()));
                                      },
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Color(0xFF3B747D),
                                        foregroundColor: Colors.white,
                                        minimumSize: Size(60, 25),
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(4)),
                                        padding: EdgeInsets.zero,
                                      ),
                                      child: Text(l10n.of(context).modify,
                                          style: TextStyle(
                                              fontSize: 10,
                                              fontWeight: FontWeight.w700)),
                                    ),
                                    SizedBox(width: screenWidth * 0.010),
                                    viewModel.isLoading
                                        ? Shimmer.fromColors(
                                            baseColor: Colors.grey,
                                            highlightColor: Colors.white,
                                            child: ElevatedButton(
                                              onPressed: () {},
                                              style: ElevatedButton.styleFrom(
                                                backgroundColor:
                                                    Color(0xFF555555),
                                                foregroundColor: Colors.white,
                                                minimumSize: Size(85, 25),
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            4)),
                                                padding: EdgeInsets.zero,
                                              ),
                                              child: Text(l10n.of(context).viewBookings,
                                                  style: TextStyle(
                                                      fontSize: 10,
                                                      fontWeight:
                                                          FontWeight.w700)),
                                            ),
                                          )
                                        : ElevatedButton(
                                            onPressed: () {
                                              Provider.of<HomeViewModel>(
                                                      context,
                                                      listen: false)
                                                  .getBookingDetails(context: context,
                                                      bookingId:
                                                          opening?.id ?? '',
                                                      courtId:
                                                          opening?.courtId ??
                                                              '');
                                            },
                                            style: ElevatedButton.styleFrom(
                                              backgroundColor:
                                                  Color(0xFF555555),
                                              foregroundColor: Colors.white,
                                              minimumSize: Size(85, 25),
                                              shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(4)),
                                              padding: EdgeInsets.zero,
                                            ),
                                            child: Text(l10n.of(context).viewBookings,
                                                style: TextStyle(
                                                    fontSize: 10,
                                                    fontWeight:
                                                        FontWeight.w700)),
                                          ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  });
        },
      ),
    );
  }
}
