import 'package:flutter/material.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:provider/provider.dart';
import '../ViewModel/VerificationViewModel.dart';

class VerificationScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final viewModel = Provider.of<VerificationViewModel>(context);
    return Scaffold(
      body: LayoutBuilder(
        builder: (context, constraints) {
          double commonWidth =
              constraints.maxWidth * 0.85; // Adjusted width dynamically
          double commonHeight =
              constraints.maxHeight * 0.07; // Adjusted height dynamically
          double otpSize =
              constraints.maxWidth * 0.15; // Dynamic OTP field size
          return Center(
            child: Padding(
              padding: EdgeInsets.symmetric(
                horizontal: constraints.maxWidth * 0.05,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  FittedBox(
                    child: Text(
                       l10n.of(context).verificationCode,
                      style: TextStyle(
                        fontSize: 34,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  SizedBox(height: 5),
                  FittedBox(
                    child: Text(
                    l10n.of(context).enterThe4digitCodeSentToYourPhone,
                      style: TextStyle(fontSize: 15, color: Colors.grey[700]),
                    ),
                  ),
                  SizedBox(height: constraints.maxHeight * 0.05),

                  // OTP Input Fields
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(4, (index) {
                      return Container(
                        width: otpSize,
                        height: otpSize,
                        margin: EdgeInsets.symmetric(horizontal: 5),
                        child: TextField(
                          controller: viewModel.otpControllers[index],
                          focusNode: viewModel.otpFocusNodes[index],
                          keyboardType: TextInputType.number,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                          maxLength: 1,
                          decoration: InputDecoration(
                            counterText: "",
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      );
                    }),
                  ),

                  SizedBox(height: constraints.maxHeight * 0.03),
                  Text(
                    l10n.of(context).didntReceiveACodeResend,
                    style: TextStyle(fontSize: 14, color: Colors.black54),
                  ),
                  SizedBox(height: 5),
                  Text(
                   l10n.of(context).resendOtpIn50s,
                    style: TextStyle(fontSize: 14, color: Colors.black54),
                  ),

                  SizedBox(height: constraints.maxHeight * 0.05),
                  SizedBox(
                    width: commonWidth,
                    height: commonHeight,
                    child: ElevatedButton(
                      onPressed: () {
                        viewModel.onVerify(context);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF8DC63F),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: Text(
                        l10n.of(context).verify,
                        style: TextStyle(fontSize: 18, color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
