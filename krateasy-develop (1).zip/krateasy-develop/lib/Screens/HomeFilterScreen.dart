import 'package:flutter/material.dart';
import 'package:kratEasyApp/GlobalUtils/app_constants.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/GlobalUtils/app_navigation.dart';
import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/GlobalUtils/network_image_widget.dart';
import 'package:kratEasyApp/ViewModel/BottomNavViewModels/HomeViewModel.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/utils/extension.dart';
import 'package:kratEasyApp/utils/throttle_debouncy.dart';
import 'package:provider/provider.dart';

import '../GlobalUtils/app_colors.dart';
import '../GlobalUtils/app_images.dart';
import '../GlobalUtils/common_app_bar.dart';
import '../ViewModel/BottomNavViewModels/HomeTabsViewModel/NearbyCourtsViewModel.dart';

class HomeFilterScreen extends StatefulWidget {
  const HomeFilterScreen({super.key});

  @override
  State<HomeFilterScreen> createState() => _HomeFilterScreenState();
}

class _HomeFilterScreenState extends State<HomeFilterScreen> {
  late NearbyCourtsViewModel viewModel1;
  @override
  void initState() {
    super.initState();
    viewModel1 = context.read<NearbyCourtsViewModel>();

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final data = await viewModel1.newSearchCourtApiForHome(context);
      if (mounted && data != null) {
        setState(() {
          viewModel1.searchFilterDataModel = data;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CommonAppBar(
        onTap: () async {
          print("home filter sccreen ontap");
          context.read<HomeViewModel>().setIsHomeFilter(false);
          Navigator.of(context).pop();
          final data = await viewModel1.newSearchCourtApiForHome(context);
          if (mounted && data != null) {
            setState(() {
              viewModel1.searchFilterDataModel = data;
            });
          }
        },
        title: l10n.of(context).filterResult,
        backIconColor: Colors.white,
        backgroundColor: Colors.white,
      ),
      backgroundColor: Colors.white,
      body: Consumer2<NearbyCourtsViewModel, HomeViewModel>(
          builder: (context, viewModel, homeViewModel, Widget? child) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: ListView(
            children: [
              SizedBox(height: 10),
              // Row(
              //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //   children: [
              //     Text(
              //       "SEARCH RESULT",
              //       style: TextStyle(
              //         color: Colors.black,
              //         fontSize: 16,
              //         fontWeight: FontWeight.w400,
              //       ),
              //     ),
              //   ],
              // ),
              // SizedBox(height: 8),
              // // Tags Section
              // Row(
              //   children: [
              //     Expanded(
              //       child: SingleChildScrollView(
              //         scrollDirection: Axis.horizontal,
              //         child: Row(
              //           children: [
              //             Chip(
              //               label: Text('Cricket'),
              //               deleteIcon: Image.asset(
              //                 'assets/icons/crosscircle.png',
              //                 width: 16,
              //                 height: 16,
              //               ),
              //               onDeleted: () {},
              //               backgroundColor: Colors.white,
              //             ),
              //             SizedBox(width: 8),
              //             Chip(
              //               label: Text('Edgbaston, Birmingham'),
              //               deleteIcon: Image.asset(
              //                 'assets/icons/crosscircle.png',
              //                 width: 16,
              //                 height: 16,
              //               ),
              //               onDeleted: () {},
              //               backgroundColor: Colors.white,
              //             ),
              //             SizedBox(width: 8),
              //             Chip(
              //               label: Text('Football'),
              //               deleteIcon: Image.asset(
              //                 'assets/icons/crosscircle.png',
              //                 width: 16,
              //                 height: 16,
              //               ),
              //               onDeleted: () {},
              //               backgroundColor: Colors.white,
              //             ),
              //           ],
              //         ),
              //       ),
              //     ),
              //   ],
              // ),

              // SizedBox(height: 8),
              viewModel.isLoading
                  ? Center(
                      child: CircularProgressIndicator(
                        color: AppColors.primaryColor,
                      ),
                    )
                  : (viewModel.searchFilterDataModel?.data?.isNotEmpty ?? false)
                      ? ListView.builder(
                          itemCount:
                              viewModel.searchFilterDataModel?.data?.length ??
                                  0,
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemBuilder: (context, index) {
                            final courtData =
                                viewModel.searchFilterDataModel?.data?[index];
                            return Padding(
                              padding: const EdgeInsets.only(
                                  bottom: 8.0), // Space between items
                              child: InkWell(
                                onTap: () async {
                                  TapThrottle.run('courtDetailsTap6', () async {
                                    homeViewModel.setRebookTextUpdate(false);
                                    final courtDetails =
                                        await homeViewModel.getCourtDetails(context: context,
                                            courtId: viewModel
                                                    .searchFilterDataModel
                                                    ?.data?[index]
                                                    .id ??
                                                "");
                                    if (courtDetails) {
                                      Navigator.pushNamed(
                                          NavigationService.context,
                                          '/viewCourtDetailsCompleteScreen');
                                    } else {
                                      showSnackbar(
                                          context: context,
                                          message: l10n.of(context).pleaseTryAgainLater);
                                    }
                                  });
                                },
                                child: Stack(
                                  children: [
                                    Container(
                                      padding: EdgeInsets.all(6),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(5),
                                        border: Border.all(
                                            color: AppColors.greyD0D0),
                                      ),
                                      child: Column(
                                        children: [
                                          Row(
                                            children: [
                                              SizedBox(
                                                  height: 75,
                                                  width: 90,
                                                  child: ClipRRect(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              2.5),
                                                      child: NetworkImageWidget(
                                                          image: (courtData
                                                                      ?.image ??
                                                                  "")
                                                              .toString()))),
                                              SizedBox(width: 10),
                                              Expanded(
                                                child: Column(
                                                  children: [
                                                    Row(
                                                      children: [
                                                        Expanded(
                                                          child: Text(
                                                            courtData?.name
                                                                    ?.capitalizeFirstLetter() ??
                                                                "",
                                                            style: TextStyle(
                                                              fontSize: 16,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                              color: AppColors
                                                                  .black,
                                                            ),
                                                          ),
                                                        ),
                                                        // SizedBox(
                                                        //   width: 25,
                                                        //   height: 25,
                                                        //   child: Image.asset(
                                                        //     'assets/icons/heart.png',
                                                        //     fit: BoxFit.fill,
                                                        //   ),
                                                        // ),
                                                      ],
                                                    ),
                                                    SizedBox(height: 10),
                                                    Row(
                                                      children: [
                                                        SizedBox(
                                                          width: 16,
                                                          height: 16,
                                                          child: Image.asset(
                                                            'assets/icons/rate.png',
                                                            fit: BoxFit.fill,
                                                          ),
                                                        ),
                                                        SizedBox(width: 4),
                                                        Text(
                                                          (courtData?.averageRating ??
                                                                  0)
                                                              .toString(),
                                                          style: TextStyle(
                                                            fontSize: 11,
                                                            fontWeight:
                                                                FontWeight.w700,
                                                            color: AppColors
                                                                .black555,
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets
                                                              .symmetric(
                                                            horizontal: 3,
                                                          ),
                                                          width: 1,
                                                          height: 15,
                                                          color: AppColors
                                                              .greyD9D9,
                                                        ),
                                                        Text(
                                                          (courtData?.facility
                                                                      ?.name ??
                                                                  l10n.of(context).na)
                                                              .toString(),
                                                          style: TextStyle(
                                                            fontSize: 11,
                                                            fontWeight:
                                                                FontWeight
                                                                    .normal,
                                                            color: AppColors
                                                                .black555,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    SizedBox(height: 10),
                                                    Row(
                                                      children: [
                                                        SizedBox(
                                                          width: 16,
                                                          height: 16,
                                                          child: Image.asset(
                                                            AppImages
                                                                .pngLocationGrey,
                                                            fit: BoxFit.fill,
                                                          ),
                                                        ),
                                                        SizedBox(width: 4),
                                                        Expanded(
                                                          child: Text(
                                                            (courtData?.facility
                                                                        ?.address ??
                                                                    l10n.of(context).na)
                                                                .toString(),
                                                            maxLines: 1,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            style: TextStyle(
                                                              fontSize: 11,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w700,
                                                              color: AppColors
                                                                  .black555,
                                                            ),
                                                          ),
                                                        ),
                                                        Text(
                                                          "${AppConstants.appCurrency} ${viewModel.searchFilterDataModel?.data?[index].price ?? 0}",
                                                          style: TextStyle(
                                                            fontSize: 13,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                            color:
                                                                AppColors.black,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                          SizedBox(height: 10),
                                          Container(
                                            width: double.infinity,
                                            height: 1,
                                            color: AppColors.grey3E3,
                                          ),
                                          SizedBox(height: 10),
                                          Consumer<NearbyCourtsViewModel>(
                                            builder: (context, viewModel, _) {
                                              return SingleChildScrollView(
                                                scrollDirection:
                                                    Axis.horizontal,
                                                child: Row(
                                                  children: List.generate(
                                                    viewModel.times.length,
                                                    (timeIndex) {
                                                      bool isSelected = viewModel
                                                              .getSelectedIndex(
                                                                  index) ==
                                                          timeIndex;

                                                      return Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(
                                                          right: 10,
                                                        ),
                                                        child: InkWell(
                                                          onTap: () {
                                                            viewModel
                                                                .updateSelectedIndex(
                                                              index,
                                                              timeIndex,
                                                            );
                                                          },
                                                          child: Container(
                                                            padding:
                                                                const EdgeInsets
                                                                    .symmetric(
                                                              horizontal: 14,
                                                              vertical: 10,
                                                            ),
                                                            decoration:
                                                                BoxDecoration(
                                                              color: isSelected
                                                                  ? Color(
                                                                      0xFF8DC63F)
                                                                  : Color(
                                                                      0xFFF4F9EC),
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          9),
                                                            ),
                                                            child: Center(
                                                              child: Text(
                                                                viewModel.times[
                                                                    timeIndex],
                                                                style:
                                                                    TextStyle(
                                                                  fontSize: 13,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w700,
                                                                  color: isSelected
                                                                      ? Colors
                                                                          .white
                                                                      : Color(
                                                                          0xFF858585),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      );
                                                    },
                                                  ),
                                                ),
                                              );
                                            },
                                          ),
                                        ],
                                      ),
                                    ),
                                    // Positioned Circular Icon
                                    Positioned(
                                      top: 5,
                                      right: 5,
                                      child: Column(
                                        children: [
                                          SizedBox(height: 2),
                                          Container(
                                            padding: EdgeInsets.symmetric(
                                              vertical: 2,
                                              horizontal: 3,
                                            ),
                                            decoration: BoxDecoration(
                                              color: AppColors.greyGreen63F
                                                  .withOpacity(.1),
                                              borderRadius:
                                                  BorderRadius.circular(5),
                                            ),
                                            child: Column(
                                              children: [
                                                Row(
                                                  children: [
                                                    SizedBox(
                                                      height: 13,
                                                      width: 14,
                                                      child: Image.asset(
                                                        "assets/icons/calender.png",
                                                      ),
                                                    ),
                                                    SizedBox(width: 3),
                                                    Text(
                                                        DateFormat("d").format(
                                                          DateTime.tryParse(viewModel
                                                                      .searchFilterDataModel
                                                                      ?.data?[
                                                                          index]
                                                                      .date ??
                                                                  '') ??
                                                              DateTime.now(),
                                                        ),
                                                        style: TextStyle(
                                                            fontSize: 20,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                            color: AppColors
                                                                .primaryColor)),
                                                  ],
                                                ),
                                                Text(
                                                    DateFormat("MMM yyyy")
                                                        .format(
                                                      DateTime.tryParse(viewModel
                                                                  .searchFilterDataModel
                                                                  ?.data?[index]
                                                                  .date ??
                                                              '') ??
                                                          DateTime.now(),
                                                    ),
                                                    style: TextStyle(
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        color: AppColors
                                                            .black555)),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        )
                      : Center(
                          child: Padding(
                          padding: EdgeInsets.only(top: 15.0),
                          child: Text(l10n.of(context).noCourtsAvailable),
                        )),
              //give some space between the two entries or openigs
            ],
          ),
        );
      }),
    );
  }
}
