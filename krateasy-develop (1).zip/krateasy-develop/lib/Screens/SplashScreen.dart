import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:geocoding/geocoding.dart';

import '../ViewModel/EntranceViewModel/booking_provider.dart';
import '../ViewModel/SplashViewModel.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final bookingVM = Provider.of<BookingProvider>(context,listen: false);
      await _getCurrentLocation();
     await bookingVM.getContacts(context: context);
      Provider.of<SplashViewModel>(context, listen: false)
          .startTimer(context);
    });
  }

  Future<void> _getCurrentLocation() async {

    LocationPermission permission = await Geolocator.checkPermission();


    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
  ;
      permission = await Geolocator.requestPermission();
      print("🎯 requestPermission → $permission");
    }

    print("✅ [SplashScreen] Final permission status → $permission");
    if (permission != LocationPermission.always &&
        permission != LocationPermission.whileInUse) {
      ScaffoldMessenger.of(context).showSnackBar(
         SnackBar(content: Text(l10n.of(context).locationPermissionNotGranted)),
      );
      return;
    }

    // 2) Check if GPS/Location Services are enabled
    print("⛰️ [SplashScreen] Checking if location service is enabled...");
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    print("⛰️ serviceEnabled: $serviceEnabled");
    if (!serviceEnabled) {
      // Prompt user to enable location services
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text(l10n.of(context).enableLocation),
          content:  Text(
            l10n.of(context).locationServicesAreDisabledPleaseTurnOnGpsToContinue
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(l10n.of(context).cancel),
            ),
            TextButton(
              onPressed: () {
                Geolocator.openLocationSettings();
                Navigator.pop(context);
              },
              child:  Text(l10n.of(context).openSettings),
            ),
          ],
        ),
      );
      return;
    }

    // 3) Fetch position and reverse‑geocode
    try {
      print("📍 [SplashScreen] Getting current position...");
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.best,
      );
      print(
        "📍 Position: lat=${position.latitude}, lon=${position.longitude}"
      );

      print("🌐 [SplashScreen] Reverse‑geocoding address...");
      List<Placemark> placemarks =
          await placemarkFromCoordinates(position.latitude, position.longitude);

      if (placemarks.isNotEmpty) {
        final place = placemarks.first;
        final address =
            "${place.street}, ${place.locality}, ${place.country}";
        print("🌐 Address: $address");
        await _saveLocationToStorage(address, position);
      }
    } catch (e) {
      print("❌ [SplashScreen] Error: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to get location: $e")),
      );
    }
  }

  Future<void> _saveLocationToStorage(
      String address, Position position) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user_address', address);
    await prefs.setDouble('latitude', position.latitude);
    await prefs.setDouble('longitude', position.longitude);
    print("💾 [SplashScreen] Location saved: $address");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SizedBox.expand(
          child: Image.asset('assets/gif/krat.gif', fit: BoxFit.cover),
        ),
      ),
    );
  }
}
