import 'package:kratEasyApp/BottomNavScreens/ChallengeTab/ActiveChallengeTab.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import '../GlobalUtils/app_imports.dart';

class AllChallenges extends StatefulWidget {
  const AllChallenges({super.key});

  @override
  State<AllChallenges> createState() => _AllChallengesState();
}

class _AllChallengesState extends State<AllChallenges> {
  @override
  Widget build(BuildContext context) {
    // double screenWidth = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: AppColors.white,
      appBar: CommonAppBar(title: l10n.of(context).availableChallenges),
      body: Consumer<AvailableChallengeGuestViewModel>(
        builder: (BuildContext context, court, Widget? child) {
          return court.challengeData.isEmpty
              ? Center(
                  child: Text(l10n.of(context).challengesNotAvailableYet,
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: AppColors.black555)))
              : ActiveChallengesContent(
                  isAvailable: false,
                  isNoTopShown: true,
                );
          // : ListView.separated(
          //     separatorBuilder: (context, index) {
          //       return Padding(padding: EdgeInsets.only(bottom: 7));
          //     },
          //     shrinkWrap: true,
          //     padding: EdgeInsets.only(left: 14, right: 14, bottom: 30),
          //     physics: AlwaysScrollableScrollPhysics(),
          //     itemCount: court.challengeData.length,
          //     itemBuilder: (context, index) {
          //       var courtData = court.challengeData[index];
          //       return GestureDetector(
          //         onTap: () {},
          //         child: Card(
          //           color: Colors.white,
          //           shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          //           elevation: 0.1,
          //           // margin: EdgeInsets.only(
          //           //   bottom: index == viewModel.openings.length - 1
          //           //       ? 0 // No margin for the last card
          //           //       : screenHeight * 0.015,
          //           // ),
          //           child: Padding(
          //             padding: EdgeInsets.all(screenWidth * 0.03),
          //             child: Column(
          //               crossAxisAlignment: CrossAxisAlignment.start,
          //               children: [
          //                 Row(
          //                   crossAxisAlignment: CrossAxisAlignment.start,
          //                   children: [
          //                     ClipRRect(
          //                       borderRadius: BorderRadius.circular(8),
          //                       child: NetworkImageWidget(image: (courtData.slots?.court?.image ?? "").toString(), width: screenWidth * 0.20, height: screenWidth * 0.20),
          //                     ),
          //                     SizedBox(width: screenWidth * 0.025),
          //                     Expanded(
          //                       child: Column(
          //                         crossAxisAlignment: CrossAxisAlignment.start,
          //                         children: [
          //                           Text(
          //                             (courtData.slots?.court?.sport?.name ?? "").toString(),
          //                             style: TextStyle(fontSize: screenWidth * 0.042, fontWeight: FontWeight.w600, color: AppColors.black),
          //                           ),
          //                           Text(
          //                             (courtData?.slots?.court?.name ?? "").toString(),
          //                             style: TextStyle(fontSize: screenWidth * 0.038, fontWeight: FontWeight.w600, color: AppColors.greyGreen47D),
          //                           ),
          //                           Row(
          //                             children: [
          //                               Image.asset("assets/png/calender.png", width: screenWidth * 0.033, height: screenWidth * 0.033, fit: BoxFit.cover),
          //                               SizedBox(width: screenWidth * 0.002),
          //                               Text(" ${courtData.date.toString()} ", style: TextStyle(fontSize: screenWidth * 0.026, color: Color(0xFF555555))),
          //                               SizedBox(width: screenWidth * 0.007),
          //                               Container(width: 1, height: screenHeight * 0.03, color: Color(0xFFDD9D9D9)),
          //                               SizedBox(width: screenWidth * 0.007),
          //                               Text(
          //                                 " ${courtData.slots?.startTime.toString()} - ${courtData.slots?.endTime.toString()}",
          //                                 style: TextStyle(fontSize: screenWidth * 0.026, color: Color(0xFF555555)),
          //                               ),
          //                             ],
          //                           ),
          //                         ],
          //                       ),
          //                     ),
          //                     Container(
          //                       padding: EdgeInsets.all(10),
          //                       decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(width: 1, color: AppColors.primaryColor)),
          //                       child: ClipRRect(
          //                         borderRadius: BorderRadius.circular(50),
          //                         child: NetworkImageWidget(image: (courtData.slots?.court?.sport?.image ?? "").toString(), width: screenWidth * 0.06, height: screenWidth * 0.06),
          //                       ),
          //                     ),
          //                   ],
          //                 ),
          //                 Divider(),
          //                 SizedBox(height: screenHeight * 0.005),
          //                 Stack(
          //                   children: [
          //                     Container(height: 6, width: screenWidth, decoration: BoxDecoration(borderRadius: BorderRadius.circular(3), color: AppColors.grey1E1)),
          //                     Container(
          //                       height: 6,
          //                       width: ((courtData.whoJoined?.length)! / (courtData.maxPlayer)) * screenWidth,
          //                       decoration: BoxDecoration(borderRadius: BorderRadius.circular(3), color: AppColors.greyGreen47D),
          //                     ),
          //                   ],
          //                 ),
          //                 SizedBox(height: 5),
          //                 Row(
          //                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //                   children: [
          //                     Expanded(
          //                       child: Row(
          //                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //                         crossAxisAlignment: CrossAxisAlignment.start,
          //                         children: [
          //                           Column(
          //                             crossAxisAlignment: CrossAxisAlignment.start,
          //                             children: [
          //                               Text(
          //                                 "${courtData.whoJoined?.length ?? 0} Player going",
          //                                 style: TextStyle(fontSize: screenWidth * 0.040, fontWeight: FontWeight.normal, color: AppColors.blackA2A),
          //                               ),
          //                               Center(child: CircularImageStack(imageUrls: court.imageUrls, maxImages: 4)),
          //                             ],
          //                           ),
          //                           Column(
          //                             crossAxisAlignment: CrossAxisAlignment.end,
          //                             children: [
          //                               Text("Out of ${courtData.maxPlayer.toString()}", style: TextStyle(fontSize: screenWidth * 0.040, fontWeight: FontWeight.normal, color: AppColors.blackA2A)),
          //                               SizedBox(height: 8),
          //                               Transform.translate(
          //                                 offset: Offset(screenWidth * .03, screenWidth * .03),
          //                                 child: Container(
          //                                   padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          //                                   decoration: BoxDecoration(
          //                                     color: AppColors.black,
          //                                     borderRadius: BorderRadius.only(topLeft: Radius.circular(3), bottomLeft: Radius.circular(5), bottomRight: Radius.circular(5)),
          //                                   ),
          //                                   child: Text(
          //                                     "${AppConstants.appCurrency} ${(courtData.slots?.price ?? 0).toString()} | JOIN US",
          //                                     style: TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: Colors.white),
          //                                   ),
          //                                 ),
          //                               ),
          //                             ],
          //                           ),
          //                         ],
          //                       ),
          //                     ),
          //                   ],
          //                 ),
          //               ],
          //             ),
          //           ),
          //         ),
          //       );
          //     },
          //   );
        },
      ),
    );
  }
}
