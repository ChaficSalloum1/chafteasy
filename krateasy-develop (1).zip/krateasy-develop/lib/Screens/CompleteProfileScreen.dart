import 'package:flutter/material.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:provider/provider.dart';
import '../ViewModel/CompleteProfileViewModel.dart';

class CompleteProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final Size screenSize = MediaQuery.of(context).size;
    double commonWidth = screenSize.width * 0.9;
    double commonHeight =
        screenSize.height * 0.07; // Adjust height proportionally

    return ChangeNotifierProvider(
      create: (context) => CompleteProfileViewModel(),
      child: Consumer<CompleteProfileViewModel>(
        builder: (context, viewModel, child) {
          return Scaffold(
            appBar: AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0,
              actions: [
                GestureDetector(
                  onTap: () {
                    viewModel.onSkip();
                  },
                  child: Padding(
                    padding: EdgeInsets.only(right: screenSize.width * 0.05),
                    child: Image.asset(
                      'assets/skip/skip.png',
                      width: 50, // Increased size
                      height: 50, // Increased size
                    ),
                  ),
                ),
              ],
            ),
            body: SingleChildScrollView(
              child: Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: screenSize.width * 0.05,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(height: screenSize.height * 0.05),

                    // Header Text
                    Text(
                      l10n.of(context).completeProfile,
                      style: TextStyle(
                        fontSize: screenSize.width * 0.08,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(height: screenSize.height * 0.015),

                    Text(
                      l10n.of(context).fillYourInformationBelowOrRegister,
                      style: TextStyle(
                        fontSize: screenSize.width * 0.04,
                        color: Colors.grey[700],
                      ),
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(height: screenSize.height * 0.02),

                    // Profile Picture Upload Box
                    GestureDetector(
                      onTap: () {
                        viewModel.pickImage();
                      },
                      child: Stack(
                        alignment: Alignment.bottomRight,
                        children: [
                          Container(
                            width: screenSize.width * 0.3,
                            height: screenSize.width * 0.3,
                            decoration: BoxDecoration(
                              color: Colors.grey[300],
                              shape: BoxShape.circle,
                              image: viewModel.image != null
                                  ? DecorationImage(
                                      image: FileImage(viewModel.image!),
                                      fit: BoxFit.cover,
                                    )
                                  : null,
                            ),
                            child: viewModel.image == null
                                ? Icon(
                                    Icons.camera_alt,
                                    size: screenSize.width * 0.1,
                                    color: Colors.white,
                                  )
                                : null,
                          ),
                          Positioned(
                            bottom: 5,
                            right: 5,
                            child: CircleAvatar(
                              backgroundColor: const Color(0xFF8DC63F),
                              radius: screenSize.width * 0.05,
                              child: Icon(
                                Icons.add_a_photo,
                                color: Colors.white,
                                size: screenSize.width * 0.05,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: screenSize.height * 0.03),

                    // Form Fields
                    buildTextField(l10n.of(context).fullName),
                    buildTextField(l10n.of(context).emailAddress),
                    buildTextField(l10n.of(context).phoneNumber),

                    // Sports Dropdown
                    SizedBox(
                      width: commonWidth,
                      child: DropdownButtonFormField<String>(
                        value: viewModel.selectedSport.isEmpty
                            ? null
                            : viewModel.selectedSport,
                        hint: Text(l10n.of(context).selectSportsName),
                        onChanged: (String? newValue) {
                          viewModel.setSelectedSport(newValue!);
                        },
                        items: viewModel.sportsList.map((String sport) {
                          return DropdownMenuItem<String>(
                            value: sport,
                            child: Text(sport),
                          );
                        }).toList(),
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    SizedBox(height: screenSize.height * 0.03),

                    // Submit Button
                    SizedBox(
                      width: commonWidth,
                      height: commonHeight,
                      child: ElevatedButton(
                        onPressed: () {
                          viewModel.onSubmit(context);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF8DC63F),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        child: Text(
                          l10n.of(context).submit,
                          style: TextStyle(
                            fontSize: screenSize.width * 0.05,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: screenSize.height * 0.05),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget buildTextField(String labelText) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10.0),
      child: SizedBox(
        width: double.infinity,
        child: TextField(
          decoration: InputDecoration(
            labelText: labelText,
            border: OutlineInputBorder(),
          ),
        ),
      ),
    );
  }
}
