import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/utils/extension.dart';
import 'package:kratEasyApp/utils/throttle_debouncy.dart';

import '../GlobalUtils/app_imports.dart';

class AllNearByCourts extends StatefulWidget {
  const AllNearByCourts({super.key});

  @override
  State<AllNearByCourts> createState() => _AllNearByCourtsState();
}

class _AllNearByCourtsState extends State<AllNearByCourts> {
  @override
  void initState() {
    super.initState();
    final viewModel1 = context.read<NearbyCourtsViewModel>();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final data = await viewModel1.newSearchCourtApiForHome(context);
      if (mounted && data != null) {
        setState(() {
          viewModel1.searchFilterDataModel = data;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    // double screenWidth = MediaQuery.of(context).size.width;
    // double screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: AppColors.white,
      appBar: CommonAppBar(title: l10n.of(context).availableNearbyCourts),
      body: Consumer2<NearbyCourtsViewModel, HomeViewModel>(
        builder:
            (BuildContext context, viewModel, homeViewModel, Widget? child) {
          return viewModel.searchFilterDataModel?.data?.isEmpty ?? false
              ? Center(
                  child: Text(l10n.of(context).courtsNotAvailableYet,
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: AppColors.black555)))
              : ListView.builder(
                  itemCount: viewModel.searchFilterDataModel?.data?.length,
                  padding: EdgeInsets.only(left: 14, right: 14, bottom: 20),
                  shrinkWrap: true,
                  physics: AlwaysScrollableScrollPhysics(),
                  itemBuilder: (context, index) {
                    var challengeData =
                        viewModel.searchFilterDataModel?.data?[index];
                    return InkWell(
                      onTap: () async {
                        TapThrottle.run('courtDetailsTap5', () async {
                          homeViewModel.setRebookTextUpdate(false);
                          final courtDetails =
                              await homeViewModel.getCourtDetails(context: context,
                                  courtId: challengeData?.id ?? "");
                          if (courtDetails) {
                            Navigator.pushNamed(NavigationService.context,
                                '/viewCourtDetailsCompleteScreen');
                          } else {
                            showSnackbar(
                                context: context,
                                message: l10n.of(context).pleaseTryAgainLater);
                          }
                        });
                      },
                      child: Stack(
                        children: [
                          Container(
                            padding: EdgeInsets.all(6),
                            margin: EdgeInsets.only(bottom: 14),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5),
                                border: Border.all(color: AppColors.greyD0D0)),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    SizedBox(
                                        height: 75,
                                        width: 90,
                                        child: ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(2.5),
                                            child: NetworkImageWidget(
                                                image:
                                                    (challengeData?.image ?? "")
                                                        .toString()))),
                                    SizedBox(width: 10),
                                    Expanded(
                                      child: Column(
                                        children: [
                                          Row(
                                            children: [
                                              Expanded(
                                                  child: Text(
                                                      (challengeData?.name ??
                                                              "")
                                                          .toString()
                                                          .capitalizeFirstLetter(),
                                                      style: TextStyle(
                                                          fontSize: 16,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: AppColors
                                                              .black))),
                                            ],
                                          ),
                                          SizedBox(height: 5),
                                          Row(
                                            children: [
                                              SizedBox(
                                                  width: 16,
                                                  height: 16,
                                                  child: Image.asset(
                                                      'assets/icons/rate.png',
                                                      fit: BoxFit.fill)),
                                              SizedBox(width: 4),
                                              Text(
                                                  (challengeData
                                                              ?.averageRating ??
                                                          0.0)
                                                      .toString(),
                                                  style: TextStyle(
                                                      fontSize: 13,
                                                      fontWeight:
                                                          FontWeight.w700,
                                                      color:
                                                          AppColors.black555)),
                                              Container(
                                                  margin: EdgeInsets.symmetric(
                                                      horizontal: 3),
                                                  width: 1,
                                                  height: 15,
                                                  color: AppColors.greyD9D9),
                                              Text(
                                                  (challengeData?.facility
                                                              ?.name ??
                                                          "")
                                                      .toString(),
                                                  style: TextStyle(
                                                      fontSize: 11,
                                                      fontWeight:
                                                          FontWeight.normal,
                                                      color:
                                                          AppColors.black555)),
                                            ],
                                          ),
                                          SizedBox(height: 5),
                                          Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              SizedBox(
                                                  width: 16,
                                                  height: 16,
                                                  child: Image.asset(
                                                      AppImages.pngLocationGrey,
                                                      fit: BoxFit.fill)),
                                              SizedBox(width: 4),
                                              Expanded(
                                                  child: Text(
                                                      (challengeData?.facility
                                                                  ?.address ??
                                                              "")
                                                          .toString()
                                                          .capitalizeFirstLetter(),
                                                      maxLines: 1,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      style: TextStyle(
                                                          fontSize: 11,
                                                          fontWeight:
                                                              FontWeight.w700,
                                                          color: AppColors
                                                              .black555))),
                                              SizedBox(width: 4),
                                              if ((challengeData?.price != 0 ||
                                                  challengeData?.slots?.first
                                                          .price !=
                                                      0))
                                                Text(
                                                  "${AppConstants.appCurrency} ${(challengeData?.price ?? challengeData?.slots?.first.price ?? 0).toString()}",
                                                  style: TextStyle(
                                                      fontSize: 13,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      color: AppColors.black),
                                                ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 10),
                                Container(
                                    width: double.infinity,
                                    height: 1,
                                    color: AppColors.grey3E3),
                                SizedBox(height: 10),
                                Consumer<NearbyCourtsViewModel>(
                                  builder: (context, viewModel, _) {
                                    return SingleChildScrollView(
                                      scrollDirection: Axis.horizontal,
                                      child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        mainAxisSize: MainAxisSize.min,
                                        children: List.generate(
                                            challengeData?.slots?.length ?? 0,
                                            (timeIndex) {
                                          bool isSelected = viewModel
                                                  .getSelectedIndex(index) ==
                                              timeIndex;
                                          var slotData =
                                              challengeData?.slots?[timeIndex];

                                          return Padding(
                                            padding: const EdgeInsets.only(
                                                right: 10),
                                            child:

                                            // InkWell(
                                            //   onTap: () {
                                            //   },
                                            //   child:

                                              Container(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 14,
                                                        vertical: 10),
                                                decoration: BoxDecoration(
                                                    color: isSelected
                                                        ? Color(0xFF8DC63F)
                                                        : Color(0xFFF4F9EC),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            9)),
                                                child: Center(
                                                  child: Text(
                                                    (slotData?.startTime)
                                                        .toString(),
                                                    style: TextStyle(
                                                        fontSize: 13,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        color: isSelected
                                                            ? Colors.white
                                                            : Color(
                                                                0xFF858585)),
                                                  ),
                                                ),
                                              ),
                                            // ),
                                          );
                                        }),
                                      ),
                                    );
                                  },
                                ),
                              ],
                            ),
                          ),
                          // Positioned Circular Icon
                          Positioned(
                            top: 5,
                            right: 5,
                            child: Column(
                              children: [
                                SizedBox(height: 2),
                                Container(
                                  padding: EdgeInsets.symmetric(
                                      vertical: 2, horizontal: 3),
                                  decoration: BoxDecoration(
                                      color: AppColors.greyGreen63F
                                          .withOpacity(.1),
                                      borderRadius: BorderRadius.circular(5)),
                                  child: Column(
                                    children: [
                                      Row(
                                        children: [
                                          SizedBox(
                                              height: 13,
                                              width: 14,
                                              child: Image.asset(
                                                  "assets/icons/calender.png")),
                                          SizedBox(width: 3),
                                          Text(
                                              DateFormat("d").format(
                                                DateTime.tryParse(viewModel
                                                            .searchFilterDataModel
                                                            ?.data?[index]
                                                            .date ??
                                                        '') ??
                                                    DateTime.now(),
                                              ),
                                              style: TextStyle(
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.w600,
                                                  color:
                                                      AppColors.primaryColor)),
                                        ],
                                      ),
                                      Text(
                                          DateFormat("MMM yyyy").format(
                                            DateTime.tryParse(viewModel
                                                        .searchFilterDataModel
                                                        ?.data?[index]
                                                        .date ??
                                                    '') ??
                                                DateTime.now(),
                                          ),
                                          style: TextStyle(
                                              fontSize: 10,
                                              fontWeight: FontWeight.w600,
                                              color: AppColors.black555)),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                );
        },
      ),
    );
  }
}
