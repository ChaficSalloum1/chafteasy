import 'package:flutter/material.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:provider/provider.dart';
import 'package:country_picker/country_picker.dart';
import '../ViewModel/SignupViewModel.dart';

class SignUpScreen extends StatelessWidget {
  const SignUpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final viewModel = Provider.of<SignupViewModel>(context);
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    double commonWidth = screenWidth * 0.9;
    double commonHeight = screenHeight * 0.07;

    return Scaffold(
      body: Stack(
        children: [
          SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(height: screenHeight * 0.1),
                Center(
                  child: Column(
                    children: [
                      Image.asset(
                        viewModel.logoPath,
                        width: screenWidth * 0.4,
                        height: screenWidth * 0.4,
                      ),
                      SizedBox(height: screenHeight * 0.02),
                      Text(
                        viewModel.headText,
                        style: TextStyle(
                          fontSize: screenWidth * 0.08,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: screenHeight * 0.01),
                      Text(
                        viewModel.midText,
                        style: TextStyle(
                          fontSize: screenWidth * 0.04,
                          color: Colors.grey[700],
                        ),
                      ),
                      Text(
                        viewModel.lowText,
                        style: TextStyle(
                          fontSize: screenWidth * 0.04,
                          color: Colors.grey[700],
                        ),
                      ),
                      SizedBox(height: screenHeight * 0.04),
                      Padding(
                        padding: EdgeInsets.symmetric(
                          horizontal: screenWidth * 0.05,
                        ),
                        child: Column(
                          children: [
                            SizedBox(
                              width: commonWidth,
                              height: commonHeight,
                              child: Container(
                                decoration: BoxDecoration(
                                  border: Border.all(color: Colors.grey),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Row(
                                  children: [
                                    GestureDetector(
                                      onTap: () {
                                        showCountryPicker(
                                          context: context,
                                          showPhoneCode: true,
                                          onSelect: (Country country) {
                                            viewModel.setCountryCode(
                                              country.phoneCode,
                                            );
                                            viewModel.setCountryFlag(
                                              country.flagEmoji,
                                            );
                                          },
                                        );
                                      },
                                      child: Padding(
                                        padding: EdgeInsets.symmetric(
                                          horizontal: screenWidth * 0.03,
                                        ),
                                        child: Row(
                                          children: [
                                            Text(
                                              viewModel.selectedCountryFlag,
                                              style: TextStyle(
                                                fontSize: screenWidth * 0.06,
                                              ),
                                            ),
                                            SizedBox(width: screenWidth * 0.02),
                                            Text(
                                              "+${viewModel.selectedCountryCode}",
                                              style: TextStyle(
                                                fontSize: screenWidth * 0.045,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Container(
                                      height: commonHeight * 0.8,
                                      width: 1,
                                      color: Colors.grey,
                                    ),
                                    Expanded(
                                      child: TextField(
                                        controller: viewModel.phoneController,
                                        keyboardType: TextInputType.phone,
                                        decoration: InputDecoration(
                                          contentPadding: EdgeInsets.symmetric(
                                            horizontal: screenWidth * 0.03,
                                          ),
                                          hintText: l10n.of(context).enterMobileNumber,
                                          border: InputBorder.none,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            SizedBox(height: screenHeight * 0.02),
                            SizedBox(
                              width: commonWidth,
                              height: commonHeight,
                              child: ElevatedButton(
                                onPressed: () {
                                  viewModel.onSignUp(context);
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xFF8DC63F),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                                child: Text(
                                  l10n.of(context).signUp,
                                  style: TextStyle(
                                    fontSize: screenWidth * 0.05,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(height: screenHeight * 0.03),
                            Row(
                              children: [
                                Expanded(
                                  child: Divider(
                                    thickness: 1,
                                    color: Colors.grey,
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.symmetric(horizontal: 10),
                                  child: Text(
                                   l10n.of(context).or,
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.grey[700],
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Divider(
                                    thickness: 1,
                                    color: Colors.grey,
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 15),
                            SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  IconButton(
                                    icon: Image.asset(
                                      'assets/icons/facebook.png',
                                      width: 30,
                                      height: 30,
                                    ),
                                    onPressed: () {
                                      viewModel.onFacebookLogin();
                                    },
                                  ),
                                  SizedBox(width: 10),
                                  IconButton(
                                    icon: Image.asset(
                                      'assets/icons/google.png',
                                      width: 30,
                                      height: 30,
                                    ),
                                    onPressed: () {
                                      viewModel.onGoogleLogin();
                                    },
                                  ),
                                  SizedBox(width: 10),
                                  IconButton(
                                    icon: Image.asset(
                                      'assets/icons/apple.png',
                                      width: 30,
                                      height: 30,
                                    ),
                                    onPressed: () {
                                      viewModel.onAppleLogin();
                                    },
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(height: screenHeight * 0.03),
                            GestureDetector(
                              onTap: () {
                                Navigator.pushNamed(context, '/login');
                              },
                              child: RichText(
                                text: TextSpan(
                                  text: l10n.of(context).alreadyHaveAccount ,
                                  style: TextStyle(
                                    fontSize: screenWidth * 0.04,
                                    color: Colors.black,
                                  ),
                                  children: [
                                    TextSpan(
                                      text:l10n.of(context).logIn ,
                                      style: TextStyle(
                                        fontSize: screenWidth * 0.04,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: screenHeight * 0.1),
              ],
            ),
          ),
          Positioned(
            top: 40,
            right: 20,
            child: GestureDetector(
              onTap: () {
                viewModel.onSkip();
              },
              child: Image.asset('assets/skip/skip.png', width: 50, height: 50),
            ),
          ),
        ],
      ),
    );
  }
}
