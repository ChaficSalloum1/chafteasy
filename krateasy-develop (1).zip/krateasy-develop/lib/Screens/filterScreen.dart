// import 'package:flutter/material.dart';

// import 'dart:developer';
// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
// import 'package:kratEasyApp/EntranceScreens/guest_booking.dart';
// import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
// import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
// import 'package:kratEasyApp/GlobalUtils/common.dart';
// import 'package:kratEasyApp/GlobalUtils/network_image_widget.dart';
// import 'package:kratEasyApp/Models/SportList.dart';
// import 'package:kratEasyApp/Models/facilities_model.dart';
// import 'package:kratEasyApp/Models/serach_Court_Payload_Model.dart';
// import 'package:kratEasyApp/ViewModel/BottomNavViewModels/FacilitiesViewModel.dart';
// import 'package:kratEasyApp/ViewModel/EntranceViewModel/SearchCourtViewModel.dart';
// import 'package:kratEasyApp/ViewModel/EntranceViewModel/booking_provider.dart';
// import 'package:kratEasyApp/utils/extension.dart';
// import 'package:kratEasyApp/utils/throttle_debouncy.dart';
// import 'package:provider/provider.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import '../API_CALLS/Helper.dart';
// import '../GlobalUtils/app_colors.dart';
// import '../Models/SearchCourtModel.dart';

// class CourtFilterScreen extends StatefulWidget {
//   final String sportId;
//   String? aminityId;
//   String? selectedTimes;
//   String? selectedDate;
//   CourtFilterScreen({
//     super.key,
//     required this.sportId,
//     this.selectedTimes,
//     this.selectedDate,
//   });

//   @override
//   State<CourtFilterScreen> createState() => _CourtFilterScreenState();
// }

// class _CourtFilterScreenState extends State<CourtFilterScreen> {
//   final TextEditingController _dateController = TextEditingController();
//   final TextEditingController _locationController = TextEditingController();
//   // Set<int> selectedSlots = {};
//   // Map<int, List<int>> selectedSlotsMap = {};

//   @override
//   void initState() {
//     super.initState();
//   }

//   // Future<void> _loadSavedLocation() async {
//   //   SharedPreferences prefs = await SharedPreferences.getInstance();
//   //   String? savedLocation = prefs.getString('saved_location');

//   //   if (savedLocation != null) {
//   //     setState(() {
//   //       _locationController.text = savedLocation;
//   //     });
//   //   } else {
//   //     setState(() {
//   //       _locationController.text = "Location not available";
//   //     });
//   //   }
//   // }

//   String? selectedTime;

//   @override
//   void didChangeDependencies() async {
//     super.didChangeDependencies();

//     selectedSportId = widget.sportId;
//     final viewModel = Provider.of<SearchCourtViewModel>(context, listen: false);

//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     double lat = await prefs.getDouble("current_lat") ?? 0.0;
//     double long = await prefs.getDouble("current_long") ?? 0.0;

//     final searchCourts = BookingRequest(
//         date: widget.selectedDate,
//         time: [widget.selectedTimes ?? ""],
//         sportId: widget.sportId,
//         amenityId: [widget.aminityId ?? ""],
//         lat: lat.toString(),
//         long: long.toString());

//     await viewModel.newSearchCourt(searchCourts, context);
//   }

//   String? selectedSportId;
//   List<String> selectedAmenities = [];
//   bool _isLoading = false;

//   @override
//   Widget build(BuildContext context) {
//     final viewModel = Provider.of<SearchCourtViewModel>(context, listen: false);
//     final homeViewModel = Provider.of<HomeViewModel>(context, listen: false);

//     return Scaffold(
//       backgroundColor: Colors.white,
//       body: Padding(
//         padding: const EdgeInsets.all(8.0),
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             viewModel.searchFilterDataModel.data != null
//                 ? Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                     children: [
//                       Text("Available Nearby Courts",
//                           style: TextStyle(
//                               color: Colors.black,
//                               fontSize: 18,
//                               fontWeight: FontWeight.w600)),
//                       IconButton(
//                         icon: Image.asset('assets/icons/filter.png',
//                             width: 25, height: 25),
//                         onPressed: () async {
//                           final result = await _showFilter(
//                             context: context,
//                             selectedSportId: selectedSportId,
//                             // viewModel: viewModel,
//                           );

//                           if (result == true) {
//                             setState(() {});
//                           }
//                         },
//                       )
//                     ],
//                   )
//                 : SizedBox(),
//             // ...(viewModel.searchFilterDataModel.exactSlotAvailable == false
//             //     ? [
//             //         Text(
//             //           "No courts are available at the selected time. Here are some alternative courts with available time slots you might be interested in.",
//             //           style:
//             //               TextStyle(fontSize: 7, fontWeight: FontWeight.w400),
//             //         ),
//             //         SizedBox(height: 12),
//             //       ]
//             //     : []),
//             viewModel.searchFilterDataModel.data != null
//                 ? Expanded(
//                     child: ListView.builder(
//                       shrinkWrap: true,
//                       itemCount: viewModel.searchFilterDataModel.data!.length,
//                       itemBuilder: (context, index) {
//                         final court =
//                             viewModel.searchFilterDataModel.data![index];
//                         final slots = court.slots ?? [];

//                         // if (selectedSlotsMap[index] == null ||
//                         //     selectedSlotsMap[index]!.isEmpty) {
//                         //   selectedSlotsMap[index] = [0];
//                         // }

//                         return GestureDetector(
//                           onTap: () {
//                             // if (selectedSlotsMap[index] == null ||
//                             //     selectedSlotsMap[index]!.isEmpty) {
//                             //   ScaffoldMessenger.of(context).showSnackBar(SnackBar(
//                             //       content: Text(
//                             //           'Please select at least one slot to continue.')));
//                             //   return;
//                             // }

//                             // final finalCourt = Courts(
//                             //   id: court.id?.toString() ?? 'Unknown',
//                             //   name: viewModel
//                             //           .searchFilterDataModel.data?[index].name
//                             //           ?.capitalizeFirstLetter() ??
//                             //       'Unknown Court',
//                             // );
//                             // context
//                             //     .read<BookingProvider>()
//                             //     .storeCourtId(cortId: finalCourt.id.toString());
//                             // context
//                             //     .read<FacilitiesViewModel>()
//                             //     .updateSelectedCourt(finalCourt);

//                             // List<String> selectedSlotIds =
//                             //     selectedSlotsMap[index]!
//                             //         .map((timeIndex) =>
//                             //             slots[timeIndex].id as String)
//                             //         .toList();

//                             // double totalPrice = selectedSlotsMap[index]!
//                             //     .map((timeIndex) => slots[timeIndex].price ?? 0)
//                             //     .reduce((a, b) => a + b)
//                             //     .toDouble();

//                             // List<String> availableTimes =
//                             //     selectedSlotsMap[index]!.map((timeIndex) {
//                             //   final slot = slots[timeIndex];
//                             //   final startTime = slot.startTime ?? 'N/A';
//                             //   final endTime = slot.endTime ?? 'N/A';
//                             //   return '$startTime, $endTime';
//                             // }).toList();

//                             // String courtName = viewModel.searchFilterDataModel
//                             //         .data?[index].facility?.name
//                             //         ?.capitalizeFirstLetter() ??
//                             //     'Unknown Court';
//                             // String courtId = court.id?.toString() ?? 'Unknown';
//                             // String requestDate =
//                             //     court.date?.toString() ?? 'Unknown';

//                             // Provider.of<BookingProvider>(context, listen: false)
//                             //     .updateBookingDetails(
//                             //   availableTimes,
//                             //   totalPrice,
//                             //   courtName,
//                             //   courtId,
//                             //   requestDate,
//                             //   selectedSlotIds,
//                             // );
//                             // log("slot availableTimes $selectedSlotIds");
//                             // Navigator.push(
//                             //   context,
//                             //   MaterialPageRoute(
//                             //       builder: (context) => GuestBookingScreen(
//                             //             courtId: courtId,
//                             //             date: requestDate,
//                             //             facilityId: viewModel
//                             //                 .searchFilterDataModel
//                             //                 .data![index]
//                             //                 .facilityId,
//                             //             selectedTimeSlots: selectedSlotIds,
//                             //             sportId: selectedSportId,
//                             //           )),
//                             // );

// TapThrottle.run('courtDetailsTap6', () async {
//                                     homeViewModel.setRebookTextUpdate(false);
//                                     final courtDetails =
//                                         await homeViewModel.getCourtDetails(
//                                             courtId: viewModel
//                                                     .searchFilterDataModel
//                                                     ?.data?[index]
//                                                     .id ??
//                                                 "");
//                                     if (courtDetails) {
//                                       Navigator.pushNamed(
//                                           NavigationService.context,
//                                           '/viewCourtDetailsCompleteScreen');
//                                     } else {
//                                       showSnackbar(
//                                           context: context,
//                                           message: "Please try again later!");
//                                     }
//                                   });
//                           },
//                           child: Stack(
//                             children: [
//                               Container(
//                                 padding: EdgeInsets.all(6),
//                                 margin: EdgeInsets.only(bottom: 10),
//                                 decoration: BoxDecoration(
//                                   borderRadius: BorderRadius.circular(5),
//                                   border: Border.all(color: Color(0xffD0D0D0)),
//                                   boxShadow: [
//                                     BoxShadow(
//                                       color: Colors.grey.withOpacity(0.15),
//                                       spreadRadius: 1,
//                                       blurRadius: 6,
//                                       offset: Offset(0, 4),
//                                     ),
//                                   ],
//                                   color: Colors.white,
//                                 ),
//                                 child: Column(
//                                   children: [
//                                     Row(
//                                       crossAxisAlignment:
//                                           CrossAxisAlignment.start,
//                                       children: [
//                                         SizedBox(
//                                           height: 90,
//                                           width: 90,
//                                           child: ClipRRect(
//                                               borderRadius:
//                                                   BorderRadius.circular(5),
//                                               child: NetworkImageWidget(
//                                                   image: court.image ?? "",
//                                                   fit: BoxFit.cover)),
//                                         ),
//                                         SizedBox(width: 10),
//                                         Expanded(
//                                           child: Column(
//                                             crossAxisAlignment:
//                                                 CrossAxisAlignment.start,
//                                             children: [
//                                               Text(
//                                                 court.name
//                                                         ?.capitalizeFirstLetter() ??
//                                                     '',
//                                                 style: TextStyle(
//                                                     fontSize: 16,
//                                                     fontWeight:
//                                                         FontWeight.w600),
//                                               ),
//                                               SizedBox(height: 10),
//                                               Row(
//                                                 children: [
//                                                   Image.asset(
//                                                       'assets/icons/rate.png',
//                                                       height: 16,
//                                                       width: 16),
//                                                   SizedBox(width: 3),
//                                                   Text(
//                                                     court.averageRating
//                                                         .toString(),
//                                                     style: TextStyle(
//                                                         fontSize: 13,
//                                                         color:
//                                                             Color(0XFF555555),
//                                                         fontWeight:
//                                                             FontWeight.w700),
//                                                   ),
//                                                   SizedBox(width: 3),
//                                                   Container(
//                                                       height: 15,
//                                                       width: 1,
//                                                       color:
//                                                           Colors.grey.shade300),
//                                                   SizedBox(width: 3),
//                                                   Expanded(
//                                                     child: Text(
//                                                       court.facility?.name ??
//                                                           '',
//                                                       overflow:
//                                                           TextOverflow.ellipsis,
//                                                       maxLines: 2,
//                                                       style: TextStyle(
//                                                           fontSize: 13,
//                                                           color:
//                                                               Color(0XFF555555),
//                                                           fontWeight:
//                                                               FontWeight.w400),
//                                                     ),
//                                                   ),
//                                                 ],
//                                               ),
//                                               SizedBox(height: 10),
//                                               Row(
//                                                 mainAxisAlignment:
//                                                     MainAxisAlignment
//                                                         .spaceBetween,
//                                                 children: [
//                                                   Row(
//                                                     children: [
//                                                       Image.asset(
//                                                           'assets/icons/location.png',
//                                                           height: 14,
//                                                           width: 14,
//                                                           color:
//                                                               Colors.black54),
//                                                       SizedBox(width: 3),
//                                                       Text(
//                                                         "${(court.facility?.address?.length ?? 0) > 20 ? court.facility!.address!.substring(0, 20) : court.facility?.address ?? ''}...",
//                                                         style: TextStyle(
//                                                             fontSize: 13,
//                                                             color: Color(
//                                                                 0XFF555555),
//                                                             fontWeight:
//                                                                 FontWeight
//                                                                     .w400),
//                                                         overflow: TextOverflow
//                                                             .ellipsis,
//                                                         maxLines: 1,
//                                                       ),
//                                                     ],
//                                                   ),
//                                                   Flexible(
//                                                     child: Text(
//                                                       // selectedSlotsMap[index]
//                                                       //             ?.isNotEmpty ==
//                                                       //         true
//                                                       //     ?
//                                                       //      '£${selectedSlotsMap[index]!.map((timeIndex) => court.slots![timeIndex].price ?? 0).reduce((a, b) => a + b)}${selectedSlotsMap[index]!.length == 1 ? '/hr' : ''}'
//                                                           // :
//                                                            '£0',
//                                                       maxLines: 2,
//                                                       overflow:
//                                                           TextOverflow.clip,
//                                                       style: TextStyle(
//                                                           fontSize: 16,
//                                                           color: Colors.black,
//                                                           fontWeight:
//                                                               FontWeight.w600),
//                                                     ),
//                                                   ),
//                                                 ],
//                                               ),
//                                             ],
//                                           ),
//                                         ),
//                                       ],
//                                     ),
//                                     Divider(color: Color(0xFFE3E3E3)),
//                                     SizedBox(
//                                       height: 40,
//                                       child: ListView.builder(
//                                         scrollDirection: Axis.horizontal,
//                                         itemCount: slots.length,
//                                         itemBuilder: (context, timeIndex) {
//                                           // final isSelected =
//                                           //     selectedSlotsMap[index]
//                                           //             ?.contains(timeIndex) ??
//                                           //         false;
//                                           final currentSlot = slots[timeIndex];

//                                           return GestureDetector(
//                                             onTap: () {
//                                           //     setState(() {
//                                           //       selectedSlotsMap[index] ??= [];

//                                           //       final selected =
//                                           //           selectedSlotsMap[index]!;
//                                           //       final isAlreadySelected =
//                                           //           selected
//                                           //               .contains(timeIndex);

//                                           //       if (isAlreadySelected) {
//                                           //         selected.sort();
//                                           //         if (timeIndex ==
//                                           //                 selected.first ||
//                                           //             timeIndex ==
//                                           //                 selected.last) {
//                                           //           selected.remove(timeIndex);
//                                           //         } else {
//                                           //           ScaffoldMessenger.of(
//                                           //                   context)
//                                           //               .showSnackBar(
//                                           //             SnackBar(
//                                           //                 content: Text(
//                                           //                     "You can only deselect the start or end of the selection.")),
//                                           //           );
//                                           //         }
//                                           //       } else {
//                                           //         if (selected.isEmpty ||
//                                           //             timeIndex ==
//                                           //                 selected.first - 1 ||
//                                           //             timeIndex ==
//                                           //                 selected.last + 1) {
//                                           //           selected.add(timeIndex);
//                                           //         } else {
//                                           //           ScaffoldMessenger.of(
//                                           //                   context)
//                                           //               .showSnackBar(
//                                           //             SnackBar(
//                                           //                 content: Text(
//                                           //                     "Please select slots in sequence.")),
//                                           //           );
//                                           //         }
//                                           //       }
//                                           //     }); // setState(() {
//                                               //   selectedSlotsMap[index] ??=
//                                               //       [];
//                                               //   if (selectedSlotsMap[index]!
//                                               //       .contains(timeIndex)) {
//                                               //     selectedSlotsMap[index]!
//                                               //         .remove(timeIndex);
//                                               //   } else {
//                                               //     selectedSlotsMap[index]!
//                                               //         .add(timeIndex);
//                                               //   }
//                                               // });
//                                             },
//                                             child: Padding(
//                                               padding: const EdgeInsets.only(
//                                                   right: 10),
//                                               child: Row(
//                                                 children: [
//                                                   Container(
//                                                     padding: const EdgeInsets
//                                                         .symmetric(
//                                                         horizontal: 14,
//                                                         vertical: 8),
//                                                     decoration: BoxDecoration(
//                                                       // color: isSelected
//                                                       //     ? AppColors
//                                                       //         .primaryColor
//                                                       //     : Color(0xFFF4F9EC),
//                                                       borderRadius:
//                                                           BorderRadius.circular(
//                                                               5),
//                                                     ),
//                                                     child: Text(
//                                                       '${currentSlot.startTime ?? ''} - ${currentSlot.endTime ?? ''}', // Show time range
//                                                       style: TextStyle(
//                                                         fontSize: 12,
//                                                         fontWeight:
//                                                             FontWeight.w500,
//                                                         // color: isSelected
//                                                         //     ? Colors.white
//                                                         //     : Color(0xFF858585),
//                                                       ),
//                                                     ),
//                                                   ),
//                                                 ],
//                                               ),
//                                             ),
//                                           );
//                                         },
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                               Positioned(
//                                 top: 5,
//                                 right: 5,
//                                 child: Container(
//                                   padding: EdgeInsets.symmetric(
//                                       vertical: 1, horizontal: 5),
//                                   decoration: BoxDecoration(
//                                     color:
//                                         AppColors.greyGreen63F.withOpacity(.1),
//                                     borderRadius: BorderRadius.circular(5),
//                                   ),
//                                   child: Column(
//                                     children: [
//                                       Row(
//                                         children: [
//                                           Image.asset(
//                                               "assets/icons/calender.png",
//                                               height: 15,
//                                               width: 15),
//                                           SizedBox(width: 3),
//                                           Text(
//                                             _dayFromApiString(viewModel
//                                                 .searchFilterDataModel
//                                                 .data?[index]
//                                                 .date),
//                                             style: TextStyle(
//                                                 fontSize: 20,
//                                                 fontWeight: FontWeight.w600,
//                                                 color: AppColors.primaryColor),
//                                           ),
//                                         ],
//                                       ),
//                                       Text(
//                                         _monthYearFromApiString(viewModel
//                                             .searchFilterDataModel
//                                             .data?[index]
//                                             .date),
//                                         style: TextStyle(
//                                             fontSize: 10,
//                                             fontWeight: FontWeight.w400,
//                                             color: AppColors.black555),
//                                       ),
//                                     ],
//                                   ),
//                                 ),
//                               ),
//                             ],
//                           ),
//                         );
//                       },
//                     ),
//                   )
//                 : Column(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     crossAxisAlignment: CrossAxisAlignment.center,
//                     children: [
//                       Image.asset(
//                         "assets/icons/footer.png",
//                         height: 200,
//                         width: 200,
//                       ),
//                       noDataWidget(text: "Courts")
//                     ],
//                   ),
//           ],
//         ),
//       ),
//     );
//   }

//   final _formKey = GlobalKey<FormState>();

//   _showFilter({
//     required BuildContext context,
//     required String? selectedSportId,
//     // required SearchCourtViewModel viewModel,
//   }) {
//     showDialog(
//       context: context,
//       builder: (context) {
//         return Dialog(
//           shape:
//               RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//           insetPadding: EdgeInsets.all(16),
//           child: Builder(builder: (context) {
//             return Consumer<SearchCourtViewModel>(
//                 builder: (context, searchCourtViewModel, child) {
//               return Padding(
//                 padding: EdgeInsets.only(
//                   left: 20,
//                   right: 20,
//                   top: 16,
//                   bottom: MediaQuery.of(context).viewInsets.bottom + 16,
//                 ),
//                 child: Form(
//                   key: _formKey,
//                   child: SingleChildScrollView(
//                     child: Column(
//                       mainAxisSize: MainAxisSize.min,
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         // Title
//                         Row(
//                           children: [
//                             Text("Filter",
//                                 style: TextStyle(
//                                     fontSize: 20, fontWeight: FontWeight.w700)),
//                             Spacer(),
//                             GestureDetector(
//                               onTap: () => Navigator.pop(context),
//                               child: Image.asset('assets/icons/cross.png',
//                                   width: 28, height: 28),
//                             ),
//                           ],
//                         ),
//                         Divider(),
//                         SizedBox(height: 8),

//                         // Sport Dropdown
//                         DropdownButtonFormField<String>(
//                           value: selectedSportId,
//                           decoration: _inputDecoration("Select Sport"),
//                           validator: (value) =>
//                               value == null ? "Please select a sport" : null,
//                           items: Helper.sports.map((sport) {
//                             return DropdownMenuItem<String>(
//                               value: sport.id.toString(),
//                               child: Text(sport.name),
//                             );
//                           }).toList(),
//                           onChanged: (value) => setState(() {
//                             selectedSportId = value;
//                           }),
//                         ),
//                         SizedBox(height: 12),

//                         // Location
//                         TextFormField(
//                           controller: _locationController,
//                           readOnly: true,
//                           decoration: InputDecoration(
//                             filled: true,
//                             fillColor: Color(0xFFF4F9EC),
//                             hintText: "Fetching Current Location...",
//                             suffixIcon: Padding(
//                               padding: const EdgeInsets.all(10.0),
//                               child: Image.asset("assets/icons/location.png",
//                                   height: 20, width: 20),
//                             ),
//                             enabledBorder: OutlineInputBorder(
//                               borderRadius: BorderRadius.circular(10),
//                               borderSide: BorderSide(color: Colors.transparent),
//                             ),
//                             focusedBorder: OutlineInputBorder(
//                               borderRadius: BorderRadius.circular(10),
//                               borderSide: BorderSide(color: Colors.transparent),
//                             ),
//                             contentPadding: EdgeInsets.symmetric(
//                                 horizontal: 12, vertical: 10),
//                           ),
//                           validator: (value) => (value == null || value.isEmpty)
//                               ? "Location not fetched"
//                               : null,
//                         ),

//                         SizedBox(height: 12),

//                         // Date Picker
//                         TextFormField(
//                           controller: _dateController,
//                           readOnly: true,
//                           decoration: InputDecoration(
//                             filled: true,
//                             fillColor: Color(0xFFF4F9EC),
//                             hintText: "Date",
//                             suffixIcon: Padding(
//                               padding: const EdgeInsets.all(12.0),
//                               child: Image.asset('assets/icons/calender.png',
//                                   height: 24, width: 24),
//                             ),
//                             enabledBorder: OutlineInputBorder(
//                               borderRadius: BorderRadius.circular(8),
//                               borderSide: BorderSide(color: Colors.transparent),
//                             ),
//                             focusedBorder: OutlineInputBorder(
//                               borderRadius: BorderRadius.circular(8),
//                               borderSide: BorderSide(color: Colors.transparent),
//                             ),
//                           ),
//                           validator: (value) => value == null || value.isEmpty
//                               ? "Please select a date"
//                               : null,
//                           onTap: () async {
//                             DateTime? pickedDate = await showDatePicker(
//                               context: context,
//                               initialDate: DateTime.now(),
//                               firstDate: DateTime(2000),
//                               lastDate: DateTime(2100),
//                             );

//                             if (pickedDate != null) {
//                               _dateController.text =
//                                   "${pickedDate.day.toString().padLeft(2, '0')}-${pickedDate.month.toString().padLeft(2, '0')}-${pickedDate.year}";
//                             }
//                           },
//                         ),

//                         SizedBox(height: 12),

//                         // Time Dropdown
//                         // DropdownButtonFormField<String>(
//                         //   decoration: _inputDecoration("Time"),
//                         //   items: viewModel.availableTimes
//                         //       .map((time) => DropdownMenuItem<String>(
//                         //           value: time, child: Text(time)))
//                         //       .toList(),
//                         //   onChanged: (value) => selectedTime = value,
//                         // ),
//                         DropdownButtonFormField<String>(
//                           decoration: _inputDecoration("Time"),
//                           validator: (value) => value == null || value.isEmpty
//                               ? "Please select a time"
//                               : null,
//                           items: searchCourtViewModel.availableTimes
//                               .map((time) => DropdownMenuItem<String>(
//                                   value: time, child: Text(time)))
//                               .toList(),
//                           onChanged: (value) => selectedTime = value,
//                         ),

//                         SizedBox(height: 12),

//                         // Amenities Dropdown
//                         DropdownButtonFormField<String>(
//                           decoration: _inputDecoration("Amenities"),
//                           items: Helper.amenities
//                               .map((amenity) => DropdownMenuItem<String>(
//                                     value: amenity.id.toString(),
//                                     child: Text(amenity.name),
//                                   ))
//                               .toList(),
//                           onChanged: (value) {
//                             if (value != null &&
//                                 !selectedAmenities.contains(value)) {
//                               selectedAmenities.add(value);
//                             }
//                           },
//                         ),

//                         SizedBox(height: 16),

//                         // Apply Button
//                         GestureDetector(
//                           onTap: searchCourtViewModel.isLoading
//                               ? () {}
//                               : () async {
//                                   if (_formKey.currentState?.validate() != true)
//                                     return;

//                                   if (searchCourtViewModel
//                                       .selectedTimeGrids.isEmpty) {
//                                     ScaffoldMessenger.of(context).showSnackBar(
//                                         SnackBar(
//                                             content: Text(
//                                                 "Please select at least one time slot")));
//                                     return;
//                                   }

//                                   try {
//                                     final selectedSportName =
//                                         searchCourtViewModel.selectedSport;
//                                     final selectedAmenityNames =
//                                         searchCourtViewModel.selectedAmenitie;
//                                     // final selectedLocation = _locationController.text;
//                                     final selectedDate = _dateController.text;
//                                     final selectedTimeSlots =
//                                         searchCourtViewModel.selectedTimeGrids
//                                             .map((index) => searchCourtViewModel
//                                                 .availableTimes[index])
//                                             .toList();

//                                     final sportId = Helper.sports
//                                         .firstWhere(
//                                           (sport) =>
//                                               sport.name == selectedSportName,
//                                           orElse: () => SportList(
//                                               id: '', name: '', image: ''),
//                                         )
//                                         .id;

//                                     final amenitiesIds = Helper.amenities
//                                         .where((amenity) => selectedAmenityNames
//                                             .contains(amenity.name))
//                                         .map((amenity) => amenity.id)
//                                         .toList();
//                                     SharedPreferences prefs =
//                                         await SharedPreferences.getInstance();
//                                     var lat = await prefs
//                                         .getDouble("current_lat")
//                                         .toString();
//                                     var long = await prefs
//                                         .getDouble("current_long")
//                                         .toString();
//                                     final searchCourts = BookingRequest(
//                                         date: selectedDate,
//                                         time: selectedTimeSlots,
//                                         sportId: sportId,
//                                         amenityId: amenitiesIds,
//                                         lat: lat,
//                                         long: long);

//                                     await searchCourtViewModel.newSearchCourt(
//                                         searchCourts, context);

//                                     Navigator.pop(context, true);
//                                   } catch (e) {
//                                     ScaffoldMessenger.of(context).showSnackBar(
//                                         SnackBar(
//                                             content: Text(
//                                                 "Error: ${e.toString()}")));
//                                   } finally {}
//                                 },
//                           child: Container(
//                             height: 47,
//                             width: double.infinity,
//                             decoration: BoxDecoration(
//                                 color: Color(0xFF8DC63F),
//                                 borderRadius: BorderRadius.circular(10)),
//                             child: Center(
//                               child: searchCourtViewModel.isLoading
//                                   ? CircularProgressIndicator(
//                                       color: AppColors.white,
//                                     )
//                                   : Text("Filter Apply",
//                                       style: TextStyle(
//                                           color: Colors.black,
//                                           fontSize: 16,
//                                           fontWeight: FontWeight.w600)),
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               );
//             });
//           }),
//         );
//       },
//     );
//   }

//   String _dayFromApiString(String? apiDate) {
//     if (apiDate == null) return "";
//     try {
//       final dt = DateFormat("dd-MM-yyyy").parseStrict(apiDate);
//       return DateFormat("d").format(dt);
//     } catch (_) {
//       return "";
//     }
//   }

//   String _monthYearFromApiString(String? apiDate) {
//     if (apiDate == null) return "";
//     try {
//       final dt = DateFormat("dd-MM-yyyy").parseStrict(apiDate);
//       return DateFormat("MMM, yyyy").format(dt);
//     } catch (_) {
//       return "";
//     }
//   }

//   // Common Input Decoration for Fields
//   InputDecoration _inputDecoration(String hintText) {
//     return InputDecoration(
//       hintText: hintText,
//       border: OutlineInputBorder(
//         borderRadius: BorderRadius.circular(10),
//         borderSide: BorderSide(color: Colors.transparent), // Transparent border
//       ),
//       enabledBorder: OutlineInputBorder(
//           borderRadius: BorderRadius.circular(10),
//           borderSide: BorderSide(color: Colors.transparent)),
//       focusedBorder: OutlineInputBorder(
//           borderRadius: BorderRadius.circular(10),
//           borderSide: BorderSide(color: Colors.transparent)),
//       filled: true,
//       fillColor: Color(0xFFF4F9EC),
//       // Background color
//       contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 14),
//     );
//   }
// }

import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/Models/AmenitiesList.dart';
import 'package:kratEasyApp/Models/sports_list_model.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/utils/extension.dart';
import 'package:kratEasyApp/utils/widgets/common_widgets.dart';

class CourtFilterscreen extends StatefulWidget {
  final SportsListModel sport;
  final AmenitiesList? amenity;
  final String? date;
  final String? time;

  const CourtFilterscreen({
    Key? key,
    required this.sport,
    this.amenity,
    this.date,
    this.time,
  }) : super(key: key);

  @override
  State<CourtFilterscreen> createState() => _CourtFilterscreenState();
}

class _CourtFilterscreenState extends State<CourtFilterscreen> {
  late NearbyCourtsViewModel viewModel1;

  @override
  void initState() {
    super.initState();
    viewModel1 = context.read<NearbyCourtsViewModel>();

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      context.read<HomeViewModel>().setIsHomeFilter(false);

      // Use default date if null
      final dateToUse =
          widget.date ?? DateFormat("dd-MM-yyyy").format(DateTime.now());

      print("date $dateToUse");
      print("sport ${widget.sport}");
      print("amene ${widget.amenity}");
      print("time ${widget.time}");

      final data = await viewModel1.newSearchCourtApiForHome2(
        date: dateToUse,
        sportId: widget.sport.id,
        amenityId: widget.amenity?.id ?? "",
        time: widget.time ?? "",
        context: context,
      );

      if (mounted && data != null) {
        setState(() {
          viewModel1.searchFilterDataModel = data;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    // double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;

    // print("${}");
    return Scaffold(
      appBar: CommonAppBar(
        onTap: () async {
          print("home filter sccreen ontap");
          context.read<HomeViewModel>().setIsHomeFilter(false);
          Navigator.of(context).pop();
          final data = await viewModel1.newSearchCourtApiForHome(context);
          if (mounted && data != null) {
            setState(() {
              viewModel1.searchFilterDataModel = data;
            });
          }
        },
        title: l10n.of(context).filterResult,
        backIconColor: Colors.white,
        backgroundColor: Colors.white,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Consumer<NearbyCourtsViewModel>(
            builder: (BuildContext context, viewModel, Widget? child) {
              return viewModel.isLoading
                  ? SizedBox(
                      height: MediaQuery.of(context).size.height,
                      child: const LoadListShimmer(),
                    )
                  : (viewModel.searchFilterDataModel?.data?.isNotEmpty ?? false)
                      ? ListView(
                          children: [
                            SizedBox(height: 10),
                            // Row(
                            //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            //   children: [
                            //     Text("Available Nearby Courts",
                            //         style: TextStyle(
                            //             color: Colors.black,
                            //             fontSize: 18,
                            //             fontWeight: FontWeight.w600)),
                            //     ElevatedButton(
                            //       onPressed: () {
                            //         Navigator.push(
                            //             context,
                            //             MaterialPageRoute(
                            //                 builder: (context) =>
                            //                     AllNearByCourts()));
                            //       },
                            //       style: ElevatedButton.styleFrom(
                            //         backgroundColor: Color(0xFF3B747D),
                            //         foregroundColor: Colors.white,
                            //         minimumSize: Size(56, 26),
                            //         shape: RoundedRectangleBorder(
                            //             borderRadius: BorderRadius.circular(6)),
                            //         padding: EdgeInsets.zero,
                            //       ),
                            //       child: Text("View All",
                            //           style: TextStyle(
                            //               fontSize: 12,
                            //               fontWeight: FontWeight.w500)),
                            //     ),
                            //   ],
                            // ),
                            // SizedBox(height: 8),
                            Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ListView.builder(
                                itemCount: viewModel
                                        .searchFilterDataModel?.data?.length ??
                                    0,
                                shrinkWrap: true,
                                physics: NeverScrollableScrollPhysics(),
                                itemBuilder: (context, index) {
                                  // final isLoading =
                                  //     homeViewModel.loadingIndex == index;

                                  return
                                      //  isLoading
                                      //     ? Shimmer.fromColors(
                                      //         baseColor: Colors.grey,
                                      //         highlightColor: Colors.white,
                                      //         child: Container(
                                      //           padding: EdgeInsets.all(6),
                                      //           margin: EdgeInsets.only(
                                      //               bottom: screenHeight * 0.01),
                                      //           decoration: BoxDecoration(
                                      //             color: Colors.grey
                                      //                 .withValues(alpha: 0.2),
                                      //             borderRadius:
                                      //                 BorderRadius.circular(5),
                                      //             // border: Border.all(
                                      //             //     color: AppColors.greyD0D0)
                                      //           ),
                                      //           height: 120,
                                      //           width:
                                      //               MediaQuery.of(context).size.width,
                                      //         ))
                                      //     :
                                      InkWell(
                                    onTap: () async {
                                      // if (homeViewModel.loadingIndex != null)
                                      //   return; // Prevent multiple taps

                                      // TapThrottle.run('courtDetailsTap1',
                                      //     () async {
                                      final courtId = viewModel
                                              .searchFilterDataModel
                                              ?.data?[index]
                                              .id ??
                                          "";

                                      // homeViewModel.setLoadingIndex(index);

                                      // homeViewModel.setLoadingIndex(
                                      //     null); // ⬅️ Hide shimmer again

                                      // if (courtDetails) {

                                      if (courtId == "") {
                                        showSnackbar(
                                          context: context,
                                          message: l10n
                                              .of(context)
                                              .somethingsWentWrongPleaseTryAgainLater,
                                        );
                                        return;
                                      }

                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (_) =>
                                                  ViewCourtDetailsCompleteScreen(
                                                    ID: courtId,isRebook: false,
                                                  )));

                                      // Navigator.pushNamed(NavigationService.context,
                                      //     '/viewCourtDetailsCompleteScreen',
                                      //     arguments: {"id": courtId});
                                      // } else {
                                      //   showSnackbar(
                                      //     context: context,
                                      //     message: "Please try again later!",
                                      //   );
                                      // }
                                      // });
                                    },
                                    // onTap: homeViewModel.isCourtDetail
                                    //     ? () {}
                                    //     : () {
                                    //         TapThrottle.run(
                                    //             'courtDetailsTap1', () async {
                                    //           homeViewModel
                                    //               .setRebookTextUpdate(false);
                                    //           final courtDetails =
                                    //               await homeViewModel
                                    //                   .getCourtDetails(
                                    //             courtId: viewModel
                                    //                     .searchFilterDataModel
                                    //                     ?.data?[index]
                                    //                     .id ??
                                    //                 "",
                                    //           );

                                    //           if (courtDetails) {
                                    //             Navigator.pushNamed(
                                    //               NavigationService.context,
                                    //               '/viewCourtDetailsCompleteScreen',
                                    //             );
                                    //           } else {
                                    //             showSnackbar(
                                    //               context: context,
                                    //               message:
                                    //                   "Please try again later!",
                                    //             );
                                    //           }
                                    //         });
                                    //       },
                                    child: Stack(
                                      children: [
                                        Container(
                                          padding: EdgeInsets.all(6),
                                          margin: EdgeInsets.only(
                                              bottom: screenHeight * 0.01),
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(5),
                                              border: Border.all(
                                                  color: AppColors.greyD0D0)),
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Row(
                                                children: [
                                                  SizedBox(
                                                      height: 75,
                                                      width: 90,
                                                      child: ClipRRect(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      2.5),
                                                          child: NetworkImageWidget(
                                                              image: (viewModel
                                                                          .searchFilterDataModel
                                                                          ?.data?[
                                                                              index]
                                                                          .image ??
                                                                      "")
                                                                  .toString()))),
                                                  SizedBox(width: 10),
                                                  Expanded(
                                                    child: Column(
                                                      children: [
                                                        Row(
                                                          children: [
                                                            Expanded(
                                                                child:
                                                                    Container(
                                                              margin: EdgeInsets
                                                                  .only(
                                                                      right:
                                                                          60),
                                                              child: Text(
                                                                  (viewModel.searchFilterDataModel?.data?[index].name ??
                                                                          l10n
                                                                              .of(
                                                                                  context)
                                                                              .na)
                                                                      .toString()
                                                                      .capitalizeFirstLetter(),
                                                                  maxLines: 1,
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          16,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w600,
                                                                      color: AppColors
                                                                          .black)),
                                                            )),
                                                          ],
                                                        ),
                                                        SizedBox(height: 10),
                                                        Row(
                                                          children: [
                                                            SizedBox(
                                                                width: 16,
                                                                height: 16,
                                                                child: Image.asset(
                                                                    'assets/icons/rate.png',
                                                                    fit: BoxFit
                                                                        .fill)),
                                                            SizedBox(width: 4),
                                                            Text(
                                                                (viewModel
                                                                            .searchFilterDataModel
                                                                            ?.data?[
                                                                                index]
                                                                            .averageRating ??
                                                                        0)
                                                                    .toString(),
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        13,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w700,
                                                                    color: AppColors
                                                                        .black555)),
                                                            Container(
                                                                margin: EdgeInsets
                                                                    .symmetric(
                                                                        horizontal:
                                                                            3),
                                                                width: 1,
                                                                height: 15,
                                                                color: AppColors
                                                                    .greyD9D9),
                                                            Text(
                                                                (viewModel
                                                                            .searchFilterDataModel
                                                                            ?.data?[
                                                                                index]
                                                                            .facility
                                                                            ?.name ??
                                                                        l10n
                                                                            .of(
                                                                                context)
                                                                            .na)
                                                                    .toString(),
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        11,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .normal,
                                                                    color: AppColors
                                                                        .black555)),
                                                          ],
                                                        ),
                                                        SizedBox(height: 5),
                                                        Row(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            SizedBox(
                                                                width: 16,
                                                                height: 16,
                                                                child: Image.asset(
                                                                    AppImages
                                                                        .pngLocationGrey,
                                                                    fit: BoxFit
                                                                        .fill)),
                                                            SizedBox(width: 4),
                                                            Expanded(
                                                              child: Row(
                                                                children: [
                                                                  Expanded(
                                                                    child: Text(
                                                                      (viewModel.searchFilterDataModel?.data?[index].facility?.address ??
                                                                              l10n.of(context).na)
                                                                          .toString(),
                                                                      maxLines:
                                                                          1,
                                                                      overflow:
                                                                          TextOverflow
                                                                              .ellipsis,
                                                                      style: TextStyle(
                                                                          fontSize:
                                                                              11,
                                                                          fontWeight: FontWeight
                                                                              .w400,
                                                                          color:
                                                                              AppColors.black555),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    " (~${((viewModel.searchFilterDataModel?.data?[index].facility?.distance ?? 0) / 1000).toStringAsFixed(1)} kms)",
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            11,
                                                                        fontWeight:
                                                                            FontWeight
                                                                                .w400,
                                                                        color: AppColors
                                                                            .black555),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            SizedBox(width: 4),
                                                            Text(
                                                              "${AppConstants.appCurrency} ${viewModel.searchFilterDataModel?.data?[index].slots?.firstOrNull?.price ?? 0}",
                                                              style: TextStyle(
                                                                  fontSize: 13,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w600,
                                                                  color: AppColors
                                                                      .black),
                                                            ),
                                                          ],
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              SizedBox(height: 10),
                                              Container(
                                                  width: double.infinity,
                                                  height: 1,
                                                  color: AppColors.grey3E3),
                                              SizedBox(height: 10),
                                              Consumer<NearbyCourtsViewModel>(
                                                builder:
                                                    (context, viewModel, _) {
                                                  return SingleChildScrollView(
                                                    scrollDirection:
                                                        Axis.horizontal,
                                                    child: Row(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      children: List.generate(
                                                          viewModel
                                                                  .searchFilterDataModel
                                                                  ?.data?[index]
                                                                  .slots
                                                                  ?.length ??
                                                              0, (timeIndex) {
                                                        bool isSelected = viewModel
                                                                .getSelectedIndex(
                                                                    index) ==
                                                            timeIndex;
                                                        var slotData = viewModel
                                                            .searchFilterDataModel
                                                            ?.data?[index]
                                                            .slots?[timeIndex];

                                                        return Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .only(
                                                                  right: 10),
                                                          child: InkWell(
                                                            onTap: () {
                                                              // viewModel
                                                              //     .updateSelectedIndex(
                                                              //         index,
                                                              //         timeIndex);
                                                            },
                                                            child: Container(
                                                              padding:
                                                                  const EdgeInsets
                                                                      .symmetric(
                                                                      horizontal:
                                                                          14,
                                                                      vertical:
                                                                          10),
                                                              decoration: BoxDecoration(
                                                                  color: isSelected
                                                                      ? Color(
                                                                          0xFF8DC63F)
                                                                      : Color(
                                                                          0xFFF4F9EC),
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              9)),
                                                              child: Center(
                                                                child: Text(
                                                                  (slotData
                                                                          ?.startTime)
                                                                      .toString(),
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          13,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w700,
                                                                      color: isSelected
                                                                          ? Colors
                                                                              .white
                                                                          : Color(
                                                                              0xFF858585)),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        );
                                                      }),
                                                    ),
                                                  );
                                                },
                                              ),
                                            ],
                                          ),
                                        ),
                                        // Positioned Circular Icon
                                        Positioned(
                                          top: 5,
                                          right: 5,
                                          child: Column(
                                            children: [
                                              SizedBox(height: 2),
                                              Container(
                                                padding: EdgeInsets.symmetric(
                                                    vertical: 2, horizontal: 3),
                                                decoration: BoxDecoration(
                                                    color: AppColors
                                                        .greyGreen63F
                                                        .withOpacity(.1),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5)),
                                                child: Column(
                                                  children: [
                                                    Row(
                                                      children: [
                                                        SizedBox(
                                                            height: 13,
                                                            width: 14,
                                                            child: Image.asset(
                                                                "assets/icons/calender.png")),
                                                        SizedBox(width: 3),
                                                        Text(
                                                            DateFormat("d")
                                                                .format(
                                                              DateTime.tryParse(viewModel
                                                                          .searchFilterDataModel
                                                                          ?.data?[
                                                                              index]
                                                                          .date ??
                                                                      '') ??
                                                                  DateTime
                                                                      .now(),
                                                            ),
                                                            style: TextStyle(
                                                                fontSize: 20,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w600,
                                                                color: AppColors
                                                                    .primaryColor)),
                                                      ],
                                                    ),
                                                    Text(
                                                        DateFormat("MMM yyyy")
                                                            .format(
                                                          DateTime.tryParse(viewModel
                                                                      .searchFilterDataModel
                                                                      ?.data?[
                                                                          index]
                                                                      .date ??
                                                                  '') ??
                                                              DateTime.now(),
                                                        ),
                                                        style: TextStyle(
                                                            fontSize: 10,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                            color: AppColors
                                                                .black555)),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        )
                      : Center(
                          child: Padding(
                          padding: EdgeInsets.only(top: 15.0),
                          child: Text(l10n.of(context).noCourtsAvailable),
                        ));
            },
          ),
        ),
      ),
    );
  }
}

// class Availablenearbycourtstab extends StatefulWidget {
//   const Availablenearbycourtstab({super.key});

//   @override
//   State<Availablenearbycourtstab> createState() =>
//       _AvailablenearbycourtstabState();
// }

// class _AvailablenearbycourtstabState extends State<Availablenearbycourtstab> {
//   // final NearbyCourtsViewModel viewModel = NearbyCourtsViewModel();
//   late NearbyCourtsViewModel viewModel1;
//   // @override
//   // void initState() {
//   //   viewModel1 = context.read<NearbyCourtsViewModel>();
//   //   WidgetsBinding.instance.addPostFrameCallback((_) {
//   //     viewModel1.newSearchCourtApiForHome(context);
//   //   });
//   //   super.initState();
//   // }

//   // @override
//   // void initState() {
//   //   viewModel1 = context.read<NearbyCourtsViewModel>();
//   //   WidgetsBinding.instance.addPostFrameCallback((_) async {
//   //     viewModel1.searchFilterDataModel =
//   //         await viewModel1.newSearchCourtApiForHome(context);
//   //     // if (result != null) {
//   //     //   viewModel1.setSearchFilterDataModel(result);
//   //     // }
//   //   });
//   //   super.initState();
//   // }
