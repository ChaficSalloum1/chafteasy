import 'package:flutter/material.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:provider/provider.dart';

import '../ViewModel/ResetPasswordSuccessViewModel.dart';

class PasswordResetSuccessScreen extends StatelessWidget {
  const PasswordResetSuccessScreen({super.key});

  @override
  Widget build(BuildContext context) {
    double commonWidth =
        MediaQuery.of(context).size.width * 0.9; // Increased width
    double commonHeight = 55; // Standardized height
    return ChangeNotifierProvider(
      create: (context) => ResetPasswordSuccessViewModel(),
      child: Consumer<ResetPasswordSuccessViewModel>(
        builder: (context, viewModel, child) {
          return Scaffold(
            body: Stack(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Spacer(flex: 5),
                    Center(
                      child: Column(
                        children: [
                          Image.asset(
                            viewModel.logoPath,
                            width: 150,
                            height: 150,
                          ),
                          SizedBox(height: 10),
                          Text(
                            l10n.of(context).password,
                            style: TextStyle(
                              fontSize: 34,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 5),
                          Text(
                            l10n.of(context).successfullyChange,
                            style: TextStyle(
                              fontSize: 32,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            l10n.of(context).yourNewPasswordIsNowActive,
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey[700],
                            ),
                          ),
                          Text(
                            l10n.of(context).staySecure,
                            style: TextStyle(
                              fontSize: 15,
                              color: Colors.grey[700],
                            ),
                          ),
                          SizedBox(height: 30),
                          SizedBox(
                            width: commonWidth,
                            height: commonHeight,
                            child: ElevatedButton(
                              onPressed: () {
                                viewModel.backtoLogin(context);
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF8DC63F),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                              ),
                              child: Text(
                                l10n.of(context).backToLogin,
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Spacer(flex: 5),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
