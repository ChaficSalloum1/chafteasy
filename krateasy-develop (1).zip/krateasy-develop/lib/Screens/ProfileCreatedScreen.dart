import 'package:flutter/material.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:provider/provider.dart';
import '../ViewModel/ProfileCreatedViewModel.dart';

class ProfileCreatedScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => ProfileCompletedViewModel(),
      child: Consumer<ProfileCompletedViewModel>(
        builder: (context, viewModel, child) {
          return Scaffold(
            body: LayoutBuilder(
              builder: (context, constraints) {
                double screenWidth = constraints.maxWidth;
                double screenHeight = constraints.maxHeight;
                double commonWidth = screenWidth * 0.9; // 90% of screen width
                double commonHeight =
                    screenHeight * 0.07; // 7% of screen height

                return Center(
                  child: Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: screenWidth * 0.05,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image.asset(
                          viewModel.logoPath,
                          width: screenWidth * 0.4, // 40% of screen width
                          height: screenHeight * 0.2, // 20% of screen height
                        ),
                        SizedBox(height: screenHeight * 0.02),
                        Text(
                          l10n.of(context).yourAccount,
                          style: TextStyle(
                            fontSize:
                                screenWidth *
                                0.08, // Adjust based on screen width
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(height: screenHeight * 0.01),
                        Text(
                          l10n.of(context).successfullyCreated,
                          style: TextStyle(
                            fontSize: screenWidth * 0.07,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(height: screenHeight * 0.01),
                        Text(
                          l10n.of(context).yourAccountSuccessfullyCreatedClick,
                          style: TextStyle(
                            fontSize: screenWidth * 0.04,
                            color: Colors.grey[700],
                          ),
                          textAlign: TextAlign.center,
                        ),
                        Text(
                          l10n.of(context).continueToGoToTheHomeScreen,
                          style: TextStyle(
                            fontSize: screenWidth * 0.04,
                            color: Colors.grey[700],
                          ),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(height: screenHeight * 0.04),
                        SizedBox(
                          width: commonWidth,
                          height: commonHeight,
                          child: ElevatedButton(
                            onPressed: () {
                              viewModel.profileCreated(context);
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF8DC63F),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                            child: Text(
                              l10n.of(context).continues,
                              style: TextStyle(
                                fontSize: screenWidth * 0.05,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
