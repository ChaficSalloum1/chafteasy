
import 'package:flutter/material.dart';
import 'package:kratEasyApp/ViewModel/ResetPasswordViewModel.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:provider/provider.dart';

class ResetPasswordScreen extends StatelessWidget {
  const ResetPasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    double commonWidth = MediaQuery.of(context).size.width * 0.9;
    double commonHeight = 55; // Adjust as needed
    return ChangeNotifierProvider(
      create: (context) => ResetPasswordViewModel(),
      child: Consumer<ResetPasswordViewModel>(
        builder: (context, viewModel, child) {
          return Scaffold(
            body: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Spacer(flex: 4),
                Center(
                  child: Column(
                    children: [
                      Text(
                        l10n.of(context).resetPassword,
                        style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 5),
                      Text(
                        l10n.of(context).atLeast9CharactersWithUppercase,
                        style: TextStyle(fontSize: 15, color: Colors.grey[700]),
                      ),
                      // Didn't receive OTP? & Resend OTP
                      Text(
                        l10n.of(context).andLowercaseLetters,
                        style: TextStyle(fontSize: 14, color: Colors.black54),
                      ),
                      SizedBox(height: 30),
                      SizedBox(
                        width: commonWidth,
                        height: commonHeight,
                        child: Consumer<ResetPasswordViewModel>(
                          builder: (context, viewModel, child) {
                            return TextField(
                              obscureText: viewModel.isPasswordHidden,
                              decoration: InputDecoration(
                                labelText:l10n.of(context).enterMobileNumber,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                suffixIcon: IconButton(
                                  icon: Icon(
                                    viewModel.isPasswordHidden ? Icons.visibility_off : Icons.visibility,
                                  ),
                                  onPressed: () {
                                    viewModel.togglePasswordVisibility();
                                  },
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      SizedBox(height: 10),
                      SizedBox(
                        width: commonWidth,
                        height: commonHeight,
                        child: Consumer<ResetPasswordViewModel>(
                          builder: (context, viewModel, child) {
                            return TextField(
                              obscureText: viewModel.isPasswordHidden,
                              decoration: InputDecoration(
                                labelText: l10n.of(context).reenterPassword,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                suffixIcon: IconButton(
                                  icon: Icon(
                                    viewModel.isPasswordHidden ? Icons.visibility_off : Icons.visibility,
                                  ),
                                  onPressed: () {
                                    viewModel.togglePasswordVisibility();
                                  },
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      SizedBox(height: 30),
                      SizedBox(
                        width: commonWidth,
                        height: commonHeight,
                        child: ElevatedButton(
                          onPressed: () {
                            viewModel.onSubmit(context); // Pass context to navigate
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF8DC63F),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          child: Text(
                            l10n.of(context).continues,
                            style: TextStyle(fontSize: 18, color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Spacer(flex: 5),
              ],
            ),
          );
        },
      ),
    );
  }
}
//on tap on submit navigate to Complete Profile and use mvvm arch
