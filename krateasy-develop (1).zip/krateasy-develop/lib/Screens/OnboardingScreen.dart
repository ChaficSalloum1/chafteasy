import 'dart:io';
import 'package:country_picker/country_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:kratEasyApp/GlobalUtils/app_button.dart';
import 'package:kratEasyApp/GlobalUtils/app_colors.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/GlobalUtils/app_text_field.dart';
import 'package:kratEasyApp/Localization/locale_provider.dart';
import 'package:kratEasyApp/ViewModel/EntranceViewModel/booking_provider.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/repository/social_login_repository.dart';
import 'package:provider/provider.dart';
import '../GlobalUtils/app_navigation.dart';
import '../ViewModel/OnboardingViewModel.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  String? selectedLang;

  void _onLangChange(String langCode) {
    final provider = context.read<LocaleProvider>();
    provider.setLocale(Locale(langCode));
    setState(() {
      selectedLang = langCode;
    });
  }

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final GlobalKey<FormState> _formKeyForGoogleLogin = GlobalKey<FormState>();

  late BookingProvider bookingViewModel;

  @override
  void initState() {
    bookingViewModel = context.read<BookingProvider>();
    selectedLang = context.read<LocaleProvider>().locale.languageCode;

    bookingViewModel.phoneController.clear();
    bookingViewModel.otpController.clear();
    bookingViewModel.isChecked = false;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;

    final viewModel = Provider.of<OnboardingViewModel>(context);
    return Scaffold(
      body: SafeArea(
        bottom: true,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            // SizedBox(height: 20,),
            // Image Section (Top)
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.47,
              child: Stack(
                children: [
                  PageView.builder(
                    controller: viewModel.pageController,
                    onPageChanged: viewModel.setCurrentPage,
                    itemCount: viewModel.images.length,
                    itemBuilder: (context, index) {
                      return Stack(
                        alignment: Alignment.bottomCenter,
                        children: [
                          // Background Image
                          Positioned.fill(
                            child: Image.asset(
                              height: h,
                              viewModel.backgroundImages[index],
                              fit: BoxFit.cover,
                            ),
                          ),
                          Image.asset(
                            viewModel.images[index], // Foreground image
                            fit: BoxFit.contain,
                            width: MediaQuery.of(context).size.width *
                                0.8, // Adjust size if needed
                          ),
                        ],
                      );
                    },
                  ),
                  Positioned(
                    right: 10,
                    top: 28,
                    child: Container(
                      width: 185,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: const Color.fromARGB(137, 240, 238, 238),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Flexible(
                            child: Text(
                              "${l10n.of(context).greek}/${l10n.of(context).english}",
                            ),
                          ),
                          SizedBox(
                            width: 6,
                          ),
                          Consumer<LocaleProvider>(
                            builder: (context, localeProvider, child) {
                              bool isEnglish =
                                  localeProvider.locale.languageCode == 'en';
                              return Transform.scale(
                                scale: 0.75,
                                child: Switch(
                                  padding: EdgeInsets.zero,
                                  value: isEnglish,
                                  activeColor: Colors.white,
                                  activeTrackColor: AppColors.primaryColor,
                                  inactiveThumbColor: AppColors.white,
                                  inactiveTrackColor: AppColors.greyD0D0,
                                  trackOutlineColor: WidgetStateProperty.all(
                                      Colors.transparent),
                                  materialTapTargetSize:
                                      MaterialTapTargetSize.shrinkWrap,
                                  onChanged: (value) {
                                    final newLangCode = value ? 'en' : 'el';
                                    _onLangChange(newLangCode);
                                  },
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: h * .01),
            // indicator image
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                viewModel.images.length,
                (index) => Container(
                  margin: EdgeInsets.all(5),
                  width: 21,
                  height: h * .02,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    image: DecorationImage(
                      image: AssetImage(
                        viewModel.currentPage == index
                            ? 'assets/onboardingImg/ball.png'
                            : 'assets/onboardingImg/ball2.png',
                      ),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: h * .01),
            // Text Content
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.0),
              child: Column(
                children: [
                  Text(
                    viewModel.currentPage == 0
                        ? l10n.of(context).welcomeEasybooking
                        : l10n.of(context).takeOnTheChallenge,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w600,
                      color: Colors.black,
                    ),
                    textAlign: TextAlign.center,
                  ),

                  // Text(
                  //   viewModel.headTexts[viewModel.currentPage],
                  //   style: TextStyle(
                  //     fontSize: 20,
                  //     fontWeight: FontWeight.w600,
                  //     color: Colors.black,
                  //   ),
                  //   textAlign: TextAlign.center,
                  // ),
                  if (viewModel.currentPage == 0) SizedBox(height: 10),
                  Text(
                    viewModel.currentPage == 0
                        ? l10n.of(context).findBookYourGameInSeconds
                        : '',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: Colors.black,
                    ),
                    textAlign: TextAlign.center,
                  ),

                  // Text(
                  //   viewModel.subTexts[viewModel.currentPage],
                  //   style: TextStyle(
                  //     fontSize: 18,
                  //     fontWeight: FontWeight.w600,
                  //     color: Colors.black,
                  //   ),
                  //   textAlign: TextAlign.center,
                  // ),
                  if (viewModel.currentPage == 0) SizedBox(height: 0),
                  if (viewModel.currentPage == 1) ...[
                    RichText(
                      textAlign: TextAlign.center,
                      text: TextSpan(
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: Color(0xff676769),
                        ),
                        text: l10n.of(context).joinAChallenge,
                        children: [
                          TextSpan(
                            text: l10n.of(context).competeProveYourSkills,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              color: Color(0xff676769),
                            ),
                          ),
                        ],
                      ),
                    ),
                    // SizedBox(height: 6),
                    RichText(
                      textAlign: TextAlign.center,
                      text: TextSpan(
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: Color(0xff676769),
                        ),
                        text: l10n.of(context).createAChallenge,
                        children: [
                          TextSpan(
                            text: l10n.of(context).inviteOthers,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              color: Color(0xff676769),
                            ),
                          ),
                        ],
                      ),
                    ),
                    // SizedBox(
                    //   height: 6,
                    // ),
                    RichText(
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      text: TextSpan(
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: Color(0xff676769),
                        ),
                        text: l10n.of(context).publicOrPrivate,
                        children: [
                          TextSpan(
                            text: l10n.of(context).openToAllOrJustYourCrew,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              color: Color(0xff676769),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                  viewModel.lowTexts[viewModel.currentPage] != ""
                      ? Text(
                          viewModel.lowTexts[viewModel.currentPage],
                          style:
                              TextStyle(fontSize: 16, color: Color(0xff676769)),
                          textAlign: TextAlign.center,
                        )
                      : SizedBox(),
                ],
              ),
            ),
            // SizedBox(height: h*.005), // Replaced Spacer
            Divider(),
            SizedBox(height: h * .005),

            Padding(
              padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.088),
              child: Stack(
                children: [
                  Container(
                    height: 51,
                    // width: 300,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Color(0xFF72A033),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      viewModel.chooseSportsToPlay(context);
                    },
                    child: Container(
                      height: 47,
                      // width: 300,
                      decoration: BoxDecoration(
                        color: Color(0xFF8DC63F),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(width: 5),
                            Text(
                              l10n.of(context).bookACourt,
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: h * .01),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.088),
              child: InkWell(
                onTap: () async {
                  context.read<BookingProvider>().selectedCountryFlag = "🇬🇧";
                  context.read<BookingProvider>().setcheck();
                  await buildShowModalBottomSheet(context);
                },
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppColors.primaryColor)),
                  child: Center(
                    child: Text(
                      l10n.of(context).alreadyHaveAccountS,
                      style: TextStyle(
                        fontSize: 16,
                        color: AppColors.primaryColor,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
              ),
            ),

            SizedBox(height: h * .01),
          ],
        ),
      ),
    );
  }

  Future<dynamic> buildSendOtpShowModalBottomSheet(
      context, countryCode, phoneNumber) {
    print("getting otp");
    final provider = Provider.of<BookingProvider>(context, listen: false);
    provider.countryCodeController.text = countryCode;
    provider.phoneController.text = phoneNumber;
    provider.startResendOtpTimer();

    return showModalBottomSheet(
      isScrollControlled: true,
      backgroundColor: Colors.white,
      context: context,
      builder: (context) {
        return ListView(
          shrinkWrap: true,
          children: [
            Padding(
              padding: EdgeInsets.only(
                  bottom: MediaQuery.of(context).viewInsets.bottom),
              child: Consumer<BookingProvider>(
                builder:
                    (BuildContext context, viewModelGetUser, Widget? child) {
                  return Container(
                    color: Colors.transparent,
                    padding: EdgeInsets.only(top: 50),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Align(
                          alignment: Alignment.topRight,
                          child: InkWell(
                            onTap: () {
                              Navigator.pop(context);
                              viewModelGetUser.clearPhoneBottomSheet();
                            },
                            child: Container(
                              height: 30,
                              width: 30,
                              margin: EdgeInsets.only(right: 16),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: AppColors.white,
                              ),
                              child: Center(
                                child:
                                    Icon(Icons.clear, color: AppColors.black),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 20),
                        Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 16, vertical: 16),
                          width: double.infinity,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(20),
                              topRight: Radius.circular(20),
                            ),
                            color: AppColors.white,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                l10n.of(context).youreAlmostThere,
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.normal,
                                  color: AppColors.black,
                                ),
                              ),
                              SizedBox(height: 20),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    l10n.of(context).enterOtp,
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.normal,
                                      color: AppColors.black555,
                                    ),
                                  ),
                                  Text(
                                    "+${viewModelGetUser.countryCode} ${viewModelGetUser.phoneController.text}",
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.normal,
                                      color: AppColors.black555,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 20),
                              OtpTextFormField(
                                controller: viewModelGetUser.otpController,
                                onchanged: viewModelGetUser.updateOtp,
                                isValidator: true,
                              ),
                              SizedBox(height: 10),
                              if (viewModelGetUser.otpErrorMessage != null)
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8.0),
                                  child: Text(
                                    viewModelGetUser.otpErrorMessage!,
                                    style: TextStyle(
                                      color: Colors.red,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              SizedBox(height: 10),
                              viewModelGetUser.isLoading
                                  ? Center(
                                      child: CircularProgressIndicator(
                                          color: AppColors.primaryColor))
                                  : AppButton(
                                      label: l10n.of(context).verifyOtp,
                                      onPressed: viewModelGetUser.isOTPFilled
                                          ? () async {
                                              String enteredOtp =
                                                  viewModelGetUser
                                                      .otpController.text;
                                              print('otp: $enteredOtp');

                                              if (enteredOtp.isNotEmpty) {
                                                try {
                                                  int otpInt = int.parse(
                                                      enteredOtp); // Convert string to int safely
                                                  bool isSuccess =
                                                      await viewModelGetUser
                                                          .verifyOtp(
                                                              context, otpInt);

                                                  if (isSuccess) {
                                                    Navigator.pop(context);
                                                    Navigator
                                                        .pushReplacementNamed(
                                                            context,
                                                            "/dashboard");
                                                    print(
                                                        "OTP verified successfully!");
                                                    viewModelGetUser
                                                        .countryCodeController
                                                        .text = "";
                                                  } else {
                                                    print(
                                                        "OTP verification failed!");
                                                  }
                                                } catch (e) {
                                                  print(
                                                      "Invalid OTP format: $e");
                                                }
                                              } else {
                                                print("OTP field is empty.");
                                              }
                                            }
                                          : () {},
                                      textColor: viewModelGetUser.isOTPFilled
                                          ? AppColors.white
                                          : AppColors.black555,
                                      bgColor: viewModelGetUser.isOTPFilled
                                          ? AppColors.primaryColor
                                          : AppColors.greyEFEF,
                                    ),
                              SizedBox(height: 20),
                              AnimatedBuilder(
                                animation: viewModelGetUser,
                                // 👈 your BookingProvider
                                builder: (context, _) {
                                  return Center(
                                    child: GestureDetector(
                                      onTap: viewModelGetUser.canResendOtp
                                          ? () async {
                                              String countryCode =
                                                  viewModelGetUser
                                                      .countryCodeController
                                                      .text;
                                              String phoneNumber =
                                                  viewModelGetUser
                                                      .phoneController.text;

                                              if (countryCode.isEmpty ||
                                                  phoneNumber.isEmpty) {
                                                ScaffoldMessenger.of(context)
                                                    .showSnackBar(
                                                  const SnackBar(
                                                      content: Text(
                                                          "Please enter valid phone number")),
                                                );
                                                return;
                                              }

                                              bool isValid =
                                                  await viewModelGetUser
                                                      .validateBeforeSendingOtp(
                                                countryCode: countryCode,
                                                phoneNumber: phoneNumber,
                                              );

                                              if (isValid) {
                                                await viewModelGetUser
                                                    .sendOtpRequest(
                                                  countryCode1: countryCode,
                                                  phoneNumber1: phoneNumber,
                                                );
                                                viewModelGetUser
                                                    .startResendOtpTimer();
                                              }
                                            }
                                          : null,
                                      child: Text(
                                        viewModelGetUser.canResendOtp
                                            ? l10n.of(context).resendOtp
                                            : "${l10n.of(context).resendOtp} ${viewModelGetUser.remainingSeconds}s",
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w700,
                                          color: viewModelGetUser.canResendOtp
                                              ? AppColors.black
                                              : AppColors.grey8A8,
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ),
                              // Consumer<BookingProvider>(
                              //   builder: (context, viewModelGetUser, _) {
                              //     return Center(
                              //       child: GestureDetector(
                              //         onTap: viewModelGetUser.canResendOtp
                              //             ? () async {
                              //                 // ✅ Validate phone number and country code before resending
                              //                 String countryCode =
                              //                     viewModelGetUser
                              //                         .countryCodeController
                              //                         .text;
                              //                 String phoneNumber =
                              //                     viewModelGetUser
                              //                         .phoneController.text;
                              //
                              //                 // Example validation (update as per your actual logic)
                              //                 if (countryCode.isEmpty ||
                              //                     phoneNumber.isEmpty) {
                              //                   ScaffoldMessenger.of(context)
                              //                       .showSnackBar(
                              //                     SnackBar(
                              //                         content: Text(
                              //                             "Please enter valid phone number")),
                              //                   );
                              //                   return;
                              //                 }
                              //
                              //                 bool isValid =
                              //                     await viewModelGetUser
                              //                         .validateBeforeSendingOtp(
                              //                   countryCode: countryCode,
                              //                   phoneNumber: phoneNumber,
                              //                 );
                              //
                              //                 if (isValid) {
                              //                   await viewModelGetUser
                              //                       .sendOtpRequest(
                              //                     countryCode1: countryCode,
                              //                     phoneNumber1: phoneNumber,
                              //                   );
                              //                   viewModelGetUser
                              //                       .startResendOtpTimer();
                              //                 } else {
                              //                   // Show error message or handle invalid case
                              //                 }
                              //               }
                              //             : null,
                              //         child: Text(
                              //           viewModelGetUser.canResendOtp
                              //               ? S.of(context).resendOtp
                              //               : "${S.of(context).resendOtp} ${viewModelGetUser.remainingSeconds}s",
                              //           style: TextStyle(
                              //             fontSize: 14,
                              //             fontWeight: FontWeight.w700,
                              //             color: viewModelGetUser.canResendOtp
                              //                 ? AppColors.black
                              //                 : AppColors.grey8A8,
                              //           ),
                              //         ),
                              //       ),
                              //     );
                              //   },
                              // ),
                              SizedBox(height: 20),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  bool showTermsError = false;

  Future<dynamic> buildShowModalBottomSheet(BuildContext context) {
    print("login bottom sheet fjgj");

    return showModalBottomSheet(
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      context: context,
      builder: (context) {
        return StatefulBuilder(builder: (context, modalSetState) {
          return SingleChildScrollView(
            padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom),
            child: Consumer<BookingProvider>(
                builder: (context, viewModelGetUser2, child) {
              // Ensure country code is set once before rendering the sheet
              if (viewModelGetUser2.countryCodeController.text.isEmpty) {
                viewModelGetUser2.countryCodeController.text = "44";
                viewModelGetUser2.updateCountryCode("44");
              }
              return Container(
                color: Colors.transparent,
                padding: EdgeInsets.only(top: 50),
                child: Column(
                  children: [
                    Align(
                      alignment: Alignment.topRight,
                      child: InkWell(
                        onTap: () {
                          Navigator.pop(context);
                          viewModelGetUser2.clearPhoneBottomSheet();
                        },
                        child: Container(
                          height: 30,
                          width: 30,
                          margin: EdgeInsets.only(right: 16),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: AppColors.white,
                          ),
                          child: Center(
                            child: Icon(Icons.clear, color: AppColors.black),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                    Container(
                      padding: EdgeInsets.all(16),
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20),
                        ),
                        color: AppColors.white,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            l10n.of(context).youreAlmostThere,
                            style:
                                TextStyle(fontSize: 18, color: AppColors.black),
                          ),
                          SizedBox(height: 20),
                          Text(
                            l10n.of(context).enterMobileNumber,
                            style: TextStyle(
                                fontSize: 16, color: AppColors.black555),
                          ),
                          SizedBox(height: 20),
                          Form(
                            key: _formKey,
                            child: Column(
                              children: [
                                AppTextField(
                                  onchanged:
                                      viewModelGetUser2.updatePhoneNumber,
                                  borderColor:
                                      AppColors.teal747D.withOpacity(.5),
                                  controller: viewModelGetUser2.phoneController,
                                  prefixWidget: GestureDetector(
                                    onTap: () {
                                      showCountryPicker(
                                        context: context,
                                        // favorite: <String>['IN'],
                                        showPhoneCode: true,
                                        onSelect: (value) {
                                          String? rawCode = value.phoneCode;
                                          if (rawCode != null &&
                                              rawCode.startsWith("+")) {
                                            rawCode = rawCode.substring(1);
                                          }

                                          viewModelGetUser2
                                              .countryCodeController
                                              .text = rawCode ?? "44";
                                          viewModelGetUser2.updateCountryCode(
                                              rawCode ?? "44");

                                          // Set the flag emoji
                                          viewModelGetUser2
                                                  .selectedCountryFlag =
                                              value
                                                  .flagEmoji; // <-- Set the flag here

                                          modalSetState(() {});
                                        },

                                        moveAlongWithKeyboard: false,
                                        countryListTheme: CountryListThemeData(
                                          borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(40.0),
                                            topRight: Radius.circular(40.0),
                                          ),
                                          inputDecoration: InputDecoration(
                                            labelText: 'Search',
                                            hintText: 'Start typing to search',
                                            prefixIcon:
                                                const Icon(Icons.search),
                                          ),
                                          searchTextStyle: const TextStyle(
                                            color: Colors.blue,
                                            fontSize: 18,
                                          ),
                                        ),
                                      );
                                    },
                                    child: Container(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 12, vertical: 8),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(viewModelGetUser2
                                                  .selectedCountryFlag ??
                                              "🇬🇧"),
                                          // Default UK flag
                                          SizedBox(width: 8),
                                          Text(
                                              '+${viewModelGetUser2.countryCodeController.text}'),
                                          Icon(Icons.arrow_drop_down),
                                        ],
                                      ),
                                    ),
                                  ),
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return l10n
                                          .of(context)
                                          .pleaseEnterYourPhoneNumber;
                                    }
                                    if (!RegExp(r'^\d{8,12}$')
                                        .hasMatch(value)) {
                                      return l10n
                                          .of(context)
                                          .phoneNumberMustBe810Digits;
                                    }
                                    return null;
                                  },
                                  inputFormatters: [
                                    FilteringTextInputFormatter.digitsOnly,
                                    LengthLimitingTextInputFormatter(12),
                                  ],
                                  height: 42,
                                  hintText:
                                      l10n.of(context).enter810DigitPhoneNumber,
                                  keyboardType: TextInputType.number,
                                ),
                                SizedBox(height: 20),
                                viewModelGetUser2.isLoading
                                    ? Center(
                                        child: CircularProgressIndicator(
                                          color: AppColors.primaryColor,
                                        ),
                                      )
                                    : AppButton(

                                        label: l10n.of(context).sendOtp,
                                        onPressed: () async {
                                          modalSetState(() {
                                            viewModelGetUser2.otpErrorMessage =
                                                null;
                                            showTermsError = false;
                                          });

                                          if (!_formKey.currentState!
                                              .validate()) {
                                            return;
                                          }

                                          if (!viewModelGetUser2.isChecked) {
                                            modalSetState(() {
                                              showTermsError = true;
                                            });
                                            return;
                                          }

                                          String phoneNumber = viewModelGetUser2
                                              .phoneController.text;
                                          String countryCode = viewModelGetUser2
                                              .countryCodeController.text;

                                          bool isSuccess =
                                              await viewModelGetUser2
                                                  .sendOtpRequest(
                                            countryCode1: countryCode,
                                            phoneNumber1: phoneNumber,
                                          );

                                          if (isSuccess) {
                                            Navigator.pop(context);
                                            buildSendOtpShowModalBottomSheet(
                                                context,
                                                countryCode,
                                                phoneNumber);
                                          } else {
                                            modalSetState(() {
                                              viewModelGetUser2
                                                      .otpErrorMessage =
                                                  l10n
                                                      .of(context)
                                                      .failedToSendOtpPleaseTryAgain;
                                            });
                                            _formKey.currentState!.validate();
                                          }
                                        },
                                        textColor: viewModelGetUser2
                                                    .phoneController
                                                    .text
                                                    .length >=
                                                8
                                            ? AppColors.white
                                            : AppColors.black555,
                                        bgColor: viewModelGetUser2
                                                    .phoneController
                                                    .text
                                                    .length >=
                                                8
                                            ? AppColors.primaryColor
                                            : AppColors.greyEFEF,
                                      ),
                              ],
                            ),
                          ),
                          SizedBox(height: 20),
                          Row(
                            children: [
                              SizedBox(
                                height: 20,
                                width: 20,
                                child: Checkbox(
                                  checkColor: AppColors.white,
                                  overlayColor:
                                      WidgetStateProperty.all(AppColors.black),
                                  fillColor: WidgetStateProperty.all(
                                    viewModelGetUser2.isChecked
                                        ? AppColors.black
                                        : AppColors.white,
                                  ),
                                  value: viewModelGetUser2.isChecked,
                                  onChanged: (bool? value) {
                                    modalSetState(() {
                                      viewModelGetUser2.updateCheckedButton();
                                      showTermsError = false;
                                    });
                                  },
                                ),
                              ),
                              SizedBox(width: 5),
                              RichText(
                                text: TextSpan(
                                  text: l10n.of(context).agreeWith,
                                  style: TextStyle(
                                      fontSize: 14, color: AppColors.grey769),
                                  children: [
                                    TextSpan(
                                      text: l10n.of(context).termsConditions,
                                      style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w800,
                                        color: AppColors.black,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          if (showTermsError)
                            Padding(
                              padding:
                                  const EdgeInsets.only(top: 8.0, left: 5.0),
                              child: Text(
                                l10n
                                    .of(context)
                                    .pleaseAcceptTheTermsConditionsToContinue,
                                style:
                                    TextStyle(color: Colors.red, fontSize: 12),
                              ),
                            ),
                          SizedBox(height: 20),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: Container(
                                  height: 1,
                                  color: AppColors.greyBEBE,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.symmetric(horizontal: 5),
                                child: Text(
                                  l10n.of(context).or,
                                  style: TextStyle(
                                      fontSize: 14, color: AppColors.grey769),
                                ),
                              ),
                              Expanded(
                                child: Container(
                                  height: 1,
                                  color: AppColors.greyBEBE,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 20),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            spacing: 10,
                            children: List.generate(2, (index) {
                              List<String> imgList = [
                                "assets/png/png_fb.png",
                                if (Platform.isAndroid)
                                  "assets/png/png_google.png",
                                if (Platform.isIOS) "assets/png/png_apple.png",
                              ];
                              return InkWell(
                                onTap: () async {
                                  switch (index) {
                                    case 0:
                                      await SocialLoginRepository
                                              .signInWithFacebook(
                                                  context: context)
                                          .then(
                                        (value) {
                                          if (value["isSuccess"]) {
                                            print(
                                                "isExist....${value["isExist"]}");

                                            print("${value["emial"]}");
                                            print("${value["id"]}");
                                            print("${value["name"]}");
                                            print("${value["type"]}");

                                            if (value["isExist"]) {
                                              viewModelGetUser2
                                                  .socialLoginApiFunc(
                                                      context: context,
                                                      email: value["email"],
                                                      socialID: value["id"],
                                                      name: value["name"],
                                                      type: value["type"]);
                                              // if(valueNew)
                                              // Navigator.pop(context);
                                              Navigator.pushReplacementNamed(
                                                  context, "/dashboard");
                                            } else {
                                              print("${value["emial"]}");
                                              print("${value["id"]}");
                                              print("${value["name"]}");
                                              print("${value["type"]}");
                                              socialLoginBottomSheet(
                                                  context: context,
                                                  email: value["email"],
                                                  socilID: value["id"],
                                                  name: value["name"],
                                                  type: value["type"]);
                                            }
                                          }
                                        },
                                      );

                                      return;
                                    case 1:
                                      if (Platform.isIOS) {
                                        await SocialLoginRepository
                                                .loginWithApple(context)
                                            //     .then(
                                            //   (value) {

                                            //   },
                                            // )
                                            ;
                                      } else {
                                        await SocialLoginRepository
                                                .signInWithGoogle(context)
                                            .then(
                                          (value) {
                                            if (value["isSuccess"]) {
                                              print(
                                                  "isExistggg....${value["isExist"]}");

                                              if (value["isExist"]) {
                                                viewModelGetUser2
                                                    .socialLoginApiFunc(
                                                        context: context,
                                                        email: value["email"],
                                                        socialID: value["id"],
                                                        name: value["name"],
                                                        type: value["type"])
                                                    .then((vallue) {
                                                  if (vallue) {
                                                    Navigator
                                                        .pushReplacementNamed(
                                                            NavigationService
                                                                .navigatorKey
                                                                .currentState!
                                                                .context,
                                                            "/dashboard");
                                                  }
                                                });
                                              } else {
                                                socialLoginBottomSheet(
                                                    context: context,
                                                    email: value["email"],
                                                    socilID: value["id"],
                                                    name: value["name"],
                                                    type: value["type"]);
                                              }
                                              print(
                                                  "google credential email ${value["emial"]}");
                                              print(
                                                  "google credential id ${value["id"]}");
                                              print(
                                                  "google credential name ${value["name"]}");
                                              print(
                                                  "google credential type ${value["type"]}");
                                            }
                                          },
                                        );
                                      }

                                      return;

                                    default:
                                      return;
                                  }
                                },
                                child: SizedBox(
                                  width: 54,
                                  height: 54,
                                  child: Image.asset(imgList[index],
                                      fit: BoxFit.fill),
                                ),
                              );
                            }),
                          ),
                          SizedBox(height: 40),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            }),
          );
        });
      },
    );
  }

  ///for social login
  Future<dynamic> socialLoginBottomSheet(
      {required BuildContext context,
      required String email,
      required String socilID,
      required String name,
      required String type}) {
    print("SSocial login bottom sheet");
    return showModalBottomSheet(
      isScrollControlled: true,
      backgroundColor: Colors.white,
      context: context,
      builder: (context) {
        return SafeArea(
          bottom: true,
          child: StatefulBuilder(builder: (context, modalSetState) {
            return SingleChildScrollView(
              padding: EdgeInsets.only(
                  bottom: MediaQuery.of(context).viewInsets.bottom),
              child: Consumer<BookingProvider>(
                  builder: (context, viewModelGetUser2, child) {
                // Ensure country code is set once before rendering the sheet
                if (viewModelGetUser2.countryCodeController.text.isEmpty) {
                  viewModelGetUser2.countryCodeController.text = "44";
                  viewModelGetUser2.updateCountryCode("44");
                  viewModelGetUser2.selectedCountryFlag = "🇬🇧";
                }
                return Container(
                  color: Colors.transparent,
                  padding: EdgeInsets.only(top: 50),
                  child: Column(
                    children: [
                      Align(
                        alignment: Alignment.topRight,
                        child: InkWell(
                          onTap: () {
                            Navigator.pop(context);
                            viewModelGetUser2.clearPhoneBottomSheet();
                          },
                          child: Container(
                            height: 30,
                            width: 30,
                            margin: EdgeInsets.only(right: 16),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: AppColors.white,
                            ),
                            child: Center(
                              child: Icon(Icons.clear, color: AppColors.black),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                      Container(
                        padding: EdgeInsets.all(16),
                        width: double.infinity,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(20),
                            topRight: Radius.circular(20),
                          ),
                          color: AppColors.white,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Please verify your mobile number using the OTP.",
                              style: TextStyle(
                                  fontSize: 18, color: AppColors.black),
                            ),
                            SizedBox(height: 20),
                            Text(
                              l10n.of(context).enterMobileNumber,
                              style: TextStyle(
                                  fontSize: 16, color: AppColors.black555),
                            ),
                            SizedBox(height: 20),
                            Form(
                              key: _formKeyForGoogleLogin,
                              child: Column(
                                children: [
                                  AppTextField(
                                    onchanged:
                                        viewModelGetUser2.updatePhoneNumber,
                                    borderColor:
                                        AppColors.teal747D.withOpacity(.5),
                                    controller:
                                        viewModelGetUser2.phoneController,
                                    prefixWidget: GestureDetector(
                                      onTap: () {
                                        showCountryPicker(
                                          context: context,
                                          // favorite: <String>['IN'],
                                          showPhoneCode: true,
                                          onSelect: (value) {
                                            String? rawCode = value.phoneCode;
                                            if (rawCode != null &&
                                                rawCode.startsWith("+")) {
                                              rawCode = rawCode.substring(1);
                                            }
                                            viewModelGetUser2
                                                    .selectedCountryFlag =
                                                value.flagEmoji;

                                            viewModelGetUser2
                                                .countryCodeController
                                                .text = rawCode ?? "44";
                                            viewModelGetUser2.updateCountryCode(
                                                rawCode ?? "44");

                                            // 💡 Trigger rebuild for selected code to show up
                                            modalSetState(() {});
                                          },
                                          moveAlongWithKeyboard: false,
                                          countryListTheme:
                                              CountryListThemeData(
                                            borderRadius: BorderRadius.only(
                                              topLeft: Radius.circular(40.0),
                                              topRight: Radius.circular(40.0),
                                            ),
                                            inputDecoration: InputDecoration(
                                              labelText: 'Search',
                                              hintText:
                                                  'Start typing to search',
                                              prefixIcon:
                                                  const Icon(Icons.search),
                                            ),
                                            searchTextStyle: const TextStyle(
                                              color: Colors.blue,
                                              fontSize: 18,
                                            ),
                                          ),
                                        );
                                      },
                                      child: Container(
                                        padding: EdgeInsets.symmetric(
                                            horizontal: 12, vertical: 8),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Text(viewModelGetUser2
                                                    .selectedCountryFlag ??
                                                "🇬🇧"),
                                            // Text(viewModelGetUser2.c)
                                            // Icon(Icons.flag),
                                            SizedBox(width: 8),
                                            Text(
                                                '+${viewModelGetUser2.countryCodeController.text}'),
                                            Icon(Icons.arrow_drop_down),
                                          ],
                                        ),
                                      ),
                                    ),
                                    validator: (value) {
                                      if (value == null || value.isEmpty) {
                                        return l10n
                                            .of(context)
                                            .pleaseEnterYourPhoneNumber;
                                      }
                                      if (!RegExp(r'^\d{8,12}$')
                                          .hasMatch(value)) {
                                        return l10n
                                            .of(context)
                                            .phoneNumberMustBe810Digits;
                                      }
                                      return null;
                                    },
                                    inputFormatters: [
                                      FilteringTextInputFormatter.digitsOnly,
                                      LengthLimitingTextInputFormatter(12),
                                    ],
                                    height: 42,
                                    hintText: l10n
                                        .of(context)
                                        .enter810DigitPhoneNumber,
                                    keyboardType: TextInputType.number,
                                  ),
                                  SizedBox(height: 20),
                                  viewModelGetUser2.isSocialOtpVerifyLoading
                                      ? Center(
                                          child: CircularProgressIndicator(
                                              color: AppColors.primaryColor))
                                      : AppButton(
                                          label: l10n.of(context).sendOtp,
                                          onPressed: () async {
                                            if (!_formKeyForGoogleLogin
                                                .currentState!
                                                .validate()) return;

                                            String phoneNumber =
                                                viewModelGetUser2
                                                    .phoneController.text;
                                            String countryCode =
                                                viewModelGetUser2
                                                    .countryCodeController.text;
                                            print(
                                                "Onboarding login ph no.. : $phoneNumber");
                                            print(
                                                "Onboarding login countryCode...: $countryCode");

                                            // bool isSuccess =
                                            await viewModelGetUser2
                                                .sendOtpForSocilaLoginRequest(
                                                    countryCode1: countryCode,
                                                    phoneNumber1: phoneNumber)
                                                .then((v) {
                                              if (v) {
                                                socialLoginVerifyOtpBottomSheet(
                                                    email: email,
                                                    name: name,
                                                    socilID: socilID,
                                                    type: type,
                                                    context: context,
                                                    countryCode: countryCode,
                                                    phoneNumber: phoneNumber);
                                              } else {
                                                modalSetState(() {
                                                  viewModelGetUser2
                                                          .otpErrorMessage =
                                                      l10n
                                                          .of(context)
                                                          .failedToSendOtpPleaseTryAgain;
                                                });
                                                _formKeyForGoogleLogin
                                                    .currentState!
                                                    .validate();
                                              }
                                            });

                                            // if (isSuccess) {
                                            //   Navigator.pop(context);
                                            //   buildSendOtpShowModalBottomSheet(
                                            //       context,
                                            //       countryCode,
                                            //       phoneNumber);
                                            // }
                                          },
                                          textColor: viewModelGetUser2
                                                      .phoneController
                                                      .text
                                                      .length >=
                                                  8
                                              ? AppColors.white
                                              : AppColors.black555,
                                          bgColor: viewModelGetUser2
                                                      .phoneController
                                                      .text
                                                      .length >=
                                                  8
                                              ? AppColors.primaryColor
                                              : AppColors.greyEFEF,
                                        ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              }),
            );
          }),
        );
      },
    );
  }

//verify otp for social login

  Future<dynamic> socialLoginVerifyOtpBottomSheet(
      {context,
      countryCode,
      phoneNumber,
      required String email,
      required String socilID,
      required String name,
      required String type}) {
    final provider = Provider.of<BookingProvider>(context, listen: false);
    provider.countryCodeController.text = countryCode;
    provider.phoneController.text = phoneNumber;
    provider.startResendOtpTimer();

    return showModalBottomSheet(
      isScrollControlled: true,
      backgroundColor: Colors.white,
      context: context,
      builder: (context) {
        return ListView(
          shrinkWrap: true,
          children: [
            Padding(
              padding: EdgeInsets.only(
                  bottom: MediaQuery.of(context).viewInsets.bottom),
              child: Consumer<BookingProvider>(
                builder:
                    (BuildContext context, viewModelGetUser, Widget? child) {
                  return Container(
                    color: Colors.transparent,
                    padding: EdgeInsets.only(top: 50),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Align(
                          alignment: Alignment.topRight,
                          child: InkWell(
                            onTap: () {
                              Navigator.pop(context);
                              viewModelGetUser.clearPhoneBottomSheet();
                            },
                            child: Container(
                              height: 30,
                              width: 30,
                              margin: EdgeInsets.only(right: 16),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: AppColors.white,
                              ),
                              child: Center(
                                child:
                                    Icon(Icons.clear, color: AppColors.black),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 20),
                        Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 16, vertical: 16),
                          width: double.infinity,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(20),
                              topRight: Radius.circular(20),
                            ),
                            color: AppColors.white,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Text(
                              //   S.of(context).youreAlmostThere,
                              //   style: TextStyle(
                              //     fontSize: 18,
                              //     fontWeight: FontWeight.normal,
                              //     color: AppColors.black,
                              //   ),
                              // ),
                              // SizedBox(height: 20),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    l10n.of(context).enterOtp,
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.normal,
                                      color: AppColors.black555,
                                    ),
                                  ),
                                  Text(
                                    "+${viewModelGetUser.countryCode} ${viewModelGetUser.phoneController.text}",
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.normal,
                                      color: AppColors.black555,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 20),
                              OtpTextFormField(
                                controller: viewModelGetUser.otpController,
                                onchanged: viewModelGetUser.updateOtp,
                                isValidator: true,
                              ),
                              SizedBox(height: 10),
                              if (viewModelGetUser.otpErrorMessage != null)
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8.0),
                                  child: Text(
                                    viewModelGetUser.otpErrorMessage!,
                                    style: TextStyle(
                                      color: Colors.red,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              SizedBox(height: 10),
                              viewModelGetUser.isSocialOtpVerifyLoading
                                  ? Center(
                                      child: CircularProgressIndicator(
                                          color: AppColors.primaryColor))
                                  : AppButton(
                                      label: l10n.of(context).verifyOtp,
                                      onPressed: viewModelGetUser.isOTPFilled
                                          ? () async {
                                              String enteredOtp =
                                                  viewModelGetUser
                                                      .otpController.text;
                                              print('otp: $enteredOtp');

                                              if (enteredOtp.isNotEmpty) {
                                                try {
                                                  int otpInt = int.parse(
                                                      enteredOtp); // Convert string to int safely
                                                  bool isSuccess =
                                                      await viewModelGetUser
                                                          .verifyForSocialLoginOtp(
                                                              context: context,
                                                              otp: otpInt,
                                                              email: email,
                                                              name: name,
                                                              socilID: socilID,
                                                              type: type);

                                                  if (isSuccess) {
                                                    Navigator.pop(context);
                                                    Navigator
                                                        .pushReplacementNamed(
                                                            context,
                                                            "/dashboard");
                                                    print(
                                                        "OTP verified successfully!");
                                                    viewModelGetUser
                                                        .countryCodeController
                                                        .text = "";
                                                  } else {
                                                    print(
                                                        "OTP verification failed!");
                                                  }
                                                } catch (e) {
                                                  print(
                                                      "Invalid OTP format: $e");
                                                }
                                              } else {
                                                print("OTP field is empty.");
                                              }
                                            }
                                          : () {},
                                      textColor: viewModelGetUser.isOTPFilled
                                          ? AppColors.white
                                          : AppColors.black555,
                                      bgColor: viewModelGetUser.isOTPFilled
                                          ? AppColors.primaryColor
                                          : AppColors.greyEFEF,
                                    ),
                              SizedBox(height: 20),
                              Consumer<BookingProvider>(
                                builder: (context, viewModelGetUser, _) {
                                  return Center(
                                    child: GestureDetector(
                                      onTap: viewModelGetUser.canResendOtp
                                          ? () async {
                                              // ✅ Validate phone number and country code before resending
                                              String countryCode =
                                                  viewModelGetUser
                                                      .countryCodeController
                                                      .text;
                                              String phoneNumber =
                                                  viewModelGetUser
                                                      .phoneController.text;

                                              // Example validation (update as per your actual logic)
                                              if (countryCode.isEmpty ||
                                                  phoneNumber.isEmpty) {
                                                ScaffoldMessenger.of(context)
                                                    .showSnackBar(
                                                  SnackBar(
                                                      content: Text(
                                                          "Please enter valid phone number")),
                                                );
                                                return;
                                              }

                                              bool isValid =
                                                  await viewModelGetUser
                                                      .validateBeforeSendingOtp(
                                                countryCode: countryCode,
                                                phoneNumber: phoneNumber,
                                              );

                                              if (isValid) {
                                                await viewModelGetUser
                                                    .sendOtpRequest(
                                                  countryCode1: countryCode,
                                                  phoneNumber1: phoneNumber,
                                                );
                                                viewModelGetUser
                                                    .startResendOtpTimer();
                                              } else {
                                                // Show error message or handle invalid case
                                              }
                                            }
                                          : null,
                                      child: Text(
                                        viewModelGetUser.canResendOtp
                                            ? l10n.of(context).resendOtp
                                            : "${l10n.of(context).resendOtp} ${viewModelGetUser.remainingSeconds}s",
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w700,
                                          color: viewModelGetUser.canResendOtp
                                              ? AppColors.black
                                              : AppColors.grey8A8,
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ),
                              SizedBox(height: 20),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}
