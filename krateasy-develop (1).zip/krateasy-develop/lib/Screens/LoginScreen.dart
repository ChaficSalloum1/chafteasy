import 'package:flutter/material.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:provider/provider.dart';
import 'package:country_picker/country_picker.dart';
import '../ViewModel/LoginViewModel.dart';

class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final viewModel = Provider.of<LoginViewModel>(context);
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    double commonWidth = screenWidth * 0.9;
    double commonHeight = screenHeight * 0.07;

    return Scaffold(
      body: Stack(
        children: [
          LayoutBuilder(
            builder: (context, constraints) {
              return SingleChildScrollView(
                child: ConstrainedBox(
                  constraints: BoxConstraints(minHeight: constraints.maxHeight),
                  child: IntrinsicHeight(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Spacer(flex: 3),
                        Center(
                          child: Column(
                            children: [
                              Image.asset(
                                l10n.of(context).assetslogopng,
                                width: screenWidth * 0.4,
                                height: screenWidth * 0.4,
                              ),
                              SizedBox(height: screenHeight * 0.02),
                              Text(
                                l10n.of(context).login,
                                style: TextStyle(
                                  fontSize: screenWidth * 0.08,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(height: screenHeight * 0.01),
                              Text(
                                l10n.of(context).getReadyToUnlockAWorldOf,
                                style: TextStyle(
                                  fontSize: screenWidth * 0.04,
                                  color: Colors.grey[700],
                                ),
                              ),
                              Text(
                                l10n.of(context).possibilitiessignIntoYourAccountNow,
                                style: TextStyle(
                                  fontSize: screenWidth * 0.04,
                                  color: Colors.grey[700],
                                ),
                              ),
                              SizedBox(height: screenHeight * 0.04),
                              Padding(
                                padding: EdgeInsets.symmetric(
                                  horizontal: screenWidth * 0.05,
                                ),
                                child: Column(
                                  children: [
                                    // Mobile Number Field with Country Picker
                                    SizedBox(
                                      width: commonWidth,
                                      height: commonHeight,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          border: Border.all(
                                            color: Colors.grey,
                                          ),
                                          borderRadius: BorderRadius.circular(
                                            10,
                                          ),
                                        ),
                                        child: Row(
                                          children: [
                                            GestureDetector(
                                              onTap: () {
                                                showCountryPicker(
                                                  context: context,
                                                  showPhoneCode: true,
                                                  onSelect: (Country country) {
                                                    viewModel.setCountryCode(
                                                      country.phoneCode,
                                                    );
                                                    viewModel.setCountryFlag(
                                                      country.flagEmoji,
                                                    );
                                                  },
                                                );
                                              },
                                              child: Padding(
                                                padding: EdgeInsets.symmetric(
                                                  horizontal:
                                                      screenWidth * 0.03,
                                                ),
                                                child: Row(
                                                  children: [
                                                    Text(
                                                      viewModel
                                                          .selectedCountryFlag,
                                                      style: TextStyle(
                                                        fontSize:
                                                            screenWidth * 0.06,
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: screenWidth * 0.02,
                                                    ),
                                                    Text(
                                                      "+${viewModel.selectedCountryCode}",
                                                      style: TextStyle(
                                                        fontSize:
                                                            screenWidth * 0.045,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Container(
                                              height: commonHeight * 0.8,
                                              width: 1,
                                              color: Colors.grey,
                                            ),
                                            Expanded(
                                              child: TextField(
                                                controller:
                                                    viewModel.phoneController,
                                                keyboardType:
                                                    TextInputType.phone,
                                                decoration: InputDecoration(
                                                  contentPadding:
                                                      EdgeInsets.symmetric(
                                                    horizontal:
                                                        screenWidth * 0.03,
                                                  ),
                                                  hintText:
                                                      l10n.of(context).enterMobileNumber,
                                                  border: InputBorder.none,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: screenHeight * 0.015),
                                    // Password Field with Eye Icon
                                    SizedBox(
                                      width: commonWidth,
                                      height: commonHeight,
                                      child: Consumer<LoginViewModel>(
                                        builder: (context, viewModel, child) {
                                          return TextField(
                                            obscureText:
                                                viewModel.isPasswordHidden,
                                            decoration: InputDecoration(
                                              labelText: l10n.of(context).password,
                                              border: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                              ),
                                              suffixIcon: IconButton(
                                                icon: Icon(
                                                  viewModel.isPasswordHidden
                                                      ? Icons.visibility_off
                                                      : Icons.visibility,
                                                ),
                                                onPressed: () {
                                                  viewModel
                                                      .togglePasswordVisibility();
                                                },
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                    SizedBox(height: screenHeight * 0.015),
                                    // Remember Me Checkbox & Forgot Password Button
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          children: [
                                            Consumer<LoginViewModel>(
                                              builder: (
                                                context,
                                                viewModel,
                                                child,
                                              ) {
                                                return Checkbox(
                                                  value: viewModel
                                                      .isRememberMeChecked,
                                                  onChanged: (newValue) {
                                                    viewModel
                                                        .toggleRememberMe();
                                                  },
                                                );
                                              },
                                            ),
                                            Text(
                                              l10n.of(context).rememberMe,
                                              style: TextStyle(
                                                fontSize: screenWidth * 0.035,
                                              ),
                                            ),
                                          ],
                                        ),
                                        TextButton(
                                          onPressed: () {
                                            viewModel.onForgotPassword(context);
                                          },
                                          child: Text(
                                            l10n.of(context).forgotPassword,
                                            style: TextStyle(
                                              fontSize: screenWidth * 0.035,
                                              color: Colors.grey[700],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: screenHeight * 0.02),
                                    // Login Button
                                    SizedBox(
                                      width: commonWidth,
                                      height: commonHeight,
                                      child: ElevatedButton(
                                        onPressed: () {
                                          viewModel.onLogin(context);
                                        },
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: const Color(
                                            0xFF8DC63F,
                                          ),
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                              10,
                                            ),
                                          ),
                                        ),
                                        child: Text(
                                          l10n.of(context).logIn,
                                          style: TextStyle(
                                            fontSize: screenWidth * 0.045,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: screenHeight * 0.02),
                                    // Sign Up Label
                                    GestureDetector(
                                      onTap: () {
                                        Navigator.pushNamed(context, '/signup');
                                      },
                                      child: Text(
                                        l10n.of(context).dontHaveAnAccountSignUp,
                                        style: TextStyle(
                                          fontSize: screenWidth * 0.04,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Spacer(flex: 3),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
          Positioned(
            top: 40,
            right: 20,
            child: GestureDetector(
              onTap: () {
                viewModel.onSkip(context);
              },
              child: Image.asset('assets/skip/skip.png', width: 50, height: 50),
            ),
          ),
        ],
      ),
    );
  }
}
