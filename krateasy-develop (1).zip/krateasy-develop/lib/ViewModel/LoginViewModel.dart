import 'package:flutter/material.dart';

class LoginViewModel extends ChangeNotifier {
  // final String logoPath = S.of(context).assetslogopng; // Change to your actual logo path
  // final String headText = S.of(context).login;
  // final String midText = S.of(context).getReadyToUnlockAWorldOf;
  // final String lowText = S.of(context).possibilitiessignIntoYourAccountNow;

  bool isPasswordHidden = true;
  bool isRememberMeChecked = false; // For "Remember Me" checkbox
  TextEditingController phoneController = TextEditingController(text: '');

  // Default country code and flag
  String selectedCountryCode = '44'; // UK (+44)
  String selectedCountryFlag = '🇬🇧'; // Default flag for UK

  void togglePasswordVisibility() {
    isPasswordHidden = !isPasswordHidden;
    notifyListeners();
  }

  void setCountryCode(String newCode) {
    selectedCountryCode = newCode;
    notifyListeners();
  }

  void setCountryFlag(String newFlag) {
    selectedCountryFlag = newFlag;
    notifyListeners();
  }

  void toggleRememberMe() {
    isRememberMeChecked = !isRememberMeChecked;
    notifyListeners();
  }

  void onForgotPassword(BuildContext context) {
    Navigator.pushNamed(
      context,
      '/forgotPassword',
    ); // Ensure '/forgotPassword' is defined in your routes
  }

  void onLogin(BuildContext context) {
    Navigator.pushNamed(
      context,
      '/verification',
    ); // Navigate to Verification Code Screen
  }

  void onSignUp() {
    // Navigate to sign-up screen
  }

  void onSkip(BuildContext context) {
    Navigator.pushNamed(
      context,
      '/dashboard',
    ); // Navigate to Verification Code Screen
  }
}
