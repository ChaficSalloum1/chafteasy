
import 'package:flutter/material.dart';

class CompletedChallengeViewModel extends ChangeNotifier {
  void navigateToViewChallengeScreen(BuildContext context){
    Navigator.pushNamed(context,'/viewChallengeScreen');
  }
  bool isLoading = false;
  List<String> imageUrls = [
    "https://randomuser.me/api/portraits/men/1.jpg",
    "https://randomuser.me/api/portraits/women/2.jpg",
    "https://randomuser.me/api/portraits/men/3.jpg",
    "https://randomuser.me/api/portraits/women/4.jpg",
    "https://randomuser.me/api/portraits/men/5.jpg",
    "https://randomuser.me/api/portraits/women/6.jpg",
    "https://randomuser.me/api/portraits/men/7.jpg",
  ];
  List<Map<String, dynamic>> openings = [
    {
      "club": "Edgbaston Priory Club",
      "court": "Court Name",
      "date": "09 Feb, 2025",
      "time": "09:00AM - 11:00AM",
      "location": "Edgbaston, Birmingham",
      "image": "assets/icons/game.png",
      "icon": "assets/icons/game.png",
      "players": 9, // Number of players joined
      "maxPlayers": 12, // Maximum players allowed
      "price": 20, // Price per hour (£)
      "playerImages": [
        "assets/icons/game.png",
        "assets/icons/game.png",
        "assets/icons/game.png",
      ],
    },
  ];
}
