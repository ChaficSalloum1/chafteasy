import 'package:flutter/material.dart';
import 'package:kratEasyApp/GlobalUtils/app_navigation.dart';
import 'package:kratEasyApp/ViewModel/BottomNavViewModels/HomeViewModel.dart';
import 'package:kratEasyApp/ViewModel/EntranceViewModel/AvailableChallengeGuestViewModel.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:provider/provider.dart';
import 'NavBarViewModels/MyBookingsViewModel.dart';

class DashboardViewModel extends ChangeNotifier {
  int _currentIndex = 0;
  int get currentIndex => _currentIndex;

  final String _userName =
      l10n.of(NavigationService.navigatorKey.currentContext!).mate;
  String get userName => _userName;

  void changeIndex(int index) {
    _currentIndex = index;

    // Ensure you use a valid context for Provider after the frame rendering
    Future.delayed(Duration.zero, () {
      switch (index) {
        case 0:
          Provider.of<HomeViewModel>(NavigationService.context, listen: false)
              .getHomeData();
          break;
        case 1:
          // Use the context directly to access the provider
          final myBookingsViewModel = Provider.of<MyBookingsViewModel>(
              NavigationService.context,
              listen: false);
          myBookingsViewModel.getMyBookingData(context:NavigationService.navigatorKey.currentContext!,type:  "upcoming");
          myBookingsViewModel.getMyChallengeData(challengeType:  "upcoming",context: NavigationService.navigatorKey.currentContext!);
          break;
        case 2:
          // Provider.of<FacilitiesViewModel>(NavigationService.context, listen: false).getFacilitiesData();
          break;
        case 3:
          Provider.of<AvailableChallengeGuestViewModel>(
                  NavigationService.context,
                  listen: false)
              .fetchChallenges();
          break;
        case 4:
          break;
      }
      notifyListeners();
    });
  }

  // Navigation logic
  // void applyFilter(BuildContext context) {
  //   Navigator.pushNamed(context, '/joinChallengeScreen');
  // }
}
