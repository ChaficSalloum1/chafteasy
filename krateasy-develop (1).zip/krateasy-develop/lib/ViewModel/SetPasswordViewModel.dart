import 'package:flutter/material.dart';

class SetPasswordViewModel extends ChangeNotifier {

  // final String headText = S.of(context).setPassword;
  // final String midText = ;
  // final String lowText = ;

  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();

  bool isPasswordHidden = true;
  bool isConfirmPasswordHidden = true;

  void togglePasswordVisibility() {
    isPasswordHidden = !isPasswordHidden;
    notifyListeners();
  }

  void toggleConfirmPasswordVisibility() {
    isConfirmPasswordHidden = !isConfirmPasswordHidden;
    notifyListeners();
  }

  void onSubmit(BuildContext context) {
    Navigator.pushNamed(context, '/complete_profile');
  }
}
