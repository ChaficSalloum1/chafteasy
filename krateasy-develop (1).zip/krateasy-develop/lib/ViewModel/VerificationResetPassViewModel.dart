import 'package:flutter/material.dart';

class VerificationResetPassViewModel extends ChangeNotifier {
  // final String headText = ;
  // final String midText = ;
  // final String lowText = ;
  // final String lowText_2 = ;

  List<TextEditingController> otpControllers = List.generate(4, (index) => TextEditingController());
  List<FocusNode> otpFocusNodes = List.generate(4, (index) => FocusNode());

  void onVerify(BuildContext context) {
    Navigator.pushNamed(context, '/reset_password'); // Navigate to Verification Code Screen
  }
}
