import 'package:flutter/material.dart';
import 'package:kratEasyApp/EntranceScreens/ChooseSportsToPlayScreen.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/GlobalUtils/app_navigation.dart';
import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/ViewModel/NavBarViewModels/MyAccountViewModel.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/repository/profile_repo.dart';
import 'package:kratEasyApp/repository/social_login_repository.dart';
import 'package:kratEasyApp/services/local/local_service.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../Screens/OnboardingScreen.dart';

class SideDrawerViewModel extends ChangeNotifier {
//for lamg

  String _selectedLanguageCode = "en"; // default

  String get selectedLanguageCode => _selectedLanguageCode;

  void setLanguage(String code, BuildContext context) {
    _selectedLanguageCode = code;
    // You can add your localization switching logic here
    // For example: context.setLocale(Locale(code));
    notifyListeners();
  }

  bool _isNotificationSwitched =
      Provider.of<MyAccountViewModel>(NavigationService.context, listen: false)
              .profileModel
              .isNotificationOn ??
          true;

  bool get isNotificationSwitched => _isNotificationSwitched;

  void switchNotification(bool value, BuildContext context) {
    _isNotificationSwitched = value;
    notifyListeners();
    notificationToggle(context);
  }

  void navigateToMyAccount() {
    Navigator.pushNamed(NavigationService.context, '/myAccount');
  }

  void navigateToFavCourtsScreen() {
    Navigator.pushNamed(NavigationService.context, '/favouriteCourtsScreen');
  }

  void navigateToWallet() {
    // Navigator.pushNamed(NavigationService.context, '/wallet');
    Navigator.pushNamed(NavigationService.context, '/allWalletTxn');
  }

  void navigateToFavouritePlayers() {
    Navigator.pushNamed(NavigationService.context, '/favouritePlayers');
  }

  void showTermsAndConditions() {
    Navigator.pushNamed(NavigationService.context, '/termsAndConditions');
  }

  void showPrivacyPolicy() {
    Navigator.pushNamed(NavigationService.context, '/privacyPolicy');
  }

  bool islogoutloading = false;
  void logout() async {
    islogoutloading = true;
    notifyListeners();
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var loginType = prefs.getString("loginType");
    if (loginType != null && loginType != "") {
      await SocialLoginRepository.logoutFromFacebook();
    } else {}

    islogoutloading = false;
    notifyListeners();
    Navigator.pushNamedAndRemoveUntil(
        NavigationService.context, '/onboarding', (route) => false);
  }

  /// delect account Apis handle
  bool isLoading = false;
  final ProfileRepo repo = ProfileRepo();
  Future<void> deleteAccount(BuildContext context) async {
    isLoading = true;
    notifyListeners();
    final requestBody = {
      "country_code": Provider.of<MyAccountViewModel>(NavigationService.context,
              listen: false)
          .countryCode,
      "mobile_number": Provider.of<MyAccountViewModel>(
              NavigationService.context,
              listen: false)
          .mobileno
    };
    try {
      final response = await repo.deleteAccount(requestBody);
      if (response.status == true) {
        showSnackbar(
            context: NavigationService.context,
            message: l10n.of(context).accountDeleteSuccessfully);
        Navigator.pushAndRemoveUntil(
            NavigationService.navigatorKey.currentContext!,
            MaterialPageRoute(builder: (_) => OnboardingScreen()),
            (route) => false);
        LocalService.instance.clearAllData();
        final prefs = await SharedPreferences.getInstance();
        await prefs.clear();
        await prefs.remove('auth_token');
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e) {
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context).somethingsWentWrongdeleteaccount);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> notificationToggle(BuildContext context) async {
    isLoading = true;
    notifyListeners();
    try {
      Navigator.pop(context);
      final response = await repo.notificationOnOff();
      if (response.status == true) {
        // _isLanguageSwitched = response.body["is_notification_on"];
        // Navigator.pop(context);
        showSnackbar(
          duration: Duration(seconds: 1),
            context: NavigationService.context,
            message: response.message ?? "");
        debugPrint("notification ${response.body["is_notification_on"]}");
      } else {}
    } catch (e, stackTrack) {
      debugPrint("stackTrack : $stackTrack");
      showSnackbar(
        duration: Duration(seconds: 1),
          context: NavigationService.context,
          message: l10n.of(context).somethingsWentWrongnotificationtoggle);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }
}
