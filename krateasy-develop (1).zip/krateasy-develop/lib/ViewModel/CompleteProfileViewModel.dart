import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/generated/l10n.dart';

import '../GlobalUtils/app_navigation.dart';

class CompleteProfileViewModel extends ChangeNotifier {
  // final String headText = S.of(context).completeProfile;
  // final String midText = S.of(context).fillYourInformationBelowOrRegister;
  // final String lowText = S.of(context).withYourAccount;

  File? _image;
  File? get image => _image;

  String _selectedSport = ""; // Default sport selection
  List<String> _sportsList = [
    l10n.of(NavigationService.navigatorKey.currentContext!).football,
    l10n.of(NavigationService.navigatorKey.currentContext!).basketball,
    l10n.of(NavigationService.navigatorKey.currentContext!).tennis,
    l10n.of(NavigationService.navigatorKey.currentContext!).cricket,
    l10n.of(NavigationService.navigatorKey.currentContext!).hockey,
    l10n.of(NavigationService.navigatorKey.currentContext!).badminton
  ];

  String get selectedSport => _selectedSport;
  List<String> get sportsList => _sportsList;

  void setSelectedSport(String newSport) {
    _selectedSport = newSport;
    notifyListeners();
  }

  void onSkip() {
    // Handle skipping logic here (Navigate to Home screen)
  }

  void onSubmit(BuildContext context) {
    Navigator.pushNamed(context, '/profile_created');
  }

  Future<void> pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      _image = File(pickedFile.path);
      notifyListeners();
    }
  }
}
