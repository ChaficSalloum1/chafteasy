// forgot_password_view_model.dart
import 'package:flutter/material.dart';

class ForgotPasswordViewModel extends ChangeNotifier {
  final String logoPath = 'assets/logo.png';
  // final String headText = S.of(context).forgetPassword;
  // final String midText = S.of(context).pleaseEnterYourRegisteredNumberTo;
  // final String lowText = S.of(context).receiveAVerificationCode;

  TextEditingController phoneController = TextEditingController(text: '');

  // Default country code and flag
  String selectedCountryCode = '44'; // UK (+44)
  String selectedCountryFlag = '🇬🇧'; // Default flag for UK

  void setCountryCode(String newCode) {
    selectedCountryCode = newCode;
    notifyListeners();
  }

  void setCountryFlag(String newFlag) {
    selectedCountryFlag = newFlag;
    notifyListeners();
  }

  void onContinue(BuildContext context) {
    Navigator.pushNamed(context, '/reset_verification_code'); // Navigate to Verification Code Screen
  }
}
