import 'package:flutter/material.dart';
import 'package:kratEasyApp/GlobalUtils/app_navigation.dart';
import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/Models/sports_list_model.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/repository/profile_repo.dart';

class EditScreenViewModel extends ChangeNotifier {
  // String name = "";
  // String email = "";
  // String phone = "";
  // String dob = "";
  // String gender = "";

  // final String headText = ;

  final ProfileRepo repo = ProfileRepo();

  // TextEditingController phoneController = TextEditingController(text: '');

  String _selectedSkill = "Beginner"; // Default value
  String get selectedSkill => _selectedSkill;
  //"Beginner", "Intermediate"
  void setSkill(String skill) {
    _selectedSkill = skill;
    notifyListeners();
  }

  String _selectedSport = ""; // Default value
  String get selectedSport => _selectedSport;

  void setSport(String sport) {
    _selectedSport = sport;
    notifyListeners();
  }

  // Default country code and flag
  String selectedCountryCode = '44'; // UK (+44)
  String selectedCountryFlag = '🇬🇧'; // Default flag for UK

  void setCountryCode(String newCode) {
    selectedCountryCode = newCode;
    notifyListeners();
  }

  void setCountryFlag(String newFlag) {
    selectedCountryFlag = newFlag;
    notifyListeners();
  }

  // List<Map<String, String>> favoriteSports = [
  //   {"sport": "Tanies", "position": "Midfield & Attack"},
  //   {"sport": "Football", "position": "Defender"},
  //   {"sport": "Rugby", "position": "Hooker"},
  // ];

  // void updateField(String field, String value) {
  //   switch (field) {
  //     case "name":
  //       name = value;
  //       break;
  //     case "email":
  //       email = value;
  //       break;
  //     case "phone":
  //       phone = value;
  //       break;
  //     case "dob":
  //       dob = value;
  //       break;
  //     case "gender":
  //       gender = value;
  //       break;
  //   }
  //   notifyListeners();
  // }

  // void updateFavoriteSport(int index, String key, String value) {
  //   // favoriteSports[index][key] = value;
  //   notifyListeners();
  // }

  void saveProfile() {
    // Implement saving logic (API call or local storage)
    debugPrint("Profile Saved!");
  }

  ///----------------------------------------------
  List<SportsListModel> sportsListModel = [];

  bool isLoadingSports = false;
  Future<void> getSportsDataApi() async {
    isLoadingSports = true;
    notifyListeners();
    try {
      final response = await repo.getSportsListDataApi();
      if (response.status == true) {
        sportsListModel = List<SportsListModel>.from(
                response.body['data'].map((x) => SportsListModel.fromJson(x)))
            .toList();
        notifyListeners();
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e, stackTrace) {
      debugPrint("stackTrace : $stackTrace");
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(NavigationService.navigatorKey.currentContext!).somethingsWentWronggetprofiledataapi);
    } finally {
      isLoadingSports = false;
      notifyListeners();
    }
  }
}
