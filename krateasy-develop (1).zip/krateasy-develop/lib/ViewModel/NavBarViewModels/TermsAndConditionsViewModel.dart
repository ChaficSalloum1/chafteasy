import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:kratEasyApp/API_CALLS/GlobalAPIUtils.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'dart:convert';
import '../../Models/TermsAndConditionsModel.dart';

class TermsAndConditionsViewModel extends ChangeNotifier {
  TermsAndConditionsModel? termsAndConditions;
  bool isLoading = false;
  String errorMessage = '';

  String baseURL = GlobalAPIUtils.getBaseUrl();
  String termConditonsURL = GlobalAPIUtils.getTermsConditionsUrl();
  String aboutUsUrl = GlobalAPIUtils.getAboutUs();

  Future<void> fetchTermsAndConditions({required BuildContext context}) async {
    isLoading = true;
    errorMessage = '';
    notifyListeners();

    try {
      final response = await http.get(Uri.parse(baseURL + termConditonsURL));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        termsAndConditions = TermsAndConditionsModel.fromJson(data);
      } else {
        errorMessage = l10n.of(context).failedToLoadTermsConditions;
      }
    } catch (error) {
      errorMessage = l10n.of(context).somethingWentWrongPleaseTryAgain;
    }

    isLoading = false;
    notifyListeners();
  }

  Future<void> fetchAboutUs({required BuildContext context}) async {
    isLoading = true;
    errorMessage = '';
    notifyListeners();

    try {
      final response = await http.get(Uri.parse(baseURL + aboutUsUrl));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        termsAndConditions = TermsAndConditionsModel.fromJson(data);
      } else {
        errorMessage = l10n.of(context).failedToLoadAboutUs;
      }
    } catch (error) {
      errorMessage = l10n.of(context).somethingWentWrongPleaseTryAgain;
    }

    isLoading = false;
    notifyListeners();
  }
}
