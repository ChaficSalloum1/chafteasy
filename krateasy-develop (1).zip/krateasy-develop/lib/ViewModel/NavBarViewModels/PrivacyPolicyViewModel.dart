import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:kratEasyApp/API_CALLS/GlobalAPIUtils.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'dart:convert';
import '../../Models/PrivacyPolicyModel.dart';

class PrivacyPolicyViewModel extends ChangeNotifier {
  PrivacyPolicyModel? privacyPolicy;
  bool isLoading = false;
  String errorMessage = '';

  String baseURL = GlobalAPIUtils.getBaseUrl();
  String privacyPolicyURL = GlobalAPIUtils.getPrivacyPolicyUrl();

  Future<void> fetchPrivacyPolicy({required BuildContext context}) async {
    isLoading = true;
    errorMessage = '';
    notifyListeners();

    try {
      final response = await http.get(Uri.parse(baseURL + privacyPolicyURL));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        privacyPolicy = PrivacyPolicyModel.fromJson(data);
      } else {
        errorMessage = l10n.of(context).failedToLoadTermsConditions;
      }
    } catch (error) {
      errorMessage = l10n.of(context).somethingWentWrongPleaseTryAgain;
    }

    isLoading = false;
    notifyListeners();
  }
}
