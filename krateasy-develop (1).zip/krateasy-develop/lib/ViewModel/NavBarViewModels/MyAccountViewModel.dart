import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:kratEasyApp/GlobalUtils/app_navigation.dart';
import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/GlobalUtils/app_text_field.dart';
import 'package:kratEasyApp/Models/profile_model.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/repository/profile_repo.dart';
import 'package:kratEasyApp/services/local/local_keys.dart';
import 'package:kratEasyApp/services/local/local_service.dart';
import 'package:kratEasyApp/services/remote/remote_service.dart';
import 'package:kratEasyApp/services/remote/responce_helper.dart';
import 'package:provider/provider.dart';
import '../../API_CALLS/Helper.dart';
import '../DashboardViewModel.dart';

class MyAccountViewModel extends ChangeNotifier {
  String email = "";
  String mobileno = "";
  String name = "";
  String userImage = "";
  String skillSet = "";
  String countryCode = "";

  File? _image;

  File? get image => _image;
  String? imageStorePath;
  bool isUploadingImage = false;

  void updateImageUplaodPath(String url) {
    imageStorePath = url;
    // notifyListeners();
  }

  Future<void> pickImageCamera() async {
    isUploadingImage = true;
    Navigator.pop(NavigationService.context);
    final picker = ImagePicker();
    // Capture a photo.
    final pickedFile =
        await picker.pickImage(source: ImageSource.camera, imageQuality: 10);

    if (pickedFile != null) {
      // Crop the image
      final croppedFile = await ImageCropper().cropImage(
        sourcePath: pickedFile.path,
        aspectRatio: const CropAspectRatio(ratioX: 1, ratioY: 1),
        // Square aspect ratio
        compressFormat: ImageCompressFormat.jpg,
        compressQuality: 70,
        uiSettings: [
          AndroidUiSettings(
            toolbarTitle: 'Crop Image',
            toolbarColor: Colors.deepOrange,
            toolbarWidgetColor: Colors.white,
            initAspectRatio: CropAspectRatioPreset.original,
            lockAspectRatio: false,
          ),
          IOSUiSettings(
            title: 'Crop Image',
            aspectRatioLockEnabled: false,
          ),
        ],
      );

      if (croppedFile != null) {
        _image = File(croppedFile.path);
        ResponseHelper responseData =
            await RemoteService().uploadImage(_image, 'file', {});
        debugPrint("image >>>>>>>>>> ${responseData.body}");
        if (responseData.body != null) {
          var result = responseData.body;
          imageStorePath = result;
          print("imageStorePath is $imageStorePath");
          notifyListeners();
        } else {
          isUploadingImage = false;
          print("Error: Response body is not a valid map");
        }
      } else {
        isUploadingImage = false;
        print("Image cropping was cancelled");
      }
    } else {
      print("No image picked.");
    }
    isUploadingImage = false;
  }

  Future<void> pickImageGallery() async {
    isUploadingImage = true;
    Navigator.pop(NavigationService.context);
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 10,
    );

    if (pickedFile != null) {
      final String filePath = pickedFile.path.toLowerCase();
      if (filePath.endsWith('.png') ||
          filePath.endsWith('.jpg') ||
          filePath.endsWith('.jpeg')) {
        // Crop the image
        final croppedFile = await ImageCropper().cropImage(
          sourcePath: pickedFile.path,
          aspectRatio: const CropAspectRatio(ratioX: 1, ratioY: 1),
          // Square aspect ratio
          compressFormat: ImageCompressFormat.jpg,
          compressQuality: 70,
          uiSettings: [
            AndroidUiSettings(
              toolbarTitle: 'Crop Image',
              toolbarColor: Colors.deepOrange,
              toolbarWidgetColor: Colors.white,
              initAspectRatio: CropAspectRatioPreset.original,
              lockAspectRatio: false,
            ),
            IOSUiSettings(
              title: 'Crop Image',
              aspectRatioLockEnabled: false,
            ),
          ],
        );

        if (croppedFile != null) {
          _image = File(croppedFile.path);
          ResponseHelper responseData =
              await RemoteService().uploadImage(_image, "file", {});
          print("images >>>>>>>>>> ${responseData.body}");
          debugPrint("image >>>>>>>>>> ${responseData.body}");
          if (responseData.body != null) {
            var result = responseData.body;
            imageStorePath = result;
            notifyListeners();
          } else {
            isUploadingImage = false;
            print("Error: Response body is not a valid map");
          }
        } else {
          print("Image cropping was cancelled");
        }
      } else {
        // Show snackbar for invalid format
        ScaffoldMessenger.of(NavigationService.context).showSnackBar(
          SnackBar(
            content: Text("Only PNG, JPG, or JPEG formats are allowed."),
          ),
        );
      }
    } else {
      print("No image picked.");
    }
    isUploadingImage = false;
  }

  // Future<void> pickImageGallery() async {
  //   Navigator.pop(NavigationService.context);
  //   final picker = ImagePicker();
  //   final pickedFile =
  //       await picker.pickImage(source: ImageSource.gallery, imageQuality: 10);
  //   if (pickedFile != null) {
  //     _image = File(pickedFile.path);
  //     ResponseHelper responseData =
  //         await RemoteService().uploadImage(_image, "file", {});
  //     debugPrint("image >>>>>>>>>> ${responseData.body}");
  //     if (responseData.body != null) {
  //       var result = responseData.body;
  //       imageStorePath = result;
  //       notifyListeners();
  //     } else {
  //       print("Error: Response body is not a valid map");
  //     }
  //   } else {
  //     print("No image picked.");
  //   }
  // }

  // String header = S.of(context).interestedSports;
  String get logoPath => 'assets/icons/user.png';

  String getusername(BuildContext context) {
    return Provider.of<DashboardViewModel>(context, listen: false).userName;
  }

  void goBack(BuildContext context) {
    Navigator.pop(context);
  }

  void editProfile(
    BuildContext context,
  ) {
    Navigator.pushNamed(context, '/editprofile',
        arguments: {"countryCode": countryCode});
  }

  /// get profile data Apis handle
  bool isLoading = false;
  final ProfileRepo repo = ProfileRepo();
  ProfileModel profileModel = ProfileModel();

  List<Map<String, String>> selectedSportsAndSkills = [];

  Future<void> getProfileDataApi() async {
    isLoading = true;
    notifyListeners();
    try {
      final response = await repo.getProfileDataApi();
      if (response.status == true) {
        profileModel = ProfileModel.fromJson(response.body);
        mobileno = (profileModel?.mobileNumber ?? "").toString();
        countryCode = (profileModel?.countryCode ?? "").toString();
        name = (profileModel?.name ?? "").toString();
        userImage = (profileModel?.image ?? "").toString();
        email = (profileModel?.email ?? "").toString();
        skillSet = (profileModel?.skillSet ?? "").toString();
        debugPrint("name >>>>>>> ${profileModel?.name}");
        debugPrint("image url >>>> ${profileModel?.image}");
        LocalService.instance
            .setData(LocalKeys.instance.userName, profileModel?.name ?? "");
        LocalService.instance
            .setData(LocalKeys.instance.userId, profileModel?.id ?? "");
        LocalService.instance
            .setData(LocalKeys.instance.userImage, profileModel?.image ?? "");

        // Prefill sports & skills
        selectedSportsAndSkills = profileModel?.sports?.map((item) {
              return {
                'sportId': item.id.toString(),
                'skill': item.skillLevel ?? ""
              };
            }).toList() ??
            [];

        notifyListeners();
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e, stackTrace) {
      print("stackTrace : $stackTrace");
      showSnackbar(
          context: NavigationService.context,
          message: l10n
              .of(NavigationService.navigatorKey.currentContext!)
              .somethingWentWrongGetprofiledataapi);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  List<Map<String, String>>? formattedList = [];

  void addSportAndSkill(dynamic sportId, String skill) {
    final safeSportId = (sportId != null && sportId.toString().isNotEmpty)
        ? sportId.toString()
        : (Helper.sports.firstOrNull?.id ?? "");

    selectedSportsAndSkills.add({
      'sportId': safeSportId,
      'skill': skill.isNotEmpty ? skill : "Beginner"
    });

    formatSelectedSportsAndSkills();
    notifyListeners();
  }

  // void addSportAndSkill(dynamic sportId, String skill) {
  //   selectedSportsAndSkills.add({
  //     'sportId': sportId.isNotEmpty ? sportId : (Helper.sports.firstOrNull?.id),
  //     'skill': skill.isNotEmpty ? skill : "Beginner"
  //   });
  //   formatSelectedSportsAndSkills();
  //   notifyListeners();
  // }

  void updateSportAndSkill(int index, dynamic sportId, String skill) {
    selectedSportsAndSkills[index] = {
      'sportId': sportId.isNotEmpty ? sportId : (Helper.sports.firstOrNull?.id),
      'skill': skill.isNotEmpty ? skill : "Beginner"
    };
    formatSelectedSportsAndSkills();
    notifyListeners();
  }

  void removeSportAndSkill(int index) {
    printLog(
        "selectedSportsAndSkills Length After Before : ${selectedSportsAndSkills.length}");
    selectedSportsAndSkills.removeAt(index);
    printLog(
        "selectedSportsAndSkills Length After Remove : ${selectedSportsAndSkills.length}");
    notifyListeners();
  }

  void formatSelectedSportsAndSkills() {
    formattedList = selectedSportsAndSkills
        .map((item) => {
              'sport_id': item['sportId'] ?? '',
              'skill_level': item['skill'] ?? 'Beginner',
            })
        .toList();
    print({"sports": formattedList});
  } // void formatSelectedSportsAndSkills() {
  //   formattedList = selectedSportsAndSkills
  //       .map((item) =>
  //           {'sport_id': item['sportId']!, 'skill_level': item['skill']!})
  //       .toList();
  //   print({"sports": formattedList});
  // }

  Future<void> editMyAccount(
      {required String name,
      required String email,
      required String countryCode,
      required String phoneNumber,
      required String skillSet,
      required BuildContext context}) async {
    isLoading = true;
    notifyListeners();
    print("it runnn??1111");
    if (selectedSportsAndSkills.isEmpty) {
      if (formattedList == null ||
          formattedList!.isEmpty ||
          formattedList!.any((item) =>
              item['sport_id'] == null || item['sport_id'] == 'null')) {
        print("it runnn??222");
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(l10n.of(context).errorPleaseSelectSport),
          ),
        );
        isLoading = false;
        return;
      }
    }

    print("it runnn??333");

    formatSelectedSportsAndSkills();
    final requestBody = {
      "name": name,
      "email": email,
      "country_code": countryCode,
      "mobile_number": phoneNumber,
      "image": imageStorePath ?? "",
      "sports": formattedList,
      "skillSet": skillSet,
    };

    try {
      final response = await repo.editMyAccount(requestBody);
      if (response.status == true) {
        getProfileDataApi();

        showSnackbar(
            context: NavigationService.context,
            message: l10n
                .of(NavigationService.navigatorKey.currentContext!)
                .profileUpdateSuccessfully);
        Navigator.popUntil(
            NavigationService.context, ModalRoute.withName('/myAccount'));
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e) {
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context).somethingsWentWrongeditMyAccount);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }
}
