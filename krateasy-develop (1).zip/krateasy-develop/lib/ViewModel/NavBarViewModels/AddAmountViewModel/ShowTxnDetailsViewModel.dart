// import 'package:flutter/foundation.dart';

// class ShowTxnDetailsViewModel extends ChangeNotifier {
//   // double _transactionAmount = 1500.00;
//   String _transactionTime = "12:15 pm on Nov 04 2024";
//   String _transactionSource = "Apple Pay";
//   String _transactionId = "DDJHJNKLKPS6685465OJKIHUJ";

//   // double get transactionAmount => _transactionAmount;
//   String get transactionTime => _transactionTime;
//   String get transactionSource => _transactionSource;
//   String get transactionId => _transactionId;

//   void setTransactionDetails({
//     required double amount,
//     required String time,
//     required String source,
//     required String id,
//   }) {
//     // _transactionAmount = amount;
//     _transactionTime = time;
//     _transactionSource = source;
//     _transactionId = id;
//     notifyListeners();
//   }
// }
