// import 'package:flutter/material.dart';
// import '../../../API_CALLS/API/AddMoneyInWallet.dart';

// class AddAmountViewModel extends ChangeNotifier {
//   // double currentBalance = 0;
//   bool isLoading = false;
//   TextEditingController amountController = TextEditingController();

//   int? selectedAmount;

//   void setSelectedAmount(int amount) {
//     selectedAmount = amount;
//     amountController.text = amount.toString();
//     notifyListeners();
//   }

//   Future<bool> addMoney(BuildContext context) async {
//     int? amount = int.tryParse(amountController.text);
//     if (amount == null || amount <= 0) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text('Please enter a valid amount')),
//       );
//       return false;
//     }

//     isLoading = true;
//     notifyListeners();

//     try {
//       AddMoneyInWallet addMoneyService = AddMoneyInWallet();
//       final result = await addMoneyService.addMoney(amount, context);

//       if (result.success) {

        
//         // currentBalance = result.amount?.toDouble() ?? currentBalance;
//         // notifyListeners();
//         return true;
//       } else {
//         return false;
//       }
//     } catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text('An error occurred. Please try again.')),
//       );
//       return false;
//     } finally {
//       isLoading = false;
//       notifyListeners();
//     }
//   }
// }
