// import 'package:flutter/material.dart';

// class AmountAddedSuccessViewModel extends ChangeNotifier {
//   final String logoPath =
//       'assets/successImg/success.png'; // Change to your actual logo path
//   final String headText = "Payment Successful";
//   final String midText = "Your transaction is complete. ✅";

//   void backtoWallet(BuildContext context) {
//     Navigator.pushReplacementNamed(context, '/wallet');
//   }
// }
