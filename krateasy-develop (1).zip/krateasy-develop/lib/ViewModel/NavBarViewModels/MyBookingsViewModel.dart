
import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/Models/booking_details_model.dart';
import 'package:kratEasyApp/Models/my_booking_model.dart';
import 'package:kratEasyApp/Models/my_challenge_type_model.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/repository/booking_repository.dart';
import 'package:kratEasyApp/utils.dart';

import '../../services/local/local_keys.dart';


class MyBookingsViewModel extends ChangeNotifier {

 bool _ischange = false;
 bool get ischange =>_ischange;

 void setchange(bool value){
   _ischange = value;
   notifyListeners();
 }

    bool isLoading = false;
  TextEditingController ratingReviewController = TextEditingController();

  String? selectedDate; // Stores selected date
  String? selectedSport; // Stores last selected sport

  // List<String> sortItems = ["Option 1", "Option 2", "Option 3", "Option 4"];

  // List<String> sportsItems = ["Option 1", "Option 2", "Option 3", "Option 4"];

  // List<Map<String, dynamic>> openings = [
  //   {
  //     "club": "Edgbaston Priory Club",
  //     "court": "Court Name",
  //     "date": "09 Feb, 2025",
  //     "time": "09:00AM - 11:00AM",
  //     "location": "Edgbaston, Birmingham",
  //     "privacy": "Public",
  //     "image": "assets/icons/game.png",
  //     "icon": "assets/icons/game.png",
  //   },
  //   {
  //     "club": "Edgbaston Priory Club",
  //     "court": "Court Name",
  //     "date": "09 Feb, 2025",
  //     "time": "09:00AM - 11:00AM",
  //     "location": "Edgbaston, Birmingham",
  //     "privacy": "Private",
  //     "image": "assets/icons/game.png",
  //     "icon": "assets/icons/game.png",
  //   },
  //   {
  //     "club": "Edgbaston Priory Club",
  //     "court": "Court Name",
  //     "date": "09 Feb, 2025",
  //     "time": "09:00AM - 11:00AM",
  //     "location": "Edgbaston, Birmingham",
  //     "privacy": "Public",
  //     "image": "assets/icons/game.png",
  //     "icon": "assets/icons/game.png",
  //   },
  // ];

  // Navigation logic for skipping to featured facilities
  void applyFilter(BuildContext context) {
    Navigator.pushNamed(
      context,
      '/featuredFacilities', // Ensure '/featuredFacilities' is defined in your routes
    );
  }

  BookingRepository repository = BookingRepository();
  MyBookingModel myBookingModel = MyBookingModel();
  BookingDetailsModel bookingDetailsModel = BookingDetailsModel();

  Future<void> getMyBookingData({required String type,required BuildContext context}) async {
    isLoading = true;
    notifyListeners();
    try {
      final response = await repository.getMyBookingApi(type, returnData: true);
      if (response.status == true) {
        myBookingModel = MyBookingModel.fromJson(response.body);
        // favouriteCourtData = List<FavouriteCourtModel>.from(response.body.map((x) => FavouriteCourtModel.fromJson(x))).toList();

        printLog("Booking get length : ${myBookingModel.data?.docs?.length}");
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e, stackTrace) {
      print("stackTrace : $stackTrace");
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context).somethingsWentWronggetmybookingdata);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  bool isCancelBookingLoading = false;
  Future<void> cancelBooking({required String bookingId, required BuildContext context,bool? fromHome}) async {
    try {
      isCancelBookingLoading = true;
      if (fromHome == true) {
        final homeViewModel = Provider.of<HomeViewModel>(
            NavigationService.context,
            listen: false);
        homeViewModel.homeResponseModel.data?.upcomingBookings
            ?.removeWhere((item) => item.id == bookingId);
      } else {
        myBookingModel.data?.docs?.removeWhere((item) => item.sId == bookingId);
      }
      notifyListeners();

      final response = await repository.cancelBookingApi(bookingId);
      if (response.status == true) {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
        // myBookingModel = MyBookingModel.from(response.body);
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
        await getMyBookingData(context:context,type: l10n.of(context).upcoming);
      }
    } catch (e, stackTrace) {
      print("Error : $e");
      print("stackTrace : $stackTrace");
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context).somethingsWentWronggetmybookingdata);
      await getMyBookingData(context:context,type: l10n.of(context).upcoming);
    } finally {
      isCancelBookingLoading = false;
      notifyListeners();
    }
  }



  ///new cancel
 // Future<bool> cancelPayment({
 //   required String courtId,
 //   required String bookingid,
 // // optional auth token if you need it
 // }) async {
 //
 //   notifyListeners();
 //   final token =
 //   LocalService.instance.getData(LocalKeys.instance.accessToken);
 //   try {
 //     final uri = Uri.parse('https://backend.krateasy.gr/api/app/payment/cancel');
 //
 //     final headers = <String, String>{
 //       'Content-Type': 'application/json',
 //       if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
 //     };
 //
 //     final body = jsonEncode({
 //       "courtId": courtId, // <- API expects courtId
 //       "bookingId":bookingid,
 //     });
 //
 //     final res = await http.post(uri, headers: headers, body: body);
 //
 //     if (res.statusCode >= 200 && res.statusCode < 300) {
 //       // success
 //       final data = res.body.isNotEmpty ? jsonDecode(res.body) : {};
 //       print("data =>$data");
 //       notifyListeners();
 //       return true;
 //     } else {
 //       // failure
 //       final data = res.body.isNotEmpty ? jsonDecode(res.body) : {};
 //       print("data2 =>$data");
 //       // _error = data['message']?.toString() ?? 'Failed with status ${res.statusCode}';
 //       // _loading = false;
 //       notifyListeners();
 //       return false;
 //     }
 //   } catch (e) {
 //     print("===>");
 //     print(e.toString());
 //     // _error = e.toString();
 //     // _loading = false;
 //     notifyListeners();
 //     return false;
 //   }
 // }

 Future<bool> cancelPayment({
   required String courtId,
   required String bookingid,
 }) async {
   notifyListeners();

   final token = LocalService.instance.getData(LocalKeys.instance.accessToken);

   try {
     final uri = Uri.parse('https://backend.krateasy.gr/api/app/payment/cancel');

     final headers = <String, String>{
       'Content-Type': 'application/json',
       if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
     };

     final body = jsonEncode({
       "courtId": courtId,
       "bookingId": bookingid,
     });

     final res = await http.post(uri, headers: headers, body: body);

     // Try to decode body to inspect error/message fields
     Map<String, dynamic>? json;
     try {
       json = res.body.isNotEmpty ? jsonDecode(res.body) as Map<String, dynamic> : null;
     } catch (_) {
       json = null; // non-JSON or empty body
     }

     if (res.statusCode >= 200 && res.statusCode < 300) {
       // Success
       print("data => ${json ?? res.body}");
       notifyListeners();
       return true;
     } else {
       // Failure -> check for the specific backend error
       final errorText = (json?['error'] ?? json?['message'] ?? 'Failed with status ${res.statusCode}').toString();
       print("data2 => ${json ?? res.body}");

       if (errorText.toLowerCase().contains('no active payment intents')) {
         // Specific message from your backend -> show user-friendly snackbar
         Utils.toastMessage(

           "You can't cancel this match after the time has passed",

         );
         return false;
       } else {
         // Generic failure message
         Utils.toastMessage(
           'Cancel Failed',

         );
       }

       notifyListeners();
       return false;
     }
   } catch (e) {
     print("===>");
     print(e.toString());

     Utils.toastMessage(
       'Cancel Failed',


     );

     notifyListeners();
     return false;
   }
 }


//
  bool isRateBooking = false;
  Future<void> rateBooking({required BuildContext context,required
      String bookingId,required dynamic rate,required String message}) async {
    isRateBooking = true;
    try {
      final response = await repository.rateBookingApi(bookingId, {
        "user_id": NavigationService.navigatorKey.currentContext!
            .read<MyAccountViewModel>()
            .profileModel
            .id,
        "rate": rate,
        "message": message
      });
      if (response.status == true) {
        print("response.body is ${response.body}");
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
        notifyListeners();
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e, stackTrace) {
      print("stackTrace : $stackTrace");
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context).somethingsWentWronggetfavouritelistdata);
    } finally {
      isRateBooking = false;
      notifyListeners();
    }
  }

  bool isCancelChallengeLoading = false;
  // Future<void> cancelChallenge({required String challengeID,required BuildContext context, bool? fromHome}) async {
  //   try {
  //     isCancelChallengeLoading = true;
  //     notifyListeners();
  //     final response = await repository.cancelChallengeApi(challengeID);
  //     if (response.status == true) {
  //       showSnackbar(
  //           context: NavigationService.context,
  //           message: response.message.toString());
  //     } else {
  //       showSnackbar(
  //           context: NavigationService.context,
  //           message: response.message.toString());
  //       await getMyChallengeData( challengeType: "upcoming", context: context);
  //       await getBookingDetails(  bookingId: "upcoming",context: context);
  //
  //       notifyListeners();
  //     }
  //   } catch (e, stackTrace) {
  //     print("Error : $e");
  //     print("stackTrace : $stackTrace");
  //     showSnackbar(
  //         context: NavigationService.context,
  //         message: S.of(context).somethingsWentWronggetmychallengedata);
  //
  //     await getMyChallengeData(challengeType: "upcoming",context: context);
  //     notifyListeners();
  //   } finally {
  //     isCancelChallengeLoading = false;
  //     notifyListeners();
  //   }
  // }

  Future<bool> cancelChallenge({
    required String challengeID,
    required BuildContext context,
    bool? fromHome,
  }) async {
    try {
      isCancelChallengeLoading = true;
      notifyListeners();

      final response = await repository.cancelChallengeApi(challengeID);

      if (response.status == true) {
        showSnackbar(
          context: NavigationService.context,
          message: response.message.toString(),
        );
        return true; // ✅ SUCCESS
      } else {
        showSnackbar(
          context: NavigationService.context,
          message: response.message.toString(),
        );
        await getMyChallengeData(challengeType: "upcoming", context: context);
        await getBookingDetails(bookingId: "upcoming", context: context);
        notifyListeners();
        return false; // ❌ FAILED
      }
    } catch (e, stackTrace) {
      print("Error : $e");
      print("stackTrace : $stackTrace");
      showSnackbar(
        context: NavigationService.context,
        message: l10n.of(context).somethingsWentWronggetmychallengedata,
      );
      await getMyChallengeData(challengeType: "upcoming", context: context);
      notifyListeners();
      return false; // ❌ FAILED
    } finally {
      isCancelChallengeLoading = false;
      notifyListeners();
    }
  }

  String? bookingId;
  storeBookingId({required String booingId}) {
    bookingId = booingId;
    notifyListeners();
  }

  Future<void> getBookingDetails({required String bookingId,required  BuildContext context}) async {
    isLoading = true;
    notifyListeners();
    try {
      final response =
          await repository.getMyBookingApi(bookingId, returnData: true);
      if (response.status == true) {
        bookingDetailsModel = BookingDetailsModel.fromJson(response.body);

        // printLog("Booking Details Name: ${myBookingModel?.data?.docs?.length}") ;
        // notifyListeners();
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e, stackTrace) {
      print("stackTrace : $stackTrace");
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context).somethingsWentWronggetmybookingdata);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  MyChallengeTypeModel myChallengeData = MyChallengeTypeModel();
  MyChallengeTypeModel myChallengeDataComplete = MyChallengeTypeModel();
  Future<void> getMyChallengeData({required String challengeType,required BuildContext context})async {
    print("api runn ");
    isLoading = true;
    notifyListeners();
    try {
      final response =
          await repository.getMyChallengeData(challengeType, returnData: true);
      if (response.status == true) {
        if (challengeType == "completed") {
          myChallengeDataComplete =
              MyChallengeTypeModel.fromJson(response.body);
        } else if (challengeType == "upcoming") {
          myChallengeData = MyChallengeTypeModel.fromJson(response.body);
        }
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e, stackTrace) {
      print("Error : $e");
      print("stackTrace : $stackTrace");
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context).somethingsWentWrongtypeChallenge);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  /// Upcoming view Model
  ///

  // void navigatorToViewDetailsScreen(BuildContext context) {
  //   Navigator.pushNamed(context, '/viewCourtDetailsScreen');
  // }

  void navigatorToViewChallengeBookingScreen(BuildContext context) {
    Navigator.pushNamed(context, '/viewChallengeBookingUpcomingScreen');
  }

  void navigateToFeedsScreen(BuildContext context) {
    Navigator.pushNamed(context, "/feedsScreen");
  }

  // List<String> imageUrls = [
  //   "https://randomuser.me/api/portraits/men/1.jpg",
  //   "https://randomuser.me/api/portraits/women/2.jpg",
  //   "https://randomuser.me/api/portraits/men/3.jpg",
  //   "https://randomuser.me/api/portraits/women/4.jpg",
  //   "https://randomuser.me/api/portraits/men/5.jpg",
  //   "https://randomuser.me/api/portraits/women/6.jpg",
  //   "https://randomuser.me/api/portraits/men/7.jpg",
  // ];
}
