import 'package:flutter/material.dart';
import 'package:kratEasyApp/Models/wallet_Detail_Model.dart';

import '../../API_CALLS/API/TransactionDetailsAPI.dart';
import '../../Models/TransactionDetailsModel.dart';

class WalletViewModel extends ChangeNotifier {
  List<TransactionDetailsModel> transactions = [];
  WalletDetailModel? walletDetailModel;
  bool isLoading = true;
  String errorMessage = '';
  double totalAmount = 0.0;

  /// Navigates to add amount screen
  void addAmount(BuildContext context,amount) {
    Navigator.pushNamed(context, '/addAmount',arguments: {"amount":amount});
  }
  /// Navigates to widhdraw amount screen
  void withdrawAmount(BuildContext context,amount) {
    Navigator.pushNamed(context, '/withdrawAmount',arguments: {"amount":amount});
  }

  /// Navigates to all transactions screen
  void navigateToAllTxns(BuildContext context) {
    Navigator.pushNamed(context, '/allWalletTxn');
  }

  /// Set loading state
  void setLoading(bool value) {
    if (isLoading != value) {
      isLoading = value;
      notifyListeners();
    }
  }

  /// Set error message
  void setError(String message) {
    if (errorMessage != message) {
      errorMessage = message;
      notifyListeners();
    }
  }

  /// Set total amount
  void setTotalAmount(double value) {
    if (totalAmount != value) {
      totalAmount = value;
      notifyListeners();
    }
  }

  /// Set transaction list
  void setTransactions(List<TransactionDetailsModel> data) {
    transactions = data;
    notifyListeners();
  }

  /// Set Wallet detail data
  void setWalletDetail(WalletDetailModel data) {
    walletDetailModel = data;
    notifyListeners();
  }

  bool istxnLoading = true;
  void settxnLoading(bool value) {
    if (istxnLoading != value) {
      istxnLoading = value;
      notifyListeners();
    }
  }
  /// Fetch wallet transactions and update state
  Future<void> fetchTransactions() async {
    try {
      print("fetchingg");
      setLoading(true);
      settxnLoading(true);

      final data = await TransactionDetailsAPI.getWalletTransactions();
      setTransactions(data);
      setError('');

      final amount = data.isNotEmpty ? data.last.availableBalance ?? 0.0 : 0.0;
      setTotalAmount(amount);
    } catch (e) {
      setError(e.toString());
    } finally {
      setLoading(false);
      settxnLoading(false);
    }
  }

  /// Fetch wallet transactions and update state
  Future<void> fetchWalletDetail() async {
    try {
      setLoading(true);

      final data = await TransactionDetailsAPI.getWalletDetail();
      setWalletDetail(data);
    } catch (e) {
      print("Error of wallet detail api $e");
    } finally {
      setLoading(false);
    }
  }
}
