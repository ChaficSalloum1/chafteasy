// import 'package:flutter/cupertino.dart';

// class SuccessPaymentViewModel extends ChangeNotifier {
//   final String logoPath =
//       'assets/successImg/success.png'; // Change to your actual logo path
//   // final String headText = S.of(context).paymentSuccessful;
//   // final String midText = "Your transaction is complete.";
//   // final String lowText = "Enjoy your booking! ✅";
//   // final String lowText_2 = "KE01842785";

//   // void bookingDetails(BuildContext context) {
//   //   Navigator.pushNamed(context, '/sharePaymentLinkScreen');
//   // }
// }
