// import 'package:flutter/material.dart';

// class Friend {
//   final String name;
//   final String phone;
//   final String imagePath;

//   Friend({required this.name, required this.phone, required this.imagePath});
// }

// class FacilityAddFriendsViewModel extends ChangeNotifier {
//   // final List<Friend> _friendsList = [

//   //   Friend(
//   //     name: "Alexander Hipp",
//   //     phone: "+966 5653898",
//   //     imagePath: "assets/icons/emoji.png",
//   //   ),
//   //   Friend(
//   //     name: "Alexander Hipp",
//   //     phone: "+966 5653898",
//   //     imagePath: "assets/icons/emoji.png",
//   //   ),
//   //   Friend(
//   //     name: "Alexander Hipp",
//   //     phone: "+966 5653898",
//   //     imagePath: "assets/icons/emoji.png",
//   //   ),
//   //   Friend(
//   //     name: "Alexander Hipp",
//   //     phone: "+966 5653898",
//   //     imagePath: "assets/icons/emoji.png",
//   //   ),
//   //   Friend(
//   //     name: "Alexander Hipp",
//   //     phone: "+966 5653898",
//   //     imagePath: "assets/icons/emoji.png",
//   //   ),
//   //   Friend(
//   //     name: "Alexander Hipp",
//   //     phone: "+966 5653898",
//   //     imagePath: "assets/icons/emoji.png",
//   //   ),
//   //   Friend(
//   //     name: "Alexander Hipp",
//   //     phone: "+966 5653898",
//   //     imagePath: "assets/icons/emoji.png",
//   //   ),
//   // ];

//   // List<Friend> get friendsList => _friendsList;

//   // void addFriend(Friend friend) {
//   //   _friendsList.add(friend);
//   //   notifyListeners();
//   // }

//   // void removeFriend(int index) {
//   //   _friendsList.removeAt(index);
//   //   notifyListeners();
//   // }
// }
