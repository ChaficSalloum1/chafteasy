import 'package:flutter/cupertino.dart';

class CheckoutViewModel extends ChangeNotifier {
  bool isWalletSelected = false;

  void setWalletSelected(bool value) {
    isWalletSelected = value;
    notifyListeners();
  }

  void confirmPayment(BuildContext context) {
    Navigator.pushNamed(context, '/successPayment');
  }
}
