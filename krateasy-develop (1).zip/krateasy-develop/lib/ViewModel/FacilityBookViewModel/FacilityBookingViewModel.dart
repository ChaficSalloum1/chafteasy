// import 'package:flutter/cupertino.dart';

// class FacilityBookingViewModel extends ChangeNotifier {
//   // String? selectedCourt;
//   // DateTime selectedDate = DateTime.now();
//   // String? selectedTime;

//   // void addFriends(BuildContext context) {
//   //   Navigator.pushNamed(context, '/addFriends');
//   // }

//   // void checkOut(BuildContext context) {
//   //   Navigator.pushNamed(context, '/checkOut');
//   // }

//   // List<String> availableTimes = [
//   //   "08:00AM",
//   //   "09:00AM",
//   //   "10:00AM",
//   //   "11:00AM",
//   //   "12:00PM",
//   //   "01:30PM",
//   //   "02:30PM",
//   //   "03:30PM",
//   //   "04:30PM",
//   //   "06:00PM",
//   //   "07:00PM",
//   //   "08:00PM",
//   // ];

//   bool isPublic = true;

//   // void selectTime(String time) {
//   //   selectedTime = time;
//   //   notifyListeners();
//   // }
// }
