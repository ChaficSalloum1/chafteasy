// import 'package:flutter/cupertino.dart';
// import 'package:share_plus/share_plus.dart';

// class BookingDetailsViewModel extends ChangeNotifier {
//   final String paymentLink = "KratEasy.com/LHYN20568231";
//   final int totalPlayers = 5;
//   final String timeLeft = "1hr 23 mins left";
//   final double totalPaid = 20.00;
//   final double totalLeft = 0;
//   // final List<Player> players = [
//   //   Player(name: "You", amountPaid: 5, imageUrl: "assets/icons/men.png"),
//   //   Player(name: "John ", amountPaid: 5, imageUrl: "assets/icons/men.png"),
//   //   Player(name: "Craig", amountPaid: 5, imageUrl: "assets/icons/men.png"),
//   //   Player(name: "Latisha", amountPaid: 5, imageUrl: "assets/icons/men.png"),
//   // ];

//   void shareFacility(
//     BuildContext context,
//     String facilityName,
//     String facilityUrl,
//   ) {
//     final String shareText = 'Check out $facilityName: $facilityUrl';
//     Share.share(shareText);
//   }

//   void gotoHome(BuildContext context) {
//     Navigator.pushNamed(context, '/dashboard');
//   }
// }

// class Player {
//   final String name;
//   final double amountPaid;
//   final String imageUrl;

//   Player({
//     required this.name,
//     required this.amountPaid,
//     required this.imageUrl,
//   });
// }
