import 'package:flutter/material.dart';

class ResetPasswordSuccessViewModel extends ChangeNotifier {
  final String logoPath = 'assets/successImg/success.png'; // Change to your actual logo path
  // final String headText = ;
  // final String midText = ;
  // final String lowText = ;

  // final String lowText_2 = ;

  void backtoLogin(BuildContext context) {
    Navigator.pushReplacementNamed(context, '/login');
  }
}
