import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_contacts/properties/address.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:kratEasyApp/EntranceScreens/select_Location_Manually_Screen.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../services/local/local_keys.dart';

class MyLocationViewModel extends ChangeNotifier {
  TextEditingController _locationController = TextEditingController();
  bool _isLoading = false;
  bool _isLoadingManually = false;
  bool get isLoading => _isLoading;
  bool get isLoadingManually => _isLoadingManually;
  TextEditingController get locationController => _locationController;

  void searchCourts(BuildContext context) {
    Navigator.pushNamed(context, '/searchCourts');
  }

  void setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  // void setManualLoading(bool loading) {
  //   _isLoadingManually = loading;
  //   notifyListeners();
  // }
  Future<void> getCurrentLocation({required BuildContext context}) async {
    try {
      setLoading(true);

      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Location services are disabled.")));
        setLoading(false);
        return;
      }
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Location permission denied.")));
          setLoading(false);
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Location permissions are permanently denied. Please enable them in settings.")));
        setLoading(false);
        return;
      }

      Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);

      List<Placemark> placemarks = await placemarkFromCoordinates(position.latitude, position.longitude);

      if (placemarks.isNotEmpty) {
        Placemark place = placemarks.first;


        String   address = [
          if (place.street != null && place.street!.isNotEmpty) place.street,
          if (place.subLocality != null && place.subLocality!.isNotEmpty)
            place.subLocality,
          if (place.locality != null && place.locality!.isNotEmpty)
            place.locality,
          if (place.administrativeArea != null &&
              place.administrativeArea!.isNotEmpty)
            place.administrativeArea,
          if (place.postalCode != null && place.postalCode!.isNotEmpty)
            place.postalCode,
          if (place.country != null && place.country!.isNotEmpty) place.country,
        ].whereType<String>().join(', ');

        // String address = "${place.street}, ${place.locality}, ${place.country}";

        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setString('saved_location', address);
        await prefs.setDouble('current_lat', position.latitude);
        await prefs.setDouble(
          'current_long',
          position.longitude,
        );
        print("lat ....${position.latitude}");
        print("long  ....${position.longitude}");
        LocalService.instance.setData(LocalKeys.instance.currentLocation, address);
        _locationController.text = address;
        setLoading(false);
        notifyListeners();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("No address found.")));
        setLoading(false);
      }
    } catch (e) {
      print("Error: $e");
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Failed to get location: $e")));
      setLoading(false);
    }
  }

  // void setLoading(bool loading) {
  //   _isLoading = loading;
  //   notifyListeners();
  // }

  setLocation(address) {
    _locationController.text = address;

    notifyListeners();
  }

  // Get Current Location
  // Future<void> getCurrentLocation({required BuildContext context}) async {
  //   if (_isLoading) return; // Prevent multiple clicks while loading
  //
  //   try {
  //     setLoading(true);
  //
  //     bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
  //     if (!serviceEnabled) {
  //       ScaffoldMessenger.of(context).showSnackBar(
  //           SnackBar(content: Text(S.of(context).locationServicesAreDisabled)));
  //       setLoading(false);
  //       return;
  //     }
  //     LocationPermission permission = await Geolocator.checkPermission();
  //     if (permission == LocationPermission.denied) {
  //       permission = await Geolocator.requestPermission();
  //       if (permission == LocationPermission.denied) {
  //         ScaffoldMessenger.of(context).showSnackBar(
  //             SnackBar(content: Text(S.of(context).locationPermissionDenied)));
  //         setLoading(false);
  //         return;
  //       }
  //     }
  //
  //     if (permission == LocationPermission.deniedForever) {
  //       ScaffoldMessenger.of(context).showSnackBar(SnackBar(
  //           content: Text(S
  //               .of(context)
  //               .locationPermissionsArePermanentlyDeniedPleaseEnableThemInSettings)));
  //       setLoading(false);
  //       return;
  //     }
  //
  //     Position position = await Geolocator.getCurrentPosition(
  //         desiredAccuracy: LocationAccuracy.best);
  //
  //     List<Placemark> placemarks =
  //         await placemarkFromCoordinates(position.latitude, position.longitude);
  //
  //     if (placemarks.isNotEmpty) {
  //       Placemark place = placemarks[0];
  //       String address = [
  //         if (place.street != null && place.street!.isNotEmpty) place.street,
  //         if (place.subLocality != null && place.subLocality!.isNotEmpty)
  //           place.subLocality,
  //         if (place.locality != null && place.locality!.isNotEmpty)
  //           place.locality,
  //         if (place.administrativeArea != null &&
  //             place.administrativeArea!.isNotEmpty)
  //           place.administrativeArea,
  //         if (place.postalCode != null && place.postalCode!.isNotEmpty)
  //           place.postalCode,
  //         if (place.country != null && place.country!.isNotEmpty) place.country,
  //       ].whereType<String>().join(', ');
  //       // String address = "${place.street}, ${place.locality}, ${place.country}";
  //
  //       SharedPreferences prefs = await SharedPreferences.getInstance();
  //       await prefs.setString('saved_location', address);
  //       await prefs.setDouble('current_lat', position.latitude);
  //       await prefs.setDouble(
  //         'current_long',
  //         position.longitude,
  //       );
  //       print("lat ....${position.latitude}");
  //       print("long  ....${position.longitude}");
  //       LocalService.instance
  //           .setData(LocalKeys.instance.currentLocation, address);
  //       _locationController.text = address;
  //       setLoading(false);
  //       notifyListeners();
  //     } else {
  //       ScaffoldMessenger.of(context).showSnackBar(
  //           SnackBar(content: Text(S.of(context).noAddressFound)));
  //       setLoading(false);
  //     }
  //   } catch (e) {
  //     print("Error: $e");
  //     ScaffoldMessenger.of(context)
  //         .showSnackBar(SnackBar(content: Text("Failed to get location: $e")));
  //     setLoading(false);
  //   }
  // }

  // void setLoading(bool loading) {
  //   _isLoading = loading;
  //   notifyListeners();
  // }

  // setLocation(address) {
  //   _locationController.text = address;
  //
  //   notifyListeners();
  // }

//get location manually
  Future<void> getAndNavigateToMapScreen(
      BuildContext context, bool fromSearch) async {
    if (_isLoadingManually) return;

    try {
      setLoadingforManualLoc(true);

      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(l10n.of(context).locationServicesAreDisabled)),
        );
        setLoadingforManualLoc(false);
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(l10n.of(context).locationPermissionDenied)),
          );
          setLoadingforManualLoc(false);
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              l10n
                  .of(context)
                  .locationPermissionPermanentlyDeniedPleaseEnableItFromSettings,
            ),
          ),
        );
        setLoadingforManualLoc(false);
        return;
      }

      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.best,
      );

      // 👇 Await navigation to ensure loading flag is held
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => SelectLocationManuallyScreen(
            fromSearch: fromSearch,
            initialLat: position.latitude,
            initialLng: position.longitude,
          ),
        ),
      ); // Navigator.push(
      //   context,
      //   MaterialPageRoute(
      //     builder: (_) => SelectLocationManuallyScreen(
      //       fromSearch: fromSearch,
      //       initialLat: position.latitude,
      //       initialLng: position.longitude,
      //     ),
      //   ),
      // );
    } catch (e) {
      debugPrint("Map Launch Error: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to open map: $e")),
      );
    } finally {
      setLoadingforManualLoc(false);
    }
  }

//set loading for manual location
  void setLoadingforManualLoc(bool loading) {
    _isLoadingManually = loading;
    notifyListeners();
  }
}
