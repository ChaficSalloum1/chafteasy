import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../API_CALLS/API/SportsListAPI.dart';
import '../../API_CALLS/Helper.dart';
import '../../Models/SportList.dart';
import 'SearchCourtViewModel.dart';

class ChooseSportsViewModel extends ChangeNotifier {
  List<SportList> sports = [];
  final SportsListAPI _api = SportsListAPI();
  bool _isLoading = false;
  bool get isLoading => _isLoading;
  Future<void> fetchSports() async {
    try {
      setLoading(true);

      sports = await _api.fetchSports();
      Helper.sports = sports; // Save globally
      notifyListeners();
    } catch (e) {
      setLoading(false);

      print(e);
    } finally {
      setLoading(false);
    }
  }

  String? selectedSport;

  void selectSport(String sportName, BuildContext context) {
    Provider.of<SearchCourtViewModel>(context, listen: false).selectedSport =
        sportName;
    notifyListeners();
    Navigator.pushNamed(context, '/myLocation', arguments: sportName);
  }

  void setLoading(bool loading) {
    _isLoading = loading;
    // notifyListeners();
  }
}
