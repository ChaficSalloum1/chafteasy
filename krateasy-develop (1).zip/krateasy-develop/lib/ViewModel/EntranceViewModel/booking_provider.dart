import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:http/http.dart' as http;
import 'package:kratEasyApp/API_CALLS/GlobalAPIUtils.dart';
import 'package:kratEasyApp/Models/contact_model.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/GlobalUtils/app_routes.dart';
import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/Models/SlotsResponseModel.dart';
import 'package:kratEasyApp/Models/complete_Challenge_Detail_Model.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/repository/booking_repository.dart';
import 'package:kratEasyApp/services/local/local_keys.dart';
import 'package:kratEasyApp/utils.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../paymentprovider.dart';

class BookingProvider extends ChangeNotifier {
  TextEditingController phoneController = TextEditingController();
  TextEditingController otpController = TextEditingController();
  TextEditingController countryCodeController = TextEditingController();
  String countryCode = "44";
  String selectedCountryFlag = "🇬🇧"; // Default flag

  String _ownerid = "";

  String get ownerid => _ownerid;

  void setownerid(String id) {
    _ownerid = id;

    notifyListeners();
    print("ownerid=>$ownerid");
  }

  void updateCountryCode(String code) {
    countryCode = code;
    notifyListeners();
  }

  void init() {
    countryCodeController.text = "44";
    updateCountryCode("44");
    // selectedCountry = CountryPickerUtils.getCountryByPhoneCode('44');
  }

  void setLoadingSlots(bool value) {
    isLoadingSlotsNew = value;
    isLoadingSlotsNew1 = value;
    notifyListeners();
  }

  double bookingPrice = 0.0;
  bool isChecked = false;
  double perPersonPrice = 0.0;
  String? bookingId;
  String? ID;
  var coourtId = NavigationService.navigatorKey.currentContext!
      .read<FacilitiesViewModel>()
      .selectedCourt
      .id;
  List<String> availableTimes = [];
  String requestDate = '';
  String courtName = '';
  String courtId = "";

  // String countryCode = '';

  ///----------------------   court Id
  String selectedCourtId = '';

  void storeCourtId({required String cortId}) {
    selectedCourtId = cortId;
    // notifyListeners();
  }

  updateLoadingStatus(
      {required BuildContext context, required String navigation}) {
    isLoading = true;
    notifyListeners();
    Future.delayed(Duration(seconds: 1), () {
      isLoading = false;
      notifyListeners();
      Navigator.pushNamed(context, navigation);
    });
  }

  int totalHours = 0;

  bool isRecorded = false;

  void setRecorded(bool value) {
    isRecorded = value;
    notifyListeners();
  }

  bool isSplit = true;

  // void setSplit(bool value) {
  //   if (value == false) {
  //     removeAllUserData();
  //   }
  //   isSplit = value;
  //   print("split $value");
  //   notifyListeners();
  // }
  void setSplit(bool value) {
    if (!value) {
      removeAllUserData();
    }
    appliedDiscountAmount = null; // Also reset here if split is off
    applied = false;
    isPromoApplied = false;
    promoCodeController.clear();
    isSplit = value;

    notifyListeners();
  }

  String baseURL = GlobalAPIUtils.getBaseUrl();

  void navigateToChallengeSuccess(BuildContext context) {
    Navigator.pushNamed(context, '/successPayment');
  }

  void navigateToGuestPaymentScreen({
    required BuildContext context,
    required String sessionid,
    bool? fromGuest,
    String? amount,
    String? courtId,
    String? requestDate,
    List? availableTimes,
    List? selectedSlots,
    String? sportId,
  }) {
    Map<String, dynamic> args = {
      "fromGuest": fromGuest,
      "amount": amount ?? "0.0",
      "courtId": courtId,
      "requestDate": requestDate,
      "availableTimes": availableTimes,
      "selectedSlots": selectedSlots,
      "sportId": sportId,
      "checkoutSessionId": sessionid,
    };
    print("args $args");
    Navigator.pushNamed(context, RouteNames.guestPayment, arguments: {
      "fromGuest": fromGuest,
      "sessionid": sessionid,
      "amount": amount ?? "0.0",
      "courtId": courtId,
      "requestDate": requestDate,
      "availableTimes": availableTimes,
      "selectedSlots": selectedSlots,
      "sportId": sportId,
    });
  }

  // void navigateToGuestPaymentSuccessScreen(BuildContext context) {
  //   Navigator.pushNamed(context, "/guestSuccessPaymentScreen");
  // }

  @override
  void dispose() {
    print("DISPOSING OTP CONTROLLER");
    otpController.dispose();
    super.dispose();
  }

  void navigateToGuestSuccessPaymentScreen(
      {required BuildContext context,
      required String id,
      // required String time,
      required String bookingID,
      required bool isGuestBooking,
      required String amt}) {
    Navigator.pushNamed(
      context,
      "/guestSuccessPaymentScreen",
      arguments: {
        'bookingId': bookingID,
        "id": id,
        "isGuestBooking": isGuestBooking,
        "amount": amt,
        // "time":time
      },
    );
  }

  void navigateToGuestSharePaymentScreen(
      {required BuildContext context,
      required String amount,
      // required String time,
      required bool isChallenge,
      CompleteChallengeDetailModel? joinChallengeModelData}) {
    Navigator.pushNamed(context, "/guestSharePaymentScreen", arguments: {
      "amount": amount,
      "data": joinChallengeModelData,
      "ischallenge": isChallenge,
      // "time":time
    });
  }

  void navigateToAddedFriendsScreen(BuildContext context) {
    Navigator.pushNamed(context, "/addedFriendsScreen");
  }

  /// guest success payment
  final String logoPath =
      'assets/successImg/success.png'; // Change to your actual logo path
  // final String headText = S.of(context).paymentSuccessful;
  // final String midText =;
  // final String lowText =;

  //final String lowText_2 = "KE01842785";

  String? otpErrorMessage; // = "Failed to send OTP. Please try again";

  // void bookingDetails(BuildContext context) {
  //   Navigator.pushNamed(context, '/sharePaymentLinkScreen');
  // }

  /// guest payment
  bool isWalletSelected = true;

  void setWalletSelected(bool value) {
    isWalletSelected = value;
    notifyListeners();
  }

  String? selectedPaymentMethod;

  void setSelectedPaymentMethod(String? method) {
    selectedPaymentMethod = method;
    notifyListeners();
  }

  ///
  ///
  ///
  ///

//today
//   void updateSelectedSlot1(AvailableSlots slot, BuildContext context) {
//     // 1. figure out this slot’s index in the current list
//     final idx = availableSlots.indexWhere((s) => s.sId == slot.sId);
//     if (idx < 0) return;
//
//     // 2. turn selectedSlotIds into sorted indices
//     List<int> selIdx = selectedSlotIds
//         .map((id) => availableSlots.indexWhere((s) => s.sId == id))
//         .where((i) => i >= 0)
//         .toList()
//       ..sort();
//
//     bool isSelected = selectedSlotIds.contains(slot.sId);
//
//     // helper to show exactly one snackbar
//     void showMsg(String msg) {
//       ScaffoldMessenger.of(context)
//         ..hideCurrentSnackBar()
//         ..showSnackBar(SnackBar(content: Text(msg)));
//     }
//
//     if (isSelected) {
//       // only allow deselect if it’s at the start or end
//       int first = selIdx.first;
//       int last = selIdx.last;
//       if (idx == first || idx == last) {
//         selectedSlotIds.remove(slot.sId);
//       } else {
//         showMsg(S.of(context).youCanOnlyDeselectTheStartOrEndSlot);
//         return;
//       }
//     } else {
//       // only allow select if empty or immediately adjacent
//       if (selIdx.isEmpty || idx == selIdx.first - 1 || idx == selIdx.last + 1) {
//         selectedSlotIds.add(slot.sId!);
//       } else {
//         showMsg(S.of(context).pleaseSelectSlotsInSequence);
//         return;
//       }
//     }
//     // 🔥 Update total slot price before calculating price per person
//     slotPrice = selectedSlotIds
//         .map((id) =>
//             availableSlots
//                 .firstWhere(
//                   (s) => s.sId == id,
//                   orElse: () => AvailableSlots(price: 0.0), // ✅ Return dummy
//                 )
//                 .price ??
//             0.0)
//         .fold(0.0, (a, b) => a + b);
//     // slotPrice = selectedSlotIds
//     //     .map((id) => availableSlots.firstWhere((s) => s.sId == id).price ?? 0.0)
//     //     .fold(0.0, (a, b) => a + b);
//     // Recompute any totals, hours...
//     calculatePrice();
//     calculateTotalPrice();
//     calculateTotalHours();
//     notifyListeners();
//   }
  void updateSelectedSlot1(AvailableSlots slot, BuildContext context) {
    final idx = availableSlots.indexWhere((s) => s.sId == slot.sId);
    if (idx < 0) return;

    bool isSelected = selectedSlotIds.contains(slot.sId);
    log("messaged=>${selectedSlotIds.contains(slot.sId)}");
    print("messaged=>${selectedSlotIds.contains(slot.sId)}");
    debugPrint("messaged=>${selectedSlotIds.contains(slot.sId)}");
    if (isSelected) {
      selectedSlotIds.remove(slot.sId);
    } else {
      selectedSlotIds.add(slot.sId!);
    }

    log("selectedSlotIds=>${selectedSlotIds}");
    print("selectedSlotIds=>${selectedSlotIds}");
    debugPrint("selectedSlotIds=>${selectedSlotIds}");
    notifyListeners();
    // Update total slot price
    slotPrice = selectedSlotIds
        .map((id) =>
            availableSlots
                .firstWhere(
                  (s) => s.sId == id,
                  orElse: () => AvailableSlots(price: 0.0),
                )
                .price ??
            0.0)
        .fold(0.0, (a, b) => a + b);

    log("slotprice=>$slotPrice");
    debugPrint("slotprice=>$slotPrice");
    print("slotprice=>$slotPrice");

    // Recompute derived values
    try {
      log("in truy");
      debugPrint("in truy");
      print("in truy");
      calculatePrice();
      calculateTotalPrice();
      calculateTotalHours();
    } catch (e) {
      log("Error in 1 ${e.toString()}");
    } finally {
      notifyListeners();
    }
  }

  void calculateTotalPrice() {
    try {
      double tempPrice = 0.0;

      for (var slot in availableSlots) {
        if (selectedSlotIds.contains(slot.sId)) {
          tempPrice += (slot.price ?? 0);
        }
      }

      slotPrice = tempPrice;
      log("slotPrice =>$slotPrice");
      print("slotPrice =>$slotPrice");
      debugPrint("slotPrice =>$slotPrice");
    } catch (e) {
      // TODO
      log("Error calculateTotalPrice ${e.toString()}");
    }
    notifyListeners();
  }

  void calculateTotalHours() {
    // Assuming each slot is 1 hour, so the total hours is the length of selected slots
    totalHours = selectedSlotIds.length;
  }

  List<String> selectedSlotIds = [];
  List<AvailableSlots> availableSlots = [];

  // double totalPrice = 0.0;

  SlotsResponseModel slotsResponseModel = SlotsResponseModel(); // your model
  bool isLoadingSlotsNew = false;
  bool isLoadingSlotsNewBooking = false;

  // Call when API data comes

  void setAvailableSlots1(
      {required List<AvailableSlots> slots, List<String>? preSelectedIds}) {
    availableSlots = slots;
    selectedSlotIds = preSelectedIds ?? [];
    log("selectedSlotIds=>$selectedSlotIds");
    debugPrint("selectedSlotIds=>$selectedSlotIds");
    log("selectedSlotIds=>$selectedSlotIds");
    // Calculate initial total price and hours
    calculateTotalPrice();
    // calculateTotalHours();
    notifyListeners();
  }

// void updateSelectedSlot1(AvailableSlots? slot) {
//   if (slot == null) return;

//   // First update selection
//   if (selectedSlotIds.contains(slot.sId)) {
//     selectedSlotIds.remove(slot.sId);
//   } else {
//     selectedSlotIds.add(slot.sId ?? "");
//   }

//   selectedSlotForBooking = slot;

//   // Now recalculate
//   calculateTotalPrice();
//   notifyListeners();
// }

  // void calculateTotalPrice() {
  //   double tempPrice = 0.0;

  //   for (var slot in availableSlots) {
  //     if (selectedSlotIds.contains(slot.sId)) {
  //       tempPrice += (slot.price ?? 0);
  //     }
  //   }

  //   totalPrice = tempPrice;
  // }

  // Optional - if you need clear
  void clearSlots() {
    selectedSlotIds.clear();
    slotPrice = 0.0;
    notifyListeners();
  }

  /// guest booking
  void addFriends() {}
  int selectTimeGrid = 0;

  void selectedTimeGrid(int index) {
    selectTimeGrid = index;
    notifyListeners();
  }

  void setcheck() {
    isChecked = false;
    notifyListeners();
  }

  void updateCheckedButton() {
    isChecked = !isChecked;
    notifyListeners(); // Notify UI to rebuild
  }

  DateTime selectedDate = DateTime.now();

  Future<void> updateSelectedDate(
      {required DateTime date, required BuildContext context}) async {
    selectedDate = date;
    notifyListeners();
    await getSlots(context: context);
  }

  bool isLoadingSlotsNew1 = false;

  Future<void> updateSelectedDate2(DateTime date) async {
    try {
      isLoadingSlotsNew1 = true;
      selectedSlotIds.clear(); // ✅ Clears previous selection
      selectedDate = date;
      isLoadingSlotsNew1 = false;
      notifyListeners();

      // 🔁 This should update `availableSlots` internally
    } catch (e) {
      print("errror");
    } finally {
      isLoadingSlotsNew1 = false;
      notifyListeners();
    }
  }

// Future<void> updateSelectedDate1({required DateTime date,required selectedFacilityId,required selectedCourtId}) async {
//   selectedDate = date;
//   isLoadingSlotsNew = true;
//   selectedSlotIds.clear(); // 🔁 Clear previous selection
//   notifyListeners();

//   try {
//     // Re-fetch slots for this date
//     final slots = await getSlotsNew(
//       courtId: selectedCourtId,
//       facilityId: selectedFacilityId,
//       date: DateFormat('yyyy-MM-dd').format(date),
//     );

//     setAvailableSlots1(slots, []); // 🔁 No preselection
//   } catch (e) {
//     // handle error or show snackbar if needed
//     print("Error fetching slots: $e");
//   } finally {
//     isLoadingSlotsNew = false;
//     notifyListeners();
//   }
// }

  List<String> selectedSlots = [];

  void clearSelectedSlots() {
    selectedTimeIndices.clear();
    selectedSlotStrings.clear();
    notifyListeners();
  }

  final List<String> allTimeSlots = [
    "12:00 AM",
    "01:00 AM",
    "02:00 AM",
    "03:00 AM",
    "04:00 AM",
    "05:00 AM",
    "06:00 AM",
    "07:00 AM",
    "08:00 AM",
    "09:00 AM",
    "10:00 AM",
    "11:00 AM",
    "12:00 PM",
    "01:00 PM",
    "02:00 PM",
    "03:00 PM",
    "04:00 PM",
    "05:00 PM",
    "06:00 PM",
    "07:00 PM",
    "08:00 PM",
    "09:00 PM",
    "10:00 PM",
    "11:00 PM"
  ];
  List<int> selectedTimeIndices = [];
  List<String> selectedSlotStrings = [];

  void updateBookingDetails(
    List<String> times,
    double price,
    String name,
    String courtId,
    String date,
    List<String> selectedSlotIds,
  ) {
    try {
      // Parse the incoming date with the correct format
      final parsedDate = DateFormat('dd-MM-yyyy').parse(date);

      // Convert it to the desired format
      final formattedDate = DateFormat('yyyy-MM-dd').format(parsedDate);

      // Store the passed details
      availableTimes = times;
      slotPrice = price;
      courtName = name;
      courtId = courtId;
      requestDate = formattedDate;
      selectedDate = parsedDate;

      // Store the selected slot IDs
      selectedSlots = selectedSlotIds;

      calculatePrice();
      // calculatePerPersonPrice();
      totalHours = times.length; // Each slot is assumed to be 1 hour
      notifyListeners();
    } catch (e) {
      print('Error parsing date: $e');
    }
    // selectedSlotStrings = times;
    // selectedTimeIndices = [];

    // for (int i = 0; i < allTimeSlots.length; i++) {
    //   if (times.contains(allTimeSlots[i])) {
    //     selectedTimeIndices.add(i);
    //   }
    // }

    // notifyListeners();
  }

  void handleSlotTap(int index, BuildContext context) {
    if (selectedTimeIndices.contains(index)) {
      selectedTimeIndices.remove(index);
    } else {
      if (selectedTimeIndices.isEmpty) {
        selectedTimeIndices.add(index);
      } else {
        final sorted = [...selectedTimeIndices]..sort();
        final min = sorted.first;
        final max = sorted.last;

        if (index == min - 1 || index == max + 1) {
          selectedTimeIndices.add(index);
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
                content: Text(l10n.of(context).pleaseSelectSlotsInSequence)),
          );
          return;
        }
      }
    }
    notifyListeners();
  }

  double myPrice = 0.0;
  double friendsPrice = 0.0;
  double slotPrice = 0.0;

  calculatePrice() {
    try {
      int totalFriends = userData.length;
      if (totalFriends > 0) {
        friendsPrice = slotPrice / (totalFriends + 1);
      } else {
        friendsPrice = slotPrice;
      }
      log("calcule $friendsPrice");
    } catch (e) {
      // TODO
      log("Error in 2 ${e.toString()}");
    }
    notifyListeners();
  }

  List<String> getSelectedTimeStrings() {
    return selectedTimeIndices.map((i) => allTimeSlots[i]).toList();
  }

  List<ContactModel> userData = [];

  void addUserData({required ContactModel user}) {
    if (!userData.any((element) => element.id.contains(user.id))) {
      userData.add(user);

      calculatePrice(); // Calculate price per person
      // calculatePerPersonPrice(); // Recalculate price
      notifyListeners(); // Notify UI
    }
  }

  // void removeAllUserData() {
  //   userData.clear();
  //   notifyListeners(); // Notify UI
  // }
  void removeAllUserData() {
    userData.clear();
    appliedDiscountAmount = null; // Clear the discount
    calculatePrice();
    notifyListeners(); // Notify UI
  }

  // void removeUserData({required ContactModel user}) {
  //   userData.remove(user);

  //   calculatePrice(); // Calculate price per person
  //   // calculatePerPersonPrice(); // Recalculate price
  //   notifyListeners();
  // }
  void removeUserData(
      {required ContactModel user, required BuildContext context}) {
    userData.remove(user);
    calculatePrice();

    if (userData.isEmpty) {
      appliedDiscountAmount = null; // Clear the discount if no users left
    }

    notifyListeners();
  }

  Future<void> getContacts({required BuildContext context}) async {
    if (await FlutterContacts.requestPermission()) {
      List<Contact> contactList = await FlutterContacts.getContacts(
          withProperties: true, withPhoto: true);
      contacts = contactList;
      searchContacts = contactList;
    } else {
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context).contactsPermissionIsRequired);
    }
    notifyListeners();
  }

  List<Contact> contacts = [];
  List<Contact> searchContacts = [];

  void searchContactList(String value) {
    if (value.trim().isEmpty) {
      searchContacts = List.from(contacts);
    } else {
      searchContacts = contacts
          .where((contact) => (contact.displayName ?? '')
              .toLowerCase()
              .contains(value.toLowerCase()))
          .toList();
    }
    notifyListeners();
  }

  Map<String, dynamic> generateBookingData2() {
    double perPersonAmount = perPersonPrice;
    // Generate startTime and endTime for each slotTime
    List<String> startTimes = [];
    List<String> endTimes = [];

    // final slots = slotsResponseModel?.data?.availableSlots ?? [];
    //
    // for (var slot in slots) {
    //   try {
    //     String time = slot.startTime ?? "";
    //     DateTime slotDateTime = DateFormat('h:mm a').parse(time);
    //     String endTime = DateFormat('h:mm a').format(slotDateTime.add(Duration(hours: 1)));
    //
    //     startTimes.add(time);
    //     endTimes.add(endTime);
    //   } catch (e) {
    //     print("Failed to parse slot time: $e");
    //   }
    // }
    startTimes.add(selectedSlotForBooking?.startTime ?? "");
    endTimes.add(selectedSlotForBooking?.endTime ?? "");

    // If you want to join all start times and end times into a single string
    String startTimesString = startTimes.join(', ');
    String endTimesString = endTimes.join(', ');
    String formattedDate = selectedDate != null
        ? DateFormat('dd-MM-yyyy').format(selectedDate!)
        : "";
    final facilityProvider = Provider.of<FacilitiesViewModel>(
        NavigationService.context,
        listen: false);
    printLog("court_id>>  ${facilityProvider?.selectedCourt?.id}");

    return {
      "court_id": facilityProvider?.selectedCourt?.id ?? "",
      "date": formattedDate,
      "slotTime": availableTimes.join,
      "slot_id":
          selectedSlotForBooking?.sId, // Join slot IDs if multiple are selected
      "duration": totalHours,
      "startTime": startTimesString, // Send as a single string
      "endTime": endTimesString, // Send as a single string
      "friends": userData.map((user) {
        final phoneNumber = user.phoneNumber.trim();
        // final phoneNumber = user.phoneNumber.replaceAll(RegExp(r'\s+'), '');
        final hasCountryCode = phoneNumber.startsWith('+');

        String mobileNumber;
        String countryCode;

        if (hasCountryCode) {
          final spaceIndex = phoneNumber.indexOf(' ');
          if (spaceIndex != -1) {
            countryCode = phoneNumber.substring(1, spaceIndex);
            mobileNumber = phoneNumber.substring(spaceIndex + 1);
          } else {
            countryCode = phoneNumber.substring(1, 3);
            mobileNumber = phoneNumber.substring(3);
          }
        } else {
          // countryCode = '0';

          countryCode = NavigationService.navigatorKey.currentState!.context
              .read<MyAccountViewModel>()
              .countryCode;
          mobileNumber = phoneNumber;
        }

        return {
          "name": user.name,
          "mobile_number": mobileNumber,
          // "split_amount": perPersonAmount.toStringAsFixed(2),
          "country_code": countryCode
        };
      }).toList(),
      "is_recorded": isRecorded,
      "is_split": isSplit,
    };
  }

  Map<String, dynamic> generateBookingData() {
    // double perPersonAmount = perPersonPrice;
    // Generate startTime and endTime for each slotTime
    List<String> startTimes = [];
    List<String> endTimes = [];

    for (String time in availableTimes) {
      print("time ...$time");
      DateTime slotDateTime = DateFormat('h:mm a').parse(time);
      String endTime =
          DateFormat('h:mm a').format(slotDateTime.add(Duration(hours: 1)));
      startTimes.add(time);
      endTimes.add(endTime);
    }

    // If you want to join all start times and end times into a single string
    String startTimesString = startTimes.join(', ');
    String endTimesString = endTimes.join(', ');

    return {
      "court_id": selectedCourtId,
      "date": requestDate,
      "slotTime": availableTimes.join(', '),
      "slot_id": selectedSlots, // Join slot IDs if multiple are selected
      "duration": totalHours,
      "startTime": startTimesString, // Send as a single string
      "endTime": endTimesString, // Send as a single string
      "friends": userData.map((user) {
        final phoneNumber = user.phoneNumber.trim();
        final hasCountryCode = phoneNumber.startsWith('+');

        String mobileNumber;
        String countryCode;

        if (hasCountryCode) {
          final spaceIndex = phoneNumber.indexOf(' ');
          if (spaceIndex != -1) {
            countryCode = phoneNumber.substring(1, spaceIndex);
            mobileNumber = phoneNumber.substring(spaceIndex + 1);
          } else {
            countryCode = phoneNumber.substring(1, 3);
            mobileNumber = phoneNumber.substring(3);
          }
        } else {
          // countryCode = '0';
          countryCode = NavigationService.navigatorKey.currentState!.context
              .read<MyAccountViewModel>()
              .countryCode; // Default or fallback
          mobileNumber = phoneNumber;
        }

        return {
          "name": user.name,
          "mobile_number": mobileNumber,
          // "split_amount": perPersonAmount.toStringAsFixed(2),
          "country_code": countryCode
        };
      }).toList(),
      "is_recorded": isRecorded,
      "is_split": isSplit,
    };
  }

  void printBookingDetails() {
    print("Court ID: $courtId");
    print("Booking Price: $slotPrice");
    print("Is Recorded: $isRecorded");
    print("Is Split: $isSplit");
    print("Available Times: $availableTimes");
    print("Selected Date: $requestDate");
    print("Total Hours: $totalHours");
    print("Selected SlotID: $selectedSlots");
    for (var user in userData) {
      final phoneNumber = user.phoneNumber.trim();
      final hasCountryCode = phoneNumber.startsWith('+');

      String mobileNumber;
      String countryCode;

      if (hasCountryCode) {
        final spaceIndex = phoneNumber.indexOf(' ');
        if (spaceIndex != -1) {
          countryCode = phoneNumber.substring(1, spaceIndex);
          mobileNumber = phoneNumber.substring(spaceIndex + 1);
        } else {
          countryCode = phoneNumber.substring(1, 3);
          mobileNumber = phoneNumber.substring(3);
        }
      } else {
        // countryCode = '0';
        countryCode = NavigationService.navigatorKey.currentState!.context
            .read<MyAccountViewModel>()
            .countryCode;
        mobileNumber = phoneNumber;
      }

      print("Friend Name: ${user.name}");
      print("Contact Number: $mobileNumber");
      // print("Split Amount: ${perPersonPrice.toStringAsFixed(2)}");
      print("Country Code: +$countryCode");
    }
  }

  ///
  ///new api Call

  ///
  // Future<String> callBookingAPI(
  //   BuildContext context, {
  //   bool fromGuest = false,
  // })
  // async {
  //   isLoading = true;
  //   notifyListeners();
  //
  //   var bookingData = {};
  //   printLog("fromguest > $fromGuest");
  //
  //   if (fromGuest == true) {
  //     bookingData = generateBookingData();
  //   } else {
  //     bookingData = generateBookingData2();
  //   }
  //
  //   printBookingDetails();
  //   String? baseurl = GlobalAPIUtils.getBaseUrl();
  //   String? bookGuestCourtUrl = GlobalAPIUtils.getGuestBookingCourtURL();
  //   String? authToken = await GlobalAPIUtils.getAuthToken();
  //
  //   try {
  //     final response = await http.post(
  //       Uri.parse(baseurl + bookGuestCourtUrl),
  //       headers: {
  //         'Content-Type': 'application/json',
  //         'Authorization': 'Bearer $authToken'
  //       },
  //       body: jsonEncode(bookingData),
  //     );
  //
  //     print('Booking Req Body: $bookingData');
  //
  //     if (response.statusCode == 200) {
  //       final responseData = jsonDecode(response.body);
  //
  //       if (responseData['status'] == true || responseData['status'] == 200) {
  //         List bookings = responseData['bookings'] ?? [];
  //
  //         if (bookings.isNotEmpty) {
  //           // Store all booking IDs if needed
  //           List<String> bookingIds = bookings
  //               .map<String>((b) => b['booking_id']?.toString() ?? '')
  //               .toList();
  //
  //           List<String> id =
  //               bookings.map((b) => b['_id']?.toString() ?? '').toList();
  //           ID = id.first;
  //           bookingId = bookingIds.first;
  //           print('Booking successful. Booking ID(s): $bookingIds');
  //         }
  //
  //         return S.of(context).bookingSuccessful;
  //       } else if (responseData['message'] ==
  //               "No booking could be completed. Either all slots are already booked." &&
  //           responseData['status'] == false) {
  //         return responseData['message'];
  //       } else if (responseData['message'] ==
  //           "Court already booked at this time. Wait until booking is completed.") {
  //         return responseData['message'];
  //       } else {
  //         return S.of(context).unexpectedErrorOccurred;
  //       }
  //     } else {
  //       return jsonDecode(response.body)['message'];
  //     }
  //   } catch (e) {
  //     print('Error occurred: $e');
  //     return S.of(context).anErrorOccurredPleaseTryAgain;
  //   } finally {
  //     isLoading = false;
  //     notifyListeners();
  //   }
  // }

  bool isLoading = false;

  void updateIsLoading(bool status) {
    isLoading = status;
    notifyListeners();
  }

  BookingRepository repository = BookingRepository();

  // SlotsResponseModel slotsResponseModel = SlotsResponseModel();
  String? minHours;
  bool isLoadingSlots = false;

  AvailableSlots? selectedSlotForBooking;

  void updateSelectedSlot({required AvailableSlots? slot, required hours}) {
    selectedSlotForBooking = slot;
    minHours = hours.toString();
    printLog("Selected SLot  :${slot?.courtId}");
    notifyListeners();
  }

  void updateSelectedID(String id) {
    if (selectedSlots.contains(id)) {
      selectedSlots.remove(id);
    } else {
      selectedSlots.add(id);
    }
    printLog("Selected Slots List: $selectedSlots");
    notifyListeners();
  }

  Future<void> getSlots({required BuildContext context}) async {
    isLoadingSlots = true;
    notifyListeners();

    try {
      final facilityProvider = Provider.of<FacilitiesViewModel>(
          NavigationService.context,
          listen: false);

      final courtId = facilityProvider.selectedCourt.id ?? "";
      final facilityId = facilityProvider.selectedFacility.id ?? "";

      // Format date to dd-MM-yyyy
      String formattedDate = selectedDate != null
          ? DateFormat('dd-MM-yyyy').format(selectedDate!)
          : "";
      SharedPreferences prefs = await SharedPreferences.getInstance();
      var timeZone = await prefs.getString("timeZone") ?? "Asia/Kolkata";
      Map<String, dynamic> map = {
        "date": formattedDate,
        "court_id": courtId,
        "facility_id": facilityId,
        "timeZone": timeZone
      };

      final response = await repository.getSlotsApi(map, returnData: true);

      if (response.status == true) {
        slotsResponseModel = SlotsResponseModel.fromJson(response.body);
        if (slotsResponseModel.data?.availableSlots != null &&
            slotsResponseModel.data?.availableSlots?.length != 0) {
          var courtData = response.body["data"]?["court"];
          int timeInMinutes = courtData?["minHours"] ?? 0;

          String formattedTime;

          if (timeInMinutes < 60) {
            formattedTime = "$timeInMinutes min";
          } else {
            int hours = timeInMinutes ~/ 60;
            int minutes = timeInMinutes % 60;

            if (minutes == 0) {
              formattedTime = "${hours}hr";
            } else {
              formattedTime = "${hours}hr ${minutes}min";
            }
          }

          print("Formatted time: $formattedTime");

          print(formattedTime);
          updateSelectedSlot(
              slot: slotsResponseModel?.data?.availableSlots?.firstOrNull ??
                  AvailableSlots(),
              hours: formattedTime);
          printLog("Selct 1st Slot ${selectedSlotForBooking?.courtId ?? ""}");
        }
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e, stackTrace) {
      printLog("error ${e.toString()} stackTrace : $stackTrace");
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context).somethingWentWrongGetslots);
    } finally {
      isLoadingSlots = false;
      notifyListeners();
    }
  }

  void clearSelectedSlot() {
    userData.clear(); // Clear the user data
    selectedSlotIds.clear(); // Clear the selected slot
    selectedSlotForBooking = null; // Reset the selected slot for booking
    calculateTotalPrice(); // Recalculate the price (but no slot selected)
    calculateTotalHours(); // Recalculate hours (no slot selected)
    notifyListeners(); // Update the UI
  }

  ///put heree

  // bool isLoadingSlotsNew = false;
  //new get court.

  Future<List<AvailableSlots>> getSlotsNew(
      {required formatedDate,
      required courtId,
      required facilityId,
      required BuildContext context}) async {
    isLoadingSlotsNew = true;
    notifyListeners();
    print("date neww .#$formatedDate");
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var timeZone = await prefs.getString("timeZone") ?? "Asia/Kolkata";
    try {
      Map<String, dynamic> map = {
        "date": formatedDate,
        "court_id": courtId,
        "facility_id": facilityId,
        "timeZone": timeZone
      };

      final response = await repository.getSlotsApi(map, returnData: true);

      if (response.status == true) {
        slotsResponseModel = SlotsResponseModel.fromJson(response.body);

        if (slotsResponseModel.data?.availableSlots != null &&
            slotsResponseModel.data!.availableSlots!.isNotEmpty) {
          var courtData = response.body["data"]?["court"];
          int timeInMinutes = courtData?["minHours"] ?? 0;

          String formattedTime;

          if (timeInMinutes < 60) {
            formattedTime = "$timeInMinutes min";
          } else {
            int hours = timeInMinutes ~/ 60;
            int minutes = timeInMinutes % 60;

            if (minutes == 0) {
              formattedTime = "${hours}hr";
            } else {
              formattedTime = "${hours}hr ${minutes}min";
            }
          }

          print("Formatted time: $formattedTime");

          print(formattedTime);
          updateSelectedSlot(
              slot: slotsResponseModel.data!.availableSlots!.firstOrNull ??
                  AvailableSlots(),
              hours: formattedTime);
          printLog("Select 1st Slot ${selectedSlotForBooking?.courtId}");
        }
        isLoadingSlotsNew = false;
        return slotsResponseModel.data?.availableSlots ?? [];
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
        return [];
      }
    } catch (e, stackTrace) {
      isLoadingSlotsNew = false;
      print("stackTrace : $stackTrace");
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context).somethingWentWrongGetslots);
      return [];
    } finally {
      isLoadingSlotsNew = false;
      notifyListeners();
    }
  }

  //for modify
  Future<List<AvailableSlots>> getSlotsForModify({
    required String formatedDate,
    required String courtId,
    required String facilityId,
    required BuildContext context,
  }) async {
    isLoadingSlotsNew = true;
    notifyListeners();
    print("date neww .#$formatedDate");
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var timeZone = await prefs.getString("timeZone") ?? "Asia/Kolkata";

    try {
      final response = await repository.getSlotsApi(
        {
          "date": formatedDate,
          "court_id": courtId,
          "facility_id": facilityId,
          "timeZone": timeZone
        },
        returnData: true,
      );

      if (response.status == true) {
        final slotsResponse = SlotsResponseModel.fromJson(response.body);
        availableSlots = slotsResponse.data?.availableSlots ?? [];
        isLoadingSlotsNew = false;
        notifyListeners();
        return availableSlots;
      } else {
        showSnackbar(context: context, message: response.message.toString());
        return [];
      }
    } catch (e) {
      showSnackbar(
          context: context,
          message: "Something went wrong while loading slots.");
      return [];
    } finally {
      isLoadingSlotsNew = false;
      notifyListeners();
    }
  }

  // Set slots + pre-selected slotIds from modify booking
  void setAvailableSlotsMOdify(
      {required List<AvailableSlots> slots, List<String>? preSelectedIds}) {
    availableSlots = slots;
    selectedSlotIds = preSelectedIds ?? [];
    calculateTotalHoursModify();
    notifyListeners();
  }

  void updateSelectedSlotModify(AvailableSlots slot, BuildContext context) {
    if (slot.sId == null) return;

    if (selectedSlotIds.contains(slot.sId)) {
      selectedSlotIds.remove(slot.sId);
    } else {
      selectedSlotIds.add(slot.sId ?? "");
    }
    calculateTotalHours();
    notifyListeners();
  }

  void calculateTotalHoursModify() {
    int totalHours = selectedSlotIds.length;
    print("Total hours selected: $totalHours");
  }

  Future<bool> sendOtpRequest({
    required String countryCode1,
    required String phoneNumber1,
  }) async {
    if (!isChecked) {
      return false;
    }

    updateIsLoading(true);

    final String apiUrl = "app/auth/send-otp";
    Map<String, String> requestBody = {
      "country_code": countryCode1,
      "mobile_number": phoneNumber1
    };

    try {
      final response = await http.post(Uri.parse(baseURL + apiUrl),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode(requestBody));

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        bool status = responseData['status'] ?? false;

        if (status) {
          showSnackbar(
              context: NavigationService.navigatorKey.currentState!.context,
              message: "OTP Sent Successfully: ${responseData['message']}");
          return true;
        } else {
          Utils.flushbarErrorMessage("${responseData['message']}",
              NavigationService.navigatorKey.currentState!.context);
          return false;
        }
      } else {
        return false;
      }
    } catch (e) {
      return false;
    } finally {
      updateIsLoading(false);
    }
  }

  Future<bool> verifyOtp(
    BuildContext context,
    int otp,
  ) async {
    final prefs = await SharedPreferences.getInstance();

    // First check saved token
    String? fcmToken = prefs.getString("fcmTokenKey");

    // If not available, fetch new from Firebase
    if (fcmToken == null || fcmToken.isEmpty) {
      try {
        fcmToken = await FirebaseMessaging.instance.getToken();
        if (fcmToken != null) {
          await prefs.setString("fcmTokenKey", fcmToken);
        }
      } catch (e) {
        debugPrint("Error fetching FCM token: $e");
      }
    }

    print("Using FCM Token: $fcmToken");

    if (otp.toString().isEmpty) {
      otpErrorMessage = l10n.of(context).pleaseEnterTheOtp;
      notifyListeners();
      return false;
    }

    updateIsLoading(true);
    otpErrorMessage = null;

    final String apiUrl = "app/auth/verify-otp";
    Map<String, dynamic> requestBody = {
      "mobile_number": phoneController.text,
      "country_code": countryCodeController.text,
      "otp": otp,
      "deviceToken": fcmToken ?? "", // never null
    };

    try {
      final response = await http.post(
        Uri.parse(baseURL + apiUrl),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(requestBody),
      );

      final responseData = jsonDecode(response.body);
      bool status = responseData['status'] ?? false;

      if (response.statusCode == 200 && status) {
        String? token = responseData['token'];

        showSnackbar(
          context: NavigationService.context,
          message: responseData['message'],
        );

        if (token != null) {
          LocalService.instance.setData(LocalKeys.instance.accessToken, token);
          await prefs.setString("auth_token", token);
        }

        otpErrorMessage = null;
        notifyListeners();
        return true;
      } else {
        otpErrorMessage = responseData['message'] ??
            l10n.of(context).invalidOtpPleaseTryAgain;
        notifyListeners();
        return false;
      }
    } catch (e) {
      otpErrorMessage = l10n.of(context).errorVerifyingOtpPleaseTryAgain;
      notifyListeners();
      return false;
    } finally {
      updateIsLoading(false);
    }
  }

  // Future<bool> verifyOtp(
  //   BuildContext context,
  //   int otp,
  // ) async {
  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //   final fcmToken = await prefs.getString("fcmTokenKey");
  //   print("============================$fcmToken");
  //   print("fcmTokenlogin==>$fcmToken");
  //   // Change otp type to int
  //   if (otp.toString().isEmpty) {
  //     otpErrorMessage = S.of(context).pleaseEnterTheOtp;
  //     notifyListeners();
  //     return false;
  //   }
  //
  //   updateIsLoading(true);
  //
  //   otpErrorMessage = null;
  //
  //
  //   final String apiUrl = "app/auth/verify-otp";
  //   Map<String, dynamic> requestBody = {
  //     // Ensure correct types
  //     "mobile_number": phoneController.text,
  //     "country_code": countryCodeController.text,
  //     "otp": otp,
  //     "deviceToken": fcmToken,
  //   };
  //
  //   try {
  //     final response = await http.post(Uri.parse(baseURL + apiUrl),
  //         headers: {"Content-Type": "application/json"},
  //         body: jsonEncode(requestBody));
  //
  //     final responseData = jsonDecode(response.body);
  //     bool status = responseData['status'] ?? false;
  //
  //     if (response.statusCode == 200 && status) {
  //       String? token = responseData['token'];
  //
  //       showSnackbar(
  //           context: NavigationService.context,
  //           message: responseData['message']);
  //
  //       if (token != null) {
  //         LocalService.instance.setData(LocalKeys.instance.accessToken, token);
  //         await prefs.setString("auth_token", token);
  //
  //         // await prefs.setBool("showBottomSheet", true);
  //       }
  //
  //       otpErrorMessage = null; // Clear error
  //       notifyListeners();
  //       return true;
  //     } else {
  //       otpErrorMessage =
  //           responseData['message'] ?? S.of(context).invalidOtpPleaseTryAgain;
  //       notifyListeners();
  //       return false;
  //     }
  //   } catch (e) {
  //     otpErrorMessage = S.of(context).errorVerifyingOtpPleaseTryAgain;
  //     notifyListeners();
  //     return false;
  //   } finally {
  //     updateIsLoading(false);
  //   }
  // }

  //new func

  bool _isFilled = false;

  bool get isFilled => _isFilled;

  bool _isOTPFilled = false;

  bool get isOTPFilled => _isOTPFilled;

  dynamic updatePhoneNumber(String? value) {
    if (value != null) {
      if (value.length >= 8) {
        _isFilled = true;
        notifyListeners();
      } else {
        _isFilled = false;
        notifyListeners();
      }
    }
  }

  dynamic updateOtp(String? value) {
    if (value != null) {
      if (value.length > 4) {
        _isOTPFilled = true;
        notifyListeners();
      } else {
        _isOTPFilled = false;
        notifyListeners();
      }
    }
  }

  clearPhoneBottomSheet() {
    countryCodeController.clear();
    phoneController.clear();
    otpController.clear();
    otpController.clear();
    _resendTimer?.cancel();
    _remainingSeconds = 30;
    _isFilled = false;

    notifyListeners();
  }

//

  Future<String> newCallBookingAPI({
    required BuildContext context,
    required String selectedCourtId,
    required String trxnid,
    required String? requestDate,
    required List availableTimes,
    required List selectedSlots,
    required bool isRecorded,
    required bool isSplit,
    String? discountId,
    String? discountAmount,
  }) async {
    isLoading = true;
    notifyListeners();

    print("in api calll");
    var bookingData = {};
    String dateOnly = DateFormat('dd-MM-yyyy').format(DateTime.now());
    print("dateonlue => $dateOnly");
    // Convert requestDate to DateTime object and format it to ISO string (yyyy-MM-dd)
    DateTime parsedDate =
        DateFormat("dd-MM-yyyy").parse(requestDate ?? "18-06-2025");
    // DateTime parsedDate = DateFormat("dd-MM-yyyy").parse(requestDate ?? "2025-06-14 00:00:00.000");

    print("parsedDate => $parsedDate");
    String formattedDate = DateFormat("yyyy-MM-dd").format(parsedDate);
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var timeZone = await prefs.getString("timeZone") ?? "Asia/Kolkata";
    bookingData = {
      "court_id": selectedCourtId,
      "checkoutSessionId": context.read<PaymentProvider>().sessionid,
      // Use the formatted date
      "transactionId": trxnid,
      "date": formattedDate, // Use the formatted date
      "slotTime": availableTimes.join(', '),
      "slot_id": selectedSlots,
      "discountId": discountId,
      "discountAmount": discountAmount,
      "timeZone": timeZone,
      "friends": userData.map((user) {
        final phoneNumber = user.phoneNumber.trim();
        final hasCountryCode = phoneNumber.startsWith('+');

        String mobileNumber;
        String countryCode;

        if (hasCountryCode) {
          final spaceIndex = phoneNumber.indexOf(' ');
          if (spaceIndex != -1) {
            countryCode = phoneNumber.substring(1, spaceIndex);
            mobileNumber = phoneNumber.substring(spaceIndex + 1);
          } else {
            countryCode = phoneNumber.substring(1, 3);
            mobileNumber = phoneNumber.substring(3);
          }
        } else {
          // countryCode = '0';
          countryCode = context
              .read<MyAccountViewModel>()
              .countryCode; // Default or fallback

          mobileNumber = phoneNumber;
        }

        return {
          "name": user.name,
          "mobile_number": mobileNumber,
          "split_amount": friendsPrice.toStringAsFixed(2),
          "country_code": countryCode
        };
      }).toList(),
      "is_recorded": isRecorded,
      "is_split": isSplit,
    };

    printBookingDetails();
    String? baseurl = GlobalAPIUtils.getBaseUrl();
    String? bookGuestCourtUrl = GlobalAPIUtils.getGuestBookingCourtURL();
    String? authToken = await GlobalAPIUtils.getAuthToken();
    context.read<AvailableChallengeGuestViewModel>().settime("");
    try {
      final response = await http.post(
        Uri.parse(baseurl + bookGuestCourtUrl),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $authToken'
        },
        body: jsonEncode(bookingData),
      );

      print('Booking Req Body: $bookingData');

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);

        if (responseData['status'] == true || responseData['status'] == 200) {
          List bookings = responseData['bookings'] ?? [];

          if (bookings.isNotEmpty) {
            List<String> bookingIds = bookings
                .map<String>((b) => b['booking_id']?.toString() ?? '')
                .toList();

            List<String> id =
                bookings.map((b) => b['_id']?.toString() ?? '').toList();
            ID = id.first;
            bookingId = bookingIds.first;
            final rawUtcString =
                responseData["bookings"][0]["bookingStartTime"];

            if (rawUtcString != null) {
              final utcDate =
                  DateTime.parse(rawUtcString).toUtc(); // ensure UTC
              final localDate = utcDate.toLocal(); // convert to local time zone
              final formattedDateTime =
                  DateFormat('MMM d, yyyy h:mm a').format(localDate);
              print("formattedDateTime: $formattedDateTime");

              context
                  .read<AvailableChallengeGuestViewModel>()
                  .settime(formattedDateTime);
            }

            print('Booking successful. Booking ID(s): $bookingIds');
          }

          return "Booking successful";
        } else if (responseData['message'] ==
                "No booking could be completed. Either all slots are already booked." &&
            responseData['status'] == false) {
          return responseData['message'];
        } else if (responseData['message'] ==
            "Court already booked at this time. Wait until booking is completed.") {
          return responseData['message'];
        } else {
          return responseData['message'];
        }
      } else {
        return jsonDecode(response.body)['message'];
      }
    } catch (e) {
      print('Error occurred: $e');
      return l10n.of(context).anErrorOccurredPleaseTryAgain;
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  ///otp timer
  ///
  // Existing fields...
  Timer? _resendTimer;
  int _remainingSeconds = 30;

  int get remainingSeconds => _remainingSeconds;

  bool get canResendOtp => _remainingSeconds == 0;

  void startResendOtpTimer() {
    _remainingSeconds = 30;
    notifyListeners();

    _resendTimer?.cancel();
    _resendTimer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (_remainingSeconds > 0) {
        _remainingSeconds--;
        notifyListeners();
      } else {
        _resendTimer?.cancel();
        notifyListeners();
      }
    });
  }

  TextEditingController promoCodeController = TextEditingController();

//var for storing promo code data
  String? appliedDiscountAmount;
  String? appliedDiscountId;
  String? appliedPromoCode;
  bool applied = false;
  bool isPromoApplied = false;

//apply promo code
  PromoViewModel() {
    // Listen to text changes to reset promo state when code changes
    promoCodeController.addListener(() {
      if (appliedPromoCode != null &&
          promoCodeController.text.trim() != appliedPromoCode) {
        applied = false;
        appliedDiscountAmount = null;
        appliedDiscountId = null;
        appliedPromoCode = null;
        notifyListeners();
      }
    });
  }

  void onPrommoCodeChange(value) {
    isPromoApplied = false;

    promoCodErrorMsg = null;
    applied = false;
    appliedDiscountAmount = null;
    appliedDiscountId = null;
    appliedPromoCode = null;

    notifyListeners();
  }

  String? promoCodErrorMsg;

  Future<String> applyPromoCode(
      {required String code,
      required String amount,
      required BuildContext context}) async {
    promoCodErrorMsg = null;
    isPromoApplied = true;
    notifyListeners();

    var bookingData = {
      "code": code,
      "court_id": courtId,
      "amount": amount,
    };

    String? baseurl = GlobalAPIUtils.getBaseUrl();
    String? promoCodeUrl = GlobalAPIUtils.getPromoCodeURLFucntion();
    String? authToken = await GlobalAPIUtils.getAuthToken();

    applied = false;
    print("token : $authToken");

    try {
      final response = await http.post(
        Uri.parse(baseurl + promoCodeUrl),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $authToken',
        },
        body: jsonEncode(bookingData),
      );

      print('Booking Req Body: $bookingData');
      print('Promo Code Response: ${response.body}');

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);

        if (responseData is Map<String, dynamic>) {
          if (responseData['status'] == true || responseData['status'] == 200) {
            final data = responseData['data'];
            if (data != null && data is Map<String, dynamic>) {
              appliedDiscountAmount = data['discountAmount']?.toString();
              appliedDiscountId = data['discountId']?.toString();
              appliedPromoCode = code;
              applied = true;
              notifyListeners();
              return responseData['message'] ?? "Promo applied successfully.";
            } else {
              return l10n.of(context).invalidPromoDataReceivedFromServer;
            }
          } else {
            appliedDiscountAmount = null;
            appliedDiscountId = null;
            appliedPromoCode = null;
            applied = false;
            notifyListeners();
            promoCodErrorMsg =
                responseData['message'] ?? "Promo code invalid or expired.";
            return responseData['message'] ?? "Promo code invalid or expired.";
          }
        } else {
          return l10n.of(context).unexpectedResponseFormatFromServer;
        }
      } else {
        return l10n.of(context).failedToApplyPromoCode;
      }
    } on FormatException catch (e) {
      print("JSON Format Exception: $e");
      return "Invalid response from server.";
    } on http.ClientException catch (e) {
      print("HTTP Client Exception: $e");
      return l10n.of(context).connectionErrorPleaseCheckYourNetwork;
    } catch (e) {
      print("Unexpected error: $e");
      return l10n.of(context).anUnexpectedErrorOccurredPleaseTryAgain;
    } finally {
      isPromoApplied = false;
      notifyListeners();
    }
  }

  Future<bool> validateBeforeSendingOtp({
    required String countryCode,
    required String phoneNumber,
  }) async {
    // Example basic validation
    if (countryCode.isEmpty || phoneNumber.length < 8) {
      otpErrorMessage = "Invalid phone number";
      notifyListeners();
      return false;
    }

    // Optional: Check if phone is registered or make any other async call
    // bool userExists = await checkUserExists(phoneNumber);
    // return userExists;

    return true;
  }

  /// get faceboook login
  Future<bool> socialLoginApiFunc(
      {required BuildContext context,
      String? countryCode,
      required String email,
      required String socialID,
      String? mobileNumber,
      String? name,
      required String type}) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    print("fb login function st");
    print("isChecked......$isChecked");
    // if (!isChecked) {
    //   print("Checkbox is not checked. Skipping OTP request.");
    //   return false;
    // }
    final fcmToken = await prefs.getString("fcm_token");

    String apiUrl = GlobalAPIUtils.getSocialLoginUrl();

    updateIsLoading(true);

    Map<String, dynamic> requestBody = {
      "mobile_number": mobileNumber,
      "country_code": countryCode,
      "name": name,
      "social_id": socialID,
      "login_type": type, // ["Email", "Google", "Facebook", "Apple", "Phone"],
      "email": email,
      "deviceToken": fcmToken,
    };
    print("fb login freq Boody $requestBody");

    try {
      final response = await http.post(Uri.parse(baseURL + apiUrl),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode(requestBody));

      final responseData = jsonDecode(response.body);
      bool status = responseData['status'] ?? false;

      if (response.statusCode == 200 && status) {
        String? token = responseData['token'];

        showSnackbar(
            context: NavigationService.context,
            message: responseData['message']);

        if (token != null) {
          LocalService.instance.setData(LocalKeys.instance.accessToken, token);
          await prefs.setString("auth_token", token);
          await prefs.setString("loginType", type);
        }

        return true;
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: responseData['message']);
        return false;
      }
    } catch (e) {
      showSnackbar(context: NavigationService.context, message: "${e}");
      return false;
    } finally {
      updateIsLoading(false);
    }
  }

  ///set otp for social login
  bool isSocialOtpVerifyLoading = false;

  void updateISSocialOtpVerifyLoadingbool(status) {
    isSocialOtpVerifyLoading = status;
    notifyListeners();
  }

  Future<bool> sendOtpForSocilaLoginRequest({
    required String countryCode1,
    required String phoneNumber1,
  }) async {
    print("sendOtpForSocilaLoginRequest");

    updateISSocialOtpVerifyLoadingbool(true);

    final String apiUrl = "app/auth/otp/send-otp";
    Map<String, String> requestBody = {
      "country_code": countryCode1,
      "mobile_number": phoneNumber1
    };

    try {
      final response = await http.post(Uri.parse(baseURL + apiUrl),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode(requestBody));

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        bool status = responseData['status'] ?? false;

        if (status) {
          print("OTP Sent Successfully: ${responseData['message']}");
          return true;
        } else {
          print("Failed to send OTP: ${responseData['message']}");
          return false;
        }
      } else {
        print("Failed to send OTP: ${response.body}");
        return false;
      }
    } catch (e) {
      print("Error sending OTP: $e");
      return false;
    } finally {
      updateISSocialOtpVerifyLoadingbool(false);
    }
  }

//veriify otp social logn
  Future<bool> verifyForSocialLoginOtp(
      {required BuildContext context,
      required int otp,
      required String email,
      required String socilID,
      required String name,
      required String type}) async {
    // Change otp type to int
    if (otp.toString().isEmpty) {
      otpErrorMessage = l10n.of(context).pleaseEnterTheOtp;
      notifyListeners();
      return false;
    }

    updateISSocialOtpVerifyLoadingbool(true);

    otpErrorMessage = null;
    // SharedPreferences prefs = await SharedPreferences.getInstance();

    // final fcmToken = await prefs.getString("fcm_token");
    final String apiUrl = "app/auth/otp/verify-otp";
    Map<String, dynamic> requestBody = {
      // Ensure correct types
      "mobile_number": phoneController.text,
      "country_code": countryCodeController.text,
      "otp": otp,
      // "deviceToken": fcmToken,
    };

    try {
      final response = await http.post(Uri.parse(baseURL + apiUrl),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode(requestBody));

      final responseData = jsonDecode(response.body);
      bool status = responseData['status'] ?? false;

      if (response.statusCode == 200 && status) {
        // String? token = responseData['token'];

        showSnackbar(
            context: NavigationService.context,
            message: responseData['message']);

        // if (token != null) {
        //   LocalService.instance.setData(LocalKeys.instance.accessToken, token);
        //   await prefs.setString("auth_token", token);

        //   // await prefs.setBool("showBottomSheet", true);
        // }
        await socialLoginApiFunc(
            context: context,
            email: email,
            socialID: socilID,
            name: name,
            type: type,
            mobileNumber: phoneController.text,
            countryCode: countryCodeController.text);
        otpErrorMessage = null; // Clear error
        notifyListeners();
        return true;
      } else {
        otpErrorMessage = responseData['message'] ??
            l10n.of(context).invalidOtpPleaseTryAgain;
        notifyListeners();
        return false;
      }
    } catch (e) {
      otpErrorMessage = l10n.of(context).errorVerifyingOtpPleaseTryAgain;
      notifyListeners();
      return false;
    } finally {
      updateISSocialOtpVerifyLoadingbool(false);
    }
  }

//check social loggin user
  Future<bool> checkSocialLoginUser(
      {required BuildContext context,
      required String socialId,
      required String type}) async {
    // Change otp type to int

    // updateISSocialOtpVerifyLoadingbool(true);

    // otpErrorMessage = null;
    // SharedPreferences prefs = await SharedPreferences.getInstance();

    // final fcmToken = await prefs.getString("fcm_token");
    final String apiUrl = "app/auth/get-social-login";
    Map<String, dynamic> requestBody = {
      "social_id": socialId,
      "login_type": type
    };

    try {
      final response = await http.post(Uri.parse(baseURL + apiUrl),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode(requestBody));

      final responseData = jsonDecode(response.body);
      bool status = responseData['user'] ?? false;

      if (response.statusCode == 200 && status) {
        // String? token = responseData['token'];

        showSnackbar(
            context: NavigationService.context,
            message: responseData['message']);

        // if (token != null) {
        //   LocalService.instance.setData(LocalKeys.instance.accessToken, token);
        //   await prefs.setString("auth_token", token);

        //   // await prefs.setBool("showBottomSheet", true);
        // }
        return true;
        // return responseData['data'];
      } else {
        // otpErrorMessage =
        //     responseData['message'] ?? S.of(context).invalidOtpPleaseTryAgain;
        // notifyListeners();
        return false;
      }
    } catch (e) {
      // otpErrorMessage = S.of(context).errorVerifyingOtpPleaseTryAgain;
      // notifyListeners();
      return false;
    }
  }
}
