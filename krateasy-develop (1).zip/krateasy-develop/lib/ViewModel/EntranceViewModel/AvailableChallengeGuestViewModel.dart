import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/Models/available_challenge_model.dart';
import 'package:kratEasyApp/Models/challenges_details_model.dart';
import 'package:kratEasyApp/Models/guest_Public_Challenges_Model.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/repository/available_challenge_repository.dart';

// import '../../API_CALLS/API/ChallenegesGuestAPI.dart';
import '../../EntranceScreens/guest_join_challenge.dart';
import '../../GlobalUtils/app_imports.dart';
import '../../Models/ChallengesGuestModel.dart';

class AvailableChallengeGuestViewModel extends ChangeNotifier {
  AvailableChallengeGuestViewModel() {
    debugPrint("AvailableChallengeGuestViewModel Created");
  }

  void addChallenge(
    BuildContext context, {
    String? selectedSport,
    String? facilityId,
    String? courtId,
  }) {
    Navigator.pushNamed(
      context,
      '/createChallenge',
      arguments: {
        'selectedSport': selectedSport,
        'facilityId': facilityId,
        'courtId': courtId,
      },
    );
  }

  final List<ChallengesGuestModel> _challenges = [];
  final bool _isLoading = true;

  List<ChallengesGuestModel> get challenges => _challenges;

  bool get isLoading => _isLoading;
  bool isLoadingData = false;

  AvailableChallengeRepository repository = AvailableChallengeRepository();

  /// search challenges list
  bool isSearch = false;
  List<AvailablePublicChallengesModel> challengeData = [];
  List<AvailablePublicChallengesModel> searchChallengeData = [];
  TextEditingController searchController = TextEditingController();

  final FocusNode searchFocusNode = FocusNode();

  clearChallengeList() {
    searchChallengeData = List.from(challengeData);
    searchController.clear();
    notifyListeners();
  }

  void statusUpdate() {
    isSearch = !isSearch;

    if (!isSearch) {
      searchChallengeData = challengeData;
      searchController.clear();
      searchFocusNode.unfocus(); // ✅ Close keyboard
    } else {
      searchFocusNode.requestFocus(); // ✅ Open keyboard
    }

    notifyListeners();
  }

  void searchChallenges(String value) {
    searchChallengeData = challengeData
        .where((challenge) =>
            challenge.slots?.court?.name
                ?.toLowerCase()
                .contains(value.toLowerCase()) ==
            true)
        .toList();
    notifyListeners();
  }

  Future<void> fetchChallenges({
    double? minPrice,
    double? maxPrice,
    String? sort,
    String? date,
    String? startTime,
    List<String>? sportId,
    List<String>? amenities,
  }) async {
    isLoadingData = true;
    notifyListeners();
    try {
      final response = await repository.getAvailableChallengeApi(
        minPrice: minPrice,
        maxPrice: maxPrice,
        sort: sort,
        date: date,
        startTime: startTime,
        sportId: sportId,
        amenities: amenities,
      );
      if (response.status == true) {
        challengeData = List<AvailablePublicChallengesModel>.from(
          response.body.map((x) => AvailablePublicChallengesModel.fromJson(x)),
        );
        searchChallengeData = challengeData;
        notifyListeners();
      } else {
        showSnackbar(
          context: NavigationService.context,
          message: response.message.toString(),
        );
      }
    } catch (e, stackTrace) {
      showSnackbar(
        context: NavigationService.context,
        message: l10n
            .of(NavigationService.navigatorKey.currentContext!)
            .somethingsWentWrongfetchchallenges,
      );
    } finally {
      isLoadingData = false;
      notifyListeners();
    }
  }

  List<String> timeItems = [
    "12:00 AM",
    "01:00 AM",
    "02:00 AM",
    "03:00 AM",
    "04:00 AM",
    "05:00 AM",
    "06:00 AM",
    "07:00 AM",
    "08:00 AM",
    "09:00 AM",
    "10:00 AM",
    "11:00 AM",
    "12:00 PM",
    "01:00 PM",
    "02:00 PM",
    "03:00 PM",
    "04:00 PM",
    "05:00 PM",
    "06:00 PM",
    "07:00 PM",
    "08:00 PM",
    "09:00 PM",
    "10:00 PM",
    "11:00 PM"
  ];

  String? selectTime;

  void changeTimeSlot(String time) {
    selectTime = time;
    notifyListeners();
  }

  //new api for fetch public challenges
  bool isLoadingDataNew = false;

  List<PublicChallenge> challengeDataList = [];
  List<PublicChallenge> searchChallengeDataList = [];

  Future<void> fetchChallengesNew(
      {List? amenities,
      String? startTime,
      required String sportId,
      required String date,
      required BuildContext context}) async {
    isLoadingDataNew = true;
    notifyListeners();

    challengeDataList = await repository.fetchPublicChallenges(
        amenities: amenities,
        startTime: startTime,
        sportId: sportId,
        date: date,
        context: context);
    searchChallengeDataList = challengeDataList;
    print("challengeDataList-----$challengeDataList");

    isLoadingDataNew = false;
    notifyListeners();
  }

  /// ----------------
  int? _loadingChallengeIndexCompleted;

  int? get loadingChallengeIndexCompleted => _loadingChallengeIndexCompleted;

  void setLoadingChallengeIndexCompleted(int? index) {
    _loadingChallengeIndexCompleted = index;
    notifyListeners();
  }

  int? _loadingChallengeIndex;

  int? get loadingChallengeIndex => _loadingChallengeIndex;

  void setLoadingChallengeIndex(int? index) {
    _loadingChallengeIndex = index;
    notifyListeners();
  }

  ChallengesDetailsModel challengesDetailsModel = ChallengesDetailsModel();
  bool isLoad = false;

  void _navigateToGuestJoinChallenge({
    required BuildContext context,
    required bool isPublic,
    required bool isGuestView,
    required bool isPlayAgain,
    bool isShowButton = true,
  }) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => GuestJoinChallenge(
          isPublic: isPublic,
          isNotGuestView: isGuestView,
          isPlayAgain: isPlayAgain,
          isShowButton: isShowButton,
        ),
      ),
    );
  }

  Future<void> getChallengesDetails({
    required String challengesId,
    required BuildContext context,
    bool? myBookingScreen,
    bool? isHome,
    required bool ispublic,
    bool? isbuttonshow,
    required bool cancelChallenge,
  }) async {
    isLoad = true;
    notifyListeners();
    try {
      settime("");
      final response = await repository.getChallengesDetailsApi(challengesId);

      if (response.body["status"] == true) {
        challengesDetailsModel = ChallengesDetailsModel.fromJson(response.body);

        _navigateToGuestJoinChallenge(
          context: context,
          isPublic: ispublic,
          isGuestView: cancelChallenge,
          isPlayAgain: false,
          isShowButton: isbuttonshow ?? true,
        );

        notifyListeners();
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e, stackTrace) {
      showSnackbar(
          context: NavigationService.context,
          message: l10n
              .of(NavigationService.navigatorKey.currentContext!)
              .somethingsWentWronggetchallengesdetails);
    } finally {
      isLoad = false;
      notifyListeners();
    }
  }

  String _challengstarttime = "";

  String get challengestarttime => _challengstarttime;

  void settime(String va) {
    _challengstarttime = va;
    notifyListeners();
  }

  bool isLoadingChallenge = false;

  Future<void> joinChallengePostApis(
      {required String challengeId,
      required BuildContext context,
      required String amount}) async {
    isLoadingChallenge = true;
    settime("");
    notifyListeners();
    final requestBody = {
      "challengeID": challengeId,
      "amount": amount,
    };
    try {
      final response = await repository.joinChallenge(requestBody);
      if (response.body["status"] == true) {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
        settime(response.body["data"]["bookingStartTime"]);

        Navigator.pushNamed(
          context,
          "/guestSuccessPaymentScreen",
          arguments: {
            'bookingId': response.body['data']?['booking_id'] ?? "",
            "amount": amount
          },
        );
        isLoadingChallenge = false;
        // Navigator.push(
        //     context,
        //     MaterialPageRoute(
        //         builder: (context) => GuestSuccessPaymentScreen()));
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e) {
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context).somethingsWentWrongeditMyAccount);
    } finally {
      isLoadingChallenge = false;
      notifyListeners();
    }
  }

  bool isLoadCompleted = false;

  Future<void> getChallengesDetailsForCompleted({
    required String challengesId,
    required BuildContext context,
    bool? myBookingScreen,
    bool? isHome,
    required bool ispublic,
    required bool cancelChallenge,
  }) async {
    isLoadCompleted = true;
    notifyListeners();
    try {
      settime("");
      final response = await repository.getChallengesDetailsApi(challengesId);

      if (response.body["status"] == true) {
        debugPrint("ChallengesDetailsModel.fromJson");

        challengesDetailsModel = ChallengesDetailsModel.fromJson(response.body);
        // if (myBookingScreen == true) {
        //   Navigator.push(
        //       context,
        //       MaterialPageRoute(
        //           builder: (context) => ViewChallengeBookingCompleteScreen()));
        // } else
        // {
        print("else");
        _navigateToGuestJoinChallenge(
          context: context,
          isPublic: ispublic,
          isGuestView: cancelChallenge,
          isPlayAgain: true,
        );
        // }

        notifyListeners();
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e, stackTrace) {
      showSnackbar(
          context: NavigationService.context,
          message: l10n
              .of(NavigationService.navigatorKey.currentContext!)
              .somethingsWentWronggetchallengesdetails);
    } finally {
      isLoadCompleted = false;
      notifyListeners();
    }
  }
}
