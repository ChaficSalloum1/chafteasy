// import 'package:flutter/material.dart';

// class CourtGuestTabViewModel extends ChangeNotifier {
//   // Store selected index for each card using a map
//   Map<int, int> _selectedIndexes = {};

//   // List<String> times = [
//   //   "08:00AM", "09:00AM", "10:00AM",
//   //   "11:00AM", "12:00PM", "01:00PM"
//   // ];


//   // Get the selected index for a specific card
//   int getSelectedIndex(int cardIndex) {
//     return _selectedIndexes[cardIndex] ?? -1;
//   }

//   // Update the selected index for a specific card
//   void updateSelectedIndex(int cardIndex, int timeIndex) {
//     _selectedIndexes[cardIndex] = timeIndex;
//     notifyListeners();
//   }
// }
