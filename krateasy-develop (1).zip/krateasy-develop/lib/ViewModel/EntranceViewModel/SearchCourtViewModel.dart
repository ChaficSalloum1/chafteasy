import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:kratEasyApp/GlobalUtils/app_navigation.dart';
import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/Models/AmenitiesList.dart';
import 'package:kratEasyApp/Models/SportList.dart';
import 'package:kratEasyApp/Models/search_Filter_Data_Model.dart';
import 'package:kratEasyApp/Models/serach_Court_Payload_Model.dart';
import 'package:kratEasyApp/Models/sports_list_model.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/services/remote/remote_service.dart';
import 'package:kratEasyApp/services/remote/responce_helper.dart';
import '../../API_CALLS/API/SearchCourtAPI.dart';
import '../../API_CALLS/Helper.dart';
import '../../Models/SearchCourtModel.dart';

class SearchCourtViewModel extends ChangeNotifier {


  final List<int> _selectedTimeGrids = [];
  List<int> get selectedTimeGrids => _selectedTimeGrids;
  void clearSelectedTimeSlots() {
    _selectedTimeGrids.clear();
    notifyListeners();
  }
  List<String> availableTimes = [
    "12:00 AM",
    "01:00 AM",
    "02:00 AM",
    "03:00 AM",
    "04:00 AM",
    "05:00 AM",
    "06:00 AM",
    "07:00 AM",
    "08:00 AM",
    "09:00 AM",
    "10:00 AM",
    "11:00 AM",
    "12:00 PM",
    "01:00 PM",
    "02:00 PM",
    "03:00 PM",
    "04:00 PM",
    "05:00 PM",
    "06:00 PM",
    "07:00 PM",
    "08:00 PM",
    "09:00 PM",
    "10:00 PM",
    "11:00 PM",
  ];



  // bool isTimeSlotPast(int index, DateTime selectedDate) {
  //   try {
  //     final now = DateTime.now();
  //
  //     final slotTime = DateFormat("hh:mm a", "en_US")
  //         .parse(availableTimes[index]);
  //
  //     // Combine selected date with parsed time
  //     final fullDateTime = DateTime(
  //       selectedDate.year,
  //       selectedDate.month,
  //       selectedDate.day,
  //       slotTime.hour,
  //       slotTime.minute,
  //     );
  //
  //     return fullDateTime.isBefore(now);
  //   } catch (e) {
  //     print("Error parsing time: $e");
  //     return false;
  //   }
  // }

  bool isTimeSlotPast(int index, DateTime selectedDate) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final selected = DateTime(selectedDate.year, selectedDate.month, selectedDate.day);

    // If the selected date is in the future, no time slots are past
    if (selected.isAfter(today)) {
      return false;
    }

    // If the selected date is today, check if the time slot is past
    final formatter = DateFormat('hh:mm a');
    final slotTime = formatter.parse(availableTimes[index]);
    final slotDateTime = DateTime(today.year, today.month, today.day, slotTime.hour, slotTime.minute);
    return slotDateTime.isBefore(now);
  }

  // void toggleTimeGrid(int index, BuildContext context) {
  //   if (_selectedTimeGrids.isEmpty) {
  //     _selectedTimeGrids.add(index);
  //   } else if (_selectedTimeGrids.contains(index)) {
  //     _selectedTimeGrids.sort();
  //     int min = _selectedTimeGrids.first;
  //     int max = _selectedTimeGrids.last;
  //
  //     if (index == min) {
  //       _selectedTimeGrids.remove(index);
  //     } else if (index == max) {
  //       _selectedTimeGrids.remove(index);
  //     } else {
  //       _selectedTimeGrids.removeWhere((i) => i >= index);
  //     }
  //   } else {
  //     _selectedTimeGrids.sort();
  //     int min = _selectedTimeGrids.first;
  //     int max = _selectedTimeGrids.last;
  //
  //     if (index == min - 1) {
  //       _selectedTimeGrids.insert(0, index);
  //     } else if (index == max + 1) {
  //       _selectedTimeGrids.add(index);
  //     } else {
  //       ScaffoldMessenger.of(context)
  //         ..hideCurrentSnackBar()
  //         ..showSnackBar(
  //           SnackBar(
  //             content: Text(S.of(context).pleaseSelectTimeSlotsInSequence),
  //             behavior: SnackBarBehavior.floating,
  //             duration: Duration(seconds: 2),
  //           ),
  //         );
  //       return;
  //     }
  //   }
  //
  //   notifyListeners();
  // }
  void toggleTimeGrid(int index, BuildContext context) {
    if (_selectedTimeGrids.contains(index)) {
      _selectedTimeGrids.remove(index);
    } else {
      _selectedTimeGrids.add(index);
    }

    notifyListeners();
  }

// ----------------------------------------------------------------------------
// /////////////////
// bool isTimeSlotPast(int index) {
//   final now = DateTime.now();
//   final formatter = DateFormat('hh:mm a');
//   final slotTime = formatter.parse(availableTimes[index]);
//   final today = DateTime(now.year, now.month, now.day);
//   final slotDateTime = DateTime(today.year, today.month, today.day, slotTime.hour, slotTime.minute);
//   return slotDateTime.isBefore(now);
// }

// void toggleTimeGrid(int index, BuildContext context) {
//   if (_selectedTimeGrids.isEmpty) {
//     _selectedTimeGrids.add(index);
//   } else if (_selectedTimeGrids.contains(index)) {
//     _selectedTimeGrids.sort();
//     int min = _selectedTimeGrids.first;
//     int max = _selectedTimeGrids.last;

//     if (index == min) {
//       _selectedTimeGrids.remove(index);
//     } else if (index == max) {
//       _selectedTimeGrids.remove(index);
//     } else {
//       _selectedTimeGrids.removeWhere((i) => i >= index);
//     }
//   } else {
//     _selectedTimeGrids.sort();
//     int min = _selectedTimeGrids.first;
//     int max = _selectedTimeGrids.last;

//     if (index == min - 1) {
//       _selectedTimeGrids.insert(0, index);
//     } else if (index == max + 1) {
//       _selectedTimeGrids.add(index);
//     } else {
//       ScaffoldMessenger.of(context)
//         ..hideCurrentSnackBar()
//         ..showSnackBar(
//           SnackBar(
//             content: Text(S.of(context).pleaseSelectTimeSlotsInSequence),
//             behavior: SnackBarBehavior.floating,
//             duration: Duration(seconds: 2),
//           ),
//         );
//       return;
//     }
//   }

//   notifyListeners();
// }








  ////////////////
  List<String> selectedSportsList = [];
  void setSportsIdsList(List<String> index) {
    selectedSportsList = index;
    notifyListeners();
  }

  List<String> selectedAminitiesList = [];
  void setAminitiesIdsList(List<String> index) {
    selectedAminitiesList = index;
    notifyListeners();
  }

  final SearchCourtsApi _apiCall;
  bool _isLoading = false;
  String? _error;

  bool get isLoading => _isLoading;
  String? get error => _error;

  SearchCourtViewModel(this._apiCall);

//new searchCourt
  SearchFilterDataModel searchFilterDataModel = SearchFilterDataModel();

//   Future<SearchFilterDataModel?> newSearchCourt(
//       BookingRequest bookingRequest, BuildContext context) async {
//     try {
//       _isLoading = true;
//       notifyListeners();
//       log("start..... ");

//       final response =
//           await _apiCall.newSearchCourtApi(bookingRequest, context);
//       log("response..... ${response?.data}");
// if(response ==1){

//    _error = response.message ?? "No courts available.";
//    return null;
// }
//       if (response != null) {
//         searchFilterDataModel = response;

//         if (response.data != null && response.data!.isNotEmpty) {
//           _error = null;
//         } else {
//           _error = response.message ?? "No courts available.";
//         }
//         return response;
//       } else {
//         _error = "Something went wrong while contacting server.";
//         return null;
//       }
//     } catch (e) {
//       log("SearchCourt API error: $e");
//       _error = "Something went wrong.";
//       return null;
//     } finally {
//       _isLoading = false;
//       notifyListeners();
//     }
//   }
Future<SearchFilterDataModel?> newSearchCourt(
    BookingRequest bookingRequest, BuildContext context) async {
  try {
    _isLoading = true;
    notifyListeners();
    log("start..... ");

    final response = await _apiCall.newSearchCourtApi(bookingRequest, context);
    log("response..... ${response?.data}");

    if (response != null) {
      searchFilterDataModel = response;

      if (response.data != null && response.data!.isNotEmpty) {
        _error = null;
      } else {
        _error = response.message ?? l10n.of(context).noCourtsAvailable;
      }

      return response;
    } else {
      _error = l10n.of(context).noSlotsAvailableAtThisTime;
      return null;
    }
  } catch (e) {
    log("SearchCourt API error: $e");
    _error = l10n.of(context).somethingWentWrong;
    return null;
  } finally {
    _isLoading = false;
    notifyListeners();
  }
}

  //
  //
  //Future<SearchFilterDataModel?> newSearchCourt(
  //     BookingRequest bookingRequest, BuildContext context) async {
  //   try {
  //     _isLoading = true;
  //     notifyListeners();
  //     log("start..... ");

  //     final response =
  //         await _apiCall.newSearchCourtApi(bookingRequest, context);
  //     log("response..... ${response?.data}");

  //     if (response != null && response.data != null) {
  //       searchFilterDataModel = response;
  //       if (response.success == true) {
  //         _error = null;
  //       } else {
  //         _error = response.message ?? "No data found.";
  //       }
  //     } else {
  //       _error = response?.message ?? "Something went wrong.";
  //     }

  //     return searchFilterDataModel;
  //   } catch (e) {
  //     log("SearchCourt API error: $e");
  //     _error = "Something went wrong.";
  //     return null;
  //   } finally {
  //     _isLoading = false;
  //     notifyListeners();
  //   }
  // }

  // Future<bool> searchCourts(
  //   SearchCourtModel bookingRequest,
  //   BuildContext context,
  // ) async {
  //   log("bookng pay load ...${bookingRequest.amenityId}");
  //   _isLoading = true;
  //   _error = null;
  //   notifyListeners();

  //   try {
  //     final success = await _apiCall.searchCourtApi(bookingRequest, context);
  //     return success;
  //   } catch (e) {
  //     _error = e.toString();
  //     return false;
  //   } finally {
  //     _isLoading = false;
  //     notifyListeners();
  //   }
  // }

  // Future<void> filterBookingData(
  //   SearchCourtModel bookingRequest,
  //   BuildContext context,
  // ) async {
  //   log("filterBookingData payload: ${bookingRequest.amenityId}");

  //   _isLoading = true;
  //   _error = null;
  //   notifyListeners();

  //   try {
  //     await _apiCall.filterBookingData(bookingRequest);
  //   } catch (e) {
  //     _error = e.toString();
  //     log("Error in filterBookingData: $_error");
  //   } finally {
  //     _isLoading = false;
  //     notifyListeners();
  //   }
  // }

  void navigateToGuestBookingScreen(
      {required BuildContext context,
      required sportId,
      required sportName,
      required selectedTimeSlots,
      required date}) {
    Navigator.pushNamed(
      context,
      "/guestTabsScreen",
      arguments: {
        'sportId': sportId,
        'sportName': sportName,
        'selectedTimeSlots': selectedTimeSlots,
        'selectedDate': date
      },
    );
  }

  // final List<int> _selectedTimeGrids = [];

  // List<int> get selectedTimeGrids => _selectedTimeGrids;

  // void toggleTimeGrid(int index, BuildContext context) {
  //   if (_selectedTimeGrids.isEmpty) {
  //     _selectedTimeGrids.add(index);
  //   } else if (_selectedTimeGrids.contains(index)) {
  //     _selectedTimeGrids.sort();
  //     int min = _selectedTimeGrids.first;
  //     int max = _selectedTimeGrids.last;

  //     // If it's the first or last, allow normal deselection
  //     if (index == min) {
  //       _selectedTimeGrids.remove(index);
  //     } else if (index == max) {
  //       _selectedTimeGrids.remove(index);
  //     } else {
  //       // If it's a middle item, remove from that point onward
  //       _selectedTimeGrids.removeWhere((i) => i >= index);
  //     }
  //   } else {
  //     _selectedTimeGrids.sort();
  //     int min = _selectedTimeGrids.first;
  //     int max = _selectedTimeGrids.last;

  //     if (index == min - 1) {
  //       _selectedTimeGrids.insert(0, index);
  //     } else if (index == max + 1) {
  //       _selectedTimeGrids.add(index);
  //     } else {
  //       // Show a SnackBar for invalid selection
  //       // ScaffoldMessenger.of(context).hideCurrentSnackBar();

  //       ScaffoldMessenger.of(context)
  //         ..hideCurrentSnackBar()
  //         ..showSnackBar(
  //           SnackBar(
  //             content: Text(S.of(context).pleaseSelectTimeSlotsInSequence),
  //             behavior: SnackBarBehavior.floating,
  //             duration: Duration(seconds: 2),
  //           ),
  //         );
  //       return;
  //     }
  //   }

  //   notifyListeners();
  // }

  String? selectedSport ;
  List selectSportsList = [];
  void addSelectedSports(String sport) {
    if (selectSportsList.contains(sport)) {
    } else {
      selectSportsList.add(sport);
    }
    notifyListeners();
  }

  void removeSelectedSports(String sport) {
    if (selectSportsList.contains(sport)) {
      selectSportsList.remove(sport);
    } else {}
    notifyListeners();
  }

  String? selectedCourtSize;
  String? selectedAmenities;

  List<String> selectedAmenitie = [];

  List<String> get sportsList =>
      Helper.sports.map((sport) => sport.name).toList();
  List<SportList> get facilityList => Helper.sports;
  void selectFaciliity(SportList value, bool select) {
    for (var e in facilityList) {
      if (e.id == value.id) {
        e.isSelected = select;
        notifyListeners();
        break;
      }
    }
  }

  List<SportList> get selectedFacilityList =>facilityList.where((e) => e.isSelected).toList();
  List<AmenitiesList> get amenititesList => Helper.amenities.map((amenity) => AmenitiesList(id: amenity.id, name: amenity.name)).toList();
  // Set<int> selectedTimeGrids = {};

  // void toggleTimeGrid(int index) {
  //   if (selectedTimeGrids.contains(index)) {
  //     selectedTimeGrids.remove(index);
  //   } else {
  //     selectedTimeGrids.add(index);
  //   }
  //   notifyListeners();
  // }

  // List<String> availableTimes = [
  //   "12:00 AM",
  //   "01:00 AM",
  //   "02:00 AM",
  //   "03:00 AM",
  //   "04:00 AM",
  //   "05:00 AM",
  //   "06:00 AM",
  //   "07:00 AM",
  //   "08:00 AM",
  //   "09:00 AM",
  //   "10:00 AM",
  //   "11:00 AM",
  //   "12:00 PM",
  //   "01:00 PM",
  //   "02:00 PM",
  //   "03:00 PM",
  //   "04:00 PM",
  //   "05:00 PM",
  //   "06:00 PM",
  //   "07:00 PM",
  //   "08:00 PM",
  //   "09:00 PM",
  //   "10:00 PM",
  //   "11:00 PM",
  // ];

  @override
  void dispose() {
    resetFields();
    super.dispose();
  }

  void resetFields() {
    selectedSport = null;
    selectedCourtSize = null;
    selectedAmenitie.clear();
    selectedAmenitie = [];
    selectedAmenitie.clear();
    selectedAmenitie = [];
    notifyListeners();
  }

  // for guest public Challenege

  String? selectedPublicFltSport;
  String? selectedPublicFltSportID;
  String? selectedPublicFltTimeSlot;
  String? selectedPublicFltSkillLevel;
  void setSelectedPublicFltSport(String? value) {
    selectedPublicFltSport = value;

    notifyListeners();
  }

  void setSelectedPublicFltSkillLevel(String? value) {
    selectedPublicFltSkillLevel = value;

    notifyListeners();
  }

  void setSelectedPublicFltTimeSlot(String? value) {
    selectedPublicFltTimeSlot = value;

    notifyListeners();
  }

  void setSelectedSportId(String? value) {
    selectedPublicFltSportID = value;

    notifyListeners();
  }

//GET SPORT FOR CHALLENGE
  List<SportsListModel> sportsListModel = [];

  Future<void> getSportsDataApi({required BuildContext context}) async {
    notifyListeners();
    try {
      final response = await getSportsListDataApi();
      if (response.status == true) {
        sportsListModel = List<SportsListModel>.from(
                response.body['data'].map((x) => SportsListModel.fromJson(x)))
            .toList();
        notifyListeners();
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e, stackTrace) {
      debugPrint("stackTrace : $stackTrace");
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context).somethingsWentWronggetprofiledataapi);
    } finally {
      // isLoadingSports = false;
      notifyListeners();
    }
  }

  Future<ResponseHelper> getSportsListDataApi() async {
    final url = "common/sport-list";
    try {
      final ResponseHelper responseHelper = await RemoteService().get(url: url);
      return responseHelper;
    } catch (e) {
      log("error ====> $e");
      throw Exception('Failed to fetch users');
    }
  }

  String? selectedPublicSport;

  void setselectedPublicSport(String? value) {
    selectedPublicSport = value;

    notifyListeners();
  }
}

// show the amenity from the helper class
