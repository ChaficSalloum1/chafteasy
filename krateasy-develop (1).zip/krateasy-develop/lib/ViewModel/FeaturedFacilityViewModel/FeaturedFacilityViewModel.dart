import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

class FeaturedFacilityViewModel extends ChangeNotifier {
  bool isLoading = false;

  // final String clubName = "Edgbaston Priory Club";
  // final String description = "Premier racquets club hosting WTA Rothesay Classic; renowned for tennis & squash excellence.";
  // final String location = "Edgbaston, Birmingham";


  // final List<Map<String, dynamic>> facilities = [
  //   {
  //     "name": "Centre Court (Grass)",
  //     "price": "£20/hr",
  //     "rating": "4.7 (5 Reviews)",
  //     "image": "assets/icons/game.png",
  //   },
  //   {
  //     "name": "Indoor Court (Hard)",
  //     "price": "£15/hr",
  //     "rating": "4.5 (8 Reviews)",
  //     "image": "assets/icons/game.png",
  //   },
  // ];

  // void fetchFacilityDetails() {
  //   isLoading = true;
  //   notifyListeners();

  //   // Simulate API delay
  //   Future.delayed(Duration(seconds: 2), () {
  //     isLoading = false;
  //     notifyListeners();
  //   });
  // }

  void shareFacility(BuildContext context/*, String facilityName*/, String facilityUrl) {
    final String shareText = '$facilityUrl';
    Share.share(shareText);
  }
}
