// SplashViewModel.dart
import 'package:flutter/material.dart';
import 'dart:async';
import 'package:flutter/widgets.dart';
import 'package:kratEasyApp/API_CALLS/GlobalAPIUtils.dart';

class SplashViewModel extends ChangeNotifier {
  Future<void> startTimer(BuildContext context) async {
    String? authToken = await GlobalAPIUtils.getAuthToken();

    Future.delayed(Duration(seconds: 4), () {
      if (authToken == null || authToken.isEmpty) {
        Navigator.pushNamedAndRemoveUntil(
          context,
          '/onboarding',
          (route) => false,
        );
      } else {
        Navigator.pushReplacementNamed(context, "/dashboard");
      }
    });
  }
}
