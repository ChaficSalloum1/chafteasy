// onboarding_viewmodel.dart
import 'package:flutter/material.dart';
import 'package:kratEasyApp/GlobalUtils/app_navigation.dart';
import 'package:kratEasyApp/generated/l10n.dart';

class OnboardingViewModel extends ChangeNotifier {
  void navigateToGuestBookingScreen(BuildContext context) {
    Navigator.pushNamed(context, "/guestBookingScreen");
  }

  final PageController pageController = PageController();
  int currentPage = 0;

  List<String> images = [
    'assets/onboardingImg/onboarding2.png',
    'assets/onboardingImg/onboarding2.png',
  ];

  List<String> backgroundImages = [
    'assets/onboardingImg/onboarding.png',
    'assets/onboardingImg/onboarding.png',
  ];

  List<String> headTexts = [
    l10n.of(NavigationService.navigatorKey.currentContext!).welcomeEasybooking,
    l10n.of(NavigationService.navigatorKey.currentContext!).takeOnTheChallenge,
  ];

  List<String> subTexts = [
    l10n.of(NavigationService.navigatorKey.currentContext!).findBookYourGameInSeconds,
    '',
  ];
  List<String> midTexts = [
    l10n.of(NavigationService.navigatorKey.currentContext!).joinAChallengeCompeteProveYourSkillsCreateAChallenge
  ];

  List<String> lowTexts = [
    l10n.of(NavigationService.navigatorKey.currentContext!).selectYourSportChooseALocationPickADateTime,
    '',
  ];

  void setCurrentPage(int page) {
    currentPage = page;
    notifyListeners();
  }

  void navigateToLogin(BuildContext context) {
    Navigator.pushReplacementNamed(context, '/guestBookingScreen');
  }

  void chooseSportsToPlay(BuildContext context) {
    // Navigator.pushReplacementNamed(context, '/dashboard');
    // Navigator.pushReplacementNamed(context, '/chooseSportsToPlay');
    Navigator.pushNamed(context, '/chooseSportsToPlay');
  }

  // void chooseSportsToPlay(BuildContext context) {
  //   Navigator.pushReplacementNamed(context, '/login');
  // }
}
