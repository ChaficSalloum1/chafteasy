import 'package:flutter/material.dart';

class CompletedBookingViewModel extends ChangeNotifier {
  // void navigatorToViewDetailsScreen(BuildContext context){
  //   Navigator.pushNamed(context,'/viewCourtDetailsCompleteScreen');
  // }
  // void navigatorToViewChallengeBookingScreen(BuildContext context){
  //   Navigator.pushNamed(context,'/viewChallengeBookingCompleteScreen');
  // }
  // void navigateToFeedsScreen(BuildContext context){
  //   Navigator.pushNamed(context,"/feedsScreen");
  // }
  // bool isLoading = false;
  // List<String> imageUrls = [
  //   "https://randomuser.me/api/portraits/men/1.jpg",
  //   "https://randomuser.me/api/portraits/women/2.jpg",
  //   "https://randomuser.me/api/portraits/men/3.jpg",
  //   "https://randomuser.me/api/portraits/women/4.jpg",
  //   "https://randomuser.me/api/portraits/men/5.jpg",
  //   "https://randomuser.me/api/portraits/women/6.jpg",
  //   "https://randomuser.me/api/portraits/men/7.jpg",
  // ];
  // List<Map<String, dynamic>> openings = [
  //   {
  //     "challengeCode": "KE01842785",
  //     "court": "Court Name",
  //     "date": "09 Feb, 2025",
  //     "time": "09:00AM - 11:00AM",
  //     "location": "Edgbaston, Birmingham",
  //     "slots": "5",
  //     "type": "Free",
  //     "privacy": "Public",
  //     "image": "assets/icons/game.png",
  //     "icon": "assets/icons/game.png",
  //   },
  //   {
  //     "challengeCode": "KE01842785",
  //     "court": "Court Name",
  //     "date": "09 Feb, 2025",
  //     "time": "09:00AM - 11:00AM",
  //     "location": "Edgbaston, Birmingham",
  //     "slots": "5",
  //     "type": "Free",
  //     "privacy": "Public",
  //     "image": "assets/icons/game.png",
  //     "icon": "assets/icons/game.png",
  //   },
  // ];
}
