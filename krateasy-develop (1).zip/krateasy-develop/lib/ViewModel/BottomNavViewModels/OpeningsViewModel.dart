// import 'package:flutter/material.dart';

// class OpeningsViewModel extends ChangeNotifier {
//   bool isLoading = false;
//   // List<Map<String, dynamic>> openings = [
//   //   {
//   //     "club": "Edgbaston Priory Club",
//   //     "court": "Court Name",
//   //     "date": "09 Feb, 2025",
//   //     "time": "09:00AM - 11:00AM",
//   //     "location": "Edgbaston, Birmingham",
//   //     "slots": "5",
//   //     "type": "Free",
//   //     "privacy": "Public",
//   //     "image": "assets/icons/game.png",
//   //     "icon": "assets/icons/game.png"
//   //   },
//   //   {
//   //     "club": "Edgbaston Priory Club",
//   //     "court": "Court Name",
//   //     "date": "09 Feb, 2025",
//   //     "time": "09:00AM - 11:00AM",
//   //     "location": "Edgbaston, Birmingham",
//   //     "slots": "1",
//   //     "type": "Paid",
//   //     "privacy": "Private",
//   //     "image": "assets/icons/game.png",
//   //     "icon": "assets/icons/game.png"
//   //   },
//   //   {
//   //     "club": "Edgbaston Priory Club",
//   //     "court": "Court Name",
//   //     "date": "09 Feb, 2025",
//   //     "time": "09:00AM - 11:00AM",
//   //     "location": "Edgbaston, Birmingham",
//   //     "slots": "2",
//   //     "type": "Free",
//   //     "privacy": "Public",
//   //     "image": "assets/icons/game.png",
//   //     "icon": "assets/icons/game.png"
//   //   },
//   // ];
// }
