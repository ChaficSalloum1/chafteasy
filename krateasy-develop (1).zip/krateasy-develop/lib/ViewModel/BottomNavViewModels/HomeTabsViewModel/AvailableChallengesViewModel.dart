import 'package:flutter/cupertino.dart';

class AvailableChallengesViewModel extends ChangeNotifier {
  final String clubName = "Edgbastan Priory";

  final List<String> iconPaths = List.generate(
    4,
    (index) => "assets/icons/tennis.png",
  );

  void addChallenge(BuildContext context) {
    Navigator.pushNamed(context, '/createChallenge');
  }

  // void joinChallenge(BuildContext context) {
  //   Navigator.pushNamed(context, '/joinChallengeScreen');
  // }

  // List<Map<String, dynamic>> openings = [
  //   {
  //     "challengeCode": "KE01842785",
  //     "court": "Court Name",
  //     "date": "09 Feb, 2025",
  //     "time": "09:00AM - 11:00AM",
  //     "location": "Edgbaston, Birmingham",
  //     "slots": "5",
  //     "type": "Free",
  //     "privacy": "Public",
  //     "image": "assets/icons/game.png",
  //     "icon": "assets/icons/game.png",
  //   },
  //   {
  //     "challengeCode": "KE01842785",
  //     "court": "Court Name",
  //     "date": "09 Feb, 2025",
  //     "time": "09:00AM - 11:00AM",
  //     "location": "Edgbaston, Birmingham",
  //     "slots": "5",
  //     "type": "Free",
  //     "privacy": "Public",
  //     "image": "assets/icons/game.png",
  //     "icon": "assets/icons/game.png",
  //   },
  // ];

  // List<Map<String, dynamic>> openings2 = [
  //   {
  //     "club": "Edgbaston Priory Club",
  //     "court": "Court Name",
  //     "date": "09 Feb, 2025",
  //     "time": "09:00AM - 11:00AM",
  //     "location": "Edgbaston, Birmingham",
  //     "slots": "5",
  //     "type": "Free",
  //     "privacy": "Public",
  //     "image": "assets/icons/game.png",
  //     "icon": "assets/icons/game.png",
  //   },
  // ];

  // List<String> imageUrls = [
  //   "https://randomuser.me/api/portraits/men/1.jpg",
  //   "https://randomuser.me/api/portraits/women/2.jpg",
  //   "https://randomuser.me/api/portraits/men/3.jpg",
  //   "https://randomuser.me/api/portraits/women/4.jpg",
  //   "https://randomuser.me/api/portraits/men/5.jpg",
  //   "https://randomuser.me/api/portraits/women/6.jpg",
  //   "https://randomuser.me/api/portraits/men/7.jpg",
  // ];
}
