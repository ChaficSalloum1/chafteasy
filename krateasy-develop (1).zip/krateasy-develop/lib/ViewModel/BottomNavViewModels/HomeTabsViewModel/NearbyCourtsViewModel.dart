import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:kratEasyApp/API_CALLS/GlobalAPIUtils.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/GlobalUtils/app_navigation.dart'
    show NavigationService;
import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/Models/available_court_challenge.dart';
import 'package:kratEasyApp/Models/search_Filter_Data_Model.dart';
import 'package:kratEasyApp/Models/serach_Court_Payload_Model.dart';
import 'package:kratEasyApp/repository/available_challenge_repository.dart';
import 'package:kratEasyApp/services/remote/api_ends.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:http/http.dart' as http;

class NearbyCourtsViewModel extends ChangeNotifier {
  final String clubName = "Edgbastan Priory";

  final List<String> iconPaths = List.generate(
    4,
    (index) => "assets/icons/tennis.png",
  );

  void addChallenge(BuildContext context) {
    Navigator.pushNamed(context, '/createChallenge');
  }

  // void joinChallenge(BuildContext context) {
  //   Navigator.pushNamed(context, '/joinChallengeScreen');
  // }

  bool _istapLoading = false;

  bool get isTapLoading => _istapLoading;

  void setLoading(bool value) {
    _istapLoading = value;
    notifyListeners();
  }

  final homeModel = Provider.of<HomeViewModel>(
      NavigationService.navigatorKey.currentContext!);
  List<Map<String, dynamic>> openings = [
    {
      "challengeCode": "KE01842785",
      "court": "Court Name",
      "date": "09 Feb, 2025",
      "time": "09:00AM - 11:00AM",
      "location": "Edgbaston, Birmingham",
      "slots": "5",
      "type": "Free",
      "privacy": "Public",
      "image": "assets/icons/game.png",
      "icon": "assets/icons/game.png",
    },
    {
      "challengeCode": "KE01842785",
      "court": "Court Name",
      "date": "09 Feb, 2025",
      "time": "09:00AM - 11:00AM",
      "location": "Edgbaston, Birmingham",
      "slots": "5",
      "type": "Free",
      "privacy": "Public",
      "image": "assets/icons/game.png",
      "icon": "assets/icons/game.png",
    },
  ];

  List<Map<String, dynamic>> openings2 = [
    {
      "club": "Edgbaston Priory Club",
      "court": "Court Name",
      "date": "09 Feb, 2025",
      "time": "09:00AM - 11:00AM",
      "location": "Edgbaston, Birmingham",
      "slots": "5",
      "type": "Free",
      "privacy": "Public",
      "image": "assets/icons/game.png",
      "icon": "assets/icons/game.png",
    },
  ];

  List<String> imageUrls = [
    "https://randomuser.me/api/portraits/men/1.jpg",
    "https://randomuser.me/api/portraits/women/2.jpg",
    "https://randomuser.me/api/portraits/men/3.jpg",
    "https://randomuser.me/api/portraits/women/4.jpg",
    "https://randomuser.me/api/portraits/men/5.jpg",
    "https://randomuser.me/api/portraits/women/6.jpg",
    "https://randomuser.me/api/portraits/men/7.jpg",
  ];

  // Store selected index for each card using a map
  Map<int, int> _selectedIndexes = {};

  List<String> times = [
    "08:00AM",
    "09:00AM",
    "10:00AM",
    "11:00AM",
    "12:00PM",
    "01:00PM"
  ];

  // Get the selected index for a specific card
  int getSelectedIndex(int cardIndex) {
    return _selectedIndexes[cardIndex] ?? -1;
  }

  // Update the selected index for a specific card
  void updateSelectedIndex(int cardIndex, int timeIndex) {
    _selectedIndexes[cardIndex] = timeIndex;
    notifyListeners();
  }

  AvailableChallengeRepository repository = AvailableChallengeRepository();
  List<AvailableNearbyCourtsModel> availableCourtChallengeData = [];
  bool isLoading = false;
  
  final String? baseUrl = GlobalAPIUtils.baseUrl;
  SearchFilterDataModel? searchFilterDataModel = SearchFilterDataModel();

  Future<SearchFilterDataModel?> newSearchCourtApiForHome(
      BuildContext context) async {
    final Uri url =
        Uri.parse('${baseUrl!}${ApiEnds.instance.availableCourtChallenge}');
isLoading=true;
notifyListeners();

    // final Uri uri = Uri.parse(url);
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      var lat = await prefs.getDouble("current_lat");
      var long = await prefs.getDouble("current_long");
 var timeZone =
                                        await prefs.getString("timeZone") ??
                                            "Asia/Kolkata";
      var body;
      // filter case
      print("====filter");
      if (homeModel.isHomeFilter == true) {
        body = {
          "date": homeModel.dateController.text,
          "latitude": lat,
          "longitude": long,
          "time": homeModel.selectedTimeSlot,
          "sport_id": homeModel.selectedSport,
          "amenity_id": homeModel.selectedAmenities,
          "timeZone": timeZone,
        };
      } else {
        body = {
          "date": DateFormat("dd-MM-yyyy").format(DateTime.now()),
          "latitude": lat,
          "longitude": long,
          "timeZone": timeZone,
        };
      }
      print("c $body");
      print("body for available courts is (jsonEncode)${jsonEncode(body)}");

      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode(body),
      );

      final jsonData = jsonDecode(response.body);
      print("fghjkjson body.....$jsonData");

      if (response.statusCode == 200) {
        print("success");

        return SearchFilterDataModel.fromJson(
            jsonData); // always return the model
      } else {
        print('.........Server error: ${response.statusCode}');
        return null;
      }
    } catch (e) {
      print('........API Error: $e');
      return null;
    }finally{
      isLoading=false;
      notifyListeners();

    }
  }

  Future<SearchFilterDataModel?> newSearchCourtApiForHome2(
      {required String date,
      String? time,
      required String? sportId,
      String? amenityId,
      required BuildContext context}) async {
    final Uri url =
        Uri.parse('${baseUrl!}${ApiEnds.instance.availableCourtChallenge}');
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      var lat = await prefs.getDouble("current_lat");
      var long = await prefs.getDouble("current_long");
      var body = {
        "date": date,
        "latitude": lat,
        "longitude": long,
        "time": time,
        "sport_id": sportId,
        "amenity_id": amenityId,
      };

      print("body for available courts is $body");
      print("body for available courts is (jsonEncode)${jsonEncode(body)}");

      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode(body),
      );

      final jsonData = jsonDecode(response.body);
      print("fghjkjson body.....$jsonData");

      if (response.statusCode == 200) {
        print("success");

        return SearchFilterDataModel.fromJson(
            jsonData); // always return the model
      } else {
        print('.........Server error: ${response.statusCode}');
        return null;
      }
    } catch (e) {
      print('........API Error: $e');
      return null;
    }
  }
}
