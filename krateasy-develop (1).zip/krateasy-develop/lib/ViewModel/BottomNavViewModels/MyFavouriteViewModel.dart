import 'package:flutter/material.dart';
import 'package:kratEasyApp/GlobalUtils/app_navigation.dart';
import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/Models/favourite_court_model.dart';
import 'package:kratEasyApp/Models/favourite_player.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/repository/favourite_court_repo.dart';

class MyFavouriteViewModel extends ChangeNotifier {
  /// ----------------------  apis response handle
  FavouriteRepository repository = FavouriteRepository();
  List<ResultModel> favouriteCourtData = [];
  List<FavouritePlayerModel> favouritePlayerData = [];
  bool isLoading = false;


  Future<void> getFavouriteListData({required BuildContext context}) async {
    isLoading = true;
    try {
      final response = await repository.getFavouriteCourtApi();
      print("onside");
      if (response.status == true) {
        print("response.body is ${response.body}");
        favouriteCourtData = List<ResultModel>.from(
            response.body.map((x) => ResultModel.fromJson(x))).toList();
        notifyListeners();
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e, stackTrace) {
      print("stackTrace : $stackTrace");
      print("stackTrace : $e");
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(NavigationService.navigatorKey.currentContext!).somethingsWentWronggetfavouritelistdata);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> getFavouritePlayerData({required BuildContext context}) async {
    isLoading = true;
    notifyListeners();
    try {
      // Make the API call
      final response = await repository.getFavouritePlayerApi();

      print("Response Body: ${response.body}");

      if (response.status == true) {
        if (response.body != null) {
          print("response is ${response.body}");

          // Convert raw response into list of models
          List<FavouritePlayerModel> tempList =
          List<FavouritePlayerModel>.from(
            response.body.map((x) => FavouritePlayerModel.fromJson(x)),
          );

          // Use a map to remove duplicates based on user_id
          final Map<String, FavouritePlayerModel> uniqueMap = {};
          for (var player in tempList) {
            uniqueMap[player.userId??""] = player;
            // 👆 This ensures only the last entry for a userId is kept
          }

          // Convert back to list
          favouritePlayerData = uniqueMap.values.toList();

          notifyListeners();
        } else {
          showSnackbar(
            context: NavigationService.context,
            message: l10n.of(context).noFavoritePlayerDataFound,
          );
        }
      }

    } catch (e, stackTrace) {
      // Handle errors and show snackbar
      print("stackTrace : $stackTrace");
      showSnackbar(
        context: NavigationService.context,
        message: l10n.of(context).somethingWentWrongGetfavouriteplayerdata,
      );
    } finally {
      // Set isLoading to false and notify listeners
      isLoading = false;
      notifyListeners();
    }
  }

  ///---------------------------------------------------
  // favourite courts
  List<int> courtsIndex = List.filled(11, 0);
  void updateCourtsIndex(int index, ind) {
    courtsIndex[index] = ind;
    notifyListeners();
  }

  // Sample data of favorite players
  // final List<Player> _favoritePlayers = [
  //   Player(
  //       name: 'John Doe',
  //       contactNumber: '+1 234 567 890',
  //       imagePath: 'assets/icons/men.png'),
  //   Player(
  //       name: 'Jane Smith',
  //       contactNumber: '+1 234 567 891',
  //       imagePath: 'assets/icons/men.png'),
  //   Player(
  //       name: 'John Doe',
  //       contactNumber: '+1 234 567 890',
  //       imagePath: 'assets/icons/men.png'),
  //   Player(
  //       name: 'Jane Smith',
  //       contactNumber: '+1 234 567 891',
  //       imagePath: 'assets/icons/men.png'),
  //   Player(
  //       name: 'John Doe',
  //       contactNumber: '+1 234 567 890',
  //       imagePath: 'assets/icons/men.png'),
  //   Player(
  //       name: 'Jane Smith',
  //       contactNumber: '+1 234 567 891',
  //       imagePath: 'assets/icons/men.png'),
  //   Player(
  //       name: 'John Doe',
  //       contactNumber: '+1 234 567 890',
  //       imagePath: 'assets/icons/men.png'),
  //   Player(
  //       name: 'Jane Smith',
  //       contactNumber: '+1 234 567 891',
  //       imagePath: 'assets/icons/men.png'),
  //   Player(
  //       name: 'Jane Smith',
  //       contactNumber: '+1 234 567 891',
  //       imagePath: 'assets/icons/men.png'),
  //   Player(
  //       name: 'John Doe',
  //       contactNumber: '+1 234 567 890',
  //       imagePath: 'assets/icons/men.png'),
  //   Player(
  //       name: 'Jane Smith',
  //       contactNumber: '+1 234 567 891',
  //       imagePath: 'assets/icons/men.png'),
  //   Player(
  //       name: 'John Doe',
  //       contactNumber: '+1 234 567 890',
  //       imagePath: 'assets/icons/men.png'),
  //   Player(
  //       name: 'Jane Smith',
  //       contactNumber: '+1 234 567 891',
  //       imagePath: 'assets/icons/men.png'),
  //   Player(
  //       name: 'John Doe',
  //       contactNumber: '+1 234 567 890',
  //       imagePath: 'assets/icons/men.png'),
  //   Player(
  //       name: 'Jane Smith',
  //       contactNumber: '+1 234 567 891',
  //       imagePath: 'assets/icons/men.png'),
  // ];

  // List<Player> get favoritePlayers => _favoritePlayers;

  // You can add methods to update the player list if needed
  // void addPlayer(Player player) {
  //   _favoritePlayers.add(player);
  //   notifyListeners();
  // }

  // void removePlayer(Player player) {
  //   _favoritePlayers.remove(player);
  //   notifyListeners();
  // }
}

class Player {
  final String name;
  final String contactNumber;
  final String imagePath;

  Player(
      {required this.name,
      required this.contactNumber,
      required this.imagePath});
}
