import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:kratEasyApp/Models/contact_model.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/GlobalUtils/app_routes.dart';
import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/Models/SlotsResponseModel.dart';
import 'package:kratEasyApp/Models/complete_Challenge_Detail_Model.dart';
import 'package:kratEasyApp/Models/sports_list_model.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/paymentprovider.dart';
import 'package:kratEasyApp/repository/available_challenge_repository.dart';
import 'package:kratEasyApp/services/remote/api_ends.dart';
import 'package:kratEasyApp/services/remote/remote_service.dart';
import 'package:kratEasyApp/services/remote/responce_helper.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../Models/favourite_player.dart';
import '../../../payment.dart';

class CreateChallengeViewModel extends ChangeNotifier {
  bool _iscourtLoading = false;

  bool get iscourtLoading => _iscourtLoading;

  void setCourtLoading(bool value) {
    _iscourtLoading = value;
    notifyListeners();
  }

  int selectTimeGrid = 0;

  void selectedTimeGrid(int index) {
    selectTimeGrid = index;
    notifyListeners();
  }

  bool isRecorded = false;

  void setRecorded(bool value) {
    isRecorded = value;
    notifyListeners();
  }

  String? selectedSports;

  void changeSelectedSports(String sport) {
    selectedSports = sport;
    notifyListeners();
  }

  String? _selectcourt;

  String? get selectcourt => _selectcourt;

  void setcourt(String court) {
    _selectcourt = court;
    notifyListeners();
  }

  List<String> discriptionList = ['Beginner', 'Intermediate', 'Advanced'];
  String? selectedDiscription;
  final TextEditingController joinRequestController = TextEditingController();

  void changeSelectedDiscription(String discription) {
    selectedDiscription = discription;
    notifyListeners();
  }

  String? selectedTime;
  bool isPublic = false;
  bool isSplit = false;

  void selectTime(String time) {
    selectedTime = time;
    notifyListeners();
  }

  TextEditingController searchFacilityController = TextEditingController();
  TextEditingController challengeCreateFacilityController =
      TextEditingController();

  String selectedFacilityId = "";

  String selectedFacilityName = "";
  String selectedCourtId = "";

  void updateSelectedFacility(
      {required String id, required String name, required String courtId}) {
    selectedFacilityId = id ?? "";
    selectedCourtId = courtId ?? "";
    selectedFacilityName = name ?? "";
    searchFacilityController.text = name ?? "";
    notifyListeners();
  }

  void addFriends() {}

  void setChallengeType({required bool isPublic}) {
    this.isPublic = isPublic;

    if (isPublic == true) {
      userData.clear();
      notifyListeners();
    }
    isSplit = false;
    notifyListeners();
  }

  void setSplitType({required bool isSplit}) {
    this.isSplit = isSplit;
    if (isSplit == true) {
      // removeAllUserData();
    }
    notifyListeners();
  }

  void navigateToChallengeSuccess(BuildContext context) {
    Navigator.pushNamed(context, '/successPayment');
  }

  // void navigateToFacilitiesListingSuccess(BuildContext context) {
  //   Navigator.pushNamed(context, "/facilitiesListingScreen");
  // }

  void navigateToPaymentScreenWithChallengeValidation(
      BuildContext context, amount, String type) {
    if (selectedSport == null) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(l10n.of(context).pleaseSelectASportFirst)));
      return;
    }
    if (selectedSport == "") {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(l10n.of(context).pleaseSelectASportFirst)));
      return;
    }
    if (challengeCreateFacilityController.text.trim().isEmpty ||
        courtId == "" ||
        facilityId == "") {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(l10n.of(context).pleaseSelectAFacilityFirst)));
      return;
    }
    if ((userData.isEmpty && slotPrice > 0.0) ||
        (userData.isNotEmpty && friendsPrice > 0.0)) {
      Navigator.pushNamed(
        context,
        RouteNames.guestPayment,
        arguments: {"forChallenge": true, "amount": amount, "type": type},
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(l10n.of(context).invalidAmountPleaseTryAgainLater)),
      );
    }
  }

  bool isLoadingCreateChallenge = false;

  AvailableChallengeRepository repository = AvailableChallengeRepository();

  void clearCreateChallengeData() {
    selectedFacilityId = "";
    selectedSports = null;
    selectedCourtId = "";
    joinRequestController.text = "2";
    isPublic = false;
    searchFacilityController.clear();
    final bookingProvider =
        Provider.of<BookingProvider>(NavigationService.context, listen: false);
    bookingProvider.selectedSlotForBooking = null;
    bookingProvider.selectedDate = DateTime.now();
  }

  // add friend
  /// add User data
  List<ContactModel> userData = [];

  calculatePrice() {
    int totalFriends = userData.length;
    if (totalFriends > 0) {
      friendsPrice = slotPrice / (totalFriends + 1);
    } else {
      friendsPrice = slotPrice;
    }
    notifyListeners();
  }

  void addUserData({required ContactModel user}) {
    if (!userData.any((element) => element.id.contains(user.id))) {
      userData.add(user);

      calculatePrice(); // Calculate price per person
      // calculatePerPersonPrice(); // Recalculate price
      notifyListeners(); // Notify UI
    }
  }

  void removeAllUserData() {
    userData.clear();
    notifyListeners(); // Notify UI
  }

  void removeUserData({required ContactModel user}) {
    userData.remove(user);

    calculatePrice(); // Calculate price per person
    // calculatePerPersonPrice(); // Recalculate price
    notifyListeners();
  }

  Future<void> getContacts(BuildContext context) async {
    bool isGranted = await FlutterContacts.requestPermission();

    if (isGranted) {
      // ✅ Permission granted
      List<Contact> contactList = await FlutterContacts.getContacts(
        withProperties: true,
        withPhoto: true,
      );
      // Assign to your variables
      contacts = contactList;
      searchContacts = contactList;
    } else {
      // ❌ Permission denied
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text("Contact Permission Required"),
          content: Text(
              "This app needs contact access to show your contact list. Please grant access from settings."),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: Text("Cancel"),
            ),
            TextButton(
              onPressed: () async {
                Navigator.of(ctx).pop();
                await openAppSettings(); // from permission_handler
              },
              child: Text("Open Settings"),
            ),
          ],
        ),
      );
    }
  }

  // Future<void> getContacts(BuildContext context) async {
  //   if (await FlutterContacts.requestPermission()) {
  //     List<Contact> contactList = await FlutterContacts.getContacts(
  //         withProperties: true, withPhoto: true);
  //     contacts = contactList;
  //     searchContacts = contactList;
  //   } else {
  //     showSnackbar(
  //         context: NavigationService.context,
  //         message: S.of(context).contactsPermissionIsRequired);
  //   }
  //   notifyListeners();
  // }

  List<Contact> contacts = [];
  List<Contact> searchContacts = [];

  String searchText = '';

  void searchContactList(String value) {
    if (value.trim().isEmpty) {
      searchContacts = List.from(contacts);
      searchText = value.trim();
    } else {
      searchContacts = contacts
          .where((contact) => (contact.displayName ?? '')
              .toLowerCase()
              .contains(value.toLowerCase()))
          .toList();
    }
    notifyListeners();
  }

  CompleteChallengeDetailModel? completeChallengeDetailModel;

  Future<void> createChallenge({
    required BuildContext context,
    required String amount,
    required String name,
    required String sessonid,
    required String mobile,
    required String email,
    bool? thisIsSplit,
  }) async {
    isLoadingCreateChallenge = true;
    notifyListeners();
    context.read<AvailableChallengeGuestViewModel>().settime("");
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var timeZone = await prefs.getString("timeZone") ?? "Asia/Kolkata";
    try {
      final List<Map<String, dynamic>> friendsList = userData.map((contact) {
        final phoneNumber = contact.phoneNumber.trim();
        final hasCountryCode = phoneNumber.startsWith('+');

        String mobileNumber;
        String countryCode;

        if (hasCountryCode) {
          final spaceIndex = phoneNumber.indexOf(' ');
          if (spaceIndex != -1) {
            countryCode = phoneNumber.substring(1, spaceIndex);
            mobileNumber = phoneNumber.substring(spaceIndex + 1);
          } else {
            countryCode = phoneNumber.substring(1, 3);
            mobileNumber = phoneNumber.substring(3);
          }
        } else {
          // countryCode = '0'; // Default or fallback
          countryCode = context
              .read<MyAccountViewModel>()
              .countryCode; // Default or fallback
          mobileNumber = phoneNumber;
        }

        return {
          "name": contact.name,
          "mobile_number": mobileNumber,
          "split_amount": friendsPrice.toStringAsFixed(2),
          "country_code": countryCode,
        };
      }).toList();

      final reqBody = {
        // "facility_id": facilityId,
        "facility_id": id,
        "sport_id": selectedSport,
        "court_id": courtId,
        "slot_id": selectedSlotIds,
        "is_public": isPublic,
        "skill_level": selectedSkillLevel,
        "timeZone": timeZone,
        "max_player": isPublic
            ? joinRequestController.text
            : userData.isNotEmpty
                ? friendsList.length + 1
                : joinRequestController.text,
        "date": DateFormat('dd-MM-yyyy').format(selectedDate),
        if (userData.isNotEmpty) "friends": friendsList,

        "transactionId": "TransactionId",

        "checkoutSessionId": context.read<PaymentProvider>().sessionid,
        "isSplit": thisIsSplit ?? isSplit,
        "amount": amount,
        "payer": {
          "phone": mobile,
          "email": email,
          "fullName": name,
        },
      };

      print("reqbody ....$reqBody");
      print("dattte ....$selectedDate");

      final response = await repository.createChallengeApi(reqBody);

      print("my responsse ${response.status}");
      print("my body msg  ${response.message}");
      printLog("response >>> ${response.status}  > ${response.body}");
      if (response.body["status"] == true) {
        print(
            " response.body['data']?['booking_id']   ${response.body['data']?['booking_id']}");
        final rawUtcString = response.body["data"]["bookingStartTime"];

        if (rawUtcString != null) {
          final utcDate = DateTime.parse(rawUtcString).toUtc(); // ensure UTC
          final localDate = utcDate.toLocal(); // convert to local time zone
          final formattedDateTime =
              DateFormat('MMM d, yyyy h:mm a').format(localDate);
          print("formattedDateTime: $formattedDateTime");

          context
              .read<AvailableChallengeGuestViewModel>()
              .settime(formattedDateTime);
        }

        // context.read<AvailableChallengeGuestViewModel>().settime(response.body['data']['bookingStartTime']);
        try {
          print("tried this ");
          completeChallengeDetailModel =
              CompleteChallengeDetailModel.fromJson(response.body);
        } catch (e, s) {
          print("ccccc-----${e}");
          print("ccccc-----${s}");
        }

        // Navigator.push(
        //   context,
        //   MaterialPageRoute(
        //     builder: (_) => VivaWebViewScreen(
        //       checkoutUrl: response.body['data']?['paymentUrl'],
        //       orderCode: response.body['data']?['orderCode'],
        //       amount: amount,
        //       isSplit: isSplit,
        //     ),
        //   ),
        // );
        Navigator.pushNamed(
            NavigationService.context, "/guestSuccessPaymentScreen",
            arguments: {
              "bookingId": response.body['data']?['booking_id'] ?? "",
              "amount": amount
            });
        isLoadingCreateChallenge = false;
        challengeCreateFacilityController.clear();
        facilityId = "";
        selectedSport = null;
        courtId = "";
        selectedSlotIds.clear();
        isPublic = false;
        selectedSkillLevel = null;
        userData.clear();
      } else if (response.status == false) {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e) {
      showSnackbar(context: NavigationService.context, message: e.toString());
    } finally {
      isLoadingCreateChallenge = false;
      notifyListeners();
    }
  }

  String? selectedSport;
  String? selectedTimeSlot;
  String? selectedSkillLevel;

  void setSelectedSport(String? value) {
    // getSlots();

    challengeCreateFacilityController.clear();
    facilityId = "";
    courtId = "";
    searchFacilityController.clear();
    selectedSport = value;

    notifyListeners();
  }

  void setSelectedSkillLevel(String? value) {
    selectedSkillLevel = value;

    notifyListeners();
  }

  void setSelectedTimeSlot(String? value) {
    selectedTimeSlot = value;

    notifyListeners();
  }

//sport
  bool isLoadingSports = false;

  Future<ResponseHelper> getSportsListDataApi(BuildContext context) async {
    final url = ApiEnds.instance.sportsList;
    try {
      final ResponseHelper responseHelper = await RemoteService().get(url: url);
      return responseHelper;
    } catch (e) {
      print("ldhasdjh;aerror ====> $e");
      throw Exception(l10n.of(context).failedToFetchUsers);
    }
  }

  List<SportsListModel> sportsListModel = [];

  Future<void> getSportsDataApi(BuildContext context) async {
    isLoadingSports = true;
    notifyListeners();
    try {
      final response = await getSportsListDataApi(context);
      if (response.status == true) {
        sportsListModel = List<SportsListModel>.from(
                response.body['data'].map((x) => SportsListModel.fromJson(x)))
            .toList();
        notifyListeners();
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e, stackTrace) {
      debugPrint("stackTrace : $stackTrace");
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context).somethingsWentWronggetprofiledataapi);
    } finally {
      isLoadingSports = false;
      notifyListeners();
    }
  }

//get slot s
  AvailableSlots? selectedSlotForBooking;
  DateTime selectedDate = DateTime.now();
  List<String> selectedSlotIds = [];

  SlotsResponseModel? slotsResponseModel = SlotsResponseModel(); // your model

  double myPrice = 0.0;
  double friendsPrice = 0.0;
  double slotPrice = 0.0;
  int totalHours = 0;

  List<AvailableSlots> availableSlots = [];

// You can create a helper function to calculate the difference
  String getTimeDifference(String start, String end) {
    final format = DateFormat("hh:mm a");
    final startTime = format.parse(start);
    final endTime = format.parse(end);
    final difference = endTime.difference(startTime);
    return "${difference.inMinutes} minutes";
  }

  // void updateSelectedSlot1(AvailableSlots slot, BuildContext context) {
  //   final idx = availableSlots.indexWhere((s) => s.sId == slot.sId);
  //   if (idx < 0) return;
  //
  //   List<int> selIdx = selectedSlotIds
  //       .map((id) => availableSlots.indexWhere((s) => s.sId == id))
  //       .where((i) => i >= 0)
  //       .toList()
  //     ..sort();
  //
  //   bool isSelected = selectedSlotIds.contains(slot.sId);
  //
  //   void showMsg(String msg) {
  //     ScaffoldMessenger.of(context)
  //       ..hideCurrentSnackBar()
  //       ..showSnackBar(SnackBar(content: Text(msg)));
  //   }
  //
  //   if (isSelected) {
  //     int first = selIdx.first;
  //     int last = selIdx.last;
  //
  //     if (idx == first || idx == last) {
  //       selectedSlotIds.remove(slot.sId);
  //     } else {
  //       showMsg(S.of(context).youCanOnlyDeselectTheFirstOrLastSlot);
  //       return;
  //     }
  //   } else {
  //     if (selIdx.isEmpty || idx == selIdx.first - 1 || idx == selIdx.last + 1) {
  //       selectedSlotIds.add(slot.sId!);
  //     } else {
  //       showMsg(S.of(context).pleaseSelectSlotsInOrder);
  //       return;
  //     }
  //   }
  //
  //   calculateTotalPrice();
  //   calculateTotalHours();
  //   calculatePrice();
  //   notifyListeners();
  // }

  void updateSelectedSlot1(AvailableSlots slot, BuildContext context) {
    final idx = availableSlots.indexWhere((s) => s.sId == slot.sId);
    if (idx < 0) return;

    bool isSelected = selectedSlotIds.contains(slot.sId);

    // Toggle selection freely (no sequence rules)
    if (isSelected) {
      selectedSlotIds.remove(slot.sId);
    } else {
      selectedSlotIds.add(slot.sId!);
    }

    // Update total slot price
    slotPrice = selectedSlotIds
        .map((id) =>
            availableSlots
                .firstWhere(
                  (s) => s.sId == id,
                  orElse: () => AvailableSlots(price: 0.0),
                )
                .price ??
            0.0)
        .fold(0.0, (a, b) => a + b);

    calculateTotalPrice();
    calculateTotalHours();
    calculatePrice();
    notifyListeners();
  }

  void calculateTotalPrice() {
    slotPrice = 0.0;
    for (var slot in availableSlots) {
      if (selectedSlotIds.contains(slot.sId)) {
        slotPrice += (slot.price ?? 0);
      }
    }
    notifyListeners();
  }

  void calculateTotalHours() {
    totalHours = selectedSlotIds.length;
    notifyListeners();
  }

  void updateSelectedSlot(
    AvailableSlots? slot,
  ) {
    selectedSlotForBooking = slot;
    printLog("Selected SLot  :${slot}");
    notifyListeners();
  }

  void clearSlot() {
    selectedSlotForBooking = null;
    notifyListeners();
  }

  bool getSlotsloadig = false;
  String courtId = "";
  String facilityId = "";

  String _id = "";

  String get id => _id;

  // setid(String ids){
  //   _id =ids;
  //   notifyListeners();
  // }

  void setfacilityiid(String value) {
    facilityId = value;
    _id = value;
    notifyListeners();
  }

  Future<void> getSlotsNew(BuildContext context, String id) async {
    slotsResponseModel = null;
    getSlotsloadig = true;
    notifyListeners();

    try {
      // Wait for SharedPreferences and fetch timezone
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? timeZone = prefs.getString("timeZone");

      // If timezone is null, wait or assign a default
      if (timeZone == null || timeZone.isEmpty) {
        timeZone = "Asia/Kolkata"; // default fallback
      }

      // Format date
      String formattedDate = DateFormat('dd-MM-yyyy').format(selectedDate);

      // Prepare request payload
      Map<String, dynamic> map = {
        "date": formattedDate,
        "court_id": courtId,
        // "facility_id": facilityId,
        "facility_id": "",
        "timeZone": timeZone,
      };

      final response = await getSlotsApi(map, returnData: true);

      if (response.status == true) {
        slotsResponseModel = SlotsResponseModel.fromJson(response.body);
        availableSlots = slotsResponseModel?.data?.availableSlots ?? [];

        if (availableSlots.isNotEmpty) {
          selectedSlotIds.add(availableSlots.first.sId!); // Select first slot
          selectedSlotIds.clear();
          calculateTotalPrice();
          calculateTotalHours();
        }
      } else {
        showSnackbar(
          context: NavigationService.context,
          message: response.message.toString(),
        );
      }
    } catch (e, stackTrace) {
      print("getSlotsNew error: $e");
      print("stackTrace : $stackTrace");
      showSnackbar(
        context: NavigationService.context,
        message: l10n.of(context).somethingWentWrongGetslots,
      );
    } finally {
      getSlotsloadig = false;
      notifyListeners();
    }
  }

// Future<void> getSlotsNew(BuildContext context) async {
  //   slotsResponseModel = null;
  //   getSlotsloadig = true;
  //   notifyListeners();
  //   print("selectedDate$selectedDate");
  //         SharedPreferences prefs = await SharedPreferences.getInstance();
  //     var timeZone = prefs.getString("timeZone") ?? "Asia/Kolkata";

  //   try {
  //     String formattedDate = DateFormat('dd-MM-yyyy').format(selectedDate);
  //     Map<String, dynamic> map = {
  //       "date": formattedDate,
  //       "court_id": courtId,
  //       "facility_id": facilityId,
  //       "timeZone":timeZone
  //     };

  //     final response = await getSlotsApi(map, returnData: true);

  //     if (response.status == true) {
  //       slotsResponseModel = SlotsResponseModel.fromJson(response.body);

  //       availableSlots = slotsResponseModel?.data?.availableSlots ?? [];

  //       if (availableSlots.isNotEmpty) {
  //         selectedSlotIds.clear();
  //         selectedSlotIds.add(availableSlots.first.sId!); // Select first slot
  //         calculateTotalPrice();
  //         calculateTotalHours();
  //       }
  //     } else {
  //       showSnackbar(
  //         context: NavigationService.context,
  //         message: response.message.toString(),
  //       );
  //     }
  //   } catch (e, stackTrace) {
  //     print("stackTrace : $stackTrace");
  //     showSnackbar(
  //       context: NavigationService.context,
  //       message: S.of(context).somethingWentWrongGetslots,
  //     );
  //   } finally {
  //     getSlotsloadig = false;
  //     notifyListeners();
  //   }
  // }

  Future<ResponseHelper> getSlotsApi(var body,
      {bool returnData = false}) async {
    print("in view model");
    final url = ApiEnds.instance.getSlots;
    try {
      final ResponseHelper responseHelper = await RemoteService()
          .post(url: url, body: body, returnData: returnData);
      return responseHelper;
    } catch (e) {
      print("errsasasdaor ====> $e");
      throw Exception('Failed to Cancel');
    }
  }

  //get slot for create challenge

  Future<void> updateSelectedDateNew(
      DateTime date, BuildContext context) async {
    selectedDate = date;

    // Clear previous selections and prices
    selectedSlotIds.clear();
    slotPrice = 0.0;
    totalHours = 0;
    selectedSlotForBooking = null;
    availableSlots = [];

    notifyListeners();

    // Fetch new slots for the new date
    await getSlotsNew(context, "");
  }

  // Future<void> updateSelectedDateNew(DateTime date) async {
  //   selectedDate = date;
  //   notifyListeners();
  //   await getSlotsNew();
  // }
  String getTimeUntilChallengeStarts(
      String bookingStartTimeUtc, BuildContext context) {
    try {
      DateTime now = DateTime.now();
      DateTime? start = _tryParseDate(bookingStartTimeUtc);

      if (start == null) throw FormatException("Invalid date");

      final diff = start.difference(now);
      if (diff.isNegative) return l10n.of(context).started;

      int hours = diff.inHours;
      int minutes = diff.inMinutes.remainder(60);

      return "${hours > 0 ? '${hours}h ' : ''}${minutes}min left";
    } catch (e) {
      print("⚠️ Error: $e");
      return l10n.of(context).invalidTime;
    }
  }

  DateTime? _tryParseDate(String input) {
    try {
      return DateTime.parse(input); // Try ISO first
    } catch (_) {}

    final formats = [
      DateFormat("yyyy-MM-dd HH:mm:ss"),
      DateFormat("dd-MM-yyyy HH:mm"),
      DateFormat("MM/dd/yyyy hh:mm a"),
      // Add more formats as needed
    ];

    for (var format in formats) {
      try {
        return format.parse(input, true).toLocal(); // Parse as UTC then convert
      } catch (_) {}
    }

    return null; // Unable to parse
  }
}
