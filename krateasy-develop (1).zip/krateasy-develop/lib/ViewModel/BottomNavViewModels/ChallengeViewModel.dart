import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class ChallengeViewModel extends ChangeNotifier {
  String? formattedDate;

  void selectedDate(DateTime date) {
    formattedDate = DateFormat("MMM d yyyy").format(date);
    notifyListeners();
  }

  // filter
  double startValue = 0;
  double endValue = 100;

  RangeValues rangeValues = const RangeValues(0, 100);

  void changeRangeValues(double st, double end) {
    rangeValues = RangeValues(st, end);
    notifyListeners();
  }

  // distance
  double startPoint = 0;
  double endPoint = 100;

  // Directly store the RangeValues
  RangeValues rangeDistance = const RangeValues(0, 100);

  void changeRangeDistance(double st, double end) {
    rangeDistance = RangeValues(st, end); // Corrected variable
    notifyListeners(); // Notify UI to update
  }

  // rate
  double startRate = 0;
  double endRate = 10;

  // Directly store the RangeValues
  RangeValues rangeRate = const RangeValues(0, 10);

  void changeRangeRate(double st1, double end1) {
    rangeRate = RangeValues(st1, end1); // Corrected variable
    notifyListeners();
  }

  List<String> sort = ['Alphabetically (A - Z)', 'Alphabetically (Z - A)', 'Happening Early', 'Happening Late'];
  List<String> playerList = ['1', '2', '3', '4','5', '6', '7', '8'];
  String? player;
  void changePlayer(String play) {
    player = play;
    notifyListeners();
  }

  List<String> courtList = ['1*1', '2*2', '3*3', '4*4','5*5', '6*6', '7*7', '8*8'];
  String? courtSize;
  void changeCourtSize(String court) {
    courtSize = court;
    notifyListeners();
  }
  List<String> sportsList = ['Cricket', 'Football', 'baseball', "cricket", "basketball", "volleyball", "badminton", "hockey"];
  String? sportsName;
  void changeSports(String sport) {
    sportsName = sport;
    notifyListeners();
  }

  List<String> courtList1 = ['1*1', '2*2', '3*3', '4*4','5*5', '6*6', '7*7', '8*8'];
  String? courtSize1;
  void changeCourtSize1(String court) {
    courtSize1 = court;
    notifyListeners();
  }
  List<String> sportsList1 = ['Cricket', 'Football', 'baseball', "cricket", "basketball", "volleyball", "badminton", "hockey"];
  String? sportsName1;
  void changeSports1(String sport) {
    sportsName1 = sport;
    notifyListeners();
  }


  String? challenge;
  void changeChallenge(String sort) {
    challenge = sort;
    if (storeChallenges.contains(sort)) {
    } else {
      storeChallenges.add(sort);
    }
    notifyListeners();
  }
  void deleteChallenges(int index) {
    storeChallenges.removeAt(index);
    notifyListeners();
  }

  List<String> storeChallenges = [];

  //
  List<String> amenitiesList = ['Fitness Suite', 'Swimming Pools', 'Bar & Bistro'];
  String? amenities;
  void changeAmenities(String value) {
    amenities = value;
    if (storeAmenities.contains(value)) {
    } else {
      storeAmenities.add(value);
    }
    notifyListeners();
  }

  void deleteAmenities(int index) {
    storeAmenities.removeAt(index);
    notifyListeners();
  }
  List<String> storeAmenities = [];

  bool isLoading = false;
  // List<Map<String, dynamic>> openings = [
  //   {
  //     "club": "Edgbaston Priory Club",
  //     "court": "Court Name",
  //     "date": "09 Feb, 2025",
  //     "time": "09:00AM - 11:00AM",
  //     "location": "Edgbaston, Birmingham",
  //     "privacy": "Public",
  //     "image": "assets/icons/game.png",
  //     "icon": "assets/icons/game.png",
  //   },
  //   {
  //     "club": "Edgbaston Priory Club",
  //     "court": "Court Name",
  //     "date": "09 Feb, 2025",
  //     "time": "09:00AM - 11:00AM",
  //     "location": "Edgbaston, Birmingham",
  //     "privacy": "Private",
  //     "image": "assets/icons/game.png",
  //     "icon": "assets/icons/game.png",
  //   },
  //   {
  //     "club": "Edgbaston Priory Club",
  //     "court": "Court Name",
  //     "date": "09 Feb, 2025",
  //     "time": "09:00AM - 11:00AM",
  //     "location": "Edgbaston, Birmingham",
  //     "privacy": "Public",
  //     "image": "assets/icons/game.png",
  //     "icon": "assets/icons/game.png",
  //   },
  // ];

  void addChallenge(BuildContext context) {
    Navigator.pushNamed(context, '/createChallenge');
  }
}
