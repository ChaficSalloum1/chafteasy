import 'package:kratEasyApp/API_CALLS/Helper.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/Models/AmenitiesList.dart';
import 'package:kratEasyApp/Models/booking_court_detail.dart';
import 'package:kratEasyApp/Models/booking_court_detail_newmodel.dart';
import 'package:kratEasyApp/Models/booking_detail_model_new.dart';
import 'package:kratEasyApp/Models/booking_details_model.dart';
import 'package:kratEasyApp/Models/challengeBookkigDetailModel.dart';
import 'package:kratEasyApp/Models/checkChallengeCodeModel.dart';
import 'package:kratEasyApp/Models/court_details_model.dart';
import 'package:kratEasyApp/Models/home_response_model.dart';
import 'package:kratEasyApp/Models/search_Filter_Data_Model.dart';
import 'package:kratEasyApp/Models/serach_Court_Payload_Model.dart';
import 'package:kratEasyApp/Models/sports_list_model.dart';
import 'package:kratEasyApp/NavBarScreens/mybooking/booking_details.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/repository/home_repository.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../Models/favourite_player.dart';
import '../../paymentprovider.dart';

class HomeViewModel extends ChangeNotifier {
  HomeViewModel(this._apiCall1);
  // final String clubName = "Edgbastan Priory";
  bool rebookTextUpdate = false;
  void setRebookTextUpdate(bool name) {
    rebookTextUpdate = name;
    notifyListeners();
  }

  TextEditingController challengeCodeTextEditingController =
      TextEditingController();
  final List<String> iconPaths = List.generate(
    4,
    (index) => "assets/icons/tennis.png",
  );

  void addChallenge(BuildContext context) {
    Navigator.pushNamed(context, '/createChallenge');
  }

  // void joinChallenge(BuildContext context) {
  //   Navigator.pushNamed(context, '/joinChallengeScreen');
  // }

  // List<String> banners = [
  //   "assets/banner/banner.png",
  //   "assets/banner/scrolbanner.png",
  //   "assets/banner/scrolbanner.png",
  // ];
  int selectedTabIndex = 0;

  void setSelectedTabIndex(int index) {
    selectedTabIndex = index;
    notifyListeners();
  }

  bool get isAnyFilterSelected {
    return selectedSport != null ||
        selectedAmenities != null ||
        selectedTimeSlot != null ||
        (dateController.text.isNotEmpty);
  }
  void resetFilters() {
    selectedSport = null;
    selectedAmenities = null;
    selectedTimeSlot = null;
    dateController.clear();
    notifyListeners();
  }


  List<String> imageUrls = [
    "https://randomuser.me/api/portraits/men/1.jpg",
    "https://randomuser.me/api/portraits/women/2.jpg",
    "https://randomuser.me/api/portraits/men/3.jpg",
    "https://randomuser.me/api/portraits/women/4.jpg",
    "https://randomuser.me/api/portraits/men/5.jpg",
    "https://randomuser.me/api/portraits/women/6.jpg",
    "https://randomuser.me/api/portraits/men/7.jpg",
  ];

  HomeRepository repository = HomeRepository();
  HomeDataResponse homeResponseModel = HomeDataResponse();
  BookingDetailsModel bookingDetailsModel = BookingDetailsModel();
  BookingDetailsModelNew bookingDetailsModelNew = BookingDetailsModelNew();
  BookingChallengesDetailsModel challlengebookingDetailsModel = BookingChallengesDetailsModel();
  BookingCourtDetailsModel bookkingcourt = BookingCourtDetailsModel();
  BookingCourtDetailsModelNew bookkingcourtnew = BookingCourtDetailsModelNew();

  Future<void> getHomeData() async {
    notifyListeners();

    try {
      final response = await repository.getHomeDataApi();
      if (response.body["status"] == true) {
        ("Raw response body: ${response.body}");

        homeResponseModel = HomeDataResponse.fromJson(response.body);


      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e, stackTrace) {
      print("stackTrace : $stackTrace");
      showSnackbar(
          context: NavigationService.context,
          message: l10n
              .of(NavigationService.navigatorKey.currentContext!)
              .somethingsWentWronggethomedata);
    } finally {
      notifyListeners();
    }
  }

  bool _loading = false;
  bool get loading => _loading;

  void setloadingg(bool value){
    _loading = value;
    notifyListeners();
  }

  bool _isTapLoading = false;

  bool get isTapLoading => _isTapLoading;

  void setTapLoading(bool value) {
    _isTapLoading = value;
    notifyListeners();
  }

  Future<void> getBookingDetails({
    required BuildContext context,
    required String bookingId,
    String? courtId,
    bool? courtDetails,
  }) async {
    context.read<AvailableChallengeGuestViewModel>().settime("");
    // notifyListeners();
    setloading(true);
    try {
      final response = await repository.getBookingDetailsApi(bookingId);
      if (response.body["status"] == true) {
        if(response.body["data"]["type"]=="Challenge"){
          print("inside if");
        }else{
          print("inside else");

          final rawUtcString = response.body["data"]["bookingStartTime"];

          if (rawUtcString != null) {
            final utcDate = DateTime.parse(rawUtcString).toUtc(); // ensure UTC
            final localDate = utcDate.toLocal(); // convert to local time zone
            final formattedDateTime = DateFormat('MMM d, yyyy h:mm a').format(localDate);
            print("formattedDateTime: $formattedDateTime");

            context.read<AvailableChallengeGuestViewModel>().settime(formattedDateTime);
          }

        }
        courtDetails == true
            ? null
            : Navigator.push(
                NavigationService.navigatorKey.currentContext!,
                MaterialPageRoute(
                    builder: (context) => BookingDetails(
                          ID: courtId,
                        )));
        bookingDetailsModel = BookingDetailsModel.fromJson(response.body);
        bookingDetailsModelNew = BookingDetailsModelNew.fromJson(response.body);

        printLog(
            "HomeResponse Banner > ${homeResponseModel.data?.banners?.length}");
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e, stackTrace) {
      print("stackTrace : $stackTrace");
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context).somethingsWentWronggetbookingdetails);
    } finally {
      setloading(false);
      notifyListeners();
    }
  }


  Future<void> getChalllengeBookingDetails({
    required BuildContext context,
    required String challenggid,

  }) async {
    context.read<AvailableChallengeGuestViewModel>().settime("");

    // notifyListeners();
    try {
      final response = await repository.gechallengetBookingDetailsApi(challenggid);
      if (response.body["status"] == true) {

        challlengebookingDetailsModel = BookingChallengesDetailsModel.fromJson(response.body);
        // printLog("bookkkkk=>${response.body["data"]["challenge"]["bookingStartTime"] }");
        // final rawUtcString = response.body["data"]["challenge"]["bookingStartTime"];
        //
        // if (rawUtcString != null) {
        //   final utcDate = DateTime.parse(rawUtcString).toUtc(); // ensure UTC
        //   final localDate = utcDate.toLocal(); // convert to local time zone
        //   final formattedDateTime = DateFormat('MMM d, yyyy h:mm a').format(localDate);
        //   print("formattedDateTime: $formattedDateTime");
        //
        //   context.read<AvailableChallengeGuestViewModel>().settime(formattedDateTime);
        // }

        // context.read<AvailableChallengeGuestViewModel>().settime("${response.body["data"]["challenge"]["bookingStartTime"] }");

        printLog(
            "HomeResponse Banner > ${homeResponseModel.data?.banners?.length}");
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e, stackTrace) {
      print("stackTrace : $stackTrace");
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context).somethingsWentWronggetbookingdetails);
    } finally {
      notifyListeners();
    }
  }


  Future<void> paymentfriendsApi(
      {required String friendid, required String id,required BuildContext context}) async {
    notifyListeners();
    final requestBody = {
      "friend_id": friendid,
      "transactionId":"",

    };
    try {
      setloading(true);
      final response = await repository.friendpaymentApi(requestBody,id);
      if (response.status == true) {
        showSnackbar(
            context: NavigationService.context,
            message: response.message ?? "");

      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
      setloading(false);
    } catch (e) {
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context).somethingsWentWrongPleaseTryAgainLater);
    } finally {
      notifyListeners();
    }
    setloading(false);
  }

  bool _loadding =false;
  bool get loadding => _loadding;

 void setloading(bool vallue){
   _loadding = vallue;
   notifyListeners();
 }

  Future<void> getCourtBookingdetails({
    required BuildContext context,
    required String challenggid,

  }) async {
    // notifyListeners();
    context.read<AvailableChallengeGuestViewModel>().settime("");
    try {
      setloading(true);
      final response = await repository.getcourtbookingdetail(challenggid);
      if (response.body["status"] == true) {

        // final rawUtcString = response.body["data"]["challenge"]["bookingStartTime"];

        // if (rawUtcString != null) {
        //   final utcDate = DateTime.parse(rawUtcString).toUtc(); // ensure UTC
        //   final localDate = utcDate.toLocal(); // convert to local time zone
        //   final formattedDateTime = DateFormat('MMM d, yyyy h:mm a').format(localDate);
        //   print("formattedDateTime2: $formattedDateTime");
        //
        //   context.read<AvailableChallengeGuestViewModel>().settime(formattedDateTime);
        // }

        bookkingcourt = BookingCourtDetailsModel.fromJson(response.body);
        bookkingcourtnew = BookingCourtDetailsModelNew.fromJson(response.body);

        setloading(false);
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
        setloading(false);
      }
    } catch (e, stackTrace) {
      print("stackTrace : $stackTrace");
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context).somethingsWentWronggetbookingdetails);
      setloading(false);
    } finally {
      notifyListeners();
    }
    setLoading(false);
  }


  CourtDetailsModel courtDetailsModel = CourtDetailsModel();
  String bookingId = "";
  storeBookingId({required String bookId}) {
    bookingId = bookId;
    notifyListeners();
  }

  // int? loadingIndex;
  // void setLoadingIndex(int? index) {
  //   loadingIndex = index;
  //   notifyListeners();
  // }

  bool isCourtDetail = false;
  Future<bool> getCourtDetails(
      {required String courtId, required BuildContext context}) async {
    isCourtDetail = true;
    notifyListeners();
    try {
      final response = await repository.getCourtDetailsApi(courtId);
      if (response.status == true) {
        courtDetailsModel = CourtDetailsModel.fromJson(response.body);
        print("response.body ${response.body}");
        printLog(
            "HomeResponse Banner > ${homeResponseModel.data?.banners?.length}");
        return true;
      } else {
        showSnackbar(
          context: NavigationService.context,
          message: response.message.toString(),
        );
        return false;
      }
    } catch (e, stackTrace) {
      print("Error : $e");
      print("stackTrace : $stackTrace");
      showSnackbar(
        context: NavigationService.context,
        message: l10n.of(context).somethingWentWrongGetbookingdetails,
      );
      return false;
    } finally {
      isCourtDetail = false;
      notifyListeners();
    }
  }

  Future<void> addCourtToFavouriteApi(
      {required String courtId, required BuildContext context}) async {
    notifyListeners();
    final requestBody = {
      "court_id": courtId,
    };
    try {
      final response = await repository.favouriteCourtApi(requestBody);
      if (response.status == true) {
        showSnackbar(
            context: NavigationService.context,
            message: response.message ?? "");
        Provider.of<HomeViewModel>(
                NavigationService.navigatorKey.currentContext!,
                listen: false)
            .getCourtDetails(context: context, courtId: courtId);
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e) {
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context).somethingsWentWrongPleaseTryAgainLater);
    } finally {
      notifyListeners();
    }
  }

  // Future<void> removePlayerFromFavouriteApi(
  //     {required String playerId, required BuildContext context}) async {
  //   notifyListeners();
  //   final requestBody = {
  //     "player_id": playerId,
  //   };
  //   try {
  //     final response = await repository.favouritePlayerApi(requestBody);
  //     if (response.status == true) {
  //       showSnackbar(
  //           context: NavigationService.context,
  //           message: response.message ?? "");
  //     } else {
  //       showSnackbar(
  //           context: NavigationService.context,
  //           message: response.message.toString());
  //     }
  //   } catch (e) {
  //     showSnackbar(
  //         context: NavigationService.context,
  //         message: S.of(context).somethingsWentWrongPleaseTryAgainLater);
  //   } finally {
  //     notifyListeners();
  //   }
  // }

  Future<void> removePlayerFromFavouriteApi({
    required String playerId,
    required BuildContext context,
    required List<FavouritePlayerModel> players,
  }) async {
    try {
      final response = await repository.favouritePlayerApi({
        "player_id": playerId,
      });

      if (response.status == true) {
        // ✅ Remove player from local list
        players.removeWhere((player) => player?.playerid == playerId);

        showSnackbar(
          context: NavigationService.context,
          message: response.message ?? "",
        );

        notifyListeners(); // 🔄 trigger UI rebuild
      } else {
        showSnackbar(
          context: NavigationService.context,
          message: response.message.toString(),
        );
      }
    } catch (e) {
      showSnackbar(
        context: NavigationService.context,
        message: l10n.of(context).somethingsWentWrongPleaseTryAgainLater,
      );
    }
  }

  //time calculation
  /// Returns a string like '2h 45min left' based on current time and booking start time/day.
  String getTimeUntilBookingStarts({
    required String startTime, // e.g. "10:00 AM"
    required String day, // e.g. "Monday"
  }) {
    try {
      DateTime now = DateTime.now();

      // Map days to weekday index
      const weekdays = {
        'Monday': 1,
        'Tuesday': 2,
        'Wednesday': 3,
        'Thursday': 4,
        'Friday': 5,
        'Saturday': 6,
        'Sunday': 7,
      };

      int targetWeekday = weekdays[day] ?? now.weekday;

      // Calculate next occurrence of that weekday
      int daysUntilTarget = (targetWeekday - now.weekday + 7) % 7;
      DateTime targetDate = now.add(Duration(days: daysUntilTarget));

      // Parse the time
      final timeFormat = DateFormat('hh:mm a');
      final parsedStartTime = timeFormat.parse(startTime);

      // Combine date and parsed start time
      DateTime bookingStart = DateTime(
        targetDate.year,
        targetDate.month,
        targetDate.day,
        parsedStartTime.hour,
        parsedStartTime.minute,
      );

      // Get the duration
      final diff = bookingStart.difference(now);

      if (diff.isNegative) return "Started";

      int hours = diff.inHours;
      int minutes = diff.inMinutes.remainder(60);

      return "${hours > 0 ? '${hours}h ' : ''}${minutes}min left";
    } catch (e) {
      print("⚠️ Error: $e");
      return "Invalid time";
    }
  }

  bool isHomeFilter = false;
  void setIsHomeFilter(bool? value) {
    isHomeFilter = value!;
    notifyListeners();
  }

  final TextEditingController dateController = TextEditingController();
  String? selectedSport;
  String? selectedTimeSlot;

  String? selectedSkillLevel;

// String? selectedSport; // This is the sport ID

  void setSelectedSport(String? value) {
    selectedSport = value;
    SharedPreferences.getInstance().then((prefs) {
      prefs.setString("sportID", value ?? '');
    });
    notifyListeners();
  }
  // void setSelectedSport(String? value) {
  //   selectedSport = value;

  //   notifyListeners();
  // }

  void setSelectedSkillLevel(String? value) {
    selectedSkillLevel = value;

    notifyListeners();
  }

  void setSelectedTimeSlot(String? value) {
    selectedTimeSlot = value;

    notifyListeners();
  }

  void clearCode() {
    challengeCodeTextEditingController.clear();
    notifyListeners();
  }

  String? selectedAmenities;

  List<AmenitiesList> get amenititesList => Helper.amenities
      .map((amenity) => AmenitiesList(id: amenity.id, name: amenity.name))
      .toList();
  void setSelectedAminities(String? value) {
    selectedAmenities = value;
    notifyListeners();
  }
  // List<String> get sportsList =>
  //     Helper.sports.map((sport) => sport.name).toList();

  List<String> availableTimes = [
    "12:00 AM",
    "01:00 AM",
    "02:00 AM",
    "03:00 AM",
    "04:00 AM",
    "05:00 AM",
    "06:00 AM",
    "07:00 AM",
    "08:00 AM",
    "09:00 AM",
    "10:00 AM",
    "11:00 AM",
    "12:00 PM",
    "01:00 PM",
    "02:00 PM",
    "03:00 PM",
    "04:00 PM",
    "05:00 PM",
    "06:00 PM",
    "07:00 PM",
    "08:00 PM",
    "09:00 PM",
    "10:00 PM",
    "11:00 PM",
  ];
  List<SportsListModel> sportsListModel = [];
  Future<void> getSportsDataApi({required BuildContext context}) async {
    notifyListeners();
    try {
      final response = await repository.getSportsListDataApi();
      if (response.status == true) {
        sportsListModel = List<SportsListModel>.from(
                response.body['data'].map((x) => SportsListModel.fromJson(x)))
            .toList();

        // Get saved sportID from SharedPreferences
        SharedPreferences prefs = await SharedPreferences.getInstance();
        final savedSportId = prefs.getString("sportID");

        if (savedSportId != null &&
            sportsListModel.any((s) => s.id == savedSportId)) {
          selectedSport = savedSportId;
        }
        notifyListeners();
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e, stackTrace) {
      debugPrint("stackTrace : $stackTrace");
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context).somethingsWentWronggetprofiledataapi);
    } finally {
      notifyListeners();
    }
  }

  ///check poup
  Future<void> checkAndShowPopup({
    required VoidCallback showPopupCallback,
  }) async {
    final prefs = await SharedPreferences.getInstance();

    final isFilled = prefs.getBool('userFilledInfo') ?? false;
    final lastShownDate = prefs.getString('popupLastShownDate');

    final today = DateTime.now();
    final todayStr = "${today.year}-${today.month}-${today.day}";

    if (!isFilled && lastShownDate != todayStr) {
      showPopupCallback();

      await prefs.setString('popupLastShownDate', todayStr);
    }
  }

  Future<void> markUserFilledInfo() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('userFilledInfo', true);
  }

  bool isUserPreferencesLoading = false;
  Future<void> setUserPreferences({
    required List<String> sportIds, // Changed to List<String>
    required List<String> skillLevel, // Changed to List<String>
    required List<String> timeSlot, // Changed to List<String>
    required String timeRadius,
    required BuildContext context,
  }) async {
    isUserPreferencesLoading = true;
    notifyListeners();
    SharedPreferences prefs = await SharedPreferences.getInstance();
    final lat = await prefs.getDouble("current_lat");
    final long = await prefs.getDouble("current_long");

    final requestBody = {
      "sportIds": sportIds, // Now a List<String>
      "latitude": lat,
      "longitude": long,
      "radius": timeRadius,
      "timeSlots": timeSlot, // Now a List<String>
      "skillLevels": skillLevel // Now a List<String>
    };

    try {
      final response = await repository.setUserPreferencesApi(requestBody);
      if (response.status == true) {
        // navigate to back screen
        // await prefs.setBool("showBottomSheet", false);
        markUserFilledInfo();
        Navigator.pop(context);
      } else {
        showSnackbar(
          context: NavigationService.context,
          message: response.message.toString(),
        );
      }
    } catch (e) {
      showSnackbar(
        context: NavigationService.context,
        message: l10n.of(context).somethingsWentWrongeditMyAccount,
      );
    } finally {
      isUserPreferencesLoading = false;
      notifyListeners();
    }
  }

//   Future<void> setUserPreferences(
//         {required sportIds,
//         required skillLevel,
//         required timeSlot,
//       required String timeRadius,
//       required BuildContext context}) async {
//     isUserPreferencesLoading = true;
//     notifyListeners();
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     final lat = await prefs.getDouble("current_lat");
//     final long = await prefs.getDouble("current_long");
//     final requestBody = {
//       "sportIds":
//           sportIds, // ["67ffadb5029193386da8c17a", "68010d77925d2a55623c17f4"],
//       "latitude": lat,
//       "longitude": long,
//       "radius": timeRadius,
//       "timeSlots": timeSlot,
//       "skillLevels": skillLevel
//     };
//     try {
//       final response = await repository.setUserPreferencesApi(requestBody);
//       if (response.status == true) {
// //navigate to back screen
//         await prefs.setBool("showBottomSheeet", false);
//         Navigator.pop(context);
//       } else {
//         showSnackbar(
//             context: NavigationService.context,
//             message: response.message.toString());
//       }
//     } catch (e) {
//       showSnackbar(
//           context: NavigationService.context,
//           message: "Somethings went wrong(Edit My Account)");
//     } finally {
//       isLoading = false;
//       notifyListeners();
//     }
//   }

  bool isLoading = false;

  void setLoader(bool value) {
    isLoading = value;
    notifyListeners();
  }

  List<String> imageUrlss = [
    "https://randomuser.me/api/portraits/men/1.jpg",
    "https://randomuser.me/api/portraits/women/2.jpg",
    "https://randomuser.me/api/portraits/men/3.jpg",
    "https://randomuser.me/api/portraits/women/4.jpg",
    "https://randomuser.me/api/portraits/men/5.jpg",
    "https://randomuser.me/api/portraits/women/6.jpg",
    "https://randomuser.me/api/portraits/men/7.jpg",
  ];

  // new search court filter

  String? _error1;

  String? get error1 => _error1;

  final SearchCourtsApi _apiCall1;

  final List<int> _selectedTimeGrids = [];

  List<int> get selectedTimeGrids => _selectedTimeGrids;
  List<String> selectedAmenitie = [];
  SearchFilterDataModel searchFilterDataModel = SearchFilterDataModel();

  // Future<SearchFilterDataModel?> newSearchCourt(
  //     BookingRequest bookingRequest, BuildContext context) async {
  //   try {
  //     _isLoading1 = true;
  //     notifyListeners();
  //     print("start..... ");

  //     final response =
  //         await _apiCall1.newSearchCourtApi(bookingRequest, context);
  //     print("response..... ${response?.data}");

  //     if (response != null) {
  //       searchFilterDataModel = response;

  //       if (response.data != null && response.data!.isNotEmpty) {
  //         _error1 = null;
  //       } else {
  //         _error1 = response.message ?? S.of(context).noCourtsAvailable;
  //       }

  //       return response;
  //     } else {
  //       _error1 = S.of(context).noSlotsAvailableAtThisTime;
  //       return null;
  //     }
  //   } catch (e) {
  //     print("SearchCourt API error: $e");
  //     _error1 = S.of(context).somethingWentWrong;
  //     return null;
  //   } finally {
  //     _isLoading1 = false;
  //     notifyListeners();
  //   }
  // }

//modify challenge
// http://localhost:3000/api/app/Booking/update-booking/663fcae77a2a2d78cc1e9b23

// {
//   "date": "2025-05-20",
//   "slot_id": ["609c8a8f8e620b0015eabcde"],
//   "slotTime": "09:00 AM - 10:00 AM",
//   "startTime": "09:00 AM",
//   "endTime": "10:00 AM"
// }

  /// /app/challenges/check-challenge/:code
  ///
  ///
  ///
  ///

  String? challengeCodeErrorText;

  void setChallengeCodeError(String? error) {
    challengeCodeErrorText = error;
    notifyListeners();
  }

  bool isCheckCodeLoading = false;

  void setLoading(bool value) {
    if (isCheckCodeLoading != value) {
      isCheckCodeLoading = value;
      notifyListeners();
    }
  }

  CheckChallengeCodeModel? checkChallengeCodeModel;

  /// Set Wallet detail data
  void setCheckCodeData(CheckChallengeCodeModel data) {
    checkChallengeCodeModel = data;
    notifyListeners();
  }

  Future<void> checkChallengeCode({
    required String code,
    required BuildContext context,
  }) async {
    if (code.isEmpty) {
      setChallengeCodeError(l10n.of(context).codeCannotBeEmpty);
      return;
    }

    try {
      debugPrint("code $code");
      setChallengeCodeError(null); // Clear previous errors
      setLoading(true);

      final data =
          await _apiCall1.checkChallengeCodeApi(code: code, context: context);
      print("...............${data.data?.id}");

      if (data.status == true && data.data?.id != null) {
        Provider.of<AvailableChallengeGuestViewModel>(context, listen: false)
            .getChallengesDetails(
                cancelChallenge: false,
                ispublic: false,
                challengesId: data.data?.id ?? "",
                context: context);
        challengeCodeTextEditingController.clear();
        // Optional: Navigator.pop(context); if needed after successful join
      } else {
        // ❗ Show snackbar and pop bottom sheet
        Navigator.pop(context); // Pop the bottom sheet
        Future.delayed(Duration(milliseconds: 300), () {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(data.message ?? l10n.of(context).challengeNotFound),
              behavior: SnackBarBehavior.floating,
              margin: EdgeInsets.only(bottom: 80, left: 16, right: 16),
            ),
          );
        });
      }
    } catch (e) {
      print("Error of wallet detail api $e");
    } finally {
      setLoading(false);
    }
  }




}
