import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/GlobalUtils/app_navigation.dart';
import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/Models/notification_List_Model.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/repository/notification_repo.dart';
import 'package:kratEasyApp/services/local/local_keys.dart';
import 'package:kratEasyApp/services/local/local_service.dart';
import 'package:kratEasyApp/services/remote/api_ends.dart';
//
// class NotificationsViewModel extends ChangeNotifier {
//   bool isLoading = false;
//   bool _showUnreadOnly = false;
//   List<Map<String, String>> _allNotifications = [];
//   List<Map<String, String>> _unreadNotifications = [];
//
//   bool _hasUnreadNotifications = false;
//   bool get hasUnreadNotifications => _hasUnreadNotifications;
//
//   void setisanyunread(){
//   _hasUnreadNotifications=  notificationModel.any((n)=>n.isRead==false);
//   notifyListeners();
//   }
//
//
//
//   bool get showUnreadOnly => _showUnreadOnly;
//   List<Map<String, String>> get notifications => _showUnreadOnly ? _unreadNotifications : _allNotifications;
//
//   void toggleUnread(bool unreadOnly) {
//     _showUnreadOnly = unreadOnly;
//     notifyListeners();
//   }
//
//   void removeNotification(String id) {
//     _allNotifications.removeWhere((notif) => notif["id"] == id);
//     _updateUnreadNotifications();
//   }
//
//   void _updateUnreadNotifications() {
//     _unreadNotifications = _allNotifications.where((notif) => notif["read"] == "false").toList();
//     notifyListeners();
//   }
//
//   NotificationRepository repository = NotificationRepository();
//
//   List<NotificationListModelDoc> notificationModel = [];
//   List<NotificationListModelDoc> searchNotificationModel = [];
//   bool isLoadingData = false;
//
//   /// Fetch Notification List
//   Future<void> getNotificationListData({required BuildContext context}) async {
//     isLoadingData = true;
//     notifyListeners();
//     String baseUrl = "https://backend.krateasy.gr/api/";
//
//     final endPoint = ApiEnds.instance.notification;
//     try {
//       final token = LocalService.instance.getData(LocalKeys.instance.accessToken);
//       final url = "$baseUrl$endPoint";
//
//       final headers = {
//         'Content-Type': 'application/json',
//         if (token != null) 'Authorization': 'Bearer $token',
//       };
//
//       final response = await http.get(Uri.parse(url), headers: headers);
//
//       print("response.statusCode: ${response.statusCode}");
//       print("response.body: ${response.body}");
//
//       if (response.statusCode == 200) {
//         final Map<String, dynamic> decoded = json.decode(response.body);
//
//         if (decoded['docs'] != null && decoded['docs'] is List) {
//           final List docs = decoded['docs'];
//
//           notificationModel = docs
//               .map<NotificationListModelDoc>(
//                 (item) => NotificationListModelDoc.fromJson(item),
//               )
//               .toList();
//
//           searchNotificationModel = List.from(notificationModel);
//         } else {
//           notificationModel = [];
//           searchNotificationModel = [];
//           print("Docs is empty or invalid");
//         }
//       } else {
//         print("Failed to fetch notifications: ${response.statusCode}");
//         showSnackbar(
//           context: NavigationService.context,
//           message: "Error: ${response.statusCode} - Unable to fetch notifications.",
//         );
//       }
//     } catch (e, stackTrace) {
//       print("Error fetching notifications: $e");
//       print("Stack trace: $stackTrace");
//       showSnackbar(
//         context: NavigationService.context,
//         message: S.of(context).somethingWentWrongWhileFetchingNotifications,
//       );
//     } finally {
//       isLoadingData = false;
//       notifyListeners();
//     }
//   }
//
//   /// Filter Notification List
//   void filterNotification(String val) {
//     if (val.trim().isEmpty) {
//       searchNotificationModel = List.from(notificationModel);
//     } else {
//       searchNotificationModel = notificationModel.where((notification) => notification.title.toLowerCase().contains(val.toLowerCase())).toList();
//     }
//     notifyListeners();
//   }
//
//   /**** */
//
//   void readSingleMessage({required String id, required BuildContext context}) {
//     for (int i = 0; i < notificationModel.length; i++) {
//       if (notificationModel[i].id == id) {
//         if (notificationModel[i].isRead == false) {
//           notificationModel[i].isRead = true;
//           notifyListeners();
//           readNotification(id: id, context: context);
//         }
//         break;
//       }
//     }
//   }
//
//
//
//   Future<void> readNotification({String? id, required BuildContext context}) async {
//     isLoading = true;
//     notifyListeners();
//
//     print("id ddd $id");
//     try {
//
//       final response = await repository.readNotificationDataApi(id: id);
//
//       print("id reap[onse] $response");
//       print("id ddd ${response.body}");
//       if (response.status == true) {
//         getNotificationListData(context: context);
//         // showSnackbar(
//         //     context: NavigationService.context,
//         //     message: response.message.toString());
//       } else {
//         showSnackbar(context: NavigationService.context, message: response.message.toString());
//       }
//     } catch (e, stackTrace) {
//       print("stackTrace : $stackTrace");
//       showSnackbar(context: NavigationService.context, message: "Error: $e");
//     } finally {
//       isLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<void> unreadNotification({required BuildContext context}) async {
//     isLoading = true;
//     notifyListeners();
//     try {
//       final response = await repository.unreadNotificationDataApi();
//       if (response.status == true) {
//         getNotificationListData(context: context);
//       } else {
//         showSnackbar(context: NavigationService.context, message: response.message.toString());
//       }
//     } catch (e, stackTrace) {
//       print("stackTrace : $stackTrace");
//       showSnackbar(context: NavigationService.context, message: S.of(context).somethingsWentWrongunreadnotification);
//     } finally {
//       isLoading = false;
//       notifyListeners();
//     }
//   }
//
//   Future<void> deleteNotification({String? id, required BuildContext context}) async {
//     isLoading = true;
//     notifyListeners();
//     try {
//       final response = await repository.deleteNotificationDataApi(id: id);
//       if (response.status == true) {
//         getNotificationListData(context: context);
//         showSnackbar(context: NavigationService.context, message: response.message.toString());
//       } else {
//         showSnackbar(context: NavigationService.context, message: response.message.toString());
//       }
//     } catch (e, stackTrace) {
//       print("stackTrace : $stackTrace");
//       showSnackbar(context: NavigationService.context, message: S.of(context).somethingsWentWrongdeletenotification);
//     } finally {
//       isLoading = false;
//       notifyListeners();
//     }
//   }
//
//   notificationRedirection(NotificationListModelDoc? notificationListModelDoc) {
//     AvailableChallengeGuestViewModel availableChallengeProvider;
//
//     BuildContext context = NavigationService.navigatorKey.currentContext!;
//     availableChallengeProvider = context.read<AvailableChallengeGuestViewModel>();
//     if (notificationListModelDoc?.data?.type == "New Challenge") {
//       availableChallengeProvider.getChallengesDetails(ispublic: true, cancelChallenge: true, challengesId: notificationListModelDoc?.data?.challengeId ?? "", context: context).then((_) {
//
//       });
//     }
//
//     if (notificationListModelDoc?.data?.type == "Join Challenge") {
//       availableChallengeProvider.getChallengesDetails(ispublic: true, cancelChallenge: false, challengesId: notificationListModelDoc?.data?.challengeId ?? "", context: context).then((_) {
//
//       });
//     }
//     if (notificationListModelDoc?.data?.type == "Matching Challenge Found") {
//       availableChallengeProvider.getChallengesDetails(ispublic: true, cancelChallenge: false, challengesId: notificationListModelDoc?.data?.challengeId ?? "", context: context).then((_) {
//
//       });
//
//     }
//
//     else if (notificationListModelDoc?.data?.type == "New Booking") {
//       Provider.of<HomeViewModel>(context, listen: false).getBookingDetails(context: context, bookingId: notificationListModelDoc?.data?.bookingId ?? "");
//     }
//    else if (notificationListModelDoc?.data?.type == "Booking Cancelled") {
//       // availableChallengeProvider.getChallengesDetails(ispublic: true, cancelChallenge: false, challengesId: notificationListModelDoc?.data?.challengeId ?? "", context: context).then((_) {
//         Provider.of<HomeViewModel>(context, listen: false).getBookingDetails(context: context, bookingId: notificationListModelDoc?.data?.bookingId ?? "");
//
//     }
//   }
//
// }

class NotificationsViewModel extends ChangeNotifier {
  bool isLoading = false;
  bool _showUnreadOnly = false;

  bool _hasUnreadNotifications = false;
  bool get hasUnreadNotifications => _hasUnreadNotifications;

  List<Map<String, String>> _allNotifications = [];
  List<Map<String, String>> _unreadNotifications = [];

  bool get showUnreadOnly => _showUnreadOnly;
  List<Map<String, String>> get notifications =>
      _showUnreadOnly ? _unreadNotifications : _allNotifications;

  NotificationRepository repository = NotificationRepository();

  List<NotificationListModelDoc> notificationModel = [];
  List<NotificationListModelDoc> searchNotificationModel = [];
  bool isLoadingData = false;

  /// Updates unread status flag
  void _updateUnreadFlag() {
    _hasUnreadNotifications =
        notificationModel.any((n) => n.isRead == false);
  }

  /// Toggle between all and unread
  void toggleUnread(bool unreadOnly) {
    _showUnreadOnly = unreadOnly;
    notifyListeners();
  }

  /// Remove notification by ID
  void removeNotification(String id) {
    _allNotifications.removeWhere((notif) => notif["id"] == id);
    _updateUnreadList();
  }

  /// Updates the local unread list
  void _updateUnreadList() {
    _unreadNotifications = _allNotifications
        .where((notif) => notif["read"] == "false")
        .toList();
    notifyListeners();
  }

  /// Fetch Notification List
  Future<void> getNotificationListData({required BuildContext context}) async {
    isLoadingData = true;
    notifyListeners();
    String baseUrl = "https://backend.krateasy.gr/api/";
    final endPoint = ApiEnds.instance.notification;

    try {
      final token =
      LocalService.instance.getData(LocalKeys.instance.accessToken);
      final url = "$baseUrl$endPoint";
      final headers = {
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      };

      final response = await http.get(Uri.parse(url), headers: headers);

      if (response.statusCode == 200) {
        final Map<String, dynamic> decoded = json.decode(response.body);

        if (decoded['docs'] != null && decoded['docs'] is List) {
          final List docs = decoded['docs'];

          notificationModel = docs
              .map<NotificationListModelDoc>(
                  (item) => NotificationListModelDoc.fromJson(item))
              .toList();

          searchNotificationModel = List.from(notificationModel);

          // Update unread flag whenever list changes
          _updateUnreadFlag();
        } else {
          notificationModel = [];
          searchNotificationModel = [];
        }
      } else {
        showSnackbar(
          context: NavigationService.context,
          message:
          "Error: ${response.statusCode} - Unable to fetch notifications.",
        );
      }
    } catch (e, stackTrace) {
      print("Error fetching notifications: $e");
      print("Stack trace: $stackTrace");
      showSnackbar(
        context: NavigationService.context,
        message: l10n.of(context)
            .somethingWentWrongWhileFetchingNotifications,
      );
    } finally {
      isLoadingData = false;
      notifyListeners();
    }
  }

  /// Filter Notification List
  void filterNotification(String val) {
    if (val.trim().isEmpty) {
      searchNotificationModel = List.from(notificationModel);
    } else {
      searchNotificationModel = notificationModel
          .where((notification) => notification.title
          .toLowerCase()
          .contains(val.toLowerCase()))
          .toList();
    }
    notifyListeners();
  }

  /// Mark a single message as read
  void readSingleMessage(
      {required String id, required BuildContext context}) {
    for (int i = 0; i < notificationModel.length; i++) {
      if (notificationModel[i].id == id &&
          notificationModel[i].isRead == false) {
        notificationModel[i].isRead = true;
        _updateUnreadFlag();
        notifyListeners();
        readNotification(id: id, context: context);
        break;
      }
    }
  }

  Future<void> readNotification(
      {String? id, required BuildContext context}) async {
    isLoading = true;
    notifyListeners();

    try {
      final response =
      await repository.readNotificationDataApi(id: id);

      if (response.status == true) {
        await getNotificationListData(context: context);
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e, stackTrace) {
      print("stackTrace : $stackTrace");
      showSnackbar(
          context: NavigationService.context,
          message: "Error: $e");
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> unreadNotification(
      {required BuildContext context}) async {
    isLoading = true;
    notifyListeners();
    try {
      final response =
      await repository.unreadNotificationDataApi();
      if (response.status == true) {
        await getNotificationListData(context: context);
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e, stackTrace) {
      print("stackTrace : $stackTrace");
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context)
              .somethingsWentWrongunreadnotification);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> deleteNotification(
      {String? id, required BuildContext context}) async {
    isLoading = true;
    notifyListeners();
    try {
      final response =
      await repository.deleteNotificationDataApi(id: id);
      if (response.status == true) {
        await getNotificationListData(context: context);
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e, stackTrace) {
      print("stackTrace : $stackTrace");
      showSnackbar(
          context: NavigationService.context,
          message: l10n
              .of(context)
              .somethingsWentWrongdeletenotification);
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  /// Handles navigation from notification tap
  void notificationRedirection(
      NotificationListModelDoc? notificationListModelDoc) {
    BuildContext context =
    NavigationService.navigatorKey.currentContext!;
    final availableChallengeProvider =
    context.read<AvailableChallengeGuestViewModel>();

    switch (notificationListModelDoc?.data?.type) {
      case "New Challenge":
        availableChallengeProvider.getChallengesDetails(
            ispublic: true,
            cancelChallenge: true,
            challengesId:
            notificationListModelDoc?.data?.challengeId ?? "",
            context: context);
        break;
      case "Join Challenge":
      case "Matching Challenge Found":
        availableChallengeProvider.getChallengesDetails(
            ispublic: true,
            cancelChallenge: false,
            challengesId:
            notificationListModelDoc?.data?.challengeId ?? "",
            context: context);
        break;
      case "New Booking":

      case "Join Booking"|| "JOIN_BOOKING":
        context.read<HomeViewModel>().getBookingDetails(
            context: context,
            bookingId:
            notificationListModelDoc?.data?.bookingId ?? "");
        break;
      case "Booking Cancelled":
        context.read<HomeViewModel>().getBookingDetails(
            context: context,
            bookingId:
            notificationListModelDoc?.data?.bookingId ?? "");
        break;
    }
  }
}
