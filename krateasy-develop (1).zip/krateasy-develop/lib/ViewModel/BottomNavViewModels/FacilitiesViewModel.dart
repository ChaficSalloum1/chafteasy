import 'dart:math';

import 'package:easy_date_timeline/easy_date_timeline.dart';
import 'package:flutter/material.dart';
import 'package:kratEasyApp/API_CALLS/Helper.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/GlobalUtils/app_navigation.dart';
import 'package:kratEasyApp/GlobalUtils/app_routes.dart';
import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/Models/AmenitiesList.dart';
import 'package:kratEasyApp/Models/create_Challenge_Facility_Model.dart';
import 'package:kratEasyApp/Models/facilities_model.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/repository/facilities_repository.dart';
import 'package:kratEasyApp/services/remote/responce_helper.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FacilitiesViewModel extends ChangeNotifier {

  final TextEditingController dateController = TextEditingController();

  String? selectedDate;
  String? _selectedGalleryImage;
  void clearSelectedDate() {
    selectedDate = null;
    notifyListeners(); // so UI updates
  }


  String? get selectedGalleryImage =>
      _selectedGalleryImage ?? selectedFacility.image;

  void setSelectedGalleryImage(String imageUrl) {
    _selectedGalleryImage = imageUrl;
    notifyListeners();
  }

  // Optional: clear image when loading new facility
  void resetGalleryImage() {
    _selectedGalleryImage = null;
    notifyListeners();
  }

  List<String> selectedSorts = [];

  void addSort(String sort) {
    if (!selectedSorts.contains(sort)) {
      selectedSorts.add(sort);
      notifyListeners();
    }
  }

  void removeSort(String sort) {
    selectedSorts.remove(sort);
    notifyListeners();
  }
String? selectedSort;
String? selectedSortOrder;
String? selectedSortName;

  void clearSortValues() {
    selectedSort = null;
    selectedSortOrder = null;
    selectedSortName = null;
    notifyListeners(); // Notifies UI to update if listening
  }

final List<Map<String, dynamic>> sortItems = [
  {"sort": "name", "name": "Name A-Z","sortOrder":"asc"},
  // {"sort": "rating", "name": "Rating High-Low","sortOrder":"asc"},
  {"sort": "price", "name": "Price Low-High","sortOrder":"asc"},
  // {"sort": "price1", "name": "Price High-Low","sortOrder":"desc"},
];
  // List<Map<String, dynamic>> sortItems = [
  //   {"id": "name", "name": "Name A-Z"},
  //   {"id": "rating_desc", "name": "Rating High-Low"},
  //   {"id": "asc", "name": "Price Low-High"},
  //   {"id": "desc", "name": "Price High-Low"},
  // ];
  String selectedSortss = "";
  String selectedSortsKey = "";
  void setSortByFilter(String sortValue) {
    selectedSortss = sortValue;
    if (sortValue == "Name A-Z") {
      selectedSortsKey = "a-z";
    } else {
      selectedSortsKey = "z-a";
    }
    notifyListeners();
  }

  List<String> sortItemsKeys = ["desc"];

  List<String> sportsItems = ["Option 1", "Option 2", "Option 3", "Option 4"];

  List<String> courtItems = ["Option 1", "Option 2", "Option 3", "Option 4"];

  List<String> timeItems = [
    "12:00 AM",
    "01:00 AM",
    "02:00 AM",
    "03:00 AM",
    "04:00 AM",
    "05:00 AM",
    "06:00 AM",
    "07:00 AM",
    "08:00 AM",
    "09:00 AM",
    "10:00 AM",
    "11:00 AM",
    "12:00 PM",
    "01:00 PM",
    "02:00 PM",
    "03:00 PM",
    "04:00 PM",
    "05:00 PM",
    "06:00 PM",
    "07:00 PM",
    "08:00 PM",
    "09:00 PM",
    "10:00 PM",
    "11:00 PM"
  ];

  String? selectTime;
  void changeTimeSlot(String time) {
    selectTime = time;
    notifyListeners();
  }

  double? radius;
  double? minPrice;
  double? maxPrice;

  changeRadius(double radiusValue) {
    radius = radiusValue;
    notifyListeners();
  }

  List<Map<String, dynamic>> facilities = [
    {
      "club": "Edgbaston Priory Club",
      "court": "Court Name",
      "date": "09 Feb, 2025",
      "time": "09:00AM - 11:00AM",
      "location": "Edgbaston, Birmingham",
      "slots": "5",
      "type": "Free",
      "privacy": "Public",
      "image": "assets/icons/game.png",
      "icon": "assets/icons/game.png",
    },
    {
      "club": "Edgbaston Priory Club",
      "court": "Court Name",
      "date": "09 Feb, 2025",
      "time": "09:00AM - 11:00AM",
      "location": "Edgbaston, Birmingham",
      "slots": "1",
      "type": "Paid",
      "privacy": "Private",
      "image": "assets/icons/game.png",
      "icon": "assets/icons/game.png",
    },
    {
      "club": "Edgbaston Priory Club",
      "court": "Court Name",
      "date": "09 Feb, 2025",
      "time": "09:00AM - 11:00AM",
      "location": "Edgbaston, Birmingham",
      "slots": "2",
      "type": "Free",
      "privacy": "Public",
      "image": "assets/icons/game.png",
      "icon": "assets/icons/game.png",
    },
  ];

  final List<String> iconPaths =
      List.generate(4, (index) => "assets/icons/tennis.png");

  // Navigation logic
  void navigateToFacility(BuildContext context) {
    Navigator.pushNamed(
      context,
      '/featuredFacilities', // Ensure '/featuredFacilities' is defined in your routes
    );
  }

  /// store updated model data
  FacilitiesModel selectedFacility = FacilitiesModel();

  void updateSelectedFacility(FacilitiesModel data) {
    selectedFacility = data;
    printLog("Facility Selected > ${selectedFacility.name}");
    // notifyListeners();
  }

  Courts selectedCourt = Courts();

  void updateSelectedCourt(Courts court) {
    selectedCourt = court;
    // notifyListeners();
    printLog("Court Selected > ${selectedCourt.name}");
  }

  /// search facility list
  bool isSearch = false;
  TextEditingController searchController = TextEditingController();
  final FocusNode searchFocusNode = FocusNode();
  void searchStatus() {
    isSearch = !isSearch;

    if (isSearch) {
      searchFacilitiesData = List.from(facilitiesData);
      FocusScope.of(NavigationService.navigatorKey.currentState!.context).requestFocus(searchFocusNode);
    } else {
      searchFacilitiesData.clear();
      searchFacilitiesData = List.from(facilitiesData);
      searchController.clear();

      searchFocusNode.unfocus();
    }
    notifyListeners();
  }

  /// facilities apis handle
  bool isLoading = true;
  bool isShare= false;
  FacilitiesRepository repository = FacilitiesRepository();
  List<FacilitiesModel> facilitiesData = [];
  List<FacilitiesModel> searchFacilitiesData = [];

  void searchFacilityList(String value) {
    searchFacilitiesData = facilitiesData.where((facility) {
      final nameMatch =
          facility.name?.toLowerCase().contains(value.toLowerCase()) ?? false;
      final addressMatch =
          facility.address?.toLowerCase().contains(value.toLowerCase()) ??
              false;
      final sportMatch = facility.courts?.any((court) =>
              court.name?.toLowerCase().contains(value.toLowerCase()) ??
              false) ??
          false;
      return nameMatch || addressMatch || sportMatch;
    }).toList();

    notifyListeners();
  }

  final filterModel = Provider.of<SearchCourtViewModel>(
      NavigationService.navigatorKey.currentContext!,
      listen: false);
  // bool isFilter = false;
  // void updateIsFilter(bool filter) {
  //   isFilter = filter;
  //   notifyListeners();
  // }

  Future<void> getFacilitiesData({
    String? date,
    List<String>? sportIdList,
    List<String>? amenitiesList,
    String? sort,
    String? orderStatus,
    String? minPrice,
    String? maxPrice,
    String? time,
    String? radius,
    required BuildContext context
  }) async {
    isLoading = true;
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var lat = await prefs.getDouble("current_lat");
    var long = await prefs.getDouble("current_long");

    notifyListeners();
    try {
      ResponseHelper response;
      // if (isFilter) {
      //   response = await repository.getFacilitiesApis(
      //     latitude: (lat ?? 0.0).toDouble(),
      //     longitude: (long ?? 0.0).toDouble(),
      //     sportIdList: filterModel.selectedSportsList,
      //     // amenitiesList: filterModel.selectedAminitiesList,
      //     // sort: selectedSortsKey,
      //     orderStatus: orderStatus,
      //     minPrice: minPrice,
      //     // maxPrice: maxPrice,
      //     date: selectedDate,
      //     time: selectTime,
      //     radius: radius,
      //   );
      // } else {
        response = await repository.getFacilitiesApis(
          latitude: (lat ?? 0.0).toDouble(),
          longitude: (long ?? 0.0).toDouble(),
        );
      // }

      if (response.status == true) {
        facilitiesData = List<FacilitiesModel>.from(
          response.body.map((x) => FacilitiesModel.fromJson(x)),
        );

        // Calculate and sort by distance
        for (var facility in facilitiesData) {
          if (facility.latitude != null && facility.longitude != null) {
            facility.distanceInKm = calculateDistanceInKm(
              lat1: lat ?? 0.0,
              lon1: long ?? 0.0,
              lat2: facility.latitude!,
              lon2: facility.longitude!,
            );
          } else {
            facility.distanceInKm = double.infinity;
          }
        }

        facilitiesData
            .sort((a, b) => a.distanceInKm!.compareTo(b.distanceInKm!));
        searchFacilitiesData = List.from(facilitiesData);

        notifyListeners();
      } else {
        showSnackbar(
          context: NavigationService.context,
          message: response.message.toString(),
        );
      }
    } catch (e, stackTrace) {
      print("Error : $e");
      print("stackTrace : $stackTrace");
      showSnackbar(
        context: NavigationService.context,
        message: l10n.of(context).somethingWentWrongGetfacilitiesdata,
      );
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> getFilteredFacilitiesData({
    String? date,
    String? time,
    String? sportIdList,
    List<String>? amenitiesList,
    String? sort,
    String? orderStatus,
    String? minRating,
    String? maxRating,
    String? radius,
    required BuildContext context,
  }) async {
    isLoading = true;
    notifyListeners();

    SharedPreferences prefs = await SharedPreferences.getInstance();
    double lat = prefs.getDouble("current_lat") ?? 0.0;
    double long = prefs.getDouble("current_long") ?? 0.0;

    print("sort: $sort");
    print("orderStatus: $orderStatus");
    print("sportIdListsportIdList: $sportIdList");

    try {
      final response = await repository.getFacilitiesApis(
        latitude: lat,
        longitude: long,
        sportIdList:sportIdList,
        amenitiesList:amenitiesList,
        sort: sort == "price1" ? "price" : sort,
        orderStatus:orderStatus,
        minRating:minRating,
        maxRating:maxRating,
        date: date,
        time: time,
        radius: radius,
      );

      if (response.status == true) {
        facilitiesData = List<FacilitiesModel>.from(
          response.body.map((x) => FacilitiesModel.fromJson(x)),
        );

        for (var facility in facilitiesData) {
          if (facility.latitude != null && facility.longitude != null) {
            facility.distanceInKm = calculateDistanceInKm(
              lat1: lat,
              lon1: long,
              lat2: facility.latitude!,
              lon2: facility.longitude!,
            );
          } else {
            facility.distanceInKm = double.infinity;
          }
        }

        // facilitiesData.sort(
        //       (a, b) => a.distanceInKm!.compareTo(b.distanceInKm!),
        // );

        searchFacilitiesData = List.from(facilitiesData);
        notifyListeners();
      } else {
        showSnackbar(
          context: NavigationService.context,
          message: response.message.toString(),
        );
      }
    } catch (e, stackTrace) {
      print("Error: $e");
      print("StackTrace: $stackTrace");

      showSnackbar(
        context: NavigationService.context,
        message: l10n.of(context).somethingWentWrongGetfacilitiesdata,
      );
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

//   Future<void> getFilteredFacilitiesData({
//    String ?date,
//    String ?time,
//    List<String> ?sportIdList,
//    List<String> ?amenitiesList,
//    String ?sort,
//    String ?orderStatus,
//    String ?minRating,
//    String ?maxRating,
//    String? radius,required BuildContext context
// })
//   async {
//   isLoading = true;
//   SharedPreferences prefs = await SharedPreferences.getInstance();
//   double lat = prefs.getDouble("current_lat") ?? 0.0;
//   double long = prefs.getDouble("current_long") ?? 0.0;
//
//   notifyListeners();
// print("sort $sort");
// print("orderstar $orderStatus");
//   try {
//     final response = await repository.getFacilitiesApis(
//       latitude: lat,
//       longitude: long,
//       sportIdList: sportIdList,
//       amenitiesList: amenitiesList,
//       sort:sort=="price1"? "price" : sort,
//      orderStatus: orderStatus,
//       minRating: minRating,
//       maxRating: maxRating,
//       date: date,
//       time: time,
//       radius: radius,
//     );
//
//     if (response.status == true) {
//       facilitiesData = List<FacilitiesModel>.from(
//         response.body.map((x) => FacilitiesModel.fromJson(x)),
//       );
//
//       for (var facility in facilitiesData) {
//         if (facility.latitude != null && facility.longitude != null) {
//           facility.distanceInKm = calculateDistanceInKm(
//             lat1: lat,
//             lon1: long,
//             lat2: facility.latitude!,
//             lon2: facility.longitude!,
//           );
//         } else {
//           facility.distanceInKm = double.infinity;
//         }
//       }
//
//       facilitiesData.sort((a, b) => a.distanceInKm!.compareTo(b.distanceInKm!));
//       searchFacilitiesData = List.from(facilitiesData);
//       notifyListeners();
//     } else {
//       showSnackbar(
//         context: NavigationService.context,
//         message: response.message.toString(),
//       );
//     }
//   } catch (e, stackTrace) {
//     print("Error: $e");
//     print("StackTrace: $stackTrace");
//     showSnackbar(
//       context: NavigationService.context,
//       message: S.of(context).somethingWentWrongGetfacilitiesdata,
//     );
//   } finally {
//     isLoading = false;
//     notifyListeners();
//   }
// }


  double calculateDistanceInKm({
    required double lat1,
    required double lon1,
    required double lat2,
    required double lon2,
  }) {
    const earthRadius = 6371.0; // Radius of Earth in kilometers

    final dLat = _degreesToRadians(lat2 - lat1);
    final dLon = _degreesToRadians(lon2 - lon1);

    final a = sin(dLat / 2) * sin(dLat / 2) +
        cos(_degreesToRadians(lat1)) *
            cos(_degreesToRadians(lat2)) *
            sin(dLon / 2) *
            sin(dLon / 2);

    final c = 2 * atan2(sqrt(a), sqrt(1 - a));

    return earthRadius * c;
  }

  double _degreesToRadians(double degrees) {
    return degrees * pi / 180;
  }

  // Future<void> getFacilitiesData(
  //     {
  //     //   List<String>? sportIdList,
  //     // List<String>? amenitiesList,
  //     // String? sort,
  //     // String? orderStatus,
  //     // String? minPrice,
  //     // String? maxPrice,
  //     // String? time,
  //     // String? radius,
  //     String? date,
  //     // double? latitude,
  //     // double? longitude
  //     }) async {
  //   isLoading = true;
  //         SharedPreferences prefs = await SharedPreferences.getInstance();
  //             var lat = await prefs.getDouble("current_lat");
  //             var long = await prefs.getDouble("current_long");

  //   notifyListeners();
  //   try {
  //     final response = await repository.getFacilitiesApis(
  //       // sportIdList: filterModel.selectedSportsList,
  //       // amenitiesList: filterModel.selectedAminitiesList,
  //       // sort: selectedSortsKey,
  //       // orderStatus: orderStatus,
  //       // minPrice: minPrice,
  //       // // maxPrice: maxPrice,
  //       // date: selectedDate,
  //       // time: selectTime,
  //       // radius: radius,
  //       latitude: (lat ?? 0.0).toDouble(),
  //       longitude: (long ?? 0.0).toDouble(),
  //     );
  //     if (response.status == true) {
  //       facilitiesData = List<FacilitiesModel>.from(
  //           response.body.map((x) => FacilitiesModel.fromJson(x))).toList();
  //       searchFacilitiesData = facilitiesData;
  //       notifyListeners();
  //     } else {
  //       showSnackbar(
  //           context: NavigationService.context,
  //           message: response.message.toString());
  //     }
  //   } catch (e, stackTrace) {
  //     print("Error : $e");
  //     print("stackTrace : $stackTrace");
  //     showSnackbar(
  //         context: NavigationService.context,
  //         message: "Somethings went Wrong(getFacilitiesData)");
  //   } finally {
  //     isLoading = false;
  //     notifyListeners();
  //   }
  // }

  void navigateToBookingScreen(BuildContext context) {
    Navigator.pushNamed(context, RouteNames.guestBooking);
  }

  Future<void> shareFacilityApi(BuildContext context) async {
    isShare = true;
    notifyListeners();
    final requestBody = {'facility_id': selectedFacility.id ?? ""};
    try {
      final response = await repository.getShareFacility(requestBody);
      if (response.status == true) {
        Provider.of<FeaturedFacilityViewModel>(context, listen: false)
            .shareFacility(context, response.body['data']['shareUrl']);
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e, stackTrace) {
      print("Error : $e");
      print("stackTrace : $stackTrace");
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context).somethingsWentWronggetfacilitiesdata);
    } finally {
      isShare = false;
      notifyListeners();
    }
  }

  bool isFacilityLoading = true;
  List<CreateFacilityData> createFacilitiesData = [];
  // List<CreateFacilityData> createSearchFacilitiesData = [];
  Future<void> getCreateChallengeFacilities({
    String? date,
    String? sportId,required BuildContext context
  }) async {
    isFacilityLoading = true;
    notifyListeners();
    String formattedDate = DateFormat("yyyy-MM-dd").format(
      date != null ? DateTime.parse(date) : DateTime.now(),
    );
    try {
      final requestBody = {
        "date": formattedDate,
        "sport_ids": sportId.toString().isNotEmpty ? [sportId] : [],
        "sortBy": "a-z"
      };

      print("requestBody : $requestBody");
      final response =
          await repository.getFacilitiesApisNew(request: requestBody);
      if (response.status == true) {
        CreateChallengeFacilityModel createChallengeFacilityModel =
            CreateChallengeFacilityModel.fromJson(response.body);

        createFacilitiesData = createChallengeFacilityModel.data ?? [];
        // createSearchFacilitiesData = createFacilitiesData;

        notifyListeners();
      } else {
        showSnackbar(
          context: NavigationService.context,
          message: response.message.toString(),
        );
      }
    } catch (e, stackTrace) {
      print("Error : $e");
      print("stackTrace : $stackTrace");
      showSnackbar(
        context: NavigationService.context,
        message:
            l10n.of(context).anErrorOccurredWhileFetchingChallengeFacilitiesPleaseTryAgain,
      );
    } finally {
      isFacilityLoading = false;
      notifyListeners();
    }
  }

  List<SportList> _selectedFacilityList = [];

  List<SportList> get selectedFacilityList => _selectedFacilityList;

  set selectedFacilityList(List<SportList> value) {
    _selectedFacilityList = value;
    notifyListeners(); // or notifyListeners() if using Provider/ChangeNotifier
  }
  //get slots
  // List<SportList> get selectedFacilityList =>facilityList.where((e) => e.isSelected).toList();
  List<AmenitiesList> get amenititesList => Helper.amenities.map((amenity) => AmenitiesList(id: amenity.id, name: amenity.name)).toList();


  String? selectedCourtSize;
  String? selectedAmenities;

  List<String> selectedAmenitie = [];

  List<String> get sportsList =>
      Helper.sports.map((sport) => sport.name).toList();
  List<SportList> get facilityList => Helper.sports;
  void selectFaciliity(SportList value, bool select) {
    for (var e in facilityList) {
      if (e.id == value.id) {
        e.isSelected = select;
        notifyListeners();
        break;
      }
    }
  }
  List<String> selectedSportsList = [];
  void clearSelectedSports() {
    selectedSportsList.clear();
    for (var sport in facilityList) {
      sport.isSelected = false;
    }
    notifyListeners(); // This will update the UI if it's listening
  }


  void setSportsIdsList(List<String> index) {
    selectedSportsList = index;
    notifyListeners();
  }


  RangeValues rangeValues = const RangeValues(0, 1000);

  void changeRangeValues(double st, double end) {
    rangeValues = RangeValues(st, end);
    notifyListeners();
  }

  // distance
  double startPoint = 0;
  double endPoint = 1000;

  // Directly store the RangeValues
  RangeValues rangeDistance = const RangeValues(0, 1000);

  void changeRangeDistance(double st, double end) {
    rangeDistance = RangeValues(st, end); // Corrected variable
    notifyListeners(); // Notify UI to update
  }

  // rate
  double startRate = 0;
  double endRate = 10;

  // Directly store the RangeValues
  RangeValues rangeRate = const RangeValues(0, 10);

  void changeRangeRate(double st1, double end1) {
    rangeRate = RangeValues(st1, end1); // Corrected variable
    notifyListeners();
  }


}
