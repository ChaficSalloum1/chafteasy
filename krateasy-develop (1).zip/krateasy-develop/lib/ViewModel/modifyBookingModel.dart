import 'dart:async';
import 'dart:convert';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:http/http.dart' as http;
import 'package:kratEasyApp/API_CALLS/GlobalAPIUtils.dart';
import 'package:kratEasyApp/Models/contact_model.dart';
import 'package:kratEasyApp/GlobalUtils/app_imports.dart';
import 'package:kratEasyApp/GlobalUtils/app_routes.dart';
import 'package:kratEasyApp/GlobalUtils/app_snackbbar.dart';
import 'package:kratEasyApp/Models/SlotsResponseModel.dart';
import 'package:kratEasyApp/Models/complete_Challenge_Detail_Model.dart';
import 'package:kratEasyApp/generated/l10n.dart';
import 'package:kratEasyApp/repository/booking_repository.dart';
import 'package:kratEasyApp/services/local/local_keys.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../Models/modifyBookingDetailModel.dart';
import '../repository/home_repository.dart';

class ModifybookingModel extends ChangeNotifier {
  bool isBookingDetailLoading = false;
  HomeRepository homeRepository = HomeRepository();
  ModifyBookingDetailResponse modifyBookingDetailResponse =
      ModifyBookingDetailResponse();
  Future<void> getModifyBookingDetails({
    required BuildContext context,
    required String bookingId,
  }) async {
    isBookingDetailLoading = true;
    try {
      final response =
          await homeRepository.getModifyBookingDetailsApi(bookingId);
      if (response.body["status"] == true) {
        modifyBookingDetailResponse =
            ModifyBookingDetailResponse.fromJson(response.body);

        // ✅ Set original slot count once after API call
        originalSlotCount =
            modifyBookingDetailResponse.data?.slotId?.length ?? 0;

        printLog("Original Slot Count: $originalSlotCount");
        printLog("new api Data > ${modifyBookingDetailResponse.data}");
      } else {
        showSnackbar(
            context: NavigationService.context,
            message: response.message.toString());
      }
    } catch (e, stackTrace) {
      print("stackTrace : $stackTrace");
      showSnackbar(
          context: NavigationService.context,
          message: l10n.of(context).somethingsWentWronggetbookingdetails);
    } finally {
      isBookingDetailLoading = false;
      notifyListeners();
    }
  }

  double bookingPrice = 0.0;
  bool isChecked = false;
  // double perPersonPrice = 0.0;
  String? bookingId;
  String? ID;
  var coourtId = NavigationService.navigatorKey.currentContext!
      .read<FacilitiesViewModel>()
      .selectedCourt
      .id;
  List<String> availableTimes = [];
  String requestDate = '';
  String courtName = '';
  String courtId = "";
  // String countryCode = '';

  String selectedCourtId = '';
  void storeCourtId({required String cortId}) {
    selectedCourtId = cortId;
    // notifyListeners();
  }

  updateLoadingStatus(
      {required BuildContext context, required String navigation}) {
    isLoading = true;
    notifyListeners();
    Future.delayed(Duration(seconds: 1), () {
      isLoading = false;
      notifyListeners();
      Navigator.pushNamed(context, navigation);
    });
  }

  int totalHours = 0;

  bool isRecorded = false;

  void setRecorded(bool value) {
    isRecorded = value;
    notifyListeners();
  }

  void setSplit(bool value) {
    print("before splite $value");
    if (!value) {
      // removeAllUserData();
    }

    print("after11 $value");

    notifyListeners();
  }

  String baseURL = GlobalAPIUtils.getBaseUrl();

  void navigateToChallengeSuccess(BuildContext context) {
    Navigator.pushNamed(context, '/successPayment');
  }

  void navigateToGuestPaymentScreen(
      {required BuildContext context,
      bool? fromGuest,
      String? amount,
      String? courtId,
      String? requestDate,
      List? availableTimes,
      List? selectedSlots,
      String? sportId}) {
    Navigator.pushNamed(context, RouteNames.guestPayment, arguments: {
      "fromGuest": fromGuest,
      "amount": amount ?? "0.0",
      "courtId": courtId,
      "requestDate": requestDate,
      "availableTimes": availableTimes,
      "selectedSlots": selectedSlots,
      "sportId": sportId,
    });
  }

  void navigateToGuestSuccessPaymentScreen(
      {required BuildContext context,
      required String id,
      required String bookingID,
      required bool isGuestBooking,
      required String amt}) {
    Navigator.pushNamed(
      context,
      "/guestSuccessPaymentScreen",
      arguments: {
        'bookingId': bookingID,
        "id": id,
        "isGuestBooking": isGuestBooking,
        "amount": amt
      },
    );
  }

  void navigateToGuestSharePaymentScreen(
      {required BuildContext context,
      required String amount,
      required bool isChallenge,
      CompleteChallengeDetailModel? joinChallengeModelData}) {
    Navigator.pushNamed(context, "/guestSharePaymentScreen", arguments: {
      "amount": amount,
      "data": joinChallengeModelData,
      "ischallenge": isChallenge
    });
  }

  void navigateToAddedFriendsScreen(BuildContext context) {
    Navigator.pushNamed(context, "/addedFriendsScreen");
  }

  /// guest success payment
  final String logoPath = 'assets/successImg/success.png';

  bool isWalletSelected = true;

  void setWalletSelected(bool value) {
    isWalletSelected = value;
    notifyListeners();
  }

  String? selectedPaymentMethod;

  void setSelectedPaymentMethod(String? method) {
    selectedPaymentMethod = method;
    notifyListeners();
  }

  // void updateSelectedSlot1(AvailableSlots slot, BuildContext context,int lenght) {
  //   // 1. figure out this slot’s index in the current list
  //   final idx = availableSlots.indexWhere((s) => s.sId == slot.sId);
  //   if (idx < 0) return;
  //
  //   // 2. turn selectedSlotIds into sorted indices
  //   List<int> selIdx = selectedSlotIds
  //       .map((id) => availableSlots.indexWhere((s) => s.sId == id))
  //       .where((i) => i >= 0)
  //       .toList()
  //     ..sort();
  //
  //   bool isSelected = selectedSlotIds.contains(slot.sId);
  //
  //   // helper to show exactly one snackbar
  //   void showMsg(String msg) {
  //     ScaffoldMessenger.of(context)
  //       ..hideCurrentSnackBar()
  //       ..showSnackBar(SnackBar(content: Text(msg)));
  //   }
  //
  //   if (isSelected) {
  //     // only allow deselect if it’s at the start or end
  //     int first = selIdx.first;
  //     int last = selIdx.last;
  //     if (idx == first || idx == last) {
  //       selectedSlotIds.remove(slot.sId);
  //     } else {
  //       showMsg(S.of(context).youCanOnlyDeselectTheStartOrEndSlot);
  //       return;
  //     }
  //   } else {
  //     // only allow select if empty or immediately adjacent
  //     if (selIdx.isEmpty || idx == selIdx.first - 1 || idx == selIdx.last + 1) {
  //       selectedSlotIds.add(slot.sId!);
  //     } else {
  //       showMsg(S.of(context).pleaseSelectSlotsInSequence);
  //       return;
  //     }
  //   }
  //   // 🔥 Update total slot price before calculating price per person
  //   slotPrice = selectedSlotIds
  //       .map((id) =>
  //           availableSlots
  //               .firstWhere(
  //                 (s) => s.sId == id,
  //                 orElse: () => AvailableSlots(price: 0.0), // ✅ Return dummy
  //               )
  //               .price ??
  //           0.0)
  //       .fold(0.0, (a, b) => a + b);
  //
  //   // calculatePrice();
  //   // calculateTotalPrice();
  //   calculateTotalHours();
  //   notifyListeners();
  // }
  void updateSelectedSlot1(AvailableSlots slot, BuildContext context, int lenght) {
    // Guard
    final id = slot.sId;
    if (id == null || id.isEmpty) return;

    // Helper: single snackbar
    void showMsg(String msg) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(msg)));
    }

    final isSelected = selectedSlotIds.contains(id);

    if (isSelected) {
      // Deselecting would reduce the count:
      // Block if it would go below the exact required count.
      if (selectedSlotIds.length <= lenght) {
        showMsg("You can select exactly $lenght slots.");
        return;
      }
      selectedSlotIds.remove(id);
    } else {
      // Selecting would increase the count:
      // Block if it would exceed the exact required count.
      if (selectedSlotIds.length >= lenght) {
        showMsg("You can select exactly $lenght slots.");
        return;
      }
      selectedSlotIds.add(id);
    }

    // ✅ Recalculate total slot price
    slotPrice = selectedSlotIds
        .map((sid) {
      final s = availableSlots.firstWhere(
            (x) => x.sId == sid,
        orElse: () => AvailableSlots(price: 0.0),
      );
      return s.price ?? 0.0;
    })
        .fold(0.0, (a, b) => a + b);

    // Update other derived values if needed
    calculateTotalHours();
    notifyListeners();
  }

  void calculateTotalPrice() {
    double tempPrice = 0.0;

    for (var slot in availableSlots) {
      if (selectedSlotIds.contains(slot.sId)) {
        tempPrice += (slot.price ?? 0);
      }
    }

    slotPrice = tempPrice;
    notifyListeners();
  }

  void calculateTotalHours() {
    totalHours = selectedSlotIds.length;
  }

  List<String> selectedSlotIds = [];
  List<AvailableSlots> availableSlots = [];

  SlotsResponseModel slotsResponseModel = SlotsResponseModel(); // your model
  bool isLoadingSlotsNew = false;
  bool isLoadingSlotsNewBooking = false;

  // Call when API data comes

  void setAvailableSlots1(
      {required List<AvailableSlots> slots, List<String>? preSelectedIds}) {
    availableSlots = slots;
    selectedSlotIds = preSelectedIds ?? [];

    calculateTotalPrice();
    calculateTotalHours();
    notifyListeners();
  }

  void clearSlots() {
    selectedSlotIds.clear();
    slotPrice = 0.0;
    notifyListeners();
  }

  int selectTimeGrid = 0;

  void selectedTimeGrid(int index) {
    selectTimeGrid = index;
    notifyListeners();
  }

  void updateCheckedButton() {
    isChecked = !isChecked;
    notifyListeners(); // Notify UI to rebuild
  }

  DateTime selectedDate = DateTime.now();

  bool isLoadingSlotsNew1 = false;
  Future<void> updateSelectedDate2(DateTime date) async {
    try {
      isLoadingSlotsNew1 = true;
      selectedSlotIds.clear(); // ✅ Clears previous selection
      selectedDate = date;
      notifyListeners();
    } catch (e) {
      print("errror");
    } finally {
      isLoadingSlotsNew1 = false;
      notifyListeners();
    }
  }

  List<String> selectedSlots = [];

  void clearSelectedSlots() {
    selectedTimeIndices.clear();
    selectedSlotStrings.clear();
    notifyListeners();
  }

  List<int> selectedTimeIndices = [];
  List<String> selectedSlotStrings = [];

  double myPrice = 0.0;
  double friendsPrice = 0.0;
  double slotPrice = 0.0;

  bool isLoading = false;

  void updateIsLoading(bool status) {
    isLoading = status;
    notifyListeners();
  }

  BookingRepository repository = BookingRepository();
  String? minHours;
  bool isLoadingSlots = false;

  AvailableSlots? selectedSlotForBooking;

  void updateSelectedSlot({required AvailableSlots? slot, required hours}) {
    selectedSlotForBooking = slot;
    minHours = hours.toString();
    printLog("Selected SLot  :${slot}");
    notifyListeners();
  }

  void updateSelectedID(String id) {
    if (selectedSlots.contains(id)) {
      selectedSlots.remove(id);
    } else {
      selectedSlots.add(id);
    }
    printLog("Selected Slots List: $selectedSlots");
    notifyListeners();
  }

  void clearSelectedSlot() {
    // userData.clear(); // Clear the user data
    selectedSlotIds.clear(); // Clear the selected slot
    selectedSlotForBooking = null; // Reset the selected slot for booking
    calculateTotalPrice(); // Recalculate the price (but no slot selected)
    calculateTotalHours(); // Recalculate hours (no slot selected)
    notifyListeners(); // Update the UI
  }

  Future<List<AvailableSlots>> getSlotsModified111({
    required String formatedDate,
    required String courtId,
    required String facilityId,
    required BuildContext context,
  }) async {
    isLoadingSlotsNew = true;
    notifyListeners();

    print("date neww .#$formatedDate");

    SharedPreferences prefs = await SharedPreferences.getInstance();
    var timeZone = prefs.getString("timeZone") ?? "Asia/Kolkata";

    try {
      Map<String, dynamic> map = {
        "date": formatedDate,
        "court_id": courtId,
        "facility_id": facilityId,
        "timeZone": timeZone,
      };

      // 🔹 Call getSlots API (second API)
      final response = await repository.getSlotsApi(map, returnData: true);

      if (response.status == true) {
        slotsResponseModel = SlotsResponseModel.fromJson(response.body);

        List<AvailableSlots> getSlotsList =
            slotsResponseModel.data?.availableSlots ?? [];
        selectedSlotIds.clear();
        // 🔹 Call modifyBookingModel slot_id (first API data already in model)
        final modifyModel = context.read<ModifybookingModel>();

        List<AvailableSlots> modifySlotList =
            modifyModel.modifyBookingDetailResponse.data?.slotId
                    ?.map<AvailableSlots>((slot) => AvailableSlots(
                          sId: slot.id,
                          startTime: slot.startTime,
                          endTime: slot.endTime,
                          startTime24: slot.startTime24,
                          endTime24: slot.endTime24,
                          day: slot.day,
                          price: slot.price,
                          courtId: slot.courtId,
                          isActive: slot.isActive,
                          isDelete: slot.isDelete,
                          // iV: slot.,
                          createdAt: slot.createdAt,
                          updatedAt: slot.updatedAt,
                        ))
                    .toList() ??
                [];

        // 🔸 Merge both lists
        List<AvailableSlots> mergedSlots = [
          ...modifySlotList,
          ...getSlotsList,
        ];

        // ⏱️ Select 1st slot for UI
        if (mergedSlots.isNotEmpty) {
          var courtData = response.body["data"]?["court"];
          int timeInMinutes = courtData?["minHours"] ?? 0;

          String formattedTime;
          if (timeInMinutes < 60) {
            formattedTime = "$timeInMinutes min";
          } else {
            int hours = timeInMinutes ~/ 60;
            int minutes = timeInMinutes % 60;
            formattedTime =
                minutes == 0 ? "${hours}hr" : "${hours}hr ${minutes}min";
          }

          updateSelectedSlot(
            slot: mergedSlots.first,
            hours: formattedTime,
          );
          printLog("Select 1st Syyy lot ${selectedSlotForBooking?.courtId}");
        }

        return mergedSlots;
      } else {
        showSnackbar(
          context: NavigationService.context,
          message: response.message.toString(),
        );
        return [];
      }
    } catch (e, stackTrace) {
      print("stackTrace : $stackTrace");
      showSnackbar(
        context: NavigationService.context,
        message: l10n.of(context).somethingWentWrongGetslots,
      );
      return [];
    } finally {
      isLoadingSlotsNew = false;
      notifyListeners();
    }
  }

  //get normal slots

  Future<List<AvailableSlots>> getSlotsNormal({
    required String formatedDate,
    required String courtId,
    required String facilityId,
    required BuildContext context,
  }) async {
    isLoadingSlotsNew = true;
    notifyListeners();
    print("date neww .#$formatedDate");
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var timeZone = await prefs.getString("timeZone") ?? "Asia/Kolkata";

    try {
      final response = await repository.getSlotsApi(
        {
          "date": formatedDate,
          "court_id": courtId,
          "facility_id": facilityId,
          "timeZone": timeZone
        },
        returnData: true,
      );

      if (response.status == true) {
        final slotsResponse = SlotsResponseModel.fromJson(response.body);
        availableSlots = slotsResponse.data?.availableSlots ?? [];

        selectedSlotIds.clear();
        notifyListeners();
        return availableSlots;
      } else {
        showSnackbar(context: context, message: response.message.toString());
        return [];
      }
    } catch (e) {
      showSnackbar(
          context: context,
          message: "Something went wrong while loading slots.");
      return [];
    } finally {
      isLoadingSlotsNew = false;
      notifyListeners();
    }
  }

  // API COMDITION

  // /app/Booking/update-booking/:id
  // SharedPreferences prefs = await SharedPreferences.getInstance();
  //
  // var timeZone =
  //     await prefs.getString("timeZone") ?? "Asia/Kolkata";

  int originalSlotCount = 0;
  bool isModifyBookingLoading = false;
  Future<void> getModifyBookingApi({
    required String formatedDate,
    required List<String> slotIds,
    required BuildContext context,
    required String id,
  }) async {
    isModifyBookingLoading = true;
    notifyListeners();

    SharedPreferences prefs = await SharedPreferences.getInstance();
    var timeZone = prefs.getString("timeZone") ?? "Asia/Kolkata";
    // "date", format YYYY-MM-DD
    // timeZone,
    // "",  (Edited)
    try {
      Map<String, dynamic> map = {
        "date": formatedDate,
        "slot_id": slotIds,
        "timeZone": timeZone,
      };
      print("map $map");
      // 🔹 Call getSlots API (second API)
      final response =
          await repository.modifyBookingApi(map, id, returnData: true);

      if (response.status == true) {
        print("appi successs");
        Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (_) => DashboardScreen(initialIndex: 0,)),
                (route) => false);

        showSnackbar(
          context: NavigationService.context,
          message: response.message.toString(),
        );

      } else {
        showSnackbar(
          context: NavigationService.context,
          message: response.message.toString(),
        );
      }
    } catch (e, stackTrace) {
      print("stackTrace : $stackTrace");
      showSnackbar(
        context: NavigationService.context,
        message: l10n.of(context).somethingWentWrongGetslots,
      );
    } finally {
      isModifyBookingLoading = false;
      notifyListeners();
    }
  }
}
