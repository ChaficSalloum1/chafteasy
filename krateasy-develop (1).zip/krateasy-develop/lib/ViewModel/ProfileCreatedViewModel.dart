import 'package:flutter/material.dart';

class ProfileCompletedViewModel extends ChangeNotifier {
  final String logoPath = 'assets/successImg/success.png'; // Change to your actual logo path
  // final String headText = ;
  // final String midText = ;
  // final String lowText = ;
  // final String lowText_2 = ;

  void profileCreated(BuildContext context) {
    Navigator.pushNamed(context, '/dashboard');
  }
}
