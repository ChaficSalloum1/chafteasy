import 'package:flutter/material.dart';

class SignupViewModel extends ChangeNotifier {
  final String logoPath = 'assets/logo.png'; // Change to your actual logo path
  final String headText = 'Sign up';
  final String midText = 'Sign up to get started. Fill your details';
  final String lowText = 'or register with a social account';


  TextEditingController phoneController = TextEditingController(text: '');

  // Default country code and flag
  String selectedCountryCode = '44'; // UK (+44)
  String selectedCountryFlag = '🇬🇧'; // Default flag for UK

  void setCountryCode(String newCode) {
    selectedCountryCode = newCode;
    notifyListeners();
  }

  void setCountryFlag(String newFlag) {
    selectedCountryFlag = newFlag;
    notifyListeners();
  }

  void onLogin() {
    // Handle login logic here
  }

  void onSignUp(BuildContext context) {
    Navigator.pushNamed(context, '/verification'); // Navigate to Verification Code Screen
  }

  void onSkip() {
    // Handle skipping logic here (Navigate to Home screen)
  }

  void onGoogleLogin() {
    // Handle login logic here
  }

  void onFacebookLogin() {
    // Navigate to sign-up screen
  }

  void onAppleLogin() {
    // Handle skipping logic here (Navigate to Home screen)
  }
}